package dev.coasterengineering.track;

import org.junit.jupiter.api.Test;

import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class VolcanicSpeedProfileTest {
    @Test
    void theFortyFivePositionsAndBanksMatchTheFrozenOnePointZeroGeometry() throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        assertEquals(45, track.points().size());
        for (ControlPoint point : track.points()) {
            digest.update(ByteBuffer.allocate(32).putDouble(point.position().x()).putDouble(point.position().y())
                    .putDouble(point.position().z()).putDouble(point.bankDegrees()).array());
        }
        // Extracted from the backed-up 1.0.0 source, before any quality changes.
        assertEquals("969b3f00d65a48a5661b3546cf91f631ceab5c80fd89308b65867816057409d8",
                HexFormat.of().formatHex(digest.digest()));
    }

    @Test
    void upgradingASavePreservesEveryCoordinateAndBankExactlyAndRequiresExplicitNewSettings() {
        SplineTrack legacy = legacyTrack(new TrackVec3(.5, 82, .5));
        assertNull(VolcanicCourseDesign.profileIfUpdated(legacy));
        SplineTrack updated = VolcanicCourseDesign.qualityUpdate(legacy);
        assertTrue(VolcanicCourseDesign.hasQualityProfile(updated));
        assertEquals(legacy.closed(), updated.closed());
        assertEquals(legacy.length(), updated.length());
        for (int i = 0; i < legacy.points().size(); i++) {
            assertEquals(legacy.points().get(i).position(), updated.points().get(i).position());
            assertEquals(legacy.points().get(i).bankDegrees(), updated.points().get(i).bankDegrees());
        }
        assertNull(VolcanicCourseDesign.profileIfUpdated(legacy), "Upgrading must not mutate a legacy course");
    }

    @Test
    void aLegacySaveRetainsTheOriginalLapDurationUntilOptingIntoQualityPhysics() {
        VolcanicCourseDesign.Metrics legacy = VolcanicCourseDesign.measure(legacyTrack(TrackVec3.ZERO));
        assertTrue(legacy.completed());
        assertEquals(3569, legacy.travelTicks());
        assertEquals(178.45, legacy.travelSeconds());
        assertEquals(120, legacy.maximumKmh(), 1e-9);
    }

    @Test
    void controlPointDistancesAreMonotonicAndRejectInvalidIndices() {
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        assertEquals(0, track.controlPointDistance(0));
        for (int i = 1; i < track.points().size(); i++) {
            assertTrue(track.controlPointDistance(i) > track.controlPointDistance(i - 1));
        }
        assertTrue(track.controlPointDistance(44) < track.length());
        assertThrows(IllegalArgumentException.class, () -> track.controlPointDistance(-1));
        assertThrows(IllegalArgumentException.class, () -> track.controlPointDistance(45));
    }

    @Test
    void metadataOrGeometryEditsInvalidateTheCachedProgram() {
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        assertSame(VolcanicCourseDesign.profile(track), VolcanicCourseDesign.profile(track));
        List<ControlPoint> changed = new ArrayList<>(track.points());
        ControlPoint point = changed.get(20);
        changed.set(20, new ControlPoint(point.position(), point.bankDegrees(), point.kind(), .41));
        SplineTrack savedTargets = new SplineTrack(changed, true);
        assertNull(VolcanicCourseDesign.profileIfUpdated(savedTargets));
        VolcanicCourseDesign.Profile updatedProfile = VolcanicCourseDesign.profileOfSavedTargets(savedTargets);
        assertNotNull(updatedProfile, "A world quality marker enables operator-edited section targets");
        assertSame(updatedProfile, VolcanicCourseDesign.profileOfSavedTargets(savedTargets));
        assertEquals(.41, updatedProfile.rawTargetSpeed(savedTargets.controlPointDistance(20)), 1e-12);
        assertEquals(.40, VolcanicCourseDesign.profile(track).rawTargetSpeed(track.controlPointDistance(20)), 1e-12);
        changed.set(20, new ControlPoint(point.position().add(new TrackVec3(0, .1, 0)),
                point.bankDegrees(), point.kind(), point.targetSpeed()));
        SplineTrack edited = new SplineTrack(changed, true);
        assertNull(VolcanicCourseDesign.profileIfUpdated(edited));
        assertNull(VolcanicCourseDesign.profileOfSavedTargets(edited));
        assertThrows(IllegalArgumentException.class, () -> VolcanicCourseDesign.qualityUpdate(edited));
        assertThrows(IllegalArgumentException.class, () -> VolcanicCourseDesign.qualityUpdate(new SplineTrack(track.points(), false)));
    }

    @Test
    void allInternalSpeedKnotsHaveContinuousTargetsAndZeroRawSlopeAtTheKnot() {
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        VolcanicCourseDesign.Profile profile = VolcanicCourseDesign.profile(track);
        for (int i = 1; i < track.points().size(); i++) {
            double distance = track.controlPointDistance(i), epsilon = 1e-4;
            double centre = profile.rawTargetSpeed(distance);
            assertEquals(track.points().get(i).targetSpeed(), centre, 1e-12);
            assertEquals(centre, profile.rawTargetSpeed(distance - epsilon), 2e-9);
            assertEquals(centre, profile.rawTargetSpeed(distance + epsilon), 2e-9);
            assertEquals(profile.targetSpeed(distance - epsilon), profile.targetSpeed(distance + epsilon), 1e-4);
            assertEquals(0, track.sample(distance).position().subtract(track.points().get(i).position()).length(), 1e-9);
        }
        assertEquals(VolcanicCourseDesign.STATION_ARRIVAL_SPEED, profile.targetSpeed(track.length()), 1e-12);
        assertThrows(IllegalArgumentException.class, () -> profile.targetSpeed(Double.NaN));
    }

    @Test
    void thePreviewEnvelopeNeverDemandsMoreThanItsBrakingAuthority() {
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        VolcanicCourseDesign.Profile profile = VolcanicCourseDesign.profile(track);
        int intervals = (int) Math.ceil(track.length() / .25);
        double interval = track.length() / intervals;
        boolean previewActuallyReducedSpeed = false;
        for (int i = 0; i < intervals; i++) {
            double distance = i * interval;
            double here = profile.targetSpeed(distance), next = profile.targetSpeed(distance + interval);
            assertTrue(here > 0 && here <= RideDynamics.MAX_SUPPORTED_SPEED);
            assertTrue(here * here <= next * next + 2 * profile.maximumBraking() * interval + 1e-10);
            assertTrue(here <= profile.rawTargetSpeed(distance) + 1e-10);
            previewActuallyReducedSpeed |= here < profile.rawTargetSpeed(distance) - .01;
        }
        assertTrue(previewActuallyReducedSpeed, "A rapid future slowdown must begin braking before its control point");
    }

    @Test
    void aCompleteLapRespectsComfortLimitsAndArrivesAtWalkingSpeed() {
        SplineTrack track = VolcanicCourseDesign.create(new TrackVec3(.5, 82, .5));
        VolcanicCourseDesign.Profile profile = VolcanicCourseDesign.profile(track);
        RideDynamics.Step step = new RideDynamics.Step(0, 0, false, true);
        for (int tick = 0; tick < 6000; tick++) {
            double speed = step.speed();
            step = RideDynamics.advanceProfiled(track, step.distance(), speed, true,
                    RideDynamics.MAX_SUPPORTED_SPEED, .025, profile);
            assertTrue(step.speed() - speed <= VolcanicCourseDesign.PROFILE_ACCELERATION + 1e-12);
            assertTrue(step.speed() - speed >= -VolcanicCourseDesign.PROFILE_BRAKING - 1e-12);
            assertTrue(step.speed() <= RideDynamics.MAX_SUPPORTED_SPEED);
            assertFalse(step.stopped(), "No early station stop or unpowered hill stall is allowed");
            if (step.crossedFinish()) break;
        }
        assertTrue(step.crossedFinish());
        assertTrue(step.speed() <= .026, "The entity's final seam parking must remove only creeping speed");
        RideDynamics.Step parked = RideDynamics.advanceProfiled(track, 0, 0, false,
                RideDynamics.MAX_SUPPORTED_SPEED, .025, profile);
        assertEquals(0, parked.distance());
        assertEquals(0, parked.speed());
        assertTrue(parked.stopped());
    }

    @Test
    void theActualMonsterLocationIsPassedDuringTheSlowShowScene() {
        SplineTrack track = VolcanicCourseDesign.create(new TrackVec3(.5, 82, .5));
        VolcanicCourseDesign.Profile profile = VolcanicCourseDesign.profile(track);
        TrackVec3 monster = new TrackVec3(-29, 83, 10);
        double minimum = Double.POSITIVE_INFINITY, closestDistance = 0;
        for (double distance = 0; distance < track.length(); distance += .25) {
            double separation = track.sample(distance).position().subtract(monster).length();
            if (separation < minimum) { minimum = separation; closestDistance = distance; }
        }
        assertEquals(VolcanicCourseDesign.Stage.MONSTER, profile.stage(closestDistance));
        assertTrue(profile.targetSpeed(closestDistance) <= .35);
        RideDynamics.Step step = new RideDynamics.Step(0, 0, false, true);
        for (int tick = 0; tick < 6000 && step.distance() < closestDistance; tick++) {
            step = RideDynamics.advanceProfiled(track, step.distance(), step.speed(), true,
                    RideDynamics.MAX_SUPPORTED_SPEED, .025, profile);
        }
        assertTrue(step.speed() <= .35, "Monster speed must be reached before the viewing point");
        System.out.printf("Monster closest pass: distance=%.2f blocks, separation=%.2f blocks, speed=%.2f km/h%n",
                closestDistance, minimum, step.speed() * 72);
    }

    @Test
    void theRideHasDistinctSlowExplorationMonsterAndHighSpeedClimaxBeats() {
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        VolcanicCourseDesign.Profile profile = VolcanicCourseDesign.profile(track);
        int count = VolcanicCourseDesign.Stage.values().length;
        int[] ticks = new int[count];
        double[] sums = new double[count], peaks = new double[count];
        RideDynamics.Step step = new RideDynamics.Step(0, 0, false, true);
        for (int tick = 0; tick < 6000; tick++) {
            int stage = profile.stage(step.distance()).ordinal();
            step = RideDynamics.advanceProfiled(track, step.distance(), step.speed(), true,
                    RideDynamics.MAX_SUPPORTED_SPEED, .025, profile);
            ticks[stage]++;
            sums[stage] += step.speed();
            peaks[stage] = Math.max(peaks[stage], step.speed());
            if (step.crossedFinish()) break;
        }
        assertTrue(step.crossedFinish());
        for (VolcanicCourseDesign.Stage stage : VolcanicCourseDesign.Stage.values()) {
            assertTrue(ticks[stage.ordinal()] > 0);
            System.out.printf("Speed stage %s: start=%.3f blocks, duration=%.2f s, average=%.2f km/h, peak=%.2f km/h%n",
                    stage, profile.stageStart(stage), ticks[stage.ordinal()] / 20.0,
                    sums[stage.ordinal()] / ticks[stage.ordinal()] * 72, peaks[stage.ordinal()] * 72);
        }
        assertTrue(peaks[VolcanicCourseDesign.Stage.EXPLORE.ordinal()] < .4);
        assertTrue(peaks[VolcanicCourseDesign.Stage.MONSTER.ordinal()] <= .43);
        assertEquals(RideDynamics.MAX_SUPPORTED_SPEED, peaks[VolcanicCourseDesign.Stage.CLIMAX.ordinal()], 1e-10);
        assertTrue(sums[VolcanicCourseDesign.Stage.CLIMAX.ordinal()] / ticks[VolcanicCourseDesign.Stage.CLIMAX.ordinal()]
                > 3 * sums[VolcanicCourseDesign.Stage.EXPLORE.ordinal()] / ticks[VolcanicCourseDesign.Stage.EXPLORE.ordinal()]);
    }

    @Test
    void corruptCustomProfilesCannotMoveAValidVehicle() {
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        for (double target : new double[] {Double.NaN, Double.POSITIVE_INFINITY, -.1}) {
            assertThrows(IllegalArgumentException.class, () -> RideDynamics.advanceProfiled(track, 0, 0, true,
                    RideDynamics.MAX_SUPPORTED_SPEED, .025, distance -> target));
        }
        assertThrows(NullPointerException.class, () -> RideDynamics.advanceProfiled(track, 0, 0, true,
                RideDynamics.MAX_SUPPORTED_SPEED, .025, null));
    }

    private static SplineTrack legacyTrack(TrackVec3 origin) {
        List<ControlPoint> points = new ArrayList<>(VolcanicCourseDesign.points(origin));
        for (int i = 0; i < points.size(); i++) {
            ControlPoint point = points.get(i);
            RailKind kind;
            double speed;
            if (i == 0) { kind = RailKind.STATION; speed = .32; }
            else if (i < 8) { kind = RailKind.LIFT; speed = .22; }
            else if (i < 11) { kind = RailKind.BOOST; speed = RideDynamics.MAX_SUPPORTED_SPEED; }
            else if (i == 11) { kind = RailKind.BRAKE; speed = .40; }
            else if (i < 22) { kind = RailKind.LIFT; speed = .30; }
            else if (i < 39) { kind = i == 27 || i == 36 ? RailKind.NORMAL : RailKind.LIFT; speed = .37; }
            else { kind = i == 40 || i == 41 ? RailKind.LIFT : RailKind.BRAKE; speed = .25; }
            points.set(i, new ControlPoint(point.position(), point.bankDegrees(), kind, speed));
        }
        return new SplineTrack(points, true);
    }
}
