package dev.coasterengineering.track;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RideDynamicsTest {
    @Test
    void gravityAcceleratesDownhillAndSlowsUphillWithFrictionOnFlatGround() {
        RideDynamics.Step downhill = ticks(line(-1000, RailKind.NORMAL, 1.2), 0.6, 20);
        RideDynamics.Step uphill = ticks(line(1000, RailKind.NORMAL, 1.2), 0.6, 20);
        RideDynamics.Step flat = ticks(line(0, RailKind.NORMAL, 1.2), 0.6, 20);
        assertTrue(downhill.speed() > 0.85);
        assertTrue(uphill.speed() < 0.35);
        assertTrue(flat.speed() < 0.6 && flat.speed() > uphill.speed());
        assertTrue(downhill.distance() > flat.distance());
        assertTrue(uphill.distance() < flat.distance());
    }

    @Test
    void aCoasterCanStartByGravityOnANormalDownhillRail() {
        RideDynamics.Step step = RideDynamics.advance(line(-100, RailKind.NORMAL, 1), 0, 0, true, 1.2);
        assertTrue(step.speed() > 0);
        assertTrue(step.distance() > 0);
        assertFalse(step.stopped());
    }

    @Test
    void liftMaintainsItsTargetDespiteAnUphillSlope() {
        RideDynamics.Step step = ticks(line(100, RailKind.LIFT, 0.4), 0, 40);
        assertEquals(0.4, step.speed(), 1e-12);
        assertTrue(step.distance() > 12);
    }

    @Test
    void runningStationDepartsAndSettlesAtItsConfiguredTarget() {
        SplineTrack track = line(0, RailKind.STATION, 0.32);
        RideDynamics.Step first = RideDynamics.advance(track, 0, 0, true, 1.2);
        assertEquals(0.025, first.speed(), 1e-12);
        assertEquals(0.0125, first.distance(), 1e-12);
        assertFalse(first.stopped());
        assertEquals(0.32, ticks(track, 0, 40).speed(), 1e-12);
    }

    @Test
    void boostHasBoundedAccelerationAndReachesAUsefulRunningSpeed() {
        SplineTrack track = line(0, RailKind.BOOST, 0.9);
        double distance = 0, speed = 0;
        for (int tick = 0; tick < 80; tick++) {
            RideDynamics.Step next = RideDynamics.advance(track, distance, speed, true, 1.2);
            assertTrue(next.speed() - speed <= 0.025 + 1e-12);
            distance = next.distance();
            speed = next.speed();
        }
        assertTrue(speed > 0.89 && speed <= 0.9);
    }

    @Test
    void reducedComfortAccelerationTakesLongerToReachSpeedAndTravelsLessInTheSameTime() {
        SplineTrack track = line(0, RailKind.BOOST, .9);
        int normalTime = ticksToSpeed(track, .8, .025);
        int comfortTime = ticksToSpeed(track, .8, .006);
        assertTrue(comfortTime > normalTime * 3,
                "A lower positive acceleration should materially delay the launch");
        RideDynamics.Step normal = ticksWithAcceleration(track, 0, 50, .025);
        RideDynamics.Step comfort = ticksWithAcceleration(track, 0, 50, .006);
        assertTrue(comfort.distance() < normal.distance() * .5);
        assertTrue(comfort.speed() < normal.speed());
        assertTrue(comfort.distance() > 0, "Comfort launch must still depart");
    }

    @Test
    void comfortSettingAlsoBoundsGravityDrivenDownhillAndPoweredLiftAcceleration() {
        for (RailKind kind : new RailKind[] {RailKind.NORMAL, RailKind.BOOST, RailKind.LIFT, RailKind.STATION}) {
            SplineTrack track = line(-1000, kind, 1.2);
            double distance = 0, speed = 0;
            for (int tick = 0; tick < 70; tick++) {
                RideDynamics.Step next = RideDynamics.advance(track, distance, speed, true, 1.6, .004);
                assertTrue(next.speed() - speed <= .004 + 1e-12, "Positive acceleration must obey comfort cap");
                assertTrue(next.speed() > speed);
                assertFalse(next.stopped());
                distance = next.distance();
                speed = next.speed();
            }
            assertEquals(.28, speed, 1e-12);
        }
    }

    @Test
    void comfortSettingPreservesBrakingAndTheExistingDefaultBehavior() {
        SplineTrack brake = line(-1000, RailKind.BRAKE, 0);
        RideDynamics.Step stopping = RideDynamics.advance(brake, 0, .5, true, 1.6, .001);
        assertEquals(.465, stopping.speed(), 1e-12);
        SplineTrack boost = line(0, RailKind.BOOST, .9);
        assertEquals(RideDynamics.advance(boost, 7, .5, true, 1.6),
                RideDynamics.advance(boost, 7, .5, true, 1.6, .025));
        assertEquals(RideDynamics.MAX_SUPPORTED_SPEED,
                RideDynamics.advance(line(-1000, RailKind.BOOST, 50), 0, 5, true, 50, .001).speed(), 1e-12);
    }

    @Test
    void invalidComfortAccelerationIsRejectedEvenWhenTheRideIsStopped() {
        SplineTrack track = line(0, RailKind.BOOST, .9);
        for (double invalid : new double[] {0, -0.001, .02500001, Double.NaN, Double.POSITIVE_INFINITY}) {
            assertThrows(IllegalArgumentException.class,
                    () -> RideDynamics.advance(track, 0, 0, false, 1.6, invalid));
        }
    }

    @Test
    void brakingControlsDownhillSpeedAndCanStopFully() {
        RideDynamics.Step capped = ticks(line(-100, RailKind.BRAKE, 0.3), 1, 40);
        assertEquals(0.3, capped.speed(), 1e-12);
        RideDynamics.Step stopped = ticks(line(-100, RailKind.BRAKE, 0), 1, 40);
        assertEquals(0, stopped.speed());
        assertTrue(stopped.stopped());
        assertTrue(stopped.distance() > 0);
    }

    @Test
    void emergencyStopDoesNotAdvanceTheRide() {
        SplineTrack track = SplineTrackTest.circle(20, RailKind.BOOST, 1.5);
        RideDynamics.Step step = RideDynamics.advance(track, 15.5, 1.5, false, 1.6);
        assertEquals(15.5, step.distance());
        assertEquals(0, step.speed());
        assertFalse(step.crossedFinish());
        assertTrue(step.stopped());
    }

    @Test
    void maxSpeedUsesTheConfiguredLimitAndNeverExceeds120Kmh() {
        SplineTrack track = line(-100, RailKind.BOOST, 50);
        assertEquals(0.7, RideDynamics.advance(track, 0, 5, true, 0.7).speed(), 1e-12);
        assertEquals(120, RideDynamics.MAX_SUPPORTED_SPEED * 72, 1e-12);
        assertEquals(RideDynamics.MAX_SUPPORTED_SPEED, RideDynamics.advance(track, 0, 5, true, 50).speed(), 1e-12);
    }

    @Test
    void anOpenEndpointStopsAtTheLastSupportedRailPosition() {
        SplineTrack track = line(0, RailKind.LIFT, 0.4);
        RideDynamics.Step end = RideDynamics.advance(track, track.length() - 0.1, 0.4, true, 1.2);
        assertEquals(track.length(), end.distance());
        assertEquals(0, end.speed());
        assertTrue(end.crossedFinish());
        assertTrue(end.stopped());
        RideDynamics.Step again = RideDynamics.advance(track, end.distance(), 0, true, 1.2);
        assertEquals(end.distance(), again.distance());
        assertTrue(again.stopped());
        assertFalse(again.crossedFinish());
    }

    @Test
    void aClosedSeamWrapsDistanceAndReportsALapOnce() {
        SplineTrack track = SplineTrackTest.circle(20, RailKind.LIFT, 0.4);
        RideDynamics.Step seam = RideDynamics.advance(track, track.length() - 0.1, 0.4, true, 1.2);
        assertEquals(0.3, seam.distance(), 1e-10);
        assertEquals(0.4, seam.speed());
        assertTrue(seam.crossedFinish());
        assertFalse(seam.stopped());
        assertFalse(RideDynamics.advance(track, seam.distance(), seam.speed(), true, 1.2).crossedFinish());
    }

    @Test
    void repeatedLapsKeepFinitePositionSpeedAndOrientation() {
        SplineTrack track = SplineTrackTest.circle(20, RailKind.LIFT, 0.45);
        double distance = 0, speed = 0;
        int laps = 0;
        for (int tick = 0; tick < 10_000; tick++) {
            RideDynamics.Step step = RideDynamics.advance(track, distance, speed, true, 1.2);
            assertTrue(Double.isFinite(step.distance()));
            assertTrue(Double.isFinite(step.speed()));
            assertTrue(step.distance() >= 0 && step.distance() < track.length());
            assertTrue(step.speed() >= 0 && step.speed() <= 1.2);
            TrackSample sample = track.sample(step.distance());
            assertEquals(1, sample.tangent().length(), 1e-12);
            if (step.crossedFinish()) laps++;
            distance = step.distance();
            speed = step.speed();
        }
        assertTrue(laps >= 35, "Repeated laps should complete, not stall");
    }

    @Test
    void thePhaseOneEngineeringLoopCompletesWithoutStalling() {
        // The actual DemoCourseBuilder fixture, in local coordinates. This checks
        // that its gravity, lift, boost and brake choices form a runnable circuit.
        SplineTrack track = new SplineTrack(List.of(
                point(2, 64, 12, 0, RailKind.STATION, .32),
                point(2, 64, 2, 0, RailKind.LIFT, .32),
                point(12, 68, -4, -10, RailKind.LIFT, .32),
                point(26, 72, 2, -15, RailKind.NORMAL, .65),
                point(32, 66, 16, -15, RailKind.BOOST, .65),
                point(26, 64, 30, -10, RailKind.NORMAL, .65),
                point(12, 64, 34, -10, RailKind.BRAKE, .25),
                point(2, 64, 26, 0, RailKind.BRAKE, .25)), true);
        RideDynamics.Step state = new RideDynamics.Step(0, 0, false, true);
        int tick;
        for (tick = 0; tick < 1200; tick++) {
            state = RideDynamics.advance(track, state.distance(), state.speed(), true, RideDynamics.MAX_SUPPORTED_SPEED);
            assertFalse(state.stopped(), "Demo should not stall before returning to its station");
            assertTrue(state.speed() <= RideDynamics.MAX_SUPPORTED_SPEED);
            if (state.crossedFinish()) break;
        }
        assertTrue(state.crossedFinish(), "Demo must complete a full lap within one minute");
        assertTrue(tick > 100, "A lap should use continuous distance ticks, not teleport to the finish");
        // Entity-level dispatch parks exactly at distance zero after this signal.
        assertTrue(state.distance() < .3);
    }

    @Test
    void zeroSpeedLimitIsAnImmediateSafeStop() {
        RideDynamics.Step step = RideDynamics.advance(line(0, RailKind.BOOST, 1), 7, 1, true, 0);
        assertEquals(7, step.distance());
        assertEquals(0, step.speed());
        assertTrue(step.stopped());
    }

    @Test
    void corruptedRideStateIsRejectedBeforeItCanMoveAnEntity() {
        SplineTrack track = line(0, RailKind.NORMAL, 1);
        assertThrows(IllegalArgumentException.class, () -> RideDynamics.advance(track, Double.NaN, 1, true, 1));
        assertThrows(IllegalArgumentException.class, () -> RideDynamics.advance(track, 0, Double.POSITIVE_INFINITY, true, 1));
        assertThrows(IllegalArgumentException.class, () -> RideDynamics.advance(track, 0, -1, true, 1));
        assertThrows(IllegalArgumentException.class, () -> RideDynamics.advance(track, 0, 1, true, Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> RideDynamics.advance(track, 0, 1, false, -1));
    }

    private static SplineTrack line(double rise, RailKind kind, double target) {
        return new SplineTrack(List.of(
                new ControlPoint(new TrackVec3(0, 64, 0), 0, kind, target),
                new ControlPoint(new TrackVec3(1000, 64 + rise, 0), 0, kind, target)), false);
    }

    private static ControlPoint point(double x, double y, double z, double bank, RailKind kind, double target) {
        return new ControlPoint(new TrackVec3(x, y, z), bank, kind, target);
    }

    private static RideDynamics.Step ticks(SplineTrack track, double initialSpeed, int count) {
        RideDynamics.Step state = new RideDynamics.Step(0, initialSpeed, false, initialSpeed == 0);
        for (int tick = 0; tick < count; tick++) {
            state = RideDynamics.advance(track, state.distance(), state.speed(), true, 1.6);
        }
        return state;
    }

    private static RideDynamics.Step ticksWithAcceleration(SplineTrack track, double initialSpeed,
                                                          int count, double acceleration) {
        RideDynamics.Step state = new RideDynamics.Step(0, initialSpeed, false, initialSpeed == 0);
        for (int tick = 0; tick < count; tick++) {
            state = RideDynamics.advance(track, state.distance(), state.speed(), true, 1.6, acceleration);
        }
        return state;
    }

    private static int ticksToSpeed(SplineTrack track, double target, double acceleration) {
        RideDynamics.Step state = new RideDynamics.Step(0, 0, false, true);
        for (int tick = 1; tick <= 500; tick++) {
            state = RideDynamics.advance(track, state.distance(), state.speed(), true, 1.6, acceleration);
            if (state.speed() >= target) return tick;
        }
        fail("Configured launch did not reach its test target");
        return -1;
    }
}
