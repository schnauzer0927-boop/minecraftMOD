package dev.coasterengineering.track;

import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class TrainSpacingTest {
    @Test
    void allFourCarsKeepTheirConfiguredArcDistanceBehindTheLeader() {
        SplineTrack track = SplineTrackTest.circle(20, RailKind.LIFT, .45);
        for (double leader = 0; leader < track.length(); leader += .37) {
            for (int index = 0; index < TrainSpacing.MAX_CARS; index++) {
                double follower = TrainSpacing.distance(track, leader, index, TrainSpacing.DEFAULT_SPACING);
                assertTrue(follower >= 0 && follower < track.length());
                assertEquals(index * TrainSpacing.DEFAULT_SPACING,
                        track.normalizeDistance(leader - follower), 1e-10);
            }
        }
    }

    @Test
    void followersWrapAcrossTheStationSeamWithoutFallingOffTheTrack() {
        SplineTrack track = SplineTrackTest.circle(20, RailKind.LIFT, .45);
        assertEquals(track.length() - 3, TrainSpacing.distance(track, 1, 1, 4), 1e-10);
        assertEquals(track.length() - 11, TrainSpacing.distance(track, 1, 3, 4), 1e-10);
        assertEquals(1, TrainSpacing.distance(track, track.length() + 1, 0, 4), 1e-10);
        assertEquals(track.length() - 5, TrainSpacing.distance(track, -1, 1, 4), 1e-10);
    }

    @Test
    void anOpenTrackClampsFollowersAtSupportedEndpoints() {
        SplineTrack track = openLine();
        assertEquals(0, TrainSpacing.distance(track, 2, 1, 4));
        assertEquals(0, TrainSpacing.distance(track, 2, 3, 4));
        assertEquals(96, TrainSpacing.distance(track, track.length(), 1, 4), 1e-10);
        assertEquals(88, TrainSpacing.distance(track, track.length(), 3, 4), 1e-10);
        assertEquals(96, TrainSpacing.distance(track, 150, 1, 4), 1e-10);
        assertEquals(0, TrainSpacing.distance(track, -100, 0, 4));
    }

    @Test
    void maximumSupportedTrainIsFourCarsWithAtLeastThreeAndAHalfBlockSpacing() {
        SplineTrack track = openLine();
        assertEquals(39.5, TrainSpacing.distance(track, 50, 3, 3.5), 1e-10);
        assertThrows(IllegalArgumentException.class, () -> TrainSpacing.distance(track, 50, 4, 4));
        assertThrows(IllegalArgumentException.class, () -> TrainSpacing.distance(track, 50, -1, 4));
        assertThrows(IllegalArgumentException.class, () -> TrainSpacing.distance(track, 50, 1, 3.49));
    }

    @Test
    void corruptedLeaderOrSpacingCannotProduceAnInvalidFollowerPosition() {
        SplineTrack track = openLine();
        assertThrows(IllegalArgumentException.class, () -> TrainSpacing.distance(track, Double.NaN, 1, 4));
        assertThrows(IllegalArgumentException.class, () -> TrainSpacing.distance(track, Double.POSITIVE_INFINITY, 1, 4));
        assertThrows(IllegalArgumentException.class, () -> TrainSpacing.distance(track, 50, 1, Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> TrainSpacing.distance(track, 50, 1, Double.POSITIVE_INFINITY));
        assertThrows(IllegalArgumentException.class, () -> TrainSpacing.distance(track, 50, 3, Double.MAX_VALUE));
    }

    @Test
    void allFollowersDeriveFromTheSameLeaderDuringSeveralCompleteLaps() {
        SplineTrack track = SplineTrackTest.circle(20, RailKind.LIFT, .45);
        RideDynamics.Step leader = new RideDynamics.Step(0, 0, false, true);
        int laps = 0;
        for (int tick = 0; tick < 2000; tick++) {
            leader = RideDynamics.advance(track, leader.distance(), leader.speed(), true, 1.2);
            if (leader.crossedFinish()) laps++;
            for (int index = 1; index < 4; index++) {
                double distance = TrainSpacing.distance(track, leader.distance(), index, 4);
                assertEquals(index * 4, track.normalizeDistance(leader.distance() - distance), 1e-10);
                assertEquals(1, TrackFrame.from(track.sample(distance)).forward().length(), 1e-12);
            }
        }
        assertTrue(laps >= 7);
    }

    private static SplineTrack openLine() {
        return new SplineTrack(List.of(SplineTrackTest.point(0, 64, 0), SplineTrackTest.point(100, 64, 0)), false);
    }
}
