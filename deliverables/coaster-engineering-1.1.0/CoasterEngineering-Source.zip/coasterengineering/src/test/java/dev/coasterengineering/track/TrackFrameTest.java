package dev.coasterengineering.track;

import org.junit.jupiter.api.Test;

import java.util.Random;

import static org.junit.jupiter.api.Assertions.*;

class TrackFrameTest {
    @Test
    void flatForwardFrameMatchesTheEntityAndRailCoordinateConvention() {
        TrackFrame frame = TrackFrame.from(sample(new TrackVec3(0, 0, 5), 0));
        assertVector(new TrackVec3(1, 0, 0), frame.right());
        assertVector(new TrackVec3(0, 1, 0), frame.up());
        assertVector(new TrackVec3(0, 0, 1), frame.forward());
    }

    @Test
    void positiveBankRaisesTheRightSideWhileLeavingForwardUnchanged() {
        TrackFrame frame = TrackFrame.from(sample(new TrackVec3(0, 0, 1), 30));
        assertEquals(Math.cos(Math.PI / 6), frame.right().x(), 1e-12);
        assertEquals(0.5, frame.right().y(), 1e-12);
        assertEquals(-0.5, frame.up().x(), 1e-12);
        assertEquals(Math.cos(Math.PI / 6), frame.up().y(), 1e-12);
        assertEquals(new TrackVec3(0, 0, 1), frame.forward());
        assertBasis(frame);
    }

    @Test
    void steepAndExactlyVerticalFramesHaveFiniteOrthogonalSeatAxes() {
        for (double y : new double[] {-1, 1}) {
            for (double horizontal : new double[] {0, 1e-15, 1e-9, 1e-6, 1e-4}) {
                for (double bank : new double[] {-179, -70, 0, 70, 179}) {
                    TrackFrame frame = TrackFrame.from(sample(new TrackVec3(horizontal, y, -horizontal), bank));
                    assertBasis(frame);
                    assertTrue(frame.forward().y() * y > 0.999);
                }
            }
        }
    }

    @Test
    void fixedVerticalFallbackIsDeterministicAndDoesNotDependOnTinyHeadingNoise() {
        TrackFrame base = TrackFrame.from(sample(new TrackVec3(0, 1, 0), 0));
        TrackFrame noisy = TrackFrame.from(sample(new TrackVec3(-1e-10, 1, 1e-10), 0));
        assertTrue(base.right().dot(noisy.right()) > 1 - 1e-12);
        assertTrue(base.up().dot(noisy.up()) > 1 - 1e-12);
    }

    @Test
    void deterministicRandomDirectionsAndBanksRemainRightHanded() {
        Random random = new Random(0xC0A57E2);
        for (int i = 0; i < 2000; i++) {
            TrackVec3 direction = new TrackVec3(random.nextDouble() * 2 - 1,
                    random.nextDouble() * 2 - 1, random.nextDouble() * 2 - 1);
            TrackFrame frame = TrackFrame.from(sample(direction, random.nextDouble() * 1440 - 720));
            assertBasis(frame);
            assertTrue(frame.forward().dot(direction.normalized()) > 1 - 1e-12);
        }
    }

    @Test
    void wrappedBanksProduceEquivalentFramesEvenForLargeFiniteInput() {
        TrackVec3 direction = new TrackVec3(1, .2, 3);
        TrackFrame base = TrackFrame.from(sample(direction, 30));
        TrackFrame wrapped = TrackFrame.from(sample(direction, 30 + 360 * 1000));
        assertTrue(base.right().dot(wrapped.right()) > 1 - 1e-12);
        assertTrue(base.up().dot(wrapped.up()) > 1 - 1e-12);
        assertBasis(TrackFrame.from(sample(direction, Double.MAX_VALUE)));
    }

    @Test
    void constructingAnInvalidOrLeftHandedBasisIsRejected() {
        TrackVec3 right = new TrackVec3(1, 0, 0), up = new TrackVec3(0, 1, 0), forward = new TrackVec3(0, 0, 1);
        assertThrows(IllegalArgumentException.class, () -> new TrackFrame(right.scale(2), up, forward));
        assertThrows(IllegalArgumentException.class, () -> new TrackFrame(right, right, forward));
        assertThrows(IllegalArgumentException.class, () -> new TrackFrame(right, up, forward.scale(-1)));
    }

    @Test
    void vectorCrossProductHasTheExpectedDirectionAndRejectsOverflow() {
        TrackVec3 x = new TrackVec3(1, 0, 0), y = new TrackVec3(0, 1, 0), z = new TrackVec3(0, 0, 1);
        assertEquals(z, x.cross(y));
        assertVector(z.scale(-1), y.cross(x));
        assertEquals(TrackVec3.ZERO, x.cross(x));
        assertThrows(IllegalArgumentException.class, () -> new TrackVec3(Double.MAX_VALUE, 0, 0)
                .cross(new TrackVec3(0, Double.MAX_VALUE, 0)));
    }

    private static TrackSample sample(TrackVec3 tangent, double bank) {
        return new TrackSample(TrackVec3.ZERO, tangent, bank, RailKind.NORMAL, .6);
    }

    private static void assertBasis(TrackFrame frame) {
        assertEquals(1, frame.right().length(), 1e-12);
        assertEquals(1, frame.up().length(), 1e-12);
        assertEquals(1, frame.forward().length(), 1e-12);
        assertEquals(0, frame.right().dot(frame.up()), 1e-12);
        assertEquals(0, frame.right().dot(frame.forward()), 1e-12);
        assertEquals(0, frame.up().dot(frame.forward()), 1e-12);
        assertEquals(1, frame.right().cross(frame.up()).dot(frame.forward()), 1e-12);
    }

    private static void assertVector(TrackVec3 expected, TrackVec3 actual) {
        assertEquals(0, expected.subtract(actual).length(), 1e-12);
    }
}
