package dev.coasterengineering.track;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SplineTrackTest {
    @Test
    void straightThreeDimensionalTrackUsesActualBlockDistance() {
        SplineTrack track = new SplineTrack(List.of(point(0, 0, 0), point(3, 4, 12)), false);
        assertEquals(13, track.length(), 1e-9);
        TrackSample middle = track.sample(6.5);
        assertPosition(new TrackVec3(1.5, 2, 6), middle.position(), 1e-9);
        assertPosition(new TrackVec3(3.0 / 13, 4.0 / 13, 12.0 / 13), middle.tangent(), 1e-9);
        assertEquals(1, middle.tangent().length(), 1e-12);
    }

    @Test
    void openTracksClampBeforeStartAndAfterEnd() {
        SplineTrack track = new SplineTrack(List.of(point(0, 64, 0),
                new ControlPoint(new TrackVec3(20, 64, 0), 20, RailKind.BRAKE, 0)), false);
        assertPosition(new TrackVec3(0, 64, 0), track.sample(-100).position(), 1e-9);
        TrackSample end = track.sample(100);
        assertPosition(new TrackVec3(20, 64, 0), end.position(), 1e-9);
        assertEquals(RailKind.BRAKE, end.kind());
        assertEquals(0, end.targetSpeed());
    }

    @Test
    void closedTrackWrapsPositiveAndNegativeDistancesWithoutASeamJump() {
        SplineTrack track = circle(10, RailKind.NORMAL, 0.8);
        assertPosition(track.sample(3).position(), track.sample(3 + 8 * track.length()).position(), 1e-10);
        assertPosition(track.sample(track.length() - 2).position(), track.sample(-2).position(), 1e-10);
        assertPosition(track.sample(0).position(), track.sample(track.length()).position(), 1e-12);
        TrackSample before = track.sample(track.length() - 1e-5);
        TrackSample after = track.sample(1e-5);
        assertTrue(before.position().subtract(after.position()).length() < 2.01e-5);
        assertTrue(before.tangent().dot(after.tangent()) > 0.999999);
    }

    @Test
    void catmullRomPassesThroughEveryControlPointAndCurvesBetweenThem() {
        SplineTrack track = circle(10, RailKind.NORMAL, 0.8);
        double chordPerimeter = 8 * 2 * 10 * Math.sin(Math.PI / 8);
        assertTrue(track.length() > chordPerimeter);
        assertTrue(track.length() < 2 * Math.PI * 10);
        for (int i = 0; i < 8; i++) {
            assertPosition(track.points().get(i).position(), track.sample(track.length() * i / 8).position(), 1e-9);
        }
        TrackVec3 middle = track.sample(track.length() / 16).position();
        assertTrue(Math.hypot(middle.x(), middle.z()) > 9.8, "Spline should not be a polygon chord");
    }

    @Test
    void arcLengthSamplesHaveNearlyUniformSpacingOnACurvedTrack() {
        SplineTrack track = circle(30, RailKind.NORMAL, 0.8);
        for (double distance = 0; distance < track.length(); distance += 0.5) {
            double chord = track.sample(distance + 0.5).position().subtract(track.sample(distance).position()).length();
            assertEquals(0.5, chord, 0.0002);
        }
    }

    @Test
    void bankingTakesTheShortPathAcrossTheAngularSeam() {
        SplineTrack track = new SplineTrack(List.of(
                new ControlPoint(new TrackVec3(0, 0, 0), 170, RailKind.STATION, 0.32),
                new ControlPoint(new TrackVec3(20, 0, 0), -170, RailKind.BOOST, 1)), false);
        assertEquals(175, track.sample(5).bankDegrees(), 1e-9);
        assertEquals(180, Math.abs(track.sample(10).bankDegrees()), 1e-9);
        assertEquals(-175, track.sample(15).bankDegrees(), 1e-9);
        assertEquals(RailKind.STATION, track.sample(19).kind());
        assertEquals(0.32, track.sample(19).targetSpeed());
    }

    @Test
    void steepThreeDimensionalDropProducesAFiniteForwardTangent() {
        SplineTrack track = new SplineTrack(List.of(point(0, 100, 0), point(30, 40, 10),
                point(80, 30, 30), point(100, 35, 60)), false);
        boolean foundDrop = false;
        for (double distance = 0; distance <= track.length(); distance += 0.25) {
            TrackSample sample = track.sample(distance);
            assertEquals(1, sample.tangent().length(), 1e-12);
            assertTrue(sample.tangent().x() > 0);
            foundDrop |= sample.tangent().y() < -0.8;
        }
        assertTrue(foundDrop);
    }

    @Test
    void aTrackOwnsAnImmutableSnapshotOfItsPoints() {
        List<ControlPoint> source = new ArrayList<>(List.of(point(0, 0, 0), point(20, 0, 0)));
        SplineTrack track = new SplineTrack(source, false);
        source.set(1, point(500, 0, 0));
        assertEquals(20, track.length(), 1e-9);
        assertThrows(UnsupportedOperationException.class, () -> track.points().clear());
    }

    @Test
    void degenerateAndCuspTracksAreRejectedInsteadOfProducingNaNs() {
        assertThrows(IllegalArgumentException.class, () -> new SplineTrack(List.of(point(0, 0, 0)), false));
        assertThrows(IllegalArgumentException.class, () -> new SplineTrack(List.of(point(0, 0, 0), point(0, 0, 0)), false));
        assertThrows(IllegalArgumentException.class, () -> new SplineTrack(List.of(point(0, 0, 0), point(1, 0, 0), point(0, 0, 0)), false));
        assertThrows(IllegalArgumentException.class, () -> new SplineTrack(List.of(point(0, 0, 0), point(1, 0, 0), point(1, 0, 1)), true));
        assertThrows(IllegalArgumentException.class, () -> new SplineTrack(List.of(
                point(0, 0, 0), point(10, 0, 0), point(10, 0, 10), point(0, 0, 0)), true));
    }

    @Test
    void corruptNumericValuesCannotReachTheSpline() {
        assertThrows(IllegalArgumentException.class, () -> new TrackVec3(Double.NaN, 0, 0));
        assertThrows(IllegalArgumentException.class, () -> new TrackVec3(0, Double.POSITIVE_INFINITY, 0));
        assertThrows(IllegalArgumentException.class, () -> new ControlPoint(TrackVec3.ZERO, Double.NaN, RailKind.NORMAL, 0));
        assertThrows(IllegalArgumentException.class, () -> new ControlPoint(TrackVec3.ZERO, 0, RailKind.NORMAL, -1));
        assertThrows(IllegalArgumentException.class, () -> new ControlPoint(TrackVec3.ZERO, 0, RailKind.NORMAL, Double.POSITIVE_INFINITY));
        SplineTrack track = circle(10, RailKind.NORMAL, 0.8);
        assertThrows(IllegalArgumentException.class, () -> track.sample(Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> track.sample(Double.POSITIVE_INFINITY));
        assertThrows(IllegalArgumentException.class, () -> new SplineTrack(List.of(
                point(1e308, 0, 0), point(-1e308, 0, 0)), false));
    }

    @Test
    void vectorOperationsKeepFiniteValuesAndZeroNormalizationIsSafe() {
        TrackVec3 value = new TrackVec3(3, 4, 0);
        assertEquals(5, value.length());
        assertEquals(25, value.dot(value));
        assertPosition(new TrackVec3(6, 8, 0), value.add(value), 0);
        assertEquals(TrackVec3.ZERO, value.subtract(value));
        assertEquals(TrackVec3.ZERO, TrackVec3.ZERO.normalized());
        assertEquals(1, value.normalized().length(), 1e-12);
        assertThrows(IllegalArgumentException.class, () -> value.scale(Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> new TrackVec3(Double.MAX_VALUE, 0, 0).scale(2));
    }

    static ControlPoint point(double x, double y, double z) {
        return new ControlPoint(new TrackVec3(x, y, z), 0, RailKind.NORMAL, 0.8);
    }

    static SplineTrack circle(double radius, RailKind kind, double target) {
        List<ControlPoint> points = new ArrayList<>();
        for (int i = 0; i < 8; i++) {
            double angle = i * Math.PI / 4;
            points.add(new ControlPoint(new TrackVec3(radius * Math.cos(angle), 64, radius * Math.sin(angle)),
                    0, kind, target));
        }
        return new SplineTrack(points, true);
    }

    private static void assertPosition(TrackVec3 expected, TrackVec3 actual, double tolerance) {
        assertEquals(expected.x(), actual.x(), tolerance);
        assertEquals(expected.y(), actual.y(), tolerance);
        assertEquals(expected.z(), actual.z(), tolerance);
    }
}
