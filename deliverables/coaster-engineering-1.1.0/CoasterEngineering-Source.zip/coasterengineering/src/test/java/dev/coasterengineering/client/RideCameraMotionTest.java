package dev.coasterengineering.client;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class RideCameraMotionTest {
    @Test
    void ordinaryExplorationSpeedsDoNotAddCameraMotion() {
        RideCameraMotion motion = new RideCameraMotion();
        for (int tick = 0; tick < 100; tick++) motion.tick(60.0 / 72, true, .25, 3);
        assertEquals(new RideCameraMotion.Sample(0, 0, 1), motion.sample(.5, 25));
    }

    @Test
    void highSpeedMotionNeverExceedsComfortLimitsAtAnyRenderTime() {
        RideCameraMotion motion = new RideCameraMotion();
        for (int tick = 0; tick < 200; tick++) motion.tick(120.0 / 72, true, .25, 3);
        boolean vibrationObserved = false;
        for (int frame = 0; frame < 4000; frame++) {
            RideCameraMotion.Sample sample = motion.sample((frame % 60) / 60.0, frame / 3.0);
            assertTrue(Math.abs(sample.rollDegrees()) <= .25);
            assertTrue(Math.abs(sample.pitchDegrees()) <= .25);
            assertTrue(sample.fovScale() >= 1 && sample.fovScale() <= 1.03);
            vibrationObserved |= Math.abs(sample.rollDegrees()) > .1;
        }
        assertTrue(vibrationObserved, "The high-speed option must produce a small real effect");
        assertEquals(1.03, motion.sample(1, 100).fovScale(), 1e-8);
    }

    @Test
    void accelerationAndSlowingBlendStrengthAcrossTicksAndFrames() {
        RideCameraMotion motion = new RideCameraMotion();
        motion.tick(120.0 / 72, true, .18, 2);
        assertEquals(1, motion.sample(0, 0).fovScale());
        double firstTick = motion.sample(1, 0).fovScale();
        assertTrue(firstTick > 1 && firstTick < 1.02);
        assertEquals((1 + firstTick) / 2, motion.sample(.5, 0).fovScale(), 1e-12);
        for (int tick = 0; tick < 20; tick++) motion.tick(120.0 / 72, true, .18, 2);
        double high = motion.sample(1, 0).fovScale();
        motion.tick(50.0 / 72, true, .18, 2);
        double slowing = motion.sample(1, 0).fovScale();
        assertTrue(slowing < high && slowing > 1, "Slowing should ease out the previous visual strength");
    }

    @Test
    void stopDismountAndZeroSettingsRemovePreviousInterpolationImmediately() {
        RideCameraMotion motion = highSpeedMotion();
        motion.tick(0, false, .18, 2);
        assertEquals(new RideCameraMotion.Sample(0, 0, 1), motion.sample(.5, 100));
        motion = highSpeedMotion();
        motion.tick(120.0 / 72, true, 0, 0);
        assertEquals(new RideCameraMotion.Sample(0, 0, 1), motion.sample(0, 100));
        motion = highSpeedMotion();
        motion.reset();
        assertEquals(new RideCameraMotion.Sample(0, 0, 1), motion.sample(1, 100));
    }

    @Test
    void corruptInputsCannotCreateNonfiniteOrExcessiveCameraMotion() {
        RideCameraMotion motion = new RideCameraMotion();
        for (int tick = 0; tick < 100; tick++) motion.tick(1e300, true, 1000, 1000);
        RideCameraMotion.Sample sample = motion.sample(Double.NaN, Double.NaN);
        assertTrue(Double.isFinite(sample.fovScale()) && sample.fovScale() <= 1.03);
        assertTrue(Math.abs(sample.pitchDegrees()) <= .25);
        motion.tick(Double.NaN, true, .18, 2);
        assertEquals(new RideCameraMotion.Sample(0, 0, 1), motion.sample(.5, 0));
        motion.tick(120.0 / 72, true, Double.NaN, Double.POSITIVE_INFINITY);
        assertEquals(new RideCameraMotion.Sample(0, 0, 1), motion.sample(.5, 0));
    }

    @Test
    void eachSettingCanBeDisabledAndReducedIndependently() {
        RideCameraMotion motion = highSpeedMotion();
        motion.tick(120.0 / 72, true, 0, 1);
        RideCameraMotion.Sample sample = motion.sample(.5, 6);
        assertEquals(0, sample.rollDegrees());
        assertEquals(0, sample.pitchDegrees());
        assertTrue(sample.fovScale() > 1 && sample.fovScale() <= 1.01);
        motion = highSpeedMotion();
        motion.tick(120.0 / 72, true, .05, 0);
        sample = motion.sample(0, 6);
        assertEquals(1, sample.fovScale());
        assertTrue(Math.abs(sample.rollDegrees()) > 0 && Math.abs(sample.rollDegrees()) <= .05);
        assertTrue(Math.abs(sample.pitchDegrees()) <= .05);
    }

    private static RideCameraMotion highSpeedMotion() {
        RideCameraMotion motion = new RideCameraMotion();
        for (int tick = 0; tick < 30; tick++) motion.tick(120.0 / 72, true, .18, 2);
        return motion;
    }
}
