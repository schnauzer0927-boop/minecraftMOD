package dev.coasterengineering.track;

import org.junit.jupiter.api.Test;

import java.util.EnumSet;

import static org.junit.jupiter.api.Assertions.*;

class VolcanicCourseDesignTest {
    @Test
    void theDesignedAttractionCompletesOneLapWithMeasuredTargets() {
        VolcanicCourseDesign.Metrics metrics = VolcanicCourseDesign.measure(VolcanicCourseDesign.create(TrackVec3.ZERO));
        System.out.printf("Volcanic route: length=%.3f blocks, height range=%.3f blocks, travel=%d ticks (%.2f s), "
                        + "including 7 s design dwell=%.2f s, peak=%.3f km/h, completed=%s%n",
                metrics.length(), metrics.elevationRange(), metrics.travelTicks(), metrics.travelSeconds(),
                metrics.experienceSeconds(), metrics.maximumKmh(), metrics.completed());
        assertTrue(metrics.completed(), "The completed route must run without stalling");
        assertTrue(metrics.length() >= 1150 && metrics.length() <= 1250);
        assertEquals(70, metrics.elevationRange(), .05);
        assertTrue(metrics.experienceSeconds() >= 125 && metrics.experienceSeconds() <= 155);
        assertEquals(120, metrics.maximumKmh(), 1e-9);
    }

    @Test
    void allFourParkedCarsAreOnTheStraightStationApproach() {
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        TrackVec3 station = track.sample(0).position();
        for (int index = 0; index < 4; index++) {
            TrackSample sample = track.sample(TrainSpacing.distance(track, 0, index, 4));
            assertEquals(station.x(), sample.position().x(), 1e-9);
            assertEquals(station.y(), sample.position().y(), 1e-9);
            assertEquals(station.z() - index * 4, sample.position().z(), .0005);
            assertEquals(1, sample.tangent().z(), 1e-12);
            assertEquals(0, sample.bankDegrees(), 1e-9);
            assertEquals(index == 0 ? RailKind.STATION : RailKind.BRAKE, sample.kind());
        }
    }

    @Test
    void translationPreservesTheSameCourseGeometryAndRunningBehavior() {
        TrackVec3 origin = new TrackVec3(125, 80, -212);
        SplineTrack original = VolcanicCourseDesign.create(TrackVec3.ZERO);
        SplineTrack translated = VolcanicCourseDesign.create(origin);
        assertEquals(original.length(), translated.length(), 1e-8);
        for (double distance = 0; distance < original.length(); distance += 3) {
            TrackSample a = original.sample(distance), b = translated.sample(distance);
            assertEquals(0, a.position().add(origin).subtract(b.position()).length(), 1e-8);
            assertEquals(1, a.tangent().dot(b.tangent()), 1e-12);
            assertEquals(a.kind(), b.kind());
            assertEquals(a.bankDegrees(), b.bankDegrees(), 1e-8);
        }
    }

    @Test
    void sampledRouteStaysInsideTheVolcanoFootprintWithoutVerticalInversions() {
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        for (double distance = 0; distance < track.length(); distance += .5) {
            TrackSample sample = track.sample(distance);
            assertTrue(Math.abs(sample.position().x()) <= 180);
            assertTrue(Math.abs(sample.position().z()) <= 180);
            assertTrue(Math.abs(sample.bankDegrees()) <= 45);
            assertTrue(Math.abs(sample.tangent().y()) < .9, "Vertical inversions are deferred");
            assertEquals(1, TrackFrame.from(sample).forward().length(), 1e-12);
        }
        EnumSet<RailKind> kinds = EnumSet.noneOf(RailKind.class);
        for (ControlPoint point : track.points()) kinds.add(point.kind());
        assertTrue(kinds.containsAll(EnumSet.of(RailKind.STATION, RailKind.LIFT, RailKind.BOOST, RailKind.BRAKE)));
    }

    @Test
    void nonAdjacentRouteSectionsHaveSampledGeometricClearance() {
        // This catches a route crossing itself. It does not inspect terrain,
        // blocks, rider hitboxes, or prove clearance between sampling positions.
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        int count = (int) Math.ceil(track.length() / 2);
        double interval = track.length() / count;
        TrackVec3[] positions = new TrackVec3[count];
        for (int i = 0; i < count; i++) positions[i] = track.sample(i * interval).position();
        double minimumSquared = Double.POSITIVE_INFINITY;
        for (int i = 0; i < count; i++) {
            for (int j = i + 1; j < count; j++) {
                double arcSeparation = (j - i) * interval;
                if (Math.min(arcSeparation, track.length() - arcSeparation) <= 16) continue;
                double dx = positions[i].x() - positions[j].x();
                double dy = positions[i].y() - positions[j].y();
                double dz = positions[i].z() - positions[j].z();
                minimumSquared = Math.min(minimumSquared, dx * dx + dy * dy + dz * dz);
            }
        }
        System.out.printf("Volcanic route sampled nonadjacent clearance: %.3f blocks%n", Math.sqrt(minimumSquared));
        assertTrue(minimumSquared > 4 * 4, "Distant rail sections must not intersect in the route geometry");
    }

    @Test
    void theRouteAlsoCompletesWithReducedComfortAcceleration() {
        SplineTrack track = VolcanicCourseDesign.create(TrackVec3.ZERO);
        for (double acceleration : new double[] {.006, .01}) {
            RideDynamics.Step state = new RideDynamics.Step(0, 0, false, true);
            for (int tick = 0; tick < 6000; tick++) {
                state = RideDynamics.advanceProfiled(track, state.distance(), state.speed(), true,
                        RideDynamics.MAX_SUPPORTED_SPEED, acceleration, VolcanicCourseDesign.profile(track));
                assertFalse(state.stopped(), "A gentler launch must not stall before the station");
                assertTrue(state.speed() <= RideDynamics.MAX_SUPPORTED_SPEED);
                if (state.crossedFinish()) break;
            }
            assertTrue(state.crossedFinish());
        }
    }
}
