package dev.coasterengineering.world;

import dev.coasterengineering.track.SplineTrack;
import net.minecraft.core.BlockPos;
import java.util.Objects;
import java.util.UUID;

/** Immutable authoritative course. station is a safe passenger landing position. */
public record Course(UUID id, String name, SplineTrack track, BlockPos station, boolean enabled) {
    public Course {
        Objects.requireNonNull(id, "id");
        Objects.requireNonNull(name, "name");
        Objects.requireNonNull(track, "track");
        station = Objects.requireNonNull(station, "station").immutable();
        if (name.isBlank() || name.length() > 64) throw new IllegalArgumentException("Course names must be 1..64 characters");
        if (track.points().size() > 128) throw new IllegalArgumentException("At most 128 control points");
        if (track.length() > 16_000) throw new IllegalArgumentException("Course length limit is 16000 blocks");
        for (int i = 1; i < track.points().size(); i++) {
            if (track.points().get(i).position().subtract(track.points().get(i-1).position()).length() > 512)
                throw new IllegalArgumentException("Adjacent control points must be within 512 blocks");
        }
        if (track.closed() && track.points().get(0).position().subtract(track.points().get(track.points().size()-1).position()).length() > 512)
            throw new IllegalArgumentException("Closing control points must be within 512 blocks");
        for (var p : track.points()) {
            if (Math.abs(p.position().x()) > 29_999_000 || Math.abs(p.position().z()) > 29_999_000 ||
                    p.position().y() < -2048 || p.position().y() > 2048)
                throw new IllegalArgumentException("Control point outside world coordinate limits");
        }
    }
}
