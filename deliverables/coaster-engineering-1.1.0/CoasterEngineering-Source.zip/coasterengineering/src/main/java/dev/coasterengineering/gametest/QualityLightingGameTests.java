package dev.coasterengineering.gametest;

import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.QualityLightingPlan;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/** Real light propagation and occupied movement are checked against unchanged geometry. */
@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class QualityLightingGameTests {
    private QualityLightingGameTests() { }

    @GameTest(template = "empty", timeoutTicks = 600)
    public static void actualRouteLightingImprovesBothSeatsWithoutChangingTrainThenPassengerCompletesLap(GameTestHelper helper) {
        ServerCourseFixture fixture = ServerCourseFixture.create(helper);
        UUID vehicleId = fixture.vehicle().getUUID();
        Vec3 parked = fixture.vehicle().position();
        int beforeMinimum = minimumBlockLight(helper, fixture);
        helper.assertTrue(beforeMinimum < 6,
                "The unlit roofed fixture must have a real dark seat position before any lighting update");
        Map<BlockPos, BlockState> plan = QualityLightingPlan.rideLighting(fixture.course().track());
        helper.assertTrue(!plan.isEmpty(), "A real route must receive actual lighting placements");
        Map<BlockPos, BlockState> previous = new LinkedHashMap<>();
        for (var entry : plan.entrySet()) {
            helper.assertTrue(helper.getLevel().hasChunkAt(entry.getKey()),
                    "The lighting test must never force-load an unavailable planned chunk");
            previous.put(entry.getKey(), helper.getLevel().getBlockState(entry.getKey()));
            helper.getLevel().setBlock(entry.getKey(), entry.getValue(), 3);
        }
        Player[] rider = {null};
        helper.startSequence()
                .thenIdle(40)
                .thenExecute(() -> {
                    int afterMinimum = minimumBlockLight(helper, fixture);
                    helper.assertTrue(afterMinimum >= 6 && afterMinimum > beforeMinimum,
                            "Settled BLOCK light must reach both upright seat eyes around the complete covered route; min=" + afterMinimum);
                    for (double d = 0; d < fixture.course().track().length(); d += .25)
                        helper.assertTrue(fixture.vehicle().canUseTrackSample(fixture.course().track().sample(d)),
                                "Actual lamps and guide blocks must preserve the entire original rider/body envelope at " + d);
                    assertUnchanged(helper, fixture, vehicleId, parked);
                    CoasterSavedData restored = CoasterSavedData.load(CoasterSavedData.get(helper.getLevel()).save(new CompoundTag()));
                    helper.assertTrue(restored.getCourse(fixture.course().id()).track().points().equals(fixture.course().track().points())
                                    && vehicleId.equals(restored.vehicleId(fixture.course().id())),
                            "A decoration-only update must preserve actual saved geometry and reserved train UUID");
                    rider[0] = fixture.rider(helper);
                    helper.assertTrue(fixture.vehicle().startRide(), "The same occupied car must dispatch through the lit course");
                })
                .thenExecuteAfter(20, () -> helper.assertTrue(fixture.vehicle().isRunning()
                                && fixture.vehicle().getDistance() > 1 && rider[0].getVehicle() == fixture.vehicle(),
                        "Lighting safety must be exercised by meaningful actual motion with a seated passenger"))
                .thenWaitUntil(() -> helper.assertTrue(fixture.vehicle().getLaps() == 1,
                        "The actual passenger train must complete the full original course"))
                .thenExecute(() -> {
                    helper.assertTrue(!fixture.vehicle().isRunning() && fixture.vehicle().getSpeed() == 0
                                    && fixture.vehicle().getDistance() == 0 && rider[0].getVehicle() == fixture.vehicle(),
                            "The illuminated real ride must finish at the same station without dismounting or falling");
                    assertUnchanged(helper, fixture, vehicleId, parked);
                    rider[0].stopRiding();
                    fixture.cleanup(helper);
                    previous.forEach((pos, state) -> helper.getLevel().setBlock(pos, state, 3));
                })
                .thenSucceed();
    }

    private static int minimumBlockLight(GameTestHelper helper, ServerCourseFixture fixture) {
        int minimum = 15;
        for (double d = 0; d < fixture.course().track().length(); d += 2) {
            TrackSample sample = fixture.course().track().sample(d);
            TrackFrame frame = TrackFrame.from(sample);
            for (double seat : new double[] {-.45, .45}) {
                TrackVec3 eye = sample.position().add(frame.right().scale(seat)).add(frame.up().scale(.45))
                        .add(new TrackVec3(0, 1.62, 0));
                BlockPos pos = BlockPos.containing(eye.x(), eye.y(), eye.z());
                helper.assertTrue(helper.getLevel().hasChunkAt(pos), "All actual seat-eye probes must be in loaded fixture chunks");
                minimum = Math.min(minimum, helper.getLevel().getBrightness(LightLayer.BLOCK, pos));
            }
        }
        return minimum;
    }

    private static void assertUnchanged(GameTestHelper helper, ServerCourseFixture fixture, UUID vehicleId, Vec3 parked) {
        helper.assertTrue(fixture.vehicle().getUUID().equals(vehicleId) && fixture.vehicle().position().distanceTo(parked) < 1e-6,
                "Lighting must preserve the original car UUID and exact parked coordinates");
        helper.assertTrue(CoasterSavedData.get(helper.getLevel()).getCourse(fixture.course().id()) == fixture.course(),
                "Lighting must retain the exact authoritative course and all its original coordinates/banks");
    }
}
