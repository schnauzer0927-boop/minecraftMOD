package dev.coasterengineering.network;

import dev.coasterengineering.menu.StationMenu;
import dev.coasterengineering.station.StationControllerBlockEntity;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

/** All authorization and binding checks are repeated on the server. */
public record StationActionPacket(BlockPos position, UUID courseId, int action, int value) {
    public static void encode(StationActionPacket packet, FriendlyByteBuf buffer) {
        buffer.writeBlockPos(packet.position);
        buffer.writeUUID(packet.courseId);
        buffer.writeByte(packet.action);
        buffer.writeVarInt(packet.value);
    }

    public static StationActionPacket decode(FriendlyByteBuf buffer) {
        return new StationActionPacket(buffer.readBlockPos(), buffer.readUUID(), buffer.readUnsignedByte(), buffer.readVarInt());
    }

    public static void handle(StationActionPacket packet, Supplier<NetworkEvent.Context> contextSupplier) {
        NetworkEvent.Context context = contextSupplier.get();
        ServerPlayer player = context.getSender();
        if (player != null) apply(player, packet);
        context.setPacketHandled(true);
    }

    public static boolean apply(ServerPlayer player, StationActionPacket packet) {
        if (!(player.containerMenu instanceof StationMenu menu) || !menu.stillValid(player)
                || !menu.controllerPos().equals(packet.position) || !menu.courseId().equals(packet.courseId)
                || !player.serverLevel().hasChunkAt(packet.position)) return false;
        StationControllerBlockEntity station = menu.controller();
        if (station == null || !packet.courseId.equals(station.courseId()) || packet.action < 0 || packet.action > 5) return false;
        if (packet.action <= 1 ? !menu.mayOperate() : !menu.mayManage()) return false;
        boolean result = switch (packet.action) {
            case 0 -> station.dispatch();
            case 1 -> { station.stopEmergency(); yield true; }
            case 2 -> station.returnToStation();
            case 3 -> {
                if (packet.value != 0 && packet.value != 1) yield false;
                station.setAutoDeparture(packet.value == 1);
                yield true;
            }
            case 4 -> {
                if (packet.value < 140 || packet.value > 1200) yield false;
                station.setDwellTicks(packet.value);
                yield true;
            }
            case 5 -> { station.clearEmergency(); yield true; }
            default -> false;
        };
        if (!result) player.displayClientMessage(Component.translatable("station.coasterengineering.rejected"), false);
        return result;
    }
}
