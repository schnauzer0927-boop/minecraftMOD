package dev.coasterengineering.world;

import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Explicit world opt-in: old saves keep their original ride program until a successful upgrade. */
public final class WorldQualityUpgradeData extends SavedData {
    public static final int CURRENT_VERSION = 1;
    public static final String FILE_NAME = "coasterengineering_world_quality";
    private int qualityVersion;
    private String report = "No quality upgrade has completed";

    public static WorldQualityUpgradeData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(WorldQualityUpgradeData::load,
                WorldQualityUpgradeData::new, FILE_NAME);
    }

    public int version() { return qualityVersion; }
    public boolean isApplied() { return qualityVersion >= CURRENT_VERSION; }
    public boolean isApplied(UUID courseId) {
        return VolcanicWorldBuilder.COURSE_ID.equals(courseId) && isApplied();
    }
    public String report() { return report; }

    void completed(String audit) {
        qualityVersion = CURRENT_VERSION;
        report = audit;
        setDirty();
    }

    private static WorldQualityUpgradeData load(CompoundTag tag) {
        WorldQualityUpgradeData data = new WorldQualityUpgradeData();
        data.qualityVersion = Math.max(0, tag.getInt("qualityVersion"));
        if (tag.contains("report")) data.report = tag.getString("report");
        return data;
    }

    @Override public CompoundTag save(CompoundTag tag) {
        tag.putInt("qualityVersion", qualityVersion);
        tag.putString("report", report);
        return tag;
    }
}
