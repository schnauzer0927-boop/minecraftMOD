package dev.coasterengineering.client;

import dev.coasterengineering.menu.StationMenu;
import dev.coasterengineering.network.CoasterNetwork;
import dev.coasterengineering.network.StationActionPacket;
import java.util.Locale;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;

/** Live station instruments; every control is independently checked by the server. */
public final class StationScreen extends AbstractContainerScreen<StationMenu> {
    private Button dispatch;
    private Button emergency;
    private Button returnStation;
    private Button resetAlarm;
    private Button autoDeparture;
    private Button dwell7;
    private Button dwell20;
    private Button dwell60;

    public StationScreen(StationMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        imageWidth = 304;
        imageHeight = 224;
    }

    @Override
    protected void init() {
        super.init();
        dispatch = control("dispatch", 14, 106, 136, 0, 0);
        emergency = control("emergency", 154, 106, 136, 1, 0);
        returnStation = control("return", 14, 130, 136, 2, 0);
        resetAlarm = control("reset", 154, 130, 136, 5, 0);
        autoDeparture = addRenderableWidget(Button.builder(autoLabel(),
                button -> send(3, menu.autoDeparture() ? 0 : 1))
                .bounds(leftPos + 14, topPos + 154, 276, 20).build());
        dwell7 = control("dwell7", 14, 178, 89, 4, 140);
        dwell20 = control("dwell20", 108, 178, 89, 4, 400);
        dwell60 = control("dwell60", 202, 178, 88, 4, 1200);
        updateControls();
    }

    private Button control(String key, int x, int y, int width, int action, int value) {
        return addRenderableWidget(Button.builder(Component.translatable("screen.coasterengineering." + key),
                        button -> send(action, value))
                .bounds(leftPos + x, topPos + y, width, 20).build());
    }

    private void send(int action, int value) {
        if (menu.courseId() != null) CoasterNetwork.CHANNEL.sendToServer(
                new StationActionPacket(menu.controllerPos(), menu.courseId(), action, value));
    }

    @Override
    protected void containerTick() {
        super.containerTick();
        updateControls();
    }

    private void updateControls() {
        boolean operate = menu.mayOperate();
        boolean manage = menu.mayManage();
        dispatch.active = operate && !menu.running() && !menu.emergencyLatched();
        emergency.active = operate;
        returnStation.active = manage;
        resetAlarm.active = manage && menu.emergencyLatched();
        autoDeparture.active = manage;
        autoDeparture.setMessage(autoLabel());
        dwell7.active = manage;
        dwell20.active = manage;
        dwell60.active = manage;
    }

    private Component autoLabel() {
        return Component.translatable("screen.coasterengineering.auto_button",
                Component.translatable(menu.autoDeparture() ? "screen.coasterengineering.on" : "screen.coasterengineering.off"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        renderBackground(graphics);
        super.render(graphics, mouseX, mouseY, partialTick);
        renderTooltip(graphics, mouseX, mouseY);
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.fill(leftPos - 1, topPos - 1, leftPos + imageWidth + 1, topPos + imageHeight + 1, 0xFF54707C);
        graphics.fillGradient(leftPos, topPos, leftPos + imageWidth, topPos + imageHeight, 0xFF15232E, 0xFF090F17);
        graphics.fill(leftPos, topPos, leftPos + imageWidth, topPos + 28, 0xFF253744);
        graphics.fill(leftPos + 14, topPos + 93, leftPos + 290, topPos + 94,
                menu.emergencyLatched() ? 0xFFFF6442 : 0xFF52CBDC);
    }

    @Override
    protected void renderLabels(GuiGraphics graphics, int mouseX, int mouseY) {
        graphics.drawString(font, Component.translatable("screen.coasterengineering.station"), 14, 10, 0xBEEAF4, false);
        text(graphics, "state", Component.translatable(menu.running()
                ? "hud.coasterengineering.running" : "hud.coasterengineering.stopped"), 14, 36);
        text(graphics, "speed", String.format(Locale.ROOT, "%.1f", menu.speedKmh()), 154, 36);
        text(graphics, "laps", menu.laps(), 14, 52);
        text(graphics, "train", menu.carCount(), menu.riderCount(), 154, 52);
        text(graphics, "auto", Component.translatable(menu.autoDeparture()
                ? "screen.coasterengineering.on" : "screen.coasterengineering.off"), 14, 68);
        text(graphics, "countdown", String.format(Locale.ROOT, "%.1f", Math.max(0, menu.countdownTicks()) / 20.0), 154, 68);
        Component alarm = Component.translatable(menu.emergencyLatched()
                ? "screen.coasterengineering.alarm_active" : "screen.coasterengineering.alarm_clear");
        graphics.drawString(font, alarm, 14, 83, menu.emergencyLatched() ? 0xFF765C : 0x78DEC6, false);
        Component access = Component.translatable(menu.mayManage() ? "screen.coasterengineering.access_manager"
                : menu.mayOperate() ? "screen.coasterengineering.access_rider" : "screen.coasterengineering.access_viewer");
        graphics.drawString(font, access, 14, 207, 0xA6B4BE, false);
    }

    private void text(GuiGraphics graphics, String key, Object value, int x, int y) {
        graphics.drawString(font, Component.translatable("screen.coasterengineering." + key, value), x, y, 0xE3EBF0, false);
    }

    private void text(GuiGraphics graphics, String key, Object first, Object second, int x, int y) {
        graphics.drawString(font, Component.translatable("screen.coasterengineering." + key, first, second), x, y, 0xE3EBF0, false);
    }
}
