package dev.coasterengineering.world;

import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackVec3;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Dimension-local data; Minecraft persists it in data/coasterengineering_courses.dat. */
public final class CoasterSavedData extends SavedData {
    public static final int MAX_COURSES = 64;
    private final Map<UUID, Course> courses = new LinkedHashMap<>();
    private final Map<UUID, UUID> vehicles = new LinkedHashMap<>();
    private final Map<UUID, BlockPos> controllers = new LinkedHashMap<>();
    private final Set<UUID> emergencyCourses = new HashSet<>();

    public static CoasterSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(CoasterSavedData::load, CoasterSavedData::new, "coasterengineering_courses");
    }

    public Course getCourse(UUID id) { return id == null ? null : courses.get(id); }
    public Collection<Course> courses() { return List.copyOf(courses.values()); }
    public UUID vehicleId(UUID courseId) { return vehicles.get(courseId); }
    public BlockPos controllerPos(UUID courseId) { return controllers.get(courseId); }
    public boolean isEmergency(UUID courseId) { return emergencyCourses.contains(courseId); }
    public void setEmergency(UUID courseId, boolean enabled) {
        if (!courses.containsKey(courseId)) return;
        boolean changed = enabled ? emergencyCourses.add(courseId) : emergencyCourses.remove(courseId);
        if (changed) setDirty();
    }

    public boolean claimController(UUID courseId, BlockPos position) {
        if (!courses.containsKey(courseId)) return false;
        BlockPos existing = controllers.get(courseId);
        if (existing != null) return existing.equals(position);
        controllers.put(courseId, position.immutable());
        setDirty();
        return true;
    }

    public void releaseController(UUID courseId, BlockPos position) {
        if (position.equals(controllers.get(courseId))) {
            controllers.remove(courseId);
            setDirty();
        }
    }

    public boolean claimVehicle(UUID courseId, UUID vehicleId) {
        if (!courses.containsKey(courseId)) return false;
        UUID existing = vehicles.get(courseId);
        if (existing != null) return existing.equals(vehicleId);
        vehicles.put(courseId, vehicleId);
        setDirty();
        return true;
    }

    public void releaseVehicle(UUID courseId, UUID vehicleId) {
        if (vehicleId.equals(vehicles.get(courseId))) {
            vehicles.remove(courseId);
            setDirty();
        }
    }

    public void putCourse(Course course) {
        if (!courses.containsKey(course.id()) && courses.size() >= MAX_COURSES)
            throw new IllegalArgumentException("At most 64 courses per dimension");
        courses.put(course.id(), course);
        setDirty();
    }

    public void removeCourse(UUID id) {
        if (courses.remove(id) != null) {
            vehicles.remove(id);
            controllers.remove(id);
            emergencyCourses.remove(id);
            setDirty();
        }
    }

    public static CoasterSavedData load(CompoundTag root) {
        CoasterSavedData data = new CoasterSavedData();
        ListTag list = root.getList("Courses", Tag.TAG_COMPOUND);
        for (int i = 0; i < Math.min(list.size(), MAX_COURSES); i++) {
            CompoundTag c = list.getCompound(i);
            try {
                ListTag nodes = c.getList("Points", Tag.TAG_COMPOUND);
                if (nodes.size() > 128) throw new IllegalArgumentException("Too many nodes");
                ArrayList<ControlPoint> points = new ArrayList<>();
                for (int j = 0; j < nodes.size(); j++) {
                    CompoundTag p = nodes.getCompound(j);
                    points.add(new ControlPoint(new TrackVec3(p.getDouble("X"), p.getDouble("Y"), p.getDouble("Z")),
                            p.getDouble("Bank"), RailKind.valueOf(p.getString("Kind")), p.getDouble("TargetSpeed")));
                }
                Course course = new Course(c.getUUID("Id"), c.getString("Name"), new SplineTrack(points, c.getBoolean("Closed")),
                        BlockPos.of(c.getLong("Station")), c.getBoolean("Enabled"));
                data.courses.put(course.id(), course);
                if (c.hasUUID("Vehicle")) data.vehicles.put(course.id(), c.getUUID("Vehicle"));
                if (c.contains("Controller", Tag.TAG_LONG)) data.controllers.put(course.id(), BlockPos.of(c.getLong("Controller")));
                if (c.getBoolean("Emergency")) data.emergencyCourses.add(course.id());
            } catch (RuntimeException e) {
                CoasterEngineering.LOGGER.warn("Ignoring invalid saved coaster course entry {}: {}", i, e.getMessage());
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag root) {
        root.putInt("FormatVersion", 1);
        ListTag list = new ListTag();
        for (Course course : courses.values()) {
            CompoundTag c = new CompoundTag();
            c.putUUID("Id", course.id());
            c.putString("Name", course.name());
            c.putBoolean("Closed", course.track().closed());
            c.putLong("Station", course.station().asLong());
            c.putBoolean("Enabled", course.enabled());
            c.putBoolean("Emergency", emergencyCourses.contains(course.id()));
            UUID vehicleId = vehicles.get(course.id());
            if (vehicleId != null) c.putUUID("Vehicle", vehicleId);
            BlockPos controller = controllers.get(course.id());
            if (controller != null) c.putLong("Controller", controller.asLong());
            ListTag points = new ListTag();
            for (ControlPoint p : course.track().points()) {
                CompoundTag n = new CompoundTag();
                n.putDouble("X", p.position().x());
                n.putDouble("Y", p.position().y());
                n.putDouble("Z", p.position().z());
                n.putDouble("Bank", p.bankDegrees());
                n.putString("Kind", p.kind().name());
                n.putDouble("TargetSpeed", p.targetSpeed());
                points.add(n);
            }
            c.put("Points", points);
            list.add(c);
        }
        root.put("Courses", list);
        return root;
    }
}
