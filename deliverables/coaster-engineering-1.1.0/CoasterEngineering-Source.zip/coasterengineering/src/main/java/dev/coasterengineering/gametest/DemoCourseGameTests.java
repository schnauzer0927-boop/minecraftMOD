package dev.coasterengineering.gametest;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import dev.coasterengineering.world.DemoCourseBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/** Builder regression: decorations and supports must preserve the real rider's swept clearance. */
@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class DemoCourseGameTests {
    private DemoCourseGameTests() { }

    @GameTest(template = "demo_empty", timeoutTicks = 1220)
    public static void actualDemoBuilderCompletesFullLapWithMountedPlayer(GameTestHelper helper) {
        // The 48x32x48 template explicitly supplies air and loads the complete
        // documented builder footprint. Never unload chunks or clear outside it.
        BlockPos origin = helper.absolutePos(new BlockPos(6, 8, 8));
        Course course = DemoCourseBuilder.build(helper.getLevel(), origin);
        Entity registered = helper.getLevel().getEntity(CoasterSavedData.get(helper.getLevel()).vehicleId(course.id()));
        helper.assertTrue(registered instanceof CoasterEntity, "The actual demo builder must insert a real registered coaster");
        CoasterEntity vehicle = (CoasterEntity) registered;
        Player rider = helper.makeMockSurvivalPlayer();
        rider.moveTo(vehicle.position().add(0, 0, 1));
        helper.assertTrue(vehicle.interact(rider, InteractionHand.MAIN_HAND).consumesAction() && rider.getVehicle() == vehicle,
                "The generated demo must accept an actual mounted player before dispatch");
        helper.assertTrue(vehicle.startRide(), "The built and occupied demo must dispatch through its station geometry");
        boolean[] finished = {false};
        double[] farthestDistance = {0};
        for (int tick = 1; tick <= 1200; tick++) {
            int elapsed = tick;
            // Register all checks before ticking; callbacks do not mutate the
            // GameTestInfo scheduled-action map while it is being iterated.
            helper.runAfterDelay(tick, () -> {
                if (finished[0]) return;
                farthestDistance[0] = Math.max(farthestDistance[0], vehicle.getDistance());
                helper.assertTrue(rider.getVehicle() == vehicle && vehicle.hasPassenger(rider),
                        "The player must stay aboard the real generated course throughout the ride");
                helper.assertTrue(rider.isAlive(), "Generated architecture and supports must not harm the rider");
                helper.assertTrue(Double.isFinite(vehicle.getDistance()) && Double.isFinite(vehicle.getSpeed()),
                        "The generated demo must maintain finite continuous ride state");
                TrackVec3 onTrack = course.track().sample(vehicle.getDistance()).position();
                helper.assertTrue(vehicle.position().distanceTo(new Vec3(onTrack.x(), onTrack.y(), onTrack.z())) < .05,
                        "The generated demo must follow its own saved 3D path");
                helper.assertTrue(rider.position().distanceTo(vehicle.position()) < 2,
                        "The mounted player's real seat position must remain within the generated vehicle");
                if (vehicle.getLaps() == 0) {
                    helper.assertTrue(vehicle.isRunning(), "Built track or decorations stopped the occupied demo prematurely at distance="
                            + vehicle.getDistance() + ", speed=" + vehicle.getSpeed() + ", tick=" + elapsed);
                } else {
                    helper.assertTrue(vehicle.getLaps() == 1 && !vehicle.isRunning(),
                            "The actual generated demo must complete exactly one lap and stop");
                    helper.assertTrue(farthestDistance[0] > course.track().length() * .9,
                            "Full-course test must actually traverse the far end of the loop");
                    helper.assertTrue(Math.abs(vehicle.getDistance()) < .001 && Math.abs(vehicle.getSpeed()) < .001,
                            "The generated demo must return to the station boarding point at zero speed");
                    finished[0] = true;
                    rider.stopRiding();
                    helper.assertTrue(rider.getVehicle() == null && helper.getLevel().noCollision(rider, rider.getBoundingBox()),
                            "After the full lap the real rider must dismount onto unobstructed station space");
                    vehicle.discard();
                    CoasterSavedData.get(helper.getLevel()).removeCourse(course.id());
                    clearGeneratedBlocks(helper);
                    helper.succeed();
                }
                if (!finished[0] && elapsed == 1200)
                    helper.assertTrue(false, "The actual occupied generated demo must finish its loop within1200ticks");
            });
        }
    }

    private static void clearGeneratedBlocks(GameTestHelper helper) {
        // All these cells were explicit air in this isolated GameTest template.
        // Its stone floor and the structure controller lie below this interval.
        BlockPos first = helper.absolutePos(new BlockPos(0, 2, 0));
        BlockPos last = helper.absolutePos(new BlockPos(47, 31, 47));
        for (BlockPos position : BlockPos.betweenClosed(first, last)) {
            if (!helper.getLevel().getBlockState(position).isAir())
                helper.getLevel().setBlock(position, Blocks.AIR.defaultBlockState(), 3);
        }
    }
}
