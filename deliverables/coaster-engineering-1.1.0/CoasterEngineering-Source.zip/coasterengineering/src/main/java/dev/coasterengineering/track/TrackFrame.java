package dev.coasterengineering.track;

import java.util.Objects;

/**
 * A right-handed orthonormal seat/rail basis: right cross up equals forward.
 * Positive bank raises the right side. The near-vertical fallback is finite and
 * deterministic, but is not a transported frame for inversion/loop transitions.
 */
public record TrackFrame(TrackVec3 right, TrackVec3 up, TrackVec3 forward) {
    private static final double NEAR_VERTICAL = 1e-6;
    private static final double BASIS_TOLERANCE = 1e-8;

    public TrackFrame {
        Objects.requireNonNull(right, "right");
        Objects.requireNonNull(up, "up");
        Objects.requireNonNull(forward, "forward");
        if (Math.abs(right.length() - 1) > BASIS_TOLERANCE
                || Math.abs(up.length() - 1) > BASIS_TOLERANCE
                || Math.abs(forward.length() - 1) > BASIS_TOLERANCE
                || Math.abs(right.dot(up)) > BASIS_TOLERANCE
                || Math.abs(right.dot(forward)) > BASIS_TOLERANCE
                || Math.abs(up.dot(forward)) > BASIS_TOLERANCE
                || right.cross(up).dot(forward) < 1 - BASIS_TOLERANCE) {
            throw new IllegalArgumentException("Track frame must be right-handed and orthonormal");
        }
    }

    public static TrackFrame from(TrackSample sample) {
        Objects.requireNonNull(sample, "sample");
        TrackVec3 forward = sample.tangent().normalized();
        TrackVec3 horizontalRight = new TrackVec3(forward.z(), 0, -forward.x());
        TrackVec3 right = horizontalRight.length() >= NEAR_VERTICAL
                ? horizontalRight.normalized()
                : new TrackVec3(1, 0, 0).subtract(forward.scale(forward.x())).normalized();
        TrackVec3 up = forward.cross(right).normalized();
        // Reduce before conversion to keep even a corrupt-but-finite large bank
        // numerically bounded and consistent with spline angular wrapping.
        double bank = Math.toRadians(sample.bankDegrees() % 360);
        double cosine = Math.cos(bank), sine = Math.sin(bank);
        return new TrackFrame(right.scale(cosine).add(up.scale(sine)),
                up.scale(cosine).subtract(right.scale(sine)), forward);
    }
}
