package dev.coasterengineering.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.coasterengineering.item.CourseEditorItem;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** Solid, banked twin rails sampled from the same distance curve used by the server. */
@Mod.EventBusSubscriber(modid = "coasterengineering", value = Dist.CLIENT)
public final class TrackRenderer {
    private static final RenderType MATERIAL = RenderType.entityCutoutNoCull(
            new ResourceLocation("coasterengineering", "textures/block/rail_metal.png"));
    private static final Map<UUID, List<MeshPiece>> CACHE = new HashMap<>();
    private static final Map<UUID, AABB> COURSE_BOUNDS = new HashMap<>();
    private static List<ControlPoint> draftPoints = List.of();
    private static SplineTrack draftTrack;
    private static AABB draftBounds;
    private static List<MeshPiece> draftMesh = List.of();
    private static final double DRAW_DISTANCE_SQUARED = 192 * 192;

    private TrackRenderer() { }

    static void invalidate(UUID id) {
        CACHE.remove(id);
        COURSE_BOUNDS.remove(id);
    }
    static void clear() {
        CACHE.clear();
        COURSE_BOUNDS.clear();
        draftPoints = List.of();
        draftTrack = null;
        draftBounds = null;
        draftMesh = List.of();
    }

    @SubscribeEvent
    public static void render(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRANSLUCENT_BLOCKS) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) return;
        ItemStack editor = minecraft.player == null ? ItemStack.EMPTY : minecraft.player.getMainHandItem();
        boolean editing = editor.is(CoasterRegistries.COURSE_EDITOR.get());
        if (!editing && minecraft.player != null) {
            editor = minecraft.player.getOffhandItem();
            editing = editor.is(CoasterRegistries.COURSE_EDITOR.get());
        }
        if (ClientCourses.all().isEmpty() && !editing) return;
        Vec3 camera = event.getCamera().getPosition();
        PoseStack pose = event.getPoseStack();
        pose.pushPose();
        pose.translate(-camera.x, -camera.y, -camera.z);
        Matrix4f matrix = pose.last().pose();
        Matrix3f normals = pose.last().normal();
        MultiBufferSource.BufferSource buffers = minecraft.renderBuffers().bufferSource();
        VertexConsumer vertices = buffers.getBuffer(MATERIAL);
        for (Map.Entry<UUID, SplineTrack> entry : ClientCourses.all().entrySet()) {
            AABB bounds = COURSE_BOUNDS.computeIfAbsent(entry.getKey(),
                    ignored -> courseBounds(entry.getValue().points(), entry.getValue().closed()));
            // Test the inexpensive control-point envelope before sampling any mesh.
            // A distant synchronized course must not bake thousands of rail quads.
            if (distanceToBoundsSquared(camera, bounds) > DRAW_DISTANCE_SQUARED
                    || !event.getFrustum().isVisible(bounds)) continue;
            List<MeshPiece> pieces = CACHE.computeIfAbsent(entry.getKey(), ignored -> bake(entry.getValue()));
            for (MeshPiece piece : pieces) {
                if (piece.center.distanceToSqr(camera) > DRAW_DISTANCE_SQUARED
                        || !event.getFrustum().isVisible(piece.bounds)
                        || !minecraft.level.hasChunkAt(piece.lightPosition)) continue;
                drawPiece(vertices, matrix, normals, piece,
                        color(piece.kind), LevelRenderer.getLightColor(minecraft.level, piece.lightPosition));
            }
            if (editing) drawMarkers(vertices, matrix, normals, entry.getValue().points(), camera);
        }
        if (editing) {
            updateDraft(editor);
            if (draftTrack != null && distanceToBoundsSquared(camera, draftBounds) <= DRAW_DISTANCE_SQUARED
                    && event.getFrustum().isVisible(draftBounds)) {
                if (draftMesh.isEmpty()) draftMesh = bake(draftTrack);
                for (MeshPiece piece : draftMesh) {
                    if (piece.center.distanceToSqr(camera) < DRAW_DISTANCE_SQUARED
                            && event.getFrustum().isVisible(piece.bounds)
                            && minecraft.level.hasChunkAt(piece.lightPosition)) {
                        drawPiece(vertices, matrix, normals, piece, new float[] {.16F, .85F, .9F}, 15728880);
                    }
                }
            }
            drawMarkers(vertices, matrix, normals, draftPoints, camera);
        }
        buffers.endBatch(MATERIAL);
        pose.popPose();
    }

    private static void updateDraft(ItemStack editor) {
        try {
            List<ControlPoint> next = CourseEditorItem.readPoints(editor);
            if (next.equals(draftPoints)) return;
            draftPoints = List.copyOf(next);
            draftMesh = List.of();
            draftTrack = next.size() >= 2 ? new SplineTrack(next, next.size() >= 4) : null;
            draftBounds = next.isEmpty() ? null : courseBounds(next, next.size() >= 4);
        } catch (IllegalArgumentException invalidDraft) {
            // Bad or unfinished geometry can never interrupt rendering committed courses.
            draftTrack = null;
            draftBounds = null;
            draftMesh = List.of();
        }
    }

    private static AABB courseBounds(List<ControlPoint> points, boolean closed) {
        double minX = Double.POSITIVE_INFINITY, minY = Double.POSITIVE_INFINITY, minZ = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY, maxZ = Double.NEGATIVE_INFINITY;
        for (ControlPoint point : points) {
            TrackVec3 position = point.position();
            minX = Math.min(minX, position.x());
            minY = Math.min(minY, position.y());
            minZ = Math.min(minZ, position.z());
            maxX = Math.max(maxX, position.x());
            maxY = Math.max(maxY, position.y());
            maxZ = Math.max(maxZ, position.z());
        }
        // Committed courses limit adjacent points to 512 blocks. Catmull-Rom can
        // overshoot their envelope by at most 512/8 = 64; allow rail width too.
        // Drafts can have longer spans, so derive their envelope from the actual
        // maximum consecutive spacing to keep the preview conservatively visible.
        double maximumSpacing = 0;
        int segmentCount = points.size() - 1 + (closed ? 1 : 0);
        for (int index = 0; index < segmentCount; index++) {
            TrackVec3 a = points.get(index).position();
            TrackVec3 b = points.get((index + 1) % points.size()).position();
            maximumSpacing = Math.max(maximumSpacing, a.subtract(b).length());
        }
        return new AABB(minX, minY, minZ, maxX, maxY, maxZ).inflate(Math.max(64, maximumSpacing / 8) + 1.4);
    }

    private static double distanceToBoundsSquared(Vec3 point, AABB bounds) {
        double x = Math.max(0, Math.max(bounds.minX - point.x, point.x - bounds.maxX));
        double y = Math.max(0, Math.max(bounds.minY - point.y, point.y - bounds.maxY));
        double z = Math.max(0, Math.max(bounds.minZ - point.z, point.z - bounds.maxZ));
        return x * x + y * y + z * z;
    }

    private static void drawMarkers(VertexConsumer vertices, Matrix4f matrix, Matrix3f normals,
                                    List<ControlPoint> points, Vec3 camera) {
        for (ControlPoint point : points) {
            Vec3 center = vector(point.position());
            if (center.distanceToSqr(camera) > DRAW_DISTANCE_SQUARED) continue;
            List<Quad> quads = new ArrayList<>(6);
            addBeam(quads, corners(center.add(0, -.17, 0), new Vec3(1, 0, 0), new Vec3(0, 0, 1), .17, .17),
                    corners(center.add(0, .17, 0), new Vec3(1, 0, 0), new Vec3(0, 0, 1), .17, .17));
            drawPiece(vertices, matrix, normals, piece(center, center, quads, point.kind()),
                    new float[] {1, .66F, .13F}, 15728880);
        }
    }

    private static void drawPiece(VertexConsumer vertices, Matrix4f matrix, Matrix3f normals,
                                  MeshPiece piece, float[] color, int light) {
        for (Quad quad : piece.quads) {
            emit(vertices, matrix, normals, quad.a, 0, 0, quad.normal, color, light);
            emit(vertices, matrix, normals, quad.b, 0, 1, quad.normal, color, light);
            emit(vertices, matrix, normals, quad.c, 1, 1, quad.normal, color, light);
            emit(vertices, matrix, normals, quad.d, 1, 0, quad.normal, color, light);
        }
    }

    private static void emit(VertexConsumer vertices, Matrix4f matrix, Matrix3f normals,
                             Vec3 point, float u, float v, Vec3 normal, float[] color, int light) {
        vertices.vertex(matrix, (float) point.x, (float) point.y, (float) point.z)
                .color(color[0], color[1], color[2], 1).uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY).uv2(light)
                .normal(normals, (float) normal.x, (float) normal.y, (float) normal.z).endVertex();
    }

    private static List<MeshPiece> bake(SplineTrack track) {
        List<MeshPiece> pieces = new ArrayList<>();
        int steps = Math.max(1, (int) Math.min(24000, Math.ceil(track.length() / .8)));
        double step = track.length() / steps;
        for (int i = 0; i < steps; i++) {
            Frame start = frame(track.sample(i * step));
            Frame end = frame(track.sample((i + 1) * step));
            List<Quad> quads = new ArrayList<>(12);
            for (int side : new int[] {-1, 1}) {
                addBeam(quads, corners(start, side * .625, .07, .055), corners(end, side * .625, .07, .055));
            }
            pieces.add(piece(start.position, end.position, quads, start.kind));
        }
        double sleeperSpacing = Math.max(2, track.length() / 12000);
        for (double distance = 0; distance < track.length(); distance += sleeperSpacing) {
            Frame middle = frame(track.sample(distance));
            Vec3 first = middle.position.add(middle.right.scale(-.8)).add(middle.up.scale(-.11));
            Vec3 last = middle.position.add(middle.right.scale(.8)).add(middle.up.scale(-.11));
            List<Quad> quads = new ArrayList<>(6);
            addBeam(quads, corners(first, middle.forward, middle.up, .09, .055),
                    corners(last, middle.forward, middle.up, .09, .055));
            pieces.add(piece(first, last, quads, RailKind.NORMAL));
        }
        return pieces;
    }

    private static MeshPiece piece(Vec3 a, Vec3 b, List<Quad> quads, RailKind kind) {
        Vec3 middle = a.add(b).scale(.5);
        return new MeshPiece(middle, new AABB(a, b).inflate(1.4), BlockPos.containing(middle), quads, kind);
    }

    private static Frame frame(TrackSample sample) {
        TrackFrame frame = TrackFrame.from(sample);
        return new Frame(vector(sample.position()), vector(frame.forward()),
                vector(frame.right()), vector(frame.up()), sample.kind());
    }

    private static Vec3 vector(TrackVec3 v) { return new Vec3(v.x(), v.y(), v.z()); }

    private static Vec3[] corners(Frame frame, double offset, double halfWidth, double halfHeight) {
        return corners(frame.position.add(frame.right.scale(offset)), frame.right, frame.up, halfWidth, halfHeight);
    }

    private static Vec3[] corners(Vec3 center, Vec3 right, Vec3 up, double halfWidth, double halfHeight) {
        Vec3 r = right.scale(halfWidth), u = up.scale(halfHeight);
        return new Vec3[] {center.add(r).add(u), center.subtract(r).add(u),
                center.subtract(r).subtract(u), center.add(r).subtract(u)};
    }

    private static void addBeam(List<Quad> quads, Vec3[] a, Vec3[] b) {
        for (int i = 0; i < 4; i++) {
            int next = (i + 1) % 4;
            quad(quads, a[i], a[next], b[next], b[i]);
        }
        quad(quads, a[3], a[2], a[1], a[0]);
        quad(quads, b[0], b[1], b[2], b[3]);
    }

    private static void quad(List<Quad> output, Vec3 a, Vec3 b, Vec3 c, Vec3 d) {
        output.add(new Quad(a, b, c, d, b.subtract(a).cross(c.subtract(a)).normalize()));
    }

    private static float[] color(RailKind kind) {
        return switch (kind) {
            case NORMAL -> new float[] {.62F, .67F, .73F};
            case BOOST -> new float[] {.13F, .8F, .98F};
            case BRAKE -> new float[] {.95F, .3F, .15F};
            case LIFT -> new float[] {.93F, .7F, .16F};
            case STATION -> new float[] {.23F, .83F, .42F};
        };
    }

    private record Frame(Vec3 position, Vec3 forward, Vec3 right, Vec3 up, RailKind kind) { }
    private record Quad(Vec3 a, Vec3 b, Vec3 c, Vec3 d, Vec3 normal) { }
    private record MeshPiece(Vec3 center, AABB bounds, BlockPos lightPosition, List<Quad> quads, RailKind kind) { }
}
