package dev.coasterengineering.gametest;

import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import dev.coasterengineering.world.CourseEditService;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/** Atomic edits must validate the real train and complete proposed swept path before changing data. */
@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class CourseEditingGameTests {
    private CourseEditingGameTests() { }

    @GameTest(template = "empty", timeoutTicks = 75)
    public static void movingTrainRejectsEditWithoutChangingCourseOrRideState(GameTestHelper helper) {
        ServerCourseFixture fixture = ServerCourseFixture.create(helper);
        helper.assertTrue(fixture.vehicle().startRide(), "Moving-edit fixture must dispatch");
        helper.runAfterDelay(40, () -> {
            helper.assertTrue(fixture.vehicle().isRunning() && fixture.vehicle().getSpeed() > 0,
                    "Edit rejection must exercise a train that is actually moving");
            double distance = fixture.vehicle().getDistance();
            double speed = fixture.vehicle().getSpeed();
            Vec3 position = fixture.vehicle().position();
            TrackVec3 proposed = fixture.course().track().points().get(2).position().add(new TrackVec3(0, 1, 0));
            expectRejected(helper, IllegalStateException.class,
                    () -> CourseEditService.movePoint(helper.getLevel(), fixture.course().id(), 3, proposed));
            assertOriginalData(helper, fixture);
            near(helper, fixture.vehicle().getDistance(), distance, "Rejected moving-edit distance");
            near(helper, fixture.vehicle().getSpeed(), speed, "Rejected moving-edit speed");
            helper.assertTrue(fixture.vehicle().isRunning() && fixture.vehicle().position().distanceTo(position) < .001,
                    "A rejected edit must not interrupt, teleport or partially change a running train");
            fixture.cleanup(helper);
            helper.succeed();
        });
    }

    @GameTest(template = "empty")
    public static void occupiedStoppedTrainRejectsEditAndKeepsPassengerSeated(GameTestHelper helper) {
        ServerCourseFixture fixture = ServerCourseFixture.create(helper);
        Player passenger = fixture.rider(helper);
        Vec3 vehiclePosition = fixture.vehicle().position();
        expectRejected(helper, IllegalStateException.class,
                () -> CourseEditService.setSpeed(helper.getLevel(), fixture.course().id(), 2, .2));
        assertOriginalData(helper, fixture);
        helper.assertTrue(passenger.getVehicle() == fixture.vehicle() && fixture.vehicle().getPassengers().size() == 1,
                "Rejected occupied-course edit must preserve the actual passenger and seat");
        helper.assertTrue(fixture.vehicle().position().distanceTo(vehiclePosition) < .001,
                "Rejected occupied-course edit must not repark or move the train");
        near(helper, fixture.vehicle().getDistance(), 0, "Rejected occupied-edit station distance");
        near(helper, fixture.vehicle().getSpeed(), 0, "Rejected occupied-edit speed");
        passenger.stopRiding();
        fixture.cleanup(helper);
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void obstructedCandidateRejectsAtomicallyThenClearEditCommitsAndPersists(GameTestHelper helper) {
        ServerCourseFixture fixture = ServerCourseFixture.create(helper);
        TrackVec3 proposed = fixture.course().track().points().get(2).position().add(new TrackVec3(0, 2, 0));
        BlockPos obstacle = BlockPos.containing(proposed.x(), proposed.y(), proposed.z()).above();
        BlockState originalBlock = helper.getLevel().getBlockState(obstacle);
        helper.assertTrue(originalBlock.isAir(), "Candidate-obstruction fixture must begin in clear air");
        Vec3 originalVehiclePosition = fixture.vehicle().position();
        helper.getLevel().setBlock(obstacle, Blocks.STONE.defaultBlockState(), 3);
        expectRejected(helper, IllegalArgumentException.class,
                () -> CourseEditService.movePoint(helper.getLevel(), fixture.course().id(), 3, proposed));
        assertOriginalData(helper, fixture);
        helper.assertTrue(fixture.vehicle().position().distanceTo(originalVehiclePosition) < .001,
                "Whole-path clearance failure must leave the old vehicle pose untouched");
        helper.assertTrue(helper.getLevel().getBlockState(obstacle).is(Blocks.STONE),
                "Failed edit must preserve the user's blocking world block");
        helper.getLevel().setBlock(obstacle, originalBlock, 3);
        Course changed = CourseEditService.movePoint(helper.getLevel(), fixture.course().id(), 3, proposed);
        helper.assertTrue(changed.id().equals(fixture.course().id()) && changed.track().points().get(2).position().equals(proposed),
                "After clearing the genuine obstruction, an allowed edit must commit the proposed node under the same course UUID");
        helper.assertTrue(CoasterSavedData.get(helper.getLevel()).getCourse(changed.id()).track().points().equals(changed.track().points()),
                "Committed geometry must be the actual authoritative SavedData course");
        near(helper, fixture.vehicle().getDistance(), 0, "Successful edit must park its empty train at the station");
        near(helper, fixture.vehicle().getSpeed(), 0, "Successful edit must leave parked speed zero");
        helper.assertFalse(fixture.vehicle().isRunning(), "Successful course edit must not dispatch automatically");
        CoasterSavedData restored = CoasterSavedData.load(CoasterSavedData.get(helper.getLevel()).save(new CompoundTag()));
        helper.assertTrue(restored.getCourse(changed.id()).track().points().equals(changed.track().points()),
                "Successfully edited 3D geometry must survive actual world-data NBT round trip");
        helper.assertTrue(fixture.vehicle().getUUID().equals(restored.vehicleId(changed.id())),
                "Successful edit must preserve its original leader reservation through persistence");
        fixture.cleanup(helper);
        helper.succeed();
    }

    private static void assertOriginalData(GameTestHelper helper, ServerCourseFixture fixture) {
        Course current = CoasterSavedData.get(helper.getLevel()).getCourse(fixture.course().id());
        helper.assertTrue(current != null && current.id().equals(fixture.course().id())
                        && current.name().equals(fixture.course().name()) && current.station().equals(fixture.course().station())
                        && current.enabled() == fixture.course().enabled() && current.track().closed() == fixture.course().track().closed()
                        && current.track().points().equals(fixture.course().track().points()),
                "Rejected edit must preserve all previously saved course geometry, settings and station data");
        helper.assertTrue(fixture.vehicle().getUUID().equals(CoasterSavedData.get(helper.getLevel()).vehicleId(fixture.course().id())),
                "Rejected edit must preserve the original single-leader reservation");
    }

    private static void expectRejected(GameTestHelper helper, Class<? extends RuntimeException> kind, Runnable operation) {
        RuntimeException failure = null;
        try {
            operation.run();
        } catch (RuntimeException exception) {
            failure = exception;
        }
        helper.assertTrue(failure != null && kind.isInstance(failure),
                "Unsafe edit must report " + kind.getSimpleName() + ", got "
                        + (failure == null ? "successful mutation" : failure.getClass().getSimpleName()));
    }

    private static void near(GameTestHelper helper, double actual, double expected, String description) {
        helper.assertTrue(Double.isFinite(actual) && Math.abs(actual - expected) < .001,
                description + ": expected " + expected + ", actual " + actual);
    }
}
