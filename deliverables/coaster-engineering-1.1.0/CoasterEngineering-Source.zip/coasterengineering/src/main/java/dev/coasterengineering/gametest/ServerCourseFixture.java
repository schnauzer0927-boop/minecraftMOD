package dev.coasterengineering.gametest;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/** Shared genuine server fixture for station and editing integration checks. */
record ServerCourseFixture(Course course, CoasterEntity vehicle) {
    static ServerCourseFixture create(GameTestHelper helper) {
        double[][] coordinates = {
                {8.5, 3, 6.5}, {16.5, 3, 6.5}, {23.5, 4, 9.5}, {24.5, 8, 16.5},
                {20.5, 10, 23.5}, {12.5, 7, 24.5}, {6.5, 3, 20.5}, {5.5, 3, 12.5}
        };
        RailKind[] kinds = {RailKind.STATION, RailKind.BOOST, RailKind.BOOST, RailKind.LIFT,
                RailKind.BOOST, RailKind.BRAKE, RailKind.BOOST, RailKind.BOOST};
        List<ControlPoint> points = new ArrayList<>();
        for (int index = 0; index < coordinates.length; index++) {
            Vec3 position = helper.absoluteVec(new Vec3(coordinates[index][0], coordinates[index][1], coordinates[index][2]));
            points.add(new ControlPoint(new TrackVec3(position.x, position.y, position.z),
                    index == 2 || index == 5 ? 20 : 0, kinds[index], index == 0 ? .32 : .6));
        }
        Course course = new Course(UUID.randomUUID(), "GameTest server station and editing", new SplineTrack(points, true),
                helper.absolutePos(new BlockPos(8, 2, 4)), true);
        CoasterSavedData.get(helper.getLevel()).putCourse(course);
        CoasterEntity vehicle = new CoasterEntity(CoasterRegistries.COASTER.get(), helper.getLevel());
        vehicle.setCourse(course.id());
        helper.assertTrue(vehicle.resetToStation(), "Server fixture must park safely on its registered complete course");
        helper.assertTrue(helper.getLevel().addFreshEntity(vehicle), "Server fixture must add its real coaster to the world");
        return new ServerCourseFixture(course, vehicle);
    }

    Player rider(GameTestHelper helper) {
        Player player = helper.makeMockSurvivalPlayer();
        player.moveTo(vehicle.position().add(0, 0, 1));
        helper.assertTrue(!vehicle.isRemoved() && !vehicle.isRunning() && vehicle.hasFreeSeat(),
                "Passenger fixture needs a present stopped car with a free seat; removed=" + vehicle.isRemoved()
                        + ", running=" + vehicle.isRunning() + ", passengers=" + vehicle.getPassengers().size());
        helper.assertTrue(vehicle.canUseTrackSample(course.track().sample(vehicle.getDistance())),
                "Passenger fixture requires loaded clear track at the existing boarding pose; chunkLoaded="
                        + helper.getLevel().hasChunkAt(vehicle.blockPosition()) + ", position=" + vehicle.position());
        helper.assertTrue(player.startRiding(vehicle), "Fixture must mount its real passenger; playerBounds="
                + player.getBoundingBox() + ", vehicleBounds=" + vehicle.getBoundingBox());
        return player;
    }

    void cleanup(GameTestHelper helper) {
        vehicle.ejectPassengers();
        if (!vehicle.isRemoved()) vehicle.discard();
        CoasterSavedData.get(helper.getLevel()).removeCourse(course.id());
    }
}
