package dev.coasterengineering.track;

import java.util.Objects;

/** Followers derive their position from one leader; they never integrate separate physics. */
public final class TrainSpacing {
    public static final int MAX_CARS = 4;
    public static final double MIN_SPACING = 3.5;
    public static final double DEFAULT_SPACING = 4.0;

    private TrainSpacing() { }

    /**
     * Index zero is the leader. Normalize the leader's actual position before
     * applying the rearward arc offset. Open endpoints clamp rather than derail;
     * the entity must reject a train placement with insufficient track space.
     */
    public static double distance(SplineTrack track, double leaderDistance, int index, double spacing) {
        Objects.requireNonNull(track, "track");
        if (index < 0 || index >= MAX_CARS) throw new IllegalArgumentException("Car index must be between zero and three");
        if (!Double.isFinite(spacing) || spacing < MIN_SPACING) {
            throw new IllegalArgumentException("Train spacing must be finite and at least 3.5 blocks");
        }
        double normalizedLeader = track.normalizeDistance(leaderDistance);
        double offset = index * spacing;
        if (!Double.isFinite(offset)) throw new IllegalArgumentException("Train offset overflow");
        return track.normalizeDistance(normalizedLeader - offset);
    }
}
