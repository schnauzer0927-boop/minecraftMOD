package dev.coasterengineering.item;

import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.RideDynamics;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.station.StationControllerBlockEntity;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import dev.coasterengineering.world.CourseEditService;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/** Stores a draft course in the editor itself; placing points never replaces blocks. */
public final class CourseEditorItem extends Item {
    public static final int MAX_POINTS = 128;
    private static final String POINTS = "CoasterPoints";
    private static final String SETTINGS = "CoasterSettings";
    private static final String STATION = "CoasterStation";
    private static final String DIMENSION = "CoasterDimension";
    private static final String SELECTION = "CoasterSelection";

    public CourseEditorItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null) return InteractionResult.FAIL;
        if (context.getLevel().isClientSide) return InteractionResult.SUCCESS;
        if (!canEdit(player)) return InteractionResult.FAIL;
        if (isEditing(context.getItemInHand())) return useSelection(context, player);
        if (player.isShiftKeyDown()) return removeLast(context.getItemInHand(), player);

        ItemStack stack = context.getItemInHand();
        if (!matchesDimension(stack, context.getLevel())) {
            player.sendSystemMessage(Component.literal("This draft belongs to another dimension. Return there or use /coaster clear before placing points here."));
            return InteractionResult.FAIL;
        }
        List<ControlPoint> points;
        try {
            points = readPoints(stack);
        } catch (IllegalArgumentException ex) {
            player.sendSystemMessage(Component.literal(ex.getMessage() + " Use /coaster clear to reset this editor."));
            return InteractionResult.FAIL;
        }
        if (points.size() >= MAX_POINTS) {
            player.sendSystemMessage(Component.literal("The editor supports at most " + MAX_POINTS + " control points."));
            return InteractionResult.FAIL;
        }
        var normal = context.getClickedFace().getNormal();
        Vec3 position = context.getClickLocation().add(normal.getX() * 0.5, normal.getY() * 0.5, normal.getZ() * 0.5);
        BlockPos block = BlockPos.containing(position);
        if (!Level.isInSpawnableBounds(block) || context.getLevel().isOutsideBuildHeight(block)) {
            player.sendSystemMessage(Component.literal("The control point must be inside the world and build height."));
            return InteractionResult.FAIL;
        }
        if (!points.isEmpty()) {
            var previous = points.get(points.size() - 1).position();
            double dx = previous.x() - position.x;
            double dy = previous.y() - position.y;
            double dz = previous.z() - position.z;
            if (dx * dx + dy * dy + dz * dz < 0.25) {
                player.sendSystemMessage(Component.literal("Place the next point at least half a block away."));
                return InteractionResult.FAIL;
            }
        }
        CompoundTag settings = settings(stack);
        RailKind kind;
        try {
            kind = readKind(settings.getString("Kind"));
        } catch (IllegalArgumentException ex) {
            player.sendSystemMessage(Component.literal(ex.getMessage() + " Use /coaster clear to reset this editor."));
            return InteractionResult.FAIL;
        }
        double bank = settings.contains("Bank") ? settings.getDouble("Bank") : 0.0;
        double targetSpeed = settings.contains("TargetSpeed") ? settings.getDouble("TargetSpeed") : 0.45;
        if (!Double.isFinite(bank) || Math.abs(bank) > 75 || !Double.isFinite(targetSpeed) || targetSpeed < 0 || targetSpeed > RideDynamics.MAX_SUPPORTED_SPEED) {
            player.sendSystemMessage(Component.literal("Invalid editor settings. Use /coaster clear to reset this editor."));
            return InteractionResult.FAIL;
        }
        points.add(new ControlPoint(new TrackVec3(position.x, position.y, position.z), bank, kind, targetSpeed));
        writePoints(stack, points);
        if (points.size() == 1) {
            stack.getOrCreateTag().putLong(STATION, player.blockPosition().asLong());
            stack.getOrCreateTag().putString(DIMENSION, context.getLevel().dimension().location().toString());
        }
        player.sendSystemMessage(Component.literal("Control point " + points.size() + " placed (" + kind.name() + "). /coaster create <name> closes the loop."));
        return InteractionResult.CONSUME;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!player.isShiftKeyDown()) return InteractionResultHolder.pass(stack);
        if (level.isClientSide) return InteractionResultHolder.success(stack);
        if (!canEdit(player)) return InteractionResultHolder.fail(stack);
        if (isEditing(stack)) {
            // Air use is a deliberate mode exit; no saved point is removed.
            draft(stack);
            player.sendSystemMessage(Component.literal("Editor returned to draft mode. Right-click adds a point; shift-right-click removes its last point."));
            return InteractionResultHolder.consume(stack);
        }
        return removeLast(stack, player).consumesAction() ? InteractionResultHolder.consume(stack) : InteractionResultHolder.fail(stack);
    }

    private static InteractionResult useSelection(UseOnContext context, Player player) {
        if (!(context.getLevel() instanceof ServerLevel level)) return InteractionResult.FAIL;
        ItemStack stack = context.getItemInHand();
        try {
            Selection selection = requireSelection(stack, level);
            if (!player.isShiftKeyDown() && level.getBlockEntity(context.getClickedPos()) instanceof StationControllerBlockEntity controller) {
                if (!controller.bind(selection.course().id())) throw new IllegalArgumentException("The controller must be within eight blocks of the landing, with no other controller bound to this course.");
                player.sendSystemMessage(Component.literal("Station controller bound to " + selection.course().name() + ". Right-click it without the editor to open its controls."));
                return InteractionResult.CONSUME;
            }
            if (player.isShiftKeyDown()) {
                var normal = context.getClickedFace().getNormal();
                Vec3 target = context.getClickLocation().add(normal.getX() * 0.5, normal.getY() * 0.5, normal.getZ() * 0.5);
                Course updated = CourseEditService.movePoint(level, selection.course().id(), selection.index(), new TrackVec3(target.x, target.y, target.z));
                select(stack, level, updated, selection.index());
                player.sendSystemMessage(Component.literal("Moved point " + selection.index() + " of " + updated.name() + ". The empty train is parked at the station."));
                return InteractionResult.CONSUME;
            }
            int nearest = -1;
            double nearestSquared = 9;
            List<ControlPoint> points = selection.course().track().points();
            for (int index = 0; index < points.size(); index++) {
                var p = points.get(index).position();
                double squared = context.getClickLocation().distanceToSqr(p.x(), p.y(), p.z());
                if (squared <= nearestSquared) {
                    nearestSquared = squared;
                    nearest = index + 1;
                }
            }
            if (nearest < 1) {
                player.sendSystemMessage(Component.literal("Click within three blocks of a control point to select it. Shift-right-click a block to move the selected point."));
                return InteractionResult.FAIL;
            }
            select(stack, level, selection.course(), nearest);
            player.sendSystemMessage(Component.literal("Selected point " + nearest + " of " + selection.course().name() + ". Shift-right-click a block to move it."));
            return InteractionResult.CONSUME;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            player.sendSystemMessage(Component.literal("Edit refused: " + ex.getMessage()));
            return InteractionResult.FAIL;
        }
    }

    private static boolean canEdit(Player player) {
        if (player.hasPermissions(2)) return true;
        player.sendSystemMessage(Component.literal("Course editing requires operator permission level 2."));
        return false;
    }

    private static InteractionResult removeLast(ItemStack stack, Player player) {
        List<ControlPoint> points;
        try {
            points = readPoints(stack);
        } catch (IllegalArgumentException ex) {
            player.sendSystemMessage(Component.literal(ex.getMessage() + " Use /coaster clear to reset this editor."));
            return InteractionResult.FAIL;
        }
        if (points.isEmpty()) {
            player.sendSystemMessage(Component.literal("This editor has no control points."));
            return InteractionResult.FAIL;
        }
        points.remove(points.size() - 1);
        writePoints(stack, points);
        if (points.isEmpty() && stack.getTag() != null) {
            stack.getTag().remove(STATION);
            stack.getTag().remove(DIMENSION);
        }
        player.sendSystemMessage(Component.literal("Last point removed. " + points.size() + " point(s) remain."));
        return InteractionResult.CONSUME;
    }

    public static List<ControlPoint> readPoints(ItemStack stack) {
        CompoundTag root = stack.getTag();
        if (root == null) return new ArrayList<>();
        if (root.contains(POINTS) && !root.contains(POINTS, Tag.TAG_LIST)) throw new IllegalArgumentException("Invalid editor control-point data.");
        if (root.get(POINTS) instanceof ListTag rawPoints && !rawPoints.isEmpty() && rawPoints.getElementType() != Tag.TAG_COMPOUND) {
            throw new IllegalArgumentException("Editor control points must contain compound point records.");
        }
        ListTag tags = root.getList(POINTS, Tag.TAG_COMPOUND);
        if (tags.size() > MAX_POINTS) throw new IllegalArgumentException("Too many editor control points.");
        List<ControlPoint> points = new ArrayList<>(tags.size());
        for (int index = 0; index < tags.size(); index++) {
            CompoundTag tag = tags.getCompound(index);
            if (!tag.contains("X", Tag.TAG_ANY_NUMERIC) || !tag.contains("Y", Tag.TAG_ANY_NUMERIC) || !tag.contains("Z", Tag.TAG_ANY_NUMERIC)) {
                throw new IllegalArgumentException("A control point has missing coordinates.");
            }
            double x = tag.getDouble("X"), y = tag.getDouble("Y"), z = tag.getDouble("Z");
            double bank = tag.getDouble("Bank"), speed = tag.getDouble("TargetSpeed");
            if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z) || Math.abs(x) >= 30_000_000 || Math.abs(z) >= 30_000_000
                    || !Double.isFinite(bank) || Math.abs(bank) > 75 || !Double.isFinite(speed) || speed < 0 || speed > RideDynamics.MAX_SUPPORTED_SPEED) {
                throw new IllegalArgumentException("A control point contains invalid coordinates, bank, or target speed.");
            }
            points.add(new ControlPoint(new TrackVec3(x, y, z), bank, readKind(tag.getString("Kind")), speed));
        }
        return points;
    }

    private static RailKind readKind(String name) {
        if (name.isEmpty()) return RailKind.NORMAL;
        try {
            return RailKind.valueOf(name);
        } catch (IllegalArgumentException ex) {
            throw new IllegalArgumentException("Unknown rail kind in this editor.");
        }
    }

    private static void writePoints(ItemStack stack, List<ControlPoint> points) {
        ListTag tags = new ListTag();
        for (ControlPoint point : points) {
            CompoundTag tag = new CompoundTag();
            tag.putDouble("X", point.position().x());
            tag.putDouble("Y", point.position().y());
            tag.putDouble("Z", point.position().z());
            tag.putDouble("Bank", point.bankDegrees());
            tag.putString("Kind", point.kind().name());
            tag.putDouble("TargetSpeed", point.targetSpeed());
            tags.add(tag);
        }
        stack.getOrCreateTag().put(POINTS, tags);
    }

    public static void clear(ItemStack stack) {
        CompoundTag tag = stack.getTag();
        if (tag == null) return;
        tag.remove(POINTS);
        tag.remove(SETTINGS);
        tag.remove(STATION);
        tag.remove(DIMENSION);
        tag.remove(SELECTION);
    }

    public record Selection(Course course, int index) { }

    public static boolean isEditing(ItemStack stack) {
        return stack.getTag() != null && stack.getTag().contains(SELECTION);
    }

    public static void draft(ItemStack stack) {
        if (stack.getTag() != null) stack.getTag().remove(SELECTION);
    }

    public static void select(ItemStack stack, ServerLevel level, Course course, int oneBasedIndex) {
        if (oneBasedIndex < 1 || oneBasedIndex > course.track().points().size()) throw new IllegalArgumentException("Point index is outside this course.");
        ControlPoint point = course.track().points().get(oneBasedIndex - 1);
        CompoundTag selection = new CompoundTag();
        selection.putUUID("Course", course.id());
        selection.putInt("Index", oneBasedIndex);
        selection.putString("Dimension", level.dimension().location().toString());
        CompoundTag original = new CompoundTag();
        original.putDouble("X", point.position().x());
        original.putDouble("Y", point.position().y());
        original.putDouble("Z", point.position().z());
        original.putDouble("Bank", point.bankDegrees());
        original.putString("Kind", point.kind().name());
        original.putDouble("TargetSpeed", point.targetSpeed());
        selection.put("Original", original);
        // Detect structural changes even if the selected point happens to remain equal.
        selection.putInt("PointCount", course.track().points().size());
        stack.getOrCreateTag().put(SELECTION, selection);
    }

    public static Selection requireSelection(ItemStack stack, ServerLevel level) {
        CompoundTag root = stack.getTag();
        if (root == null || !root.contains(SELECTION, Tag.TAG_COMPOUND)) throw new IllegalArgumentException("Editor selection is missing or invalid. Select a point again.");
        CompoundTag selection = root.getCompound(SELECTION);
        if (!selection.hasUUID("Course") || !selection.contains("Index", Tag.TAG_INT) || !selection.contains("PointCount", Tag.TAG_INT)
                || !selection.contains("Dimension", Tag.TAG_STRING) || !selection.contains("Original", Tag.TAG_COMPOUND)) {
            throw new IllegalArgumentException("Editor selection is malformed. Select a point again.");
        }
        if (!level.dimension().location().toString().equals(selection.getString("Dimension"))) throw new IllegalArgumentException("Selected course belongs to another dimension.");
        Course course = CoasterSavedData.get(level).getCourse(selection.getUUID("Course"));
        int index = selection.getInt("Index");
        if (course == null || index < 1 || index > course.track().points().size()) throw new IllegalArgumentException("Selected course or point no longer exists. Select a point again.");
        if (selection.getInt("PointCount") != course.track().points().size()) throw new IllegalArgumentException("The course's point list changed. Select a point again.");
        CompoundTag original = selection.getCompound("Original");
        for (String coordinate : new String[] {"X", "Y", "Z", "Bank", "TargetSpeed"}) {
            if (!original.contains(coordinate, Tag.TAG_ANY_NUMERIC) || !Double.isFinite(original.getDouble(coordinate))) {
                throw new IllegalArgumentException("Selected point snapshot is malformed. Select a point again.");
            }
        }
        if (!original.contains("Kind", Tag.TAG_STRING)) throw new IllegalArgumentException("Selected point snapshot has no rail kind.");
        ControlPoint point = course.track().points().get(index - 1);
        if (Double.compare(original.getDouble("X"), point.position().x()) != 0 || Double.compare(original.getDouble("Y"), point.position().y()) != 0
                || Double.compare(original.getDouble("Z"), point.position().z()) != 0 || Double.compare(original.getDouble("Bank"), point.bankDegrees()) != 0
                || Double.compare(original.getDouble("TargetSpeed"), point.targetSpeed()) != 0 || !original.getString("Kind").equals(point.kind().name())) {
            throw new IllegalArgumentException("The selected point changed since selection. Select it again before editing.");
        }
        return new Selection(course, index);
    }

    public static boolean matchesDimension(ItemStack stack, Level level) {
        CompoundTag tag = stack.getTag();
        return tag == null || !tag.contains(DIMENSION, Tag.TAG_STRING)
                || level.dimension().location().toString().equals(tag.getString(DIMENSION));
    }

    public static BlockPos station(ItemStack stack, BlockPos fallback) {
        CompoundTag tag = stack.getTag();
        return tag != null && tag.contains(STATION, Tag.TAG_LONG) ? BlockPos.of(tag.getLong(STATION)) : fallback;
    }

    private static CompoundTag settings(ItemStack stack) {
        CompoundTag root = stack.getOrCreateTag();
        if (!root.contains(SETTINGS, Tag.TAG_COMPOUND)) root.put(SETTINGS, new CompoundTag());
        return root.getCompound(SETTINGS);
    }

    public static void setRailKind(ItemStack stack, RailKind kind) { settings(stack).putString("Kind", kind.name()); }
    public static void setBank(ItemStack stack, double degrees) {
        if (!Double.isFinite(degrees) || Math.abs(degrees) > 75) throw new IllegalArgumentException("Bank must be finite and between -75 and 75 degrees.");
        settings(stack).putDouble("Bank", degrees);
    }
    public static void setTargetSpeed(ItemStack stack, double speed) {
        if (!Double.isFinite(speed) || speed < 0 || speed > RideDynamics.MAX_SUPPORTED_SPEED) throw new IllegalArgumentException("Speed must be finite and between 0 and 120 km/h.");
        settings(stack).putDouble("TargetSpeed", speed);
    }
}
