package dev.coasterengineering.world;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.TrainSpacing;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.level.ServerLevel;

/** Explicit, noninteractive formation changes; missing saved cars are never respawned. */
public final class TrainService {
    private TrainService() { }

    public static boolean setCarCount(CoasterEntity selected, int count) {
        if (count < 1 || count > TrainSpacing.MAX_CARS)
            throw new IllegalArgumentException("A train must contain 1..4 cars");
        CoasterEntity leader = selected.resolveLeader();
        if (leader == null || !(leader.level() instanceof ServerLevel server)) return false;
        List<CoasterEntity> old = leader.getLoadedFormation();
        if (old.isEmpty() || leader.isRunning() || old.stream().anyMatch(CoasterEntity::isVehicle)) return false;
        ArrayList<CoasterEntity> replacement = new ArrayList<>();
        for (int index = 1; index < count; index++) {
            CoasterEntity car = CoasterRegistries.COASTER.get().create(server);
            if (car == null) return false;
            replacement.add(car);
        }
        if (!leader.canReplaceFollowers(replacement)) return false;
        if (old.size() == count) return true;
        for (int index = 0; index < replacement.size(); index++)
            replacement.get(index).initializeFollower(leader, index + 1);

        ArrayList<CoasterEntity> spawned = new ArrayList<>();
        for (CoasterEntity car : replacement) {
            if (!server.addFreshEntity(car)) {
                for (CoasterEntity added : spawned) added.discard();
                return false;
            }
            spawned.add(car);
        }
        // Commit the UUID list only after every candidate was safely inserted.
        // Old cars remain valid through validation and failed spawn attempts.
        leader.commitFollowers(replacement);
        for (int i = 1; i < old.size(); i++) old.get(i).discard();
        return true;
    }
}
