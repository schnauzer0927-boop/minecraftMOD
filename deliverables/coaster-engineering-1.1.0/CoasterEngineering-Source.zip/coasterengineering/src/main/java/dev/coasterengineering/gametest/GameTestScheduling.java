package dev.coasterengineering.gametest;

import net.minecraft.gametest.framework.GameTestHelper;

/** Scheduling for actions created while another delayed test action is executing. */
final class GameTestScheduling {
    private GameTestScheduling() { }

    static void after(GameTestHelper helper, int ticks, Runnable action) {
        // In Minecraft 1.20.1, runAfterDelay writes into the same open hash map
        // that GameTestInfo is currently iterating. A nested batch can rehash
        // that map before the current action is removed and execute it twice.
        // Test sequences live in a separate CopyOnWriteArrayList, so adding a
        // sequence here preserves both one-shot execution and assertion failures.
        helper.startSequence().thenExecuteAfter(ticks, action);
    }
}
