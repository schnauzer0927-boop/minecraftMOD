package dev.coasterengineering.track;

import java.util.Objects;

public record TrackSample(TrackVec3 position, TrackVec3 tangent, double bankDegrees,
                          RailKind kind, double targetSpeed) {
    public TrackSample {
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(tangent, "tangent");
        Objects.requireNonNull(kind, "kind");
        if (tangent.length() < 1e-12) throw new IllegalArgumentException("Tangent must have a direction");
        if (!Double.isFinite(bankDegrees)) throw new IllegalArgumentException("Bank must be finite");
        if (!Double.isFinite(targetSpeed) || targetSpeed < 0) {
            throw new IllegalArgumentException("Target speed must be finite and nonnegative");
        }
    }
}
