package dev.coasterengineering.registry;

import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.item.CoasterVehicleItem;
import dev.coasterengineering.item.CourseEditorItem;
import dev.coasterengineering.menu.StationMenu;
import dev.coasterengineering.station.StationControllerBlock;
import dev.coasterengineering.station.StationControllerBlockEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class CoasterRegistries {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, CoasterEngineering.MOD_ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, CoasterEngineering.MOD_ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CoasterEngineering.MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, CoasterEngineering.MOD_ID);
    public static final DeferredRegister<MenuType<?>> MENUS = DeferredRegister.create(ForgeRegistries.MENU_TYPES, CoasterEngineering.MOD_ID);
    public static final RegistryObject<Block> RAIL = rail("rail", MapColor.COLOR_GRAY);
    public static final RegistryObject<Block> BOOST_RAIL = rail("boost_rail", MapColor.COLOR_CYAN);
    public static final RegistryObject<Block> BRAKE_RAIL = rail("brake_rail", MapColor.COLOR_RED);
    public static final RegistryObject<Block> LIFT_RAIL = rail("lift_rail", MapColor.COLOR_YELLOW);
    public static final RegistryObject<Block> STATION_RAIL = rail("station_rail", MapColor.COLOR_BLUE);
    public static final RegistryObject<Block> SUPPORT_BEAM = rail("support_beam", MapColor.COLOR_GRAY);
    public static final RegistryObject<Block> STATION_CONTROLLER = BLOCKS.register("station_controller", () ->
            new StationControllerBlock(BlockBehaviour.Properties.of().mapColor(MapColor.METAL).strength(3F).sound(SoundType.METAL)));
    public static final RegistryObject<Item> STATION_CONTROLLER_ITEM = ITEMS.register("station_controller", () ->
            new BlockItem(STATION_CONTROLLER.get(), new Item.Properties()));
    public static final RegistryObject<BlockEntityType<StationControllerBlockEntity>> STATION_CONTROLLER_ENTITY = BLOCK_ENTITIES.register("station_controller", () ->
            BlockEntityType.Builder.of(StationControllerBlockEntity::new, STATION_CONTROLLER.get()).build(null));
    public static final RegistryObject<MenuType<StationMenu>> STATION_MENU = MENUS.register("station", () -> IForgeMenuType.create(StationMenu::new));
    public static final RegistryObject<Item> COURSE_EDITOR = ITEMS.register("course_editor", () -> new CourseEditorItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> COASTER_VEHICLE = ITEMS.register("coaster_vehicle", () -> new CoasterVehicleItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<EntityType<CoasterEntity>> COASTER = ENTITIES.register("coaster", () ->
            EntityType.Builder.<CoasterEntity>of(CoasterEntity::new, MobCategory.MISC)
                    .sized(1.8F, 1.2F).clientTrackingRange(128).updateInterval(1).fireImmune()
                    .build("coasterengineering:coaster"));

    private static RegistryObject<Block> rail(String name, MapColor color) {
        RegistryObject<Block> block = BLOCKS.register(name, () -> new Block(BlockBehaviour.Properties.of()
                .mapColor(color).strength(2F).sound(SoundType.METAL).noOcclusion().noCollission()));
        ITEMS.register(name, () -> new BlockItem(block.get(), new Item.Properties()));
        return block;
    }

    private CoasterRegistries() { }
}
