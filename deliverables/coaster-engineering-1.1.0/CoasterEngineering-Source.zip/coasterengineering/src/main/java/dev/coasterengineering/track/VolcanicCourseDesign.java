package dev.coasterengineering.track;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.WeakHashMap;

/**
 * Original Volcanic Abyss route, independent of Minecraft world construction.
 * Heights are relative to the lowest cavern. The route uses exploration motors,
 * a summit launch/drop, an underground river bend and an elevated outdoor return.
 * No inversions or vertical loops are enabled by this design.
 */
public final class VolcanicCourseDesign {
    public static final int STATION_DWELL_TICKS = 140; // seven-second design target
    private static final double HORIZONTAL_SCALE = .608;
    private static final double VERTICAL_SCALE = .9573;
    public static final double PROFILE_ACCELERATION = .012;
    public static final double PROFILE_BRAKING = .020;
    public static final double STATION_ARRIVAL_SPEED = .025;
    private static final Map<SplineTrack, Optional<Profile>> PROFILES = new WeakHashMap<>();
    private static final Map<SplineTrack, Optional<Profile>> SAVED_PROFILES = new WeakHashMap<>();

    private VolcanicCourseDesign() { }

    public static SplineTrack create(TrackVec3 origin) {
        return new SplineTrack(points(origin), true);
    }

    /** The straight first/last rail interval parks a four-car, four-block-spaced train. */
    public static List<ControlPoint> points(TrackVec3 origin) {
        Objects.requireNonNull(origin, "origin");
        return List.of(
                point(origin, 0, 12, -158, 0, RailKind.STATION, .32),
                point(origin, 0, 12, -128, 0, RailKind.STATION, .28),
                point(origin, 10, 12, -95, -8, RailKind.LIFT, .27),
                point(origin, 42, 30, -80, -12, RailKind.LIFT, .26),
                point(origin, 78, 50, -66, -18, RailKind.LIFT, .26),
                point(origin, 95, 65, -32, -12, RailKind.LIFT, .27),
                point(origin, 100, 70, 5, -8, RailKind.BOOST, .34),
                point(origin, 95, 70, 40, -20, RailKind.BOOST, .70),
                point(origin, 72, 70, 70, -25, RailKind.BOOST, 1.50),
                point(origin, 36, 48, 85, -12, RailKind.NORMAL, RideDynamics.MAX_SUPPORTED_SPEED),
                point(origin, -8, 18, 85, -18, RailKind.BRAKE, .55),
                point(origin, -42, 0, 72, -22, RailKind.BRAKE, .28),
                point(origin, -68, 0, 38, 12, RailKind.BOOST, .28),
                point(origin, -110, 4, 8, 25, RailKind.BOOST, .34),
                point(origin, -150, 8, 28, 30, RailKind.BOOST, .42),
                point(origin, -170, 12, 70, 30, RailKind.BOOST, .44),
                point(origin, -145, 15, 110, 22, RailKind.NORMAL, .46),
                point(origin, -100, 12, 132, 12, RailKind.NORMAL, .50),
                point(origin, -52, 8, 135, 20, RailKind.NORMAL, .48),
                point(origin, -18, 5, 112, 25, RailKind.BOOST, .45),
                point(origin, -14, 5, 75, -15, RailKind.BOOST, .40),
                point(origin, 6, 10, 40, -20, RailKind.BOOST, .45),
                point(origin, 40, 18, 20, -12, RailKind.BOOST, .64),
                point(origin, 85, 22, 15, -20, RailKind.BOOST, .90),
                point(origin, 135, 22, 34, -25, RailKind.BOOST, 1.40),
                point(origin, 165, 22, 70, -22, RailKind.BOOST, RideDynamics.MAX_SUPPORTED_SPEED),
                point(origin, 165, 22, 122, -30, RailKind.BOOST, RideDynamics.MAX_SUPPORTED_SPEED),
                point(origin, 130, 18, 158, -18, RailKind.BRAKE, .95),
                point(origin, 78, 14, 167, -8, RailKind.BOOST, .90),
                point(origin, 25, 18, 160, 0, RailKind.BOOST, 1.10),
                point(origin, -18, 25, 155, 10, RailKind.BOOST, RideDynamics.MAX_SUPPORTED_SPEED),
                point(origin, -70, 35, 158, -10, RailKind.BOOST, RideDynamics.MAX_SUPPORTED_SPEED),
                point(origin, -122, 35, 156, -18, RailKind.NORMAL, RideDynamics.MAX_SUPPORTED_SPEED),
                point(origin, -165, 35, 130, -25, RailKind.BRAKE, .85),
                point(origin, -177, 35, 80, -8, RailKind.BOOST, 1.20),
                point(origin, -175, 35, 25, -12, RailKind.NORMAL, RideDynamics.MAX_SUPPORTED_SPEED),
                point(origin, -155, 32, -30, -10, RailKind.BRAKE, 1.00),
                point(origin, -120, 24, -78, -6, RailKind.BRAKE, .65),
                point(origin, -82, 16, -125, -8, RailKind.BRAKE, .50),
                point(origin, -40, 12, -163, -15, RailKind.BRAKE, .40),
                point(origin, -12, 12, -200, -25, RailKind.BOOST, .25),
                point(origin, 0, 12, -196, 0, RailKind.BRAKE, .18),
                point(origin, 0, 12, -184, 0, RailKind.BRAKE, .12),
                point(origin, 0, 12, -176, 0, RailKind.BRAKE, .075),
                point(origin, 0, 12, -171, 0, RailKind.BRAKE, .045));
    }

    /** Update only rail settings, keeping every saved coordinate and bank bit-for-bit. */
    public static SplineTrack qualityUpdate(SplineTrack existing) {
        Objects.requireNonNull(existing, "existing");
        if (!sameGeometry(existing)) {
            throw new IllegalArgumentException("Quality profile requires the unchanged 45-point Volcanic route");
        }
        List<ControlPoint> settings = points(TrackVec3.ZERO);
        List<ControlPoint> updated = new ArrayList<>(settings.size());
        for (int i = 0; i < settings.size(); i++) {
            ControlPoint old = existing.points().get(i), desired = settings.get(i);
            updated.add(new ControlPoint(old.position(), old.bankDegrees(), desired.kind(), desired.targetSpeed()));
        }
        return new SplineTrack(updated, existing.closed());
    }

    /** Legacy saves and edited courses retain ordinary physics until explicitly upgraded. */
    public static boolean hasQualityProfile(SplineTrack track) {
        return profileIfUpdated(track) != null;
    }

    /** Cached by immutable track identity. Values do not retain their weak map keys. */
    public static Profile profileIfUpdated(SplineTrack track) {
        Objects.requireNonNull(track, "track");
        synchronized (PROFILES) {
            return PROFILES.computeIfAbsent(track, candidate -> {
                if (!sameGeometry(candidate)) return Optional.empty();
                List<ControlPoint> settings = points(TrackVec3.ZERO);
                for (int i = 0; i < settings.size(); i++) {
                    ControlPoint actual = candidate.points().get(i), expected = settings.get(i);
                    if (actual.kind() != expected.kind()
                            || Double.compare(actual.targetSpeed(), expected.targetSpeed()) != 0) return Optional.empty();
                }
                return Optional.of(new Profile(candidate));
            }).orElse(null);
        }
    }

    public static Profile profile(SplineTrack track) {
        Profile profile = profileIfUpdated(track);
        if (profile == null) throw new IllegalArgumentException("Track has not received the Volcanic quality profile");
        return profile;
    }

    /**
     * Retain interpolation after an operator edits saved section speed targets.
     * Callers must gate this API with the world's persisted quality opt-in marker.
     * A changed route geometry cannot silently inherit the original ride program.
     */
    public static Profile profileOfSavedTargets(SplineTrack track) {
        Objects.requireNonNull(track, "track");
        synchronized (SAVED_PROFILES) {
            return SAVED_PROFILES.computeIfAbsent(track,
                    candidate -> sameGeometry(candidate) ? Optional.of(new Profile(candidate)) : Optional.empty())
                    .orElse(null);
        }
    }

    private static boolean sameGeometry(SplineTrack track) {
        if (!track.closed() || track.points().size() != 45) return false;
        List<ControlPoint> original = points(TrackVec3.ZERO);
        TrackVec3 offset = track.points().get(0).position().subtract(original.get(0).position());
        for (int i = 0; i < original.size(); i++) {
            ControlPoint actual = track.points().get(i), expected = original.get(i);
            if (actual.position().subtract(expected.position().add(offset)).length() > 1e-8
                    || Double.compare(actual.bankDegrees(), expected.bankDegrees()) != 0) return false;
        }
        return true;
    }

    public enum Stage {
        EXPLORE(0), ANOMALY(6), DROP(8), MONSTER(11), CAVERN(14), CLIMAX(22), RETURN(37);
        private final int firstPoint;
        Stage(int firstPoint) { this.firstPoint = firstPoint; }
        public int firstPoint() { return firstPoint; }
    }

    /**
     * Cubic smoothstep targets in arc distance, with a backward braking envelope.
     * The final arrival target intentionally differs from the next departure target:
     * the entity parks at the seam after one lap, before a later station dispatch.
     */
    public static final class Profile implements RideDynamics.SpeedProfile {
        private static final double MAX_INTERVAL = .25;
        private final double length;
        private final double[] knots;
        private final double[] targets;
        private final double[] safeTargets;
        private final double interval;

        private Profile(SplineTrack track) {
            length = track.length();
            knots = new double[track.points().size() + 1];
            targets = new double[knots.length];
            for (int i = 0; i < track.points().size(); i++) {
                knots[i] = track.controlPointDistance(i);
                targets[i] = track.points().get(i).targetSpeed();
            }
            knots[knots.length - 1] = length;
            targets[targets.length - 1] = STATION_ARRIVAL_SPEED;
            int intervals = (int) Math.ceil(length / MAX_INTERVAL);
            interval = length / intervals;
            safeTargets = new double[intervals + 1];
            for (int i = 0; i < safeTargets.length; i++) safeTargets[i] = rawTargetSpeed(i * interval);
            for (int i = safeTargets.length - 2; i >= 0; i--) {
                safeTargets[i] = Math.min(safeTargets[i], Math.sqrt(safeTargets[i + 1] * safeTargets[i + 1]
                        + 2 * PROFILE_BRAKING * interval));
            }
        }

        @Override
        public double targetSpeed(double distance) {
            double bounded = bound(distance);
            double index = bounded / interval;
            int lower = Math.min((int) index, safeTargets.length - 2);
            double fraction = index - lower;
            return safeTargets[lower] + (safeTargets[lower + 1] - safeTargets[lower]) * fraction;
        }

        @Override
        public double maximumAcceleration() { return PROFILE_ACCELERATION; }

        @Override
        public double maximumBraking() { return PROFILE_BRAKING; }

        public double rawTargetSpeed(double distance) {
            double bounded = bound(distance);
            int segment = Arrays.binarySearch(knots, bounded);
            if (segment >= 0) return targets[segment];
            segment = -segment - 2;
            double fraction = (bounded - knots[segment]) / (knots[segment + 1] - knots[segment]);
            double smooth = fraction * fraction * (3 - 2 * fraction);
            return targets[segment] + (targets[segment + 1] - targets[segment]) * smooth;
        }

        public Stage stage(double distance) {
            double bounded = bound(distance);
            Stage result = Stage.EXPLORE;
            for (Stage stage : Stage.values()) {
                if (bounded >= knots[stage.firstPoint()]) result = stage;
            }
            return result;
        }

        public double stageStart(Stage stage) {
            return knots[Objects.requireNonNull(stage, "stage").firstPoint()];
        }

        private double bound(double distance) {
            if (!Double.isFinite(distance)) throw new IllegalArgumentException("Profile distance must be finite");
            return Math.max(0, Math.min(length, distance));
        }
    }

    /** Geometry and deterministic tick simulation; does not certify world clearance. */
    public static Metrics measure(SplineTrack track) {
        Objects.requireNonNull(track, "track");
        double minimum = Double.POSITIVE_INFINITY, maximum = Double.NEGATIVE_INFINITY;
        int samples = (int) Math.ceil(track.length() / .25);
        for (int i = 0; i <= samples; i++) {
            double y = track.sample(track.length() * i / samples).position().y();
            minimum = Math.min(minimum, y);
            maximum = Math.max(maximum, y);
        }
        RideDynamics.Step state = new RideDynamics.Step(0, 0, false, true);
        Profile profile = profileIfUpdated(track);
        double peakSpeed = 0;
        int tick;
        for (tick = 1; tick <= 12_000; tick++) {
            state = profile == null
                    ? RideDynamics.advance(track, state.distance(), state.speed(), true, RideDynamics.MAX_SUPPORTED_SPEED)
                    : RideDynamics.advanceProfiled(track, state.distance(), state.speed(), true,
                            RideDynamics.MAX_SUPPORTED_SPEED, PROFILE_ACCELERATION, profile);
            peakSpeed = Math.max(peakSpeed, state.speed());
            if (state.crossedFinish() || state.stopped()) break;
        }
        return new Metrics(track.length(), minimum, maximum, Math.min(tick, 12_000),
                peakSpeed, state.crossedFinish());
    }

    public record Metrics(double length, double minimumY, double maximumY, int travelTicks,
                          double maximumSpeed, boolean completed) {
        public double elevationRange() { return maximumY - minimumY; }
        public double travelSeconds() { return travelTicks / 20.0; }
        public double experienceSeconds() { return (travelTicks + STATION_DWELL_TICKS) / 20.0; }
        public double maximumKmh() { return maximumSpeed * 72; }
    }

    private static ControlPoint point(TrackVec3 origin, double x, double y, double z, double bank,
                                      RailKind kind, double target) {
        return new ControlPoint(origin.add(new TrackVec3(x * HORIZONTAL_SCALE,
                12 + (y - 12) * VERTICAL_SCALE, z * HORIZONTAL_SCALE)),
                bank, kind, target);
    }
}
