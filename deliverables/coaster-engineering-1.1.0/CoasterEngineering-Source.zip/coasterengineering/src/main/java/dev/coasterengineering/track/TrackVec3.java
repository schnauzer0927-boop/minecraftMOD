package dev.coasterengineering.track;

import java.util.Objects;

/** A finite position or direction, kept independent of Minecraft for deterministic tests. */
public record TrackVec3(double x, double y, double z) {
    public static final TrackVec3 ZERO = new TrackVec3(0, 0, 0);

    public TrackVec3 {
        if (!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z)) {
            throw new IllegalArgumentException("Track coordinates must be finite");
        }
    }

    public TrackVec3 add(TrackVec3 other) {
        Objects.requireNonNull(other, "other");
        return new TrackVec3(x + other.x, y + other.y, z + other.z);
    }

    public TrackVec3 subtract(TrackVec3 other) {
        Objects.requireNonNull(other, "other");
        return new TrackVec3(x - other.x, y - other.y, z - other.z);
    }

    public TrackVec3 scale(double factor) {
        if (!Double.isFinite(factor)) throw new IllegalArgumentException("Scale must be finite");
        return new TrackVec3(x * factor, y * factor, z * factor);
    }

    public double dot(TrackVec3 other) {
        Objects.requireNonNull(other, "other");
        double value = x * other.x + y * other.y + z * other.z;
        if (!Double.isFinite(value)) throw new IllegalArgumentException("Dot product overflow");
        return value;
    }

    public TrackVec3 cross(TrackVec3 other) {
        Objects.requireNonNull(other, "other");
        // The vector constructor rejects overflow and indeterminate products.
        return new TrackVec3(y * other.z - z * other.y,
                z * other.x - x * other.z, x * other.y - y * other.x);
    }

    public double length() {
        double value = Math.hypot(Math.hypot(x, y), z);
        if (!Double.isFinite(value)) throw new IllegalArgumentException("Vector length overflow");
        return value;
    }

    public TrackVec3 normalized() {
        double magnitude = length();
        return magnitude > 0 ? new TrackVec3(x / magnitude, y / magnitude, z / magnitude) : ZERO;
    }
}
