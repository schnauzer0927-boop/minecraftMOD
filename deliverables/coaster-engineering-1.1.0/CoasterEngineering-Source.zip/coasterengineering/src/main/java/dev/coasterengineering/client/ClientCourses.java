package dev.coasterengineering.client;

import dev.coasterengineering.track.SplineTrack;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Updated only on the client main thread by course synchronization packets. */
public final class ClientCourses {
    private static final Map<UUID, SplineTrack> COURSES = new LinkedHashMap<>();

    private ClientCourses() { }

    public static void update(UUID id, SplineTrack track) {
        COURSES.put(id, track);
        TrackRenderer.invalidate(id);
    }

    public static void remove(UUID id) {
        COURSES.remove(id);
        TrackRenderer.invalidate(id);
    }

    public static void clear() {
        COURSES.clear();
        TrackRenderer.clear();
    }

    static Map<UUID, SplineTrack> all() {
        return COURSES;
    }
}
