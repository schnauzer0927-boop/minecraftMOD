package dev.coasterengineering.network;

import dev.coasterengineering.client.ClientCourses;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.world.Course;
import io.netty.handler.codec.DecoderException;
import java.util.ArrayList;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** Server-to-client immutable geometry; clients cannot author or move server courses. */
public record CoursePacket(int action, UUID id, SplineTrack track) {
    public static CoursePacket clear() { return new CoursePacket(0, new UUID(0, 0), null); }
    public static CoursePacket update(Course c) { return new CoursePacket(1, c.id(), c.track()); }
    public static CoursePacket remove(UUID id) { return new CoursePacket(2, id, null); }

    public static void encode(CoursePacket p, FriendlyByteBuf buffer) {
        buffer.writeVarInt(p.action());
        buffer.writeUUID(p.id());
        if (p.action() != 1) return;
        buffer.writeBoolean(p.track().closed());
        buffer.writeVarInt(p.track().points().size());
        for (ControlPoint point : p.track().points()) {
            buffer.writeDouble(point.position().x());
            buffer.writeDouble(point.position().y());
            buffer.writeDouble(point.position().z());
            buffer.writeDouble(point.bankDegrees());
            buffer.writeEnum(point.kind());
            buffer.writeDouble(point.targetSpeed());
        }
    }

    public static CoursePacket decode(FriendlyByteBuf buffer) {
        int action = buffer.readVarInt();
        if (action < 0 || action > 2) throw new DecoderException("Unknown coaster packet action");
        UUID id = buffer.readUUID();
        if (action != 1) return new CoursePacket(action, id, null);
        boolean closed = buffer.readBoolean();
        int count = buffer.readVarInt();
        if (count < (closed ? 4 : 2) || count > 128) throw new DecoderException("Invalid coaster node count");
        ArrayList<ControlPoint> points = new ArrayList<>();
        try {
            for (int i = 0; i < count; i++) {
                TrackVec3 pos = new TrackVec3(buffer.readDouble(), buffer.readDouble(), buffer.readDouble());
                if (Math.abs(pos.x()) > 29_999_000 || Math.abs(pos.z()) > 29_999_000 || Math.abs(pos.y()) > 2048)
                    throw new DecoderException("Coaster position outside coordinate bounds");
                points.add(new ControlPoint(pos, buffer.readDouble(), buffer.readEnum(RailKind.class), buffer.readDouble()));
            }
            SplineTrack track = new SplineTrack(points, closed);
            if (track.length() > 16_000) throw new DecoderException("Coaster course too long");
            return new CoursePacket(1, id, track);
        } catch (IllegalArgumentException e) {
            throw new DecoderException("Invalid coaster geometry", e);
        }
    }

    public static void handle(CoursePacket packet, Supplier<NetworkEvent.Context> context) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            if (packet.action() == 0) ClientCourses.clear();
            else if (packet.action() == 1) ClientCourses.update(packet.id(), packet.track());
            else ClientCourses.remove(packet.id());
        });
        context.get().setPacketHandled(true);
    }
}
