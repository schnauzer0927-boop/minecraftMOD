package dev.coasterengineering.world;

import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.network.CoasterNetwork;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.track.VolcanicCourseDesign;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Opt-in, bounded update of the existing park; never rebuilds or clears the world. */
@Mod.EventBusSubscriber(modid = CoasterEngineering.MOD_ID)
public final class WorldQualityUpgradeService {
    private static final TicketType<UUID> TICKET = TicketType.create("coasterengineering_quality", UUID::compareTo);
    private static final int MAX_CHUNKS = 1024, MAX_PLACEMENTS = 150_000, TIMEOUT = 6000;
    private static final Map<ServerLevel, Job> ACTIVE = new IdentityHashMap<>();
    private static final Map<ServerLevel, String> STATUS = new IdentityHashMap<>();
    private static final int[][] ROOMS = {{-72,80,15,24,16,24},{45,83,40,24,19,24},{-29,83,10,22,22,22}};

    private WorldQualityUpgradeService() { }

    public static boolean begin(ServerLevel level) { return begin(level, false); }

    /** Acceptance is asynchronous. A marker is written only after successful final validation. */
    public static boolean begin(ServerLevel level, boolean reapply) {
        if (level == null) return false;
        if (!level.getServer().isSameThread()) throw new IllegalStateException("Quality updates require the server thread");
        if (ACTIVE.containsKey(level)) return false;
        try {
            if (!level.dimension().equals(Level.OVERWORLD) || level.getSeed() != VolcanicWorldBuilder.WORLD_SEED)
                throw invalid("Use the original Volcanic Abyss Overworld with seed 20261011");
            if (!reapply && WorldQualityUpgradeData.get(level).isApplied())
                throw invalid("Quality version1 is already applied; use explicit reapply to restore its lighting and speed targets");
            Course course = CoasterSavedData.get(level).getCourse(VolcanicWorldBuilder.COURSE_ID);
            if (course == null || !course.enabled()) throw invalid("The completed Volcanic Abyss course is missing or disabled");
            requireSameGeometry(VolcanicCourseDesign.create(new TrackVec3(.5,82,.5)), course.track());
            CoasterEntity leader = requireLeader(level, course);
            requirePausedEmpty(level, course, leader);
            Job job = new Job(level, course, leader);
            ACTIVE.put(level, job);
            STATUS.remove(level);
            CoasterEngineering.LOGGER.info("VOLCANIC_QUALITY_BEGIN course={} cars={} oldVersion={} reapply={}",
                    course.id(), job.cars.size(), WorldQualityUpgradeData.get(level).version(), reapply);
            return true;
        } catch (RuntimeException failure) {
            STATUS.put(level, "REJECTED: " + message(failure));
            return false;
        }
    }

    public static boolean isActive(ServerLevel level, UUID courseId) {
        Job job = ACTIVE.get(level);
        return job != null && job.original.id().equals(courseId);
    }

    public static String status(ServerLevel level) {
        if (level == null) return "The server world is not ready";
        Job job = ACTIVE.get(level);
        return job == null ? STATUS.getOrDefault(level, WorldQualityUpgradeData.get(level).report()) : job.describe();
    }

    public static boolean cancel(ServerLevel level) {
        Job job = ACTIVE.get(level);
        if (job == null) return false;
        job.finish(false, "Cancelled; already applied safe scenery remains; saved speed settings were not changed");
        return true;
    }

    /** Exact comparison deliberately includes every bank and the closed-loop flag. */
    public static void requireSameGeometry(SplineTrack original, SplineTrack candidate) {
        if (original.closed() != candidate.closed() || original.points().size() != candidate.points().size())
            throw invalid("The original 45-point closed course geometry must be preserved");
        for (int i = 0; i < original.points().size(); i++) {
            var a = original.points().get(i); var b = candidate.points().get(i);
            if (!a.position().equals(b.position()) || Double.compare(a.bankDegrees(), b.bankDegrees()) != 0)
                throw invalid("Course position or bank differs at point " + (i + 1) + "; geometry was not updated");
        }
    }

    /** Pure deterministic candidates. The runtime applies rock only into existing air. */
    public static Map<BlockPos, BlockState> tunnelRepairs(SplineTrack track) {
        return tunnelRepairs(track, QualityLightingPlan.protectedCells(track));
    }

    public static Map<BlockPos, BlockState> tunnelRepairs(SplineTrack track, Set<BlockPos> protectedCells) {
        requireSameGeometry(VolcanicCourseDesign.create(new TrackVec3(.5,82,.5)), track);
        Set<BlockPos> station = ParkStructures.station(track).keySet();
        List<TrackVec3> outdoor = new ArrayList<>();
        for (double d = 0; d < track.length(); d += .5) {
            TrackVec3 p = track.sample(d).position();
            if (p.y() >= surface(p.x(), p.z()) - 6) outdoor.add(p);
        }
        Map<BlockPos, BlockState> result = new LinkedHashMap<>();
        for (double d = 0; d < track.length(); d += .5) {
            TrackSample sample = track.sample(d);
            TrackVec3 p = sample.position();
            double roofDepth = surface(p.x(), p.z()) - p.y();
            if (roofDepth <= 6 || roofDepth > 13 && !junction(p)) continue;
            TrackFrame frame = TrackFrame.from(sample);
            for (int x = -7; x <= 7; x++) for (int y = -7; y <= 7; y++) for (int z = -7; z <= 7; z++) {
                BlockPos pos = BlockPos.containing(p.x()+x,p.y()+y,p.z()+z);
                TrackVec3 offset = new TrackVec3(pos.getX()+.5-p.x(), pos.getY()+.5-p.y(), pos.getZ()+.5-p.z());
                if (Math.abs(offset.dot(frame.forward())) > .85) continue;
                double r = Math.hypot(offset.dot(frame.right()), offset.dot(frame.up()));
                if (r < 5.5 || r > 6.6 || protectedCells.contains(pos) || station.contains(pos)) continue;
                // Keep the original cone outline and the actual cavern interior open.
                if (pos.getY() > surface(pos.getX(),pos.getZ()) || roomInterior(pos)) continue;
                if (nearOutdoor(pos, outdoor)) continue;
                result.put(pos, stone(pos));
                if (result.size() > MAX_PLACEMENTS) throw invalid("Tunnel repair plan exceeds its bounded placement budget");
            }
        }
        return Map.copyOf(result);
    }

    @SubscribeEvent public static void tick(TickEvent.LevelTickEvent event) {
        if (!(event.level instanceof ServerLevel level)) return;
        Job job = ACTIVE.get(level);
        if (job == null) return;
        if (event.phase == TickEvent.Phase.START) { level.resetEmptyTime(); return; }
        try { job.tick(); }
        catch (RuntimeException failure) { job.finish(false, message(failure)); }
    }

    @SubscribeEvent public static void stopping(ServerStoppingEvent event) {
        for (Job job : List.copyOf(ACTIVE.values())) if (job.level.getServer() == event.getServer())
            job.finish(false, "Server stopped; retry this deterministic upgrade after loading the backup or unchanged course");
        STATUS.keySet().removeIf(level -> level.getServer() == event.getServer());
    }

    private static final class Job {
        final ServerLevel level;
        final Course original;
        final Course updated;
        final UUID leaderId, ticketId = UUID.randomUUID();
        final List<CarSnapshot> cars;
        final long started;
        final CompletableFuture<Plan> preparing;
        final Map<ChunkPos, CompletableFuture<Optional<CompoundTag>>> disk = new LinkedHashMap<>();
        final Set<ChunkPos> footprint = new LinkedHashSet<>(), tickets = new LinkedHashSet<>();
        final List<Change> changes = new ArrayList<>();
        Plan plan;
        List<Map.Entry<BlockPos, Target>> entries;
        String phase = "PLANNING";
        int cursor, preserved, repairs, lights;
        double distance;
        long lightingReadyAt;
        int lightingAttempt, lightSamples, lowLight, minimumLight, minimumBlockLight;
        long lightSum, blockLightSum;
        List<QualityLightingPlan.LightProbe> lightProbes;
        boolean committed;

        Job(ServerLevel level, Course course, CoasterEntity leader) {
            this.level = level; original = course; leaderId = leader.getUUID(); started = level.getGameTime();
            SplineTrack candidate = VolcanicCourseDesign.qualityUpdate(course.track());
            requireSameGeometry(course.track(), candidate);
            updated = new Course(course.id(),course.name(),candidate,course.station(),course.enabled());
            cars = leader.getLoadedFormation().stream().map(CarSnapshot::new).toList();
            preparing = CompletableFuture.supplyAsync(() -> plan(candidate), Util.backgroundExecutor());
        }

        void tick() {
            if (level.getGameTime() - started > TIMEOUT) throw invalid("Quality update exceeded6000 actual world ticks");
            requireUnchanged();
            long deadline = System.nanoTime() + 12_000_000;
            int work = 0;
            if (phase.equals("PLANNING")) {
                if (!preparing.isDone()) return;
                plan = preparing.join(); entries = new ArrayList<>(plan.targets.entrySet());
                for (BlockPos pos : plan.targets.keySet()) footprint.add(new ChunkPos(pos));
                for (double d=0; d<original.track().length(); d+=1) {
                    TrackVec3 p=original.track().sample(d).position();
                    for (int dx : new int[]{-4,4}) for (int dz : new int[]{-4,4})
                        footprint.add(new ChunkPos(BlockPos.containing(p.x()+dx,p.y(),p.z()+dz)));
                }
                Set<ChunkPos> halo = new LinkedHashSet<>();
                for (ChunkPos c:footprint) for(int dx=-2;dx<=2;dx++) for(int dz=-2;dz<=2;dz++) {
                    halo.add(new ChunkPos(c.x+dx,c.z+dz));
                    if(halo.size()>MAX_CHUNKS) throw invalid("Upgrade chunk halo exceeds1024 existing chunks");
                }
                for (ChunkPos c:halo) if(level.getChunkSource().getChunkNow(c.x,c.z)==null)
                    disk.put(c,level.getChunkSource().chunkMap.read(c));
                phase="CHECKING_SAVED_CHUNKS";
                logProgress(); return;
            }
            if(phase.equals("CHECKING_SAVED_CHUNKS")) {
                for(var check:disk.entrySet()) {
                    if(!check.getValue().isDone()) return;
                    Optional<CompoundTag> saved=check.getValue().join();
                    if(saved.isEmpty() || ChunkStatus.byName(saved.get().getString("Status"))!=ChunkStatus.FULL)
                        throw invalid("Missing or unfinished saved chunk "+check.getKey()+"; upgrade will not generate it");
                }
                for(ChunkPos c:footprint) { level.getChunkSource().addRegionTicket(TICKET,c,2,ticketId); tickets.add(c); }
                phase="LOADING_EXISTING_CHUNKS"; logProgress(); return;
            }
            if(phase.equals("LOADING_EXISTING_CHUNKS")) {
                for(ChunkPos c:footprint) if(level.getChunkSource().getChunkNow(c.x,c.z)==null) return;
                phase="PREFLIGHT"; cursor=0; logProgress();
            }
            if(phase.equals("PREFLIGHT")) {
                while(cursor<entries.size() && work++<4096 && System.nanoTime()<deadline) {
                    var entry=entries.get(cursor++); BlockPos pos=entry.getKey(); Target target=entry.getValue();
                    if(!level.getWorldBorder().isWithinBounds(pos) || level.isOutsideBuildHeight(pos))
                        throw invalid("A planned quality cell is outside world limits");
                    BlockState current=level.getBlockState(pos);
                    if(current.equals(target.state)) continue;
                    if(level.getBlockEntity(pos)!=null || !eligible(pos,current,target)) { preserved++; continue; }
                    changes.add(new Change(pos,current,target));
                }
                if(cursor==entries.size()) { phase="BASELINE_CLEARANCE"; distance=0; logProgress(); }
                return;
            }
            if(phase.equals("BASELINE_CLEARANCE") || phase.equals("FINAL_CLEARANCE")) {
                CoasterEntity leader=requireLeader(level,original);
                while(distance<updated.track().length() && work++<192 && System.nanoTime()<deadline) {
                    if(!leader.canUseTrackSample(updated.track().sample(distance)))
                        throw invalid("Body or upright-rider clearance failed at distance "+String.format(Locale.ROOT,"%.2f",distance));
                    distance+=.25;
                }
                if(distance<updated.track().length()) return;
                if(!leader.canPlaceFormationOnTrack(updated.track(),leader.getDistance()))
                    throw invalid("The unchanged parked formation lacks safe clearance");
                if(phase.equals("BASELINE_CLEARANCE")) { phase="APPLYING"; cursor=0; logProgress(); }
                else {
                    phase="LIGHT_PROPAGATION"; lightingReadyAt=level.getGameTime()+40;
                    lightProbes=QualityLightingPlan.passengerLightProbes(updated.track());
                    logProgress();
                }
                return;
            }
            if(phase.equals("APPLYING")) {
                while(cursor<changes.size() && work++<2048 && System.nanoTime()<deadline) {
                    Change change=changes.get(cursor++);
                    if(!level.getBlockState(change.pos).equals(change.before) || level.getBlockEntity(change.pos)!=null)
                        throw invalid("A world block changed after preflight at "+change.pos+"; saved ride settings remain unchanged");
                    if(!level.setBlock(change.pos,change.target.state,Block.UPDATE_CLIENTS))
                        throw invalid("Could not safely apply quality cell at "+change.pos);
                    if(change.target.repair) repairs++; else lights++;
                }
                if(cursor==changes.size()) { phase="FINAL_CLEARANCE"; distance=0; logProgress(); }
                return;
            }
            if(phase.equals("LIGHT_PROPAGATION")) {
                if(level.getGameTime()<lightingReadyAt) return;
                phase="LIGHTING_AUDIT"; cursor=0; lightSamples=lowLight=0;
                minimumLight=minimumBlockLight=15; lightSum=blockLightSum=0; lightingAttempt++;
            }
            if(phase.equals("LIGHTING_AUDIT")) {
                while(cursor<lightProbes.size() && work++<192 && System.nanoTime()<deadline) {
                    var probe=lightProbes.get(cursor++);
                    int block=level.getBrightness(LightLayer.BLOCK,probe.position());
                    int sky=level.getBrightness(LightLayer.SKY,probe.position());
                    int combined=Math.max(block,sky);
                    lightSamples++; lightSum+=combined; blockLightSum+=block;
                    minimumLight=Math.min(minimumLight,combined); minimumBlockLight=Math.min(minimumBlockLight,block);
                    if(combined<probe.minimumBrightness()) {
                        if(lightingAttempt==1 && lowLight<8)
                            CoasterEngineering.LOGGER.info("VOLCANIC_QUALITY_DIM_PROBE distance={} seat={} pos={} block={} sky={} target={}",
                                    probe.distance(),probe.seat(),probe.position(),block,sky,probe.minimumBrightness());
                        lowLight++;
                    }
                }
                if(cursor<lightProbes.size()) return;
                CoasterEngineering.LOGGER.info("VOLCANIC_QUALITY_LIGHTING_AUDIT attempt={} samples={} belowTarget={} min={} mean={} blockMin={} blockMean={} stationTarget=9 routeTarget=6",
                        lightingAttempt,lightSamples,lowLight,minimumLight,lightSum/(double)Math.max(1,lightSamples),
                        minimumBlockLight,blockLightSum/(double)Math.max(1,lightSamples));
                if(lowLight==0) { commit(); return; }
                if(lightingAttempt>=10) throw invalid("Passenger-eye lighting remained below station9/route6 at "+lowLight
                        +" of "+lightSamples+" probes after10 propagation checks; protected custom blocks remain intact");
                phase="LIGHT_PROPAGATION"; lightingReadyAt=level.getGameTime()+40; logProgress();
            }
        }

        void requireUnchanged() {
            CoasterSavedData data=CoasterSavedData.get(level);
            if(data.getCourse(original.id())!=original || !leaderId.equals(data.vehicleId(original.id())))
                throw invalid("Course or reserved train changed during upgrade");
            CoasterEntity leader=requireLeader(level,original);
            requirePausedEmpty(level,original,leader);
            List<CoasterEntity> actual=leader.getLoadedFormation();
            if(actual.size()!=cars.size()) throw invalid("The original train formation changed");
            for(int i=0;i<actual.size();i++) if(!cars.get(i).unchanged(actual.get(i)))
                throw invalid("Original car UUID, distance, lap counter or position changed during upgrade");
        }

        void commit() {
            requireUnchanged(); requireSameGeometry(original.track(),updated.track());
            CoasterSavedData.get(level).putCourse(updated);
            committed=true;
            String audit="COMPLETED qualityVersion=1 course="+original.id()+"; original45 positions/banks, station and "+cars.size()
                    +" vehicle UUIDs/poses preserved; repaired air cells="+repairs+"; lighting cells="+lights
                    +"; preserved occupied/edited cells="+preserved+"; .25-block body/upright-rider clearance passed; temporary tickets released";
            audit += "; passenger-eye light probes="+lightSamples+" belowTarget="+lowLight+" min="+minimumLight
                    +" mean="+String.format(Locale.ROOT,"%.2f",lightSum/(double)Math.max(1,lightSamples))
                    +" blockMin="+minimumBlockLight+" blockMean="+String.format(Locale.ROOT,"%.2f",blockLightSum/(double)Math.max(1,lightSamples));
            WorldQualityUpgradeData.get(level).completed(audit);
            try { CoasterNetwork.broadcastCourse(level,updated); }
            catch(RuntimeException networkFailure) {
                CoasterEngineering.LOGGER.warn("Quality update committed; client course resync will retry on login",networkFailure);
            }
            finish(true,audit);
        }

        String describe() {
            return phase+"; qualityVersion="+WorldQualityUpgradeData.get(level).version()+"; course="+original.id()
                    +"; cells="+cursor+"/"+(entries==null?0:entries.size())+"; repairs="+repairs+"; lights="+lights
                    +"; temporary chunks="+tickets.size()+"; dispatch and boarding blocked";
        }

        void logProgress() { CoasterEngineering.LOGGER.info("VOLCANIC_QUALITY_PROGRESS {}",describe()); }

        void finish(boolean success,String reason) {
            if(ACTIVE.get(level)!=this) return;
            for(ChunkPos c:tickets) level.getChunkSource().removeRegionTicket(TICKET,c,2,ticketId);
            tickets.clear(); ACTIVE.remove(level);
            String result=success?reason:"FAILED at "+phase+": "+reason+"; safe applied scenery remains; quality marker was not changed";
            STATUS.put(level,result);
            if(success) CoasterEngineering.LOGGER.info("VOLCANIC_QUALITY_COMPLETED {}",result);
            else CoasterEngineering.LOGGER.warn("VOLCANIC_QUALITY_FAILED {} committed={}",result,committed);
        }
    }

    private static Plan plan(SplineTrack track) {
        Set<BlockPos> protectedCells=QualityLightingPlan.protectedCells(track);
        Map<BlockPos,Target> targets=new LinkedHashMap<>();
        tunnelRepairs(track,protectedCells).forEach((pos,state)->targets.put(pos,new Target(state,true)));
        VolcanicDecor.qualityUpgrade(track,protectedCells).forEach((pos,state)->targets.put(pos,new Target(state,false)));
        ParkStructures.qualityUpgrade(track,protectedCells).forEach((pos,state)->targets.put(pos,new Target(state,false)));
        if(targets.size()>MAX_PLACEMENTS) throw invalid("Quality plan exceeds150000 cells");
        for(BlockPos pos:targets.keySet()) if(protectedCells.contains(pos))
            throw invalid("A quality placement entered the protected car or upright passenger envelope");
        return new Plan(Map.copyOf(targets));
    }

    private static boolean eligible(BlockPos pos,BlockState old,Target target) {
        if(target.repair) return old.isAir();
        if(target.state.is(Blocks.LIGHT)) return old.isAir() || old.is(Blocks.LIGHT);
        if(QualityLightingPlan.requiresExistingSolid(pos) && (old.isAir() || old.is(Blocks.LIGHT))) return false;
        if(old.is(Blocks.BLACK_CONCRETE) && pos.getY()==103 && pos.getX()==-7
                && pos.getZ()>=-110 && pos.getZ()<=-90) return true;
        return old.isAir() || old.is(Blocks.BASALT) || old.is(Blocks.DEEPSLATE) || old.is(Blocks.BLACKSTONE)
                || old.is(Blocks.POLISHED_BLACKSTONE) || old.is(Blocks.POLISHED_DEEPSLATE)
                || old.is(Blocks.BLUE_STAINED_GLASS) || old.is(Blocks.CYAN_STAINED_GLASS)
                || old.is(Blocks.SEA_LANTERN) || old.is(Blocks.SHROOMLIGHT) || old.is(Blocks.LIGHT);
    }

    private static CoasterEntity requireLeader(ServerLevel level,Course course) {
        UUID id=CoasterSavedData.get(level).vehicleId(course.id()); Entity entity=id==null?null:level.getEntity(id);
        if(!(entity instanceof CoasterEntity leader) || leader.isRemoved() || !leader.isTrainLeader()
                || !course.id().equals(leader.courseId())) throw invalid("The original reserved leader must be loaded");
        return leader;
    }

    private static void requirePausedEmpty(ServerLevel level,Course course,CoasterEntity leader) {
        List<CoasterEntity> cars=leader.getLoadedFormation();
        if(cars.size()!=leader.carCount()) throw invalid("All original train cars must be loaded");
        if(Math.abs(leader.getDistance())>1e-6) throw invalid("Park the empty train at its station before upgrading");
        for(CoasterEntity car:cars) if(car.isRemoved() || car.isRunning() || car.getSpeed()!=0 || car.isVehicle()
                || !course.id().equals(car.courseId())) throw invalid("Every original car must be stopped and empty");
        for(Entity entity:level.getAllEntities()) if(entity instanceof CoasterEntity car && !car.isRemoved()
                && course.id().equals(car.courseId()) && !cars.contains(car)) throw invalid("An extra vehicle exists on this course");
    }

    private static boolean junction(TrackVec3 p) {
        for(int[] room:ROOMS) {
            double expanded=norm(p.x(),p.y(),p.z(),room,7), inner=norm(p.x(),p.y(),p.z(),room,-5);
            if(expanded<=1 && inner>1) return true;
        }
        return false;
    }

    private static boolean roomInterior(BlockPos p) {
        for(int[] room:ROOMS) if(norm(p.getX()+.5,p.getY()+.5,p.getZ()+.5,room,0)<.77) return true;
        return false;
    }

    private static double norm(double x,double y,double z,int[] room,int extra) {
        double a=(x-room[0])/(room[3]+extra), b=(y-room[1])/(room[4]+extra), c=(z-room[2])/(room[5]+extra);
        return a*a+b*b+c*c;
    }

    private static boolean nearOutdoor(BlockPos pos,List<TrackVec3> outdoor) {
        for(TrackVec3 p:outdoor) if(Math.abs(p.x()-pos.getX())<9 && Math.abs(p.z()-pos.getZ())<9
                && new TrackVec3(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5).subtract(p).length()<8.5) return true;
        return false;
    }

    private static int surface(double x,double z) {
        double r=Math.hypot(x-.5,z-.5), ring=5*Math.exp(-Math.pow((r-28)/7,2));
        return (int)Math.floor(Math.max(64,Math.min(174,174-110*r*r/(140*140)+ring)));
    }

    private static BlockState stone(BlockPos pos) {
        long hash=VolcanicWorldBuilder.WORLD_SEED ^ pos.getX()*341873128712L ^ pos.getY()*132897987541L ^ pos.getZ()*42317861L;
        hash^=hash>>>33; int value=(int)Math.floorMod(hash,100);
        return (value<70?Blocks.BASALT:value<90?Blocks.DEEPSLATE:Blocks.BLACKSTONE).defaultBlockState();
    }

    private record Target(BlockState state,boolean repair) { }
    private record Change(BlockPos pos,BlockState before,Target target) { }
    private record Plan(Map<BlockPos,Target> targets) { }
    private record CarSnapshot(UUID id,double distance,int laps,Vec3 position) {
        CarSnapshot(CoasterEntity car) { this(car.getUUID(),car.getDistance(),car.getLaps(),car.position()); }
        boolean unchanged(CoasterEntity car) {
            return id.equals(car.getUUID()) && Double.compare(distance,car.getDistance())==0 && laps==car.getLaps()
                    && position.distanceToSqr(car.position())<1e-12;
        }
    }
    private static IllegalStateException invalid(String text) { return new IllegalStateException(text); }
    private static String message(RuntimeException error) { return error.getMessage()==null?error.getClass().getSimpleName():error.getMessage(); }
}
