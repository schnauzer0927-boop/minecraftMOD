package dev.coasterengineering.world;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.network.CoasterNetwork;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.RideDynamics;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackVec3;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.UUID;
import java.util.function.UnaryOperator;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;

/** Atomic main-thread edits. Callers authenticate the operator before invoking this service. */
public final class CourseEditService {
    private static final double CHECK_SPACING = 0.4;
    private static final int MAX_SUPPORT_BLOCKS = 32_768;
    private static final int MAX_SUPPORT_DEPTH = 96;

    private CourseEditService() { }

    public static Course movePoint(ServerLevel level, UUID courseId, int index, TrackVec3 position) {
        if (position == null) throw new IllegalArgumentException("Point position is required.");
        return replacePoint(level, courseId, index, point -> new ControlPoint(position, point.bankDegrees(), point.kind(), point.targetSpeed()));
    }

    public static Course setBank(ServerLevel level, UUID courseId, int index, double degrees) {
        if (!Double.isFinite(degrees) || Math.abs(degrees) > 75) throw new IllegalArgumentException("Bank must be between -75 and 75 degrees.");
        return replacePoint(level, courseId, index, point -> new ControlPoint(point.position(), degrees, point.kind(), point.targetSpeed()));
    }

    public static Course setKind(ServerLevel level, UUID courseId, int index, RailKind kind) {
        if (kind == null) throw new IllegalArgumentException("Rail kind is required.");
        if (index == 1 && kind != RailKind.STATION) throw new IllegalArgumentException("Point 1 is the powered dispatch station and must remain a station section.");
        return replacePoint(level, courseId, index, point -> new ControlPoint(point.position(), point.bankDegrees(), kind, point.targetSpeed()));
    }

    public static Course setSpeed(ServerLevel level, UUID courseId, int index, double blocksPerTick) {
        if (!Double.isFinite(blocksPerTick) || blocksPerTick < 0 || blocksPerTick > RideDynamics.MAX_SUPPORTED_SPEED) {
            throw new IllegalArgumentException("Target speed must be between 0 and 120 km/h.");
        }
        if (index == 1 && blocksPerTick < 0.15) throw new IllegalArgumentException("The dispatch station needs at least 10.8 km/h target speed.");
        return replacePoint(level, courseId, index, point -> new ControlPoint(point.position(), point.bankDegrees(), point.kind(), blocksPerTick));
    }

    private static Course replacePoint(ServerLevel level, UUID id, int oneBasedIndex, UnaryOperator<ControlPoint> update) {
        Course original = requireCourse(level, id);
        int index = requireIndex(original, oneBasedIndex);
        ArrayList<ControlPoint> points = new ArrayList<>(original.track().points());
        points.set(index, update.apply(points.get(index)));
        return commit(level, original, points, original.station());
    }

    public static Course removePoint(ServerLevel level, UUID id, int oneBasedIndex) {
        Course original = requireCourse(level, id);
        int index = requireIndex(original, oneBasedIndex);
        int minimum = original.track().closed() ? 4 : 2;
        if (original.track().points().size() <= minimum) throw new IllegalArgumentException("This course already has its minimum number of control points.");
        ArrayList<ControlPoint> points = new ArrayList<>(original.track().points());
        points.remove(index);
        if (index == 0) {
            ControlPoint first = points.get(0);
            points.set(0, new ControlPoint(first.position(), first.bankDegrees(), RailKind.STATION, Math.max(0.15, first.targetSpeed())));
        }
        return commit(level, original, points, original.station());
    }

    public static Course setStation(ServerLevel level, UUID id, BlockPos feet) {
        Course original = requireCourse(level, id);
        if (feet == null || !safeStation(level, feet)) throw new IllegalArgumentException("Choose a loaded landing with a solid safe floor and two blocks of free headroom.");
        BlockPos controller = CoasterSavedData.get(level).controllerPos(id);
        if (controller != null && controller.distSqr(feet) > 64) {
            throw new IllegalStateException("Remove the old station controller before moving the landing more than eight blocks away, then place and bind a new controller.");
        }
        return commit(level, original, original.track().points(), feet);
    }

    private static Course commit(ServerLevel level, Course original, List<ControlPoint> points, BlockPos station) {
        CoasterEntity leader = editableLeader(level, original);
        SplineTrack track = new SplineTrack(points, original.track().closed());
        if (track.length() < 8) throw new IllegalArgumentException("Course length must be at least eight blocks.");
        if (!stationNearStart(track, station)) {
            throw new IllegalArgumentException("The first point must stay within six blocks of the station landing. Move the station in small steps; remove its controller before relocating the landing.");
        }
        Course candidate = new Course(original.id(), original.name(), track, station, original.enabled());
        CoasterEntity probe = leader == null ? CoasterRegistries.COASTER.get().create(level) : leader;
        if (probe == null) throw new IllegalStateException("Could not create a track clearance probe.");
        int checks = Math.max(1, (int) Math.ceil(track.length() / CHECK_SPACING));
        // Course caps length at 16,000: at most 40,001 bounded, server-owned checks.
        for (int check = 0; check <= checks; check++) {
            if (!probe.canUseTrackSample(track.sample(track.length() * check / checks))) {
                throw new IllegalArgumentException("Proposed track is obstructed, unsafe, or enters an unloaded chunk near distance "
                        + Math.round(track.length() * check / checks) + " blocks. Original course retained.");
            }
        }
        if (leader != null && !leader.canPlaceFormationOnTrack(track, 0)) {
            throw new IllegalArgumentException("The complete train cannot safely park on the proposed station geometry.");
        }

        // No entity or SavedData changes occur before all geometry and poses pass.
        CoasterSavedData data = CoasterSavedData.get(level);
        data.putCourse(candidate);
        if (leader != null && !leader.resetToStation()) {
            data.putCourse(original);
            throw new IllegalStateException("Could not park the train. Original course retained.");
        }
        CoasterNetwork.broadcastCourse(level, candidate);
        return candidate;
    }

    private static Course requireCourse(ServerLevel level, UUID id) {
        Course course = CoasterSavedData.get(level).getCourse(id);
        if (course == null) throw new IllegalArgumentException("No course with that UUID in this dimension.");
        return course;
    }

    private static int requireIndex(Course course, int oneBasedIndex) {
        if (oneBasedIndex < 1 || oneBasedIndex > course.track().points().size()) {
            throw new IllegalArgumentException("Point index must be between 1 and " + course.track().points().size() + ".");
        }
        return oneBasedIndex - 1;
    }

    /** Missing persisted cars are a blocker, never an invitation to respawn or ignore them. */
    private static CoasterEntity editableLeader(ServerLevel level, Course course) {
        UUID reserved = CoasterSavedData.get(level).vehicleId(course.id());
        if (reserved == null) {
            for (Entity entity : level.getAllEntities()) {
                if (entity instanceof CoasterEntity cart && course.id().equals(cart.courseId()) && !cart.isRemoved()) {
                    throw new IllegalStateException("A course vehicle has no valid reservation. Resolve that vehicle before editing.");
                }
            }
            return null;
        }
        Entity entity = level.getEntity(reserved);
        if (!(entity instanceof CoasterEntity leader) || leader.isRemoved() || !leader.isTrainLeader() || !course.id().equals(leader.courseId())) {
            throw new IllegalStateException("Load the course's reserved train before editing.");
        }
        List<CoasterEntity> cars = leader.getLoadedFormation();
        if (cars.isEmpty() || cars.size() != leader.carCount()) throw new IllegalStateException("Load every saved car before editing this course.");
        for (CoasterEntity car : cars) {
            if (car.isRunning() || car.getSpeed() > 1.0E-7 || !car.getPassengers().isEmpty()) {
                throw new IllegalStateException("All cars must be stopped and empty before editing this course.");
            }
        }
        return leader;
    }

    public static boolean safeStation(ServerLevel level, BlockPos feet) {
        if (!level.hasChunkAt(feet) || level.isOutsideBuildHeight(feet) || level.isOutsideBuildHeight(feet.above())
                || !level.getWorldBorder().isWithinBounds(feet)) return false;
        var floor = level.getBlockState(feet.below());
        var body = level.getBlockState(feet);
        var head = level.getBlockState(feet.above());
        return !floor.getCollisionShape(level, feet.below()).isEmpty()
                && !floor.is(Blocks.MAGMA_BLOCK) && !floor.is(Blocks.CAMPFIRE) && !floor.is(Blocks.SOUL_CAMPFIRE) && !floor.is(Blocks.CACTUS)
                && body.getCollisionShape(level, feet).isEmpty() && head.getCollisionShape(level, feet.above()).isEmpty()
                && !body.is(Blocks.FIRE) && !body.is(Blocks.SOUL_FIRE) && !body.is(Blocks.SWEET_BERRY_BUSH)
                && !head.is(Blocks.FIRE) && !head.is(Blocks.SOUL_FIRE)
                && level.getFluidState(feet).isEmpty() && level.getFluidState(feet.above()).isEmpty();
    }

    public static boolean stationNearStart(SplineTrack track, BlockPos feet) {
        if (track == null || feet == null) return false;
        var p = track.sample(0).position();
        double dx = p.x() - (feet.getX() + 0.5), dy = p.y() - feet.getY(), dz = p.z() - (feet.getZ() + 0.5);
        return dx * dx + dy * dy + dz * dz <= 36;
    }

    /** Preserves every existing block and never generates a chunk. The support block has no collision. */
    public static int addSupports(ServerLevel level, UUID id) {
        Course course = requireCourse(level, id);
        editableLeader(level, course);
        LinkedHashSet<BlockPos> plan = new LinkedHashSet<>();
        for (double distance = 0; distance < course.track().length(); distance += 8) {
            var p = course.track().sample(distance).position();
            BlockPos top = BlockPos.containing(p.x(), p.y(), p.z()).below();
            if (!level.hasChunkAt(top) || !level.getWorldBorder().isWithinBounds(top) || level.isOutsideBuildHeight(top)) {
                throw new IllegalArgumentException("Every support column must be inside loaded world chunks.");
            }
            for (int depth = 0; depth < MAX_SUPPORT_DEPTH; depth++) {
                BlockPos block = top.below(depth);
                if (level.isOutsideBuildHeight(block)) break;
                if (!level.getBlockState(block).isAir() || !level.getFluidState(block).isEmpty()) break;
                plan.add(block);
                if (plan.size() > MAX_SUPPORT_BLOCKS) throw new IllegalArgumentException("Support plan exceeds 32,768 blocks. Move the course closer to ground before generating supports.");
            }
        }
        for (BlockPos block : plan) level.setBlock(block, CoasterRegistries.SUPPORT_BEAM.get().defaultBlockState(), 3);
        return plan.size();
    }
}
