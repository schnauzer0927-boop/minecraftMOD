package dev.coasterengineering.world;

import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Original research station and pedestrian entrance, generated reproducibly. */
public final class ParkStructures {
    public static final BlockPos LANDING = new BlockPos(-3, 94, -96);
    public static final BlockPos CONTROLLER = new BlockPos(-6, 94, -96);
    private ParkStructures() { }

    /** Only lighting additions; usable without rebuilding the saved station. */
    public static Map<BlockPos, BlockState> qualityUpgrade(SplineTrack track) {
        return qualityUpgrade(track, QualityLightingPlan.protectedCells(track));
    }

    public static Map<BlockPos, BlockState> qualityUpgrade(SplineTrack track, Set<BlockPos> protectedCells) {
        return QualityLightingPlan.stationLighting(track, protectedCells);
    }

    public static Map<BlockPos, BlockState> station(SplineTrack track) {
        LinkedHashMap<BlockPos, BlockState> blocks = new LinkedHashMap<>();
        BlockState metal = Blocks.POLISHED_DEEPSLATE.defaultBlockState();
        BlockState dark = Blocks.BLACK_CONCRETE.defaultBlockState();
        BlockState glass = Blocks.CYAN_STAINED_GLASS.defaultBlockState();
        BlockState light = Blocks.SEA_LANTERN.defaultBlockState();
        BlockState rail = Blocks.IRON_BARS.defaultBlockState();
        BlockState air = Blocks.AIR.defaultBlockState();

        // The railway corridor is carved first by the world job. Clear the
        // station's pedestrian interior explicitly before rebuilding its shell.
        box(blocks, -10, 94, -113, 4, 102, -89, air);
        box(blocks, -10, 93, -113, -2, 93, -89, metal);
        box(blocks, -11, 103, -114, 4, 103, -88, dark);
        for (int z = -113; z <= -89; z++) {
            for (int y = 94; y <= 102; y++) {
                put(blocks, -11, y, z, y >= 96 && y <= 99 ? glass : metal);
            }
            if ((z + 113) % 6 == 0) {
                box(blocks, 3, 94, z, 3, 102, z, metal);
                put(blocks, -10, 102, z, light);
                put(blocks, 2, 102, z, light);
            }
        }
        // Closed lab end walls stop short of the dedicated rail corridor.
        box(blocks, -10, 94, -114, -2, 102, -114, metal);
        box(blocks, -10, 94, -88, -2, 102, -88, metal);
        box(blocks, -8, 94, -114, -6, 97, -114, air);
        box(blocks, -9, 98, -114, -3, 102, -114, dark);
        glyph(blocks, "C", -9, 98, -115, light);
        glyph(blocks, "E", -5, 98, -115, Blocks.CYAN_CONCRETE.defaultBlockState());
        for (int z : new int[] {-110, -106, -102, -98, -94, -90}) {
            put(blocks, -9, 101, z, light);
            put(blocks, -3, 93, z, Blocks.YELLOW_CONCRETE.defaultBlockState());
        }
        // An open platform edge leaves the cars and their upright riders clear.
        for (int z = -113; z <= -89; z++) {
            if (z < -108 || z > -94) put(blocks, -2, 94, z, rail);
        }

        // Queue lanes are entirely on the west side of the boarding corridor.
        for (int x : new int[] {-9, -7}) {
            for (int z = -108; z <= -91; z++) {
                if ((x == -9 && z < -94) || (x == -7 && z > -106)) put(blocks, x, 94, z, rail);
            }
        }
        put(blocks, CONTROLLER.getX(), CONTROLLER.getY(), CONTROLLER.getZ(),
                CoasterRegistries.STATION_CONTROLLER.get().defaultBlockState());

        box(blocks, -18, 65, -165, 4, 80, -158, air);
        box(blocks, -12, 64, -165, -3, 64, -157, metal);

        // A protected engineering stair descends to the entrance field. Its
        // exact 46-block run makes each downward transition at most one block.
        for (int step = 0; step <= 45; step++) {
            int z = -115 - step;
            int floor = 93 - step * 29 / 45;
            int nextFloor = 93 - Math.min(45, step + 1) * 29 / 45;
            box(blocks, -10, floor + 1, z, -5, floor + 4, z, air);
            BlockState tread = nextFloor < floor ? Blocks.DEEPSLATE_BRICK_STAIRS.defaultBlockState()
                    .setValue(StairBlock.FACING, Direction.SOUTH) : metal;
            for (int x = -9; x <= -6; x++) put(blocks, x, floor, z, tread);
            put(blocks, -10, floor + 1, z, rail);
            put(blocks, -5, floor + 1, z, rail);
            if (step % 6 == 0) {
                for (int y = 64; y < floor; y++) {
                    put(blocks, -10, y, z, metal);
                    put(blocks, -5, y, z, metal);
                }
                put(blocks, -10, floor + 2, z, light);
                put(blocks, -5, floor + 2, z, light);
            }
        }

        for (int x : new int[] {-12, -3}) box(blocks, x, 65, -161, x, 71, -161, dark);
        box(blocks, -17, 72, -161, 3, 72, -161, dark);
        box(blocks, -17, 73, -161, 3, 79, -161, metal);
        String name = "ABYSS";
        for (int i = 0; i < name.length(); i++)
            glyph(blocks, String.valueOf(name.charAt(i)), -16 + i * 4, 74, -162, light);
        put(blocks, -11, 70, -161, light);
        put(blocks, -4, 70, -161, light);

        // No station decoration may obstruct any portion of the complete
        // course, even when a later layout revision crosses this building.
        Set<BlockPos> swept = sweptCells(track);
        blocks.entrySet().removeIf(entry -> !entry.getValue().isAir() && swept.contains(entry.getKey()));
        BlockPos landingFloor = LANDING.below();
        if (!blocks.containsKey(landingFloor) || blocks.get(landingFloor).isAir()
                || !blocks.containsKey(CONTROLLER) || blocks.get(CONTROLLER).isAir())
            throw new IllegalArgumentException("Course intersects the required station landing or controller");
        blocks.putAll(qualityUpgrade(track));
        return Map.copyOf(blocks);
    }

    private static Set<BlockPos> sweptCells(SplineTrack track) {
        HashSet<BlockPos> cells = new HashSet<>();
        for (double distance = 0; distance < track.length(); distance += .25) {
            TrackSample sample = track.sample(distance);
            TrackFrame frame = TrackFrame.from(sample);
            TrackVec3 anchor = sample.position();
            double minX = Double.POSITIVE_INFINITY, minY = Double.POSITIVE_INFINITY, minZ = Double.POSITIVE_INFINITY;
            double maxX = Double.NEGATIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY, maxZ = Double.NEGATIVE_INFINITY;
            for (double x : new double[] {-.9, .9}) for (double y : new double[] {-.05, 1.2})
                for (double z : new double[] {-1.5, 1.5}) {
                    TrackVec3 p = local(anchor, frame, x, y, z);
                    minX = Math.min(minX, p.x()); minY = Math.min(minY, p.y()); minZ = Math.min(minZ, p.z());
                    maxX = Math.max(maxX, p.x()); maxY = Math.max(maxY, p.y()); maxZ = Math.max(maxZ, p.z());
                }
            addCells(cells, minX, minY, minZ, maxX, maxY, maxZ);
            for (double x : new double[] {-.45, .45}) {
                TrackVec3 feet = local(anchor, frame, x, .45, 0);
                addCells(cells, feet.x() - .30, feet.y(), feet.z() - .30,
                        feet.x() + .30, feet.y() + 1.8, feet.z() + .30);
            }
        }
        return cells;
    }

    private static TrackVec3 local(TrackVec3 anchor, TrackFrame frame, double x, double y, double z) {
        return new TrackVec3(anchor.x() + frame.right().x() * x + frame.up().x() * y + frame.forward().x() * z,
                anchor.y() + frame.right().y() * x + frame.up().y() * y + frame.forward().y() * z,
                anchor.z() + frame.right().z() * x + frame.up().z() * y + frame.forward().z() * z);
    }

    private static void addCells(Set<BlockPos> cells, double minX, double minY, double minZ,
                                 double maxX, double maxY, double maxZ) {
        for (BlockPos p : BlockPos.betweenClosed(Mth.floor(minX), Mth.floor(minY), Mth.floor(minZ),
                Mth.floor(maxX - 1.0E-7), Mth.floor(maxY - 1.0E-7), Mth.floor(maxZ - 1.0E-7)))
            cells.add(p.immutable());
    }

    private static void put(Map<BlockPos, BlockState> blocks, int x, int y, int z, BlockState state) {
        blocks.put(new BlockPos(x, y, z), state);
    }

    private static void box(Map<BlockPos, BlockState> blocks, int minX, int minY, int minZ,
                            int maxX, int maxY, int maxZ, BlockState state) {
        for (BlockPos p : BlockPos.betweenClosed(minX, minY, minZ, maxX, maxY, maxZ)) blocks.put(p.immutable(), state);
    }

    private static void glyph(Map<BlockPos, BlockState> blocks, String letter, int left, int bottom, int z,
                              BlockState state) {
        String[] rows = switch (letter) {
            case "A" -> new String[] {"010", "101", "111", "101", "101"};
            case "B" -> new String[] {"110", "101", "110", "101", "110"};
            case "C" -> new String[] {"111", "100", "100", "100", "111"};
            case "E" -> new String[] {"111", "100", "110", "100", "111"};
            case "Y" -> new String[] {"101", "101", "010", "010", "010"};
            case "S" -> new String[] {"111", "100", "111", "001", "111"};
            default -> throw new IllegalArgumentException("Unsupported original station glyph");
        };
        for (int row = 0; row < rows.length; row++) for (int x = 0; x < rows[row].length(); x++)
            if (rows[row].charAt(x) == '1') put(blocks, left + x, bottom + 4 - row, z, state);
    }
}
