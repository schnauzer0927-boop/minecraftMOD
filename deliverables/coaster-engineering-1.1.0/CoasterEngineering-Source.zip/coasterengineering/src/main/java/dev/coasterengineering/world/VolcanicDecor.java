package dev.coasterengineering.world;

import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Original scenery for the fixed Volcanic Abyss attraction. This class produces
 * deterministic block data only; construction, route clearance and ride events
 * belong to separate systems. Basins deliberately use glass, without live fluids.
 */
public final class VolcanicDecor {
    public static final int MAX_BLOCKS = 50_000;
    private static final BlockState ROCK = Blocks.POLISHED_BLACKSTONE.defaultBlockState();
    private static final BlockState BASALT = Blocks.BASALT.defaultBlockState();
    private static final BlockState STEEL = Blocks.IRON_BLOCK.defaultBlockState();
    private static final BlockState COLD_LIGHT = Blocks.SEA_LANTERN.defaultBlockState();
    private static final BlockState HOT_LIGHT = Blocks.SHROOMLIGHT.defaultBlockState();

    private VolcanicDecor() { }

    /** Apply after the builder's clearance carve, or as a protected saved-world delta. */
    public static Map<BlockPos, BlockState> qualityUpgrade(SplineTrack track) {
        return qualityUpgrade(track, QualityLightingPlan.protectedCells(track));
    }

    public static Map<BlockPos, BlockState> qualityUpgrade(SplineTrack track, Set<BlockPos> protectedCells) {
        return QualityLightingPlan.volcanicLighting(track, protectedCells);
    }

    public static Map<BlockPos, BlockState> plan(SplineTrack track) {
        Objects.requireNonNull(track, "track");
        Planner planner = new Planner(track);
        riverBasin(planner);
        magmaBasin(planner);
        abyssSentinel(planner);
        mineralClusters(planner, track);
        tunnelAndBridgeFrames(planner, track);
        return planner.blocks;
    }

    private static void riverBasin(Planner plan) {
        // The underground watercourse is an illuminated, sealed glass display.
        // Its blue surface is nine blocks beneath the lowest running section.
        for (int x = -91; x <= -53; x++) for (int z = 0; z <= 30; z++) {
            plan.put(x, 69, z, ROCK);
            if (x == -91 || x == -53 || z == 0 || z == 30) {
                for (int y = 70; y <= 75; y++) plan.put(x, y, z, BASALT);
            } else {
                plan.put(x, 70, z, (x + z) % 7 == 0 ? COLD_LIGHT : Blocks.PRISMARINE.defaultBlockState());
                plan.put(x, 74, z, ((x + z) & 3) == 0
                        ? Blocks.CYAN_STAINED_GLASS.defaultBlockState() : Blocks.BLUE_STAINED_GLASS.defaultBlockState());
            }
        }
        // Uneven rockbanks and original crystal spires make the basin a landscape.
        for (int x = -88; x <= -56; x += 8) {
            for (int dy = 0; dy < 4; dy++) plan.put(x, 75 + dy, -1, BASALT);
            plan.put(x, 79, -1, Blocks.AMETHYST_BLOCK.defaultBlockState());
            plan.put(x, 76, 31, COLD_LIGHT);
        }
    }

    private static void magmaBasin(Planner plan) {
        // Orange glass over warm emitters suggests molten rock without lava
        // updates leaking into a later-carved corridor or damaging passengers.
        for (int x = 21; x <= 68; x++) for (int z = 18; z <= 61; z++) {
            double radius = Math.hypot((x - 45) / 24.0, (z - 40) / 22.0);
            if (radius > 1) continue;
            int y = radius > .82 ? 75 : 71;
            plan.put(x, y, z, radius > .82 ? BASALT
                    : (x * 3 + z) % 9 == 0 ? Blocks.MAGMA_BLOCK.defaultBlockState() : ROCK);
        }
        for (int x = 28; x <= 61; x++) for (int z = 24; z <= 55; z++) {
            plan.put(x, 70, z, ROCK);
            if (x == 28 || x == 61 || z == 24 || z == 55) {
                for (int y = 71; y <= 75; y++) plan.put(x, y, z, BASALT);
            } else {
                plan.put(x, 71, z, ((x + z) & 3) == 0 ? HOT_LIGHT : Blocks.MAGMA_BLOCK.defaultBlockState());
                plan.put(x, 74, z, (x + z) % 5 == 0
                        ? Blocks.YELLOW_STAINED_GLASS.defaultBlockState() : Blocks.ORANGE_STAINED_GLASS.defaultBlockState());
            }
        }
        for (int n = 0; n < 8; n++) {
            double angle = n * Math.PI / 4;
            int x = 45 + (int) Math.round(23 * Math.cos(angle));
            int z = 40 + (int) Math.round(20 * Math.sin(angle));
            for (int y = 76; y < 79 + n % 3; y++) plan.put(x, y, z, BASALT);
            plan.put(x, 79 + n % 3, z, HOT_LIGHT);
        }
    }

    private static void abyssSentinel(Planner plan) {
        // A wholly original four-limbed stone sentinel, facing the river descent.
        // It is scenery, not a copied character or an entity affecting ride logic.
        final int x = -29, z = 9;
        for (int dx = -11; dx <= 11; dx++) for (int dz = -10; dz <= 10; dz++) {
            if (dx * dx + dz * dz < 120) plan.put(x + dx, 71, z + dz, ROCK);
        }
        ellipsoid(plan, x, 81, z, 5.5, 7, 4.2, ROCK, BASALT);
        ellipsoid(plan, x, 90, z + 3, 4.7, 4.7, 4.5,
                Blocks.BLACKSTONE.defaultBlockState(), ROCK);
        for (int side : new int[] {-1, 1}) {
            box(plan, x + side * 4 - 1, 72, z + 1, x + side * 4 + 1, 77, z + 4, ROCK);
            box(plan, x + side * 4 - 2, 72, z + 3, x + side * 4 + 2, 73, z + 7, BASALT);
            line(plan, new TrackVec3(x + side * 5, 84, z + 1),
                    new TrackVec3(x + side * 9, 82, z + 7), ROCK, 1);
            line(plan, new TrackVec3(x + side * 9, 82, z + 7),
                    new TrackVec3(x + side * 8, 87, z + 8), BASALT, 1);
            line(plan, new TrackVec3(x + side * 3, 93, z + 1),
                    new TrackVec3(x + side * 7, 97, z), BASALT, 0);
            // Red panes over emitters give original glowing eyes in the darkness.
            plan.put(x + side * 2, 91, z + 7, HOT_LIGHT);
            plan.put(x + side * 2, 91, z + 8, Blocks.RED_STAINED_GLASS.defaultBlockState());
        }
        // Recessed dark jaw with alternating pale mineral teeth.
        box(plan, x - 3, 87, z + 7, x + 3, 89, z + 7, Blocks.BLACK_CONCRETE.defaultBlockState());
        for (int dx : new int[] {-3, -1, 1, 3}) {
            plan.put(x + dx, 87, z + 8, Blocks.CALCITE.defaultBlockState());
            plan.put(x + dx, 89, z + 8, Blocks.CALCITE.defaultBlockState());
        }
        box(plan, x - 3, 86, z + 7, x + 3, 86, z + 8, BASALT);
        // The spine is an amber geological seam rather than a creature animation.
        for (int y = 76; y <= 89; y += 2) plan.put(x, y, z - 4, HOT_LIGHT);
    }

    private static void mineralClusters(Planner plan, SplineTrack track) {
        Random random = new Random(0x5CE20261L);
        for (double distance = 38; distance < track.length() - 30; distance += 19) {
            TrackSample sample = track.sample(distance);
            TrackVec3 position = sample.position();
            if (position.y() > 123 || position.z() < -73) continue;
            TrackFrame frame = TrackFrame.from(sample);
            int side = random.nextBoolean() ? 1 : -1;
            TrackVec3 center = position.add(frame.right().scale(side * (10 + random.nextInt(4))))
                    .add(new TrackVec3(0, random.nextInt(9) - 4, 0));
            BlockState mineral = switch (random.nextInt(3)) {
                case 0 -> Blocks.AMETHYST_BLOCK.defaultBlockState();
                case 1 -> Blocks.DIAMOND_ORE.defaultBlockState();
                default -> Blocks.EMERALD_ORE.defaultBlockState();
            };
            ellipsoid(plan, center.x(), center.y(), center.z(), 2.6, 3.2, 2.2,
                    mineral, Blocks.TUFF.defaultBlockState());
            plan.put(BlockPos.containing(center.x(), center.y() + 2, center.z()), COLD_LIGHT);
            // Companion crystals read clearly even under low cave light.
            for (int dy = 0; dy < 4; dy++) {
                plan.put(BlockPos.containing(center.x() + 2, center.y() + dy, center.z() - 1),
                        dy == 3 ? COLD_LIGHT : Blocks.AMETHYST_BLOCK.defaultBlockState());
            }
        }
    }

    private static void tunnelAndBridgeFrames(Planner plan, SplineTrack track) {
        for (double distance = 0; distance < track.length(); distance += 9) {
            TrackSample sample = track.sample(distance);
            TrackFrame frame = TrackFrame.from(sample);
            TrackVec3 position = sample.position();
            if (sample.kind() == RailKind.BOOST) {
                // Sequenced luminous rings define the steep high-speed tunnel.
                ring(plan, position, frame, 9, 8, COLD_LIGHT, Blocks.CYAN_STAINED_GLASS.defaultBlockState());
            } else if (position.y() > 105 && (position.x() < -82 || position.z() > 84)) {
                // Wide exterior research bridge towers stand outside the swept train.
                for (int side : new int[] {-1, 1}) {
                    TrackVec3 foot = position.add(frame.right().scale(side * 10));
                    int x = (int) Math.floor(foot.x()), z = (int) Math.floor(foot.z());
                    for (int y = 64; y <= Math.floor(position.y()) + 8; y++) {
                        plan.put(x, y, z, y % 7 == 0 ? ROCK : STEEL);
                    }
                    plan.put(x, (int) Math.floor(position.y()) + 8, z, COLD_LIGHT);
                }
                TrackVec3 left = position.add(frame.right().scale(-10)).add(new TrackVec3(0, 8, 0));
                TrackVec3 right = position.add(frame.right().scale(10)).add(new TrackVec3(0, 8, 0));
                line(plan, left, right, STEEL, 0);
                line(plan, position.add(frame.right().scale(-10)).add(new TrackVec3(0, -8, 0)),
                        position.add(frame.right().scale(10)).add(new TrackVec3(0, -8, 0)), ROCK, 0);
            } else if (position.z() < -67 && sample.kind() != RailKind.STATION) {
                // Return-to-base tunnel instruments use a warm amber color code.
                ring(plan, position, frame, 8.5, 8, HOT_LIGHT, Blocks.YELLOW_STAINED_GLASS.defaultBlockState());
            } else if (position.y() < 104 && position.z() > -45) {
                // Sparse floor lamps illuminate chambers without touching track supports.
                for (int side : new int[] {-1, 1}) {
                    TrackVec3 lamp = position.add(frame.right().scale(side * 8.5)).add(new TrackVec3(0, -8, 0));
                    BlockPos p = BlockPos.containing(lamp.x(), lamp.y(), lamp.z());
                    plan.put(p, ROCK);
                    plan.put(p.above(), COLD_LIGHT);
                }
            }
        }
    }

    private static void ring(Planner plan, TrackVec3 center, TrackFrame frame,
                             double width, double height, BlockState light, BlockState trim) {
        TrackVec3 previous = null;
        for (int n = 0; n <= 48; n++) {
            double angle = 2 * Math.PI * n / 48;
            TrackVec3 point = center.add(frame.right().scale(width * Math.cos(angle)))
                    .add(frame.up().scale(height * Math.sin(angle)));
            if (previous != null) line(plan, previous, point, n % 6 == 0 ? light : trim, 0);
            if (n % 6 == 0) plan.put(BlockPos.containing(point.x(), point.y(), point.z()), light);
            previous = point;
        }
    }

    private static void box(Planner plan, int x0, int y0, int z0, int x1, int y1, int z1, BlockState state) {
        for (int x = x0; x <= x1; x++) for (int y = y0; y <= y1; y++) for (int z = z0; z <= z1; z++) {
            plan.put(x, y, z, state);
        }
    }

    private static void line(Planner plan, TrackVec3 start, TrackVec3 end, BlockState state, int radius) {
        TrackVec3 delta = end.subtract(start);
        int steps = Math.max(1, (int) Math.ceil(delta.length() * 2));
        for (int i = 0; i <= steps; i++) {
            TrackVec3 point = start.add(delta.scale((double) i / steps));
            BlockPos center = BlockPos.containing(point.x(), point.y(), point.z());
            for (int dx = -radius; dx <= radius; dx++) for (int dy = -radius; dy <= radius; dy++)
                for (int dz = -radius; dz <= radius; dz++) plan.put(center.offset(dx, dy, dz), state);
        }
    }

    private static void ellipsoid(Planner plan, double cx, double cy, double cz,
                                  double rx, double ry, double rz, BlockState core, BlockState shell) {
        for (int x = (int) Math.floor(cx - rx); x <= Math.ceil(cx + rx); x++)
            for (int y = (int) Math.floor(cy - ry); y <= Math.ceil(cy + ry); y++)
                for (int z = (int) Math.floor(cz - rz); z <= Math.ceil(cz + rz); z++) {
                    double d = Math.pow((x + .5 - cx) / rx, 2) + Math.pow((y + .5 - cy) / ry, 2)
                            + Math.pow((z + .5 - cz) / rz, 2);
                    if (d <= 1) plan.put(x, y, z, ((x + y + z) & 3) == 0 ? shell : core);
                }
    }

    private static final class Planner {
        private final Map<BlockPos, BlockState> blocks = new LinkedHashMap<>();
        private final Map<Cell, List<TrackVec3>> route = new HashMap<>();

        private Planner(SplineTrack track) {
            for (double distance = 0; distance < track.length(); distance += 2) {
                TrackVec3 point = track.sample(distance).position();
                route.computeIfAbsent(cell(point.x(), point.y(), point.z()), ignored -> new ArrayList<>()).add(point);
            }
        }

        private void put(int x, int y, int z, BlockState state) { put(new BlockPos(x, y, z), state); }

        private void put(BlockPos position, BlockState state) {
            if (position.getX() < -145 || position.getX() > 145 || position.getZ() < -165 || position.getZ() > 145
                    || position.getY() < 64 || position.getY() > 174 || !clearOfRoute(position)) return;
            if (blocks.size() >= MAX_BLOCKS && !blocks.containsKey(position))
                throw new IllegalStateException("Volcanic decorations exceeded the 50000-block budget");
            blocks.put(position.immutable(), state);
        }

        private boolean clearOfRoute(BlockPos position) {
            double x = position.getX() + .5, y = position.getY() + .5, z = position.getZ() + .5;
            Cell center = cell(x, y, z);
            for (int dx = -1; dx <= 1; dx++) for (int dy = -1; dy <= 1; dy++) for (int dz = -1; dz <= 1; dz++) {
                List<TrackVec3> nearby = route.get(new Cell(center.x + dx, center.y + dy, center.z + dz));
                if (nearby == null) continue;
                for (TrackVec3 point : nearby) {
                    // A seven-block envelope includes the later radius-five
                    // block carve, voxel rounding and the two-block sampling gap.
                    if (Math.abs(point.x() - x) < 7 && Math.abs(point.y() - y) < 7 && Math.abs(point.z() - z) < 7) return false;
                }
            }
            return true;
        }

        private static Cell cell(double x, double y, double z) {
            return new Cell((int) Math.floor(x / 16), (int) Math.floor(y / 16), (int) Math.floor(z / 16));
        }
    }

    private record Cell(int x, int y, int z) { }
}
