package dev.coasterengineering.world;

import com.google.gson.Gson;
import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.track.TrainSpacing;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * An explicit, temporary empty-train commissioning run in the actual world.
 * This observes normal entity ticks; it never substitutes simulated movement,
 * invents a passenger, repairs a train, or changes saved course geometry.
 */
@Mod.EventBusSubscriber(modid = CoasterEngineering.MOD_ID)
public final class RideValidationService {
    private static final TicketType<UUID> TICKET = TicketType.create("coasterengineering_validation", UUID::compareTo);
    private static final int TICKET_DISTANCE = 2;
    private static final int MAX_CHUNKS = 1024;
    private static final int LOAD_TIMEOUT = 1200;
    private static final int RIDE_TIMEOUT = 24000;
    private static final double SAMPLE_INTERVAL = .4;
    private static final double FOOTPRINT_MARGIN = 4;
    private static final Map<ServerLevel, Job> ACTIVE = new IdentityHashMap<>();
    private static final Map<ServerLevel, Result> RESULTS = new IdentityHashMap<>();
    private static final Map<ServerLevel, LightingResult> LIGHTING_RESULTS = new IdentityHashMap<>();

    private RideValidationService() { }

    /** Returns acceptance, not completion. Query status for the actual outcome. */
    public static boolean begin(ServerLevel level, UUID courseId) {
        if (!level.getServer().isSameThread()) throw new IllegalStateException("Validation must begin on the server thread");
        if (ACTIVE.containsKey(level)) return false;
        LIGHTING_RESULTS.remove(level);
        Course course = CoasterSavedData.get(level).getCourse(courseId);
        try {
            if (course == null || !course.enabled() || !course.track().closed()
                    || !Double.isFinite(course.track().length()) || course.track().length() < 2
                    || course.track().length() > 8192) throw invalid("A saved enabled closed course of 2..8192 blocks is required");
            CoasterEntity leader = leader(level, courseId);
            requirePausedEmptyFormation(level, course, leader);
            if (leader.getLaps() == Integer.MAX_VALUE) throw invalid("The saved lap counter has reached its limit");
            Job job = new Job(level, course, leader);
            ACTIVE.put(level, job);
            RESULTS.remove(level);
            LIGHTING_RESULTS.remove(level);
            CoasterEngineering.LOGGER.info("VOLCANIC_RIDE_VALIDATION_BEGIN course={} cars={} length={} emptyTrain=true temporaryChunks={}",
                    courseId, job.carIds.size(), course.track().length(), job.footprint.size());
            return true;
        } catch (RuntimeException failure) {
            RESULTS.put(level, new Result(courseId, false, "Rejected: " + message(failure), 0,
                    course == null ? 0 : course.track().length(), 0, 0, 0, 0));
            return false;
        }
    }

    public static String status(ServerLevel level) {
        Job job = ACTIVE.get(level);
        if (job != null) return job.status();
        Result result = RESULTS.get(level);
        return result == null ? "No commissioning run has been requested in this dimension." : result.toString();
    }

    public static String status(ServerLevel level, UUID courseId) {
        Job job = ACTIVE.get(level);
        Result result = RESULTS.get(level);
        return job != null && job.course.id().equals(courseId) || result != null && result.courseId.equals(courseId)
                ? status(level) : "No commissioning result is available for course " + courseId;
    }

    public static Result lastResult(ServerLevel level) { return RESULTS.get(level); }

    /** Measured at both virtual rider eyes in every actual car, once per normal ride tick. */
    public static LightingResult lastLightingResult(ServerLevel level) { return LIGHTING_RESULTS.get(level); }

    public static boolean cancel(ServerLevel level) {
        Job job = ACTIVE.get(level);
        if (job == null) return false;
        job.finish(false, "Cancelled by operator");
        return true;
    }

    @SubscribeEvent
    public static void levelTick(TickEvent.LevelTickEvent event) {
        if (!(event.level instanceof ServerLevel level)) return;
        Job job = ACTIVE.get(level);
        if (job == null) return;
        if (event.phase == TickEvent.Phase.START) {
            // A playerless ServerLevel normally suspends entity ticks after300
            // ticks. Keep this explicit diagnostic world active temporarily;
            // cars still run exactly once through the normal entity tick loop.
            level.resetEmptyTime();
        } else {
            try { job.tick(); }
            catch (RuntimeException failure) { job.finish(false, message(failure)); }
        }
    }

    @SubscribeEvent
    public static void serverStopping(ServerStoppingEvent event) {
        for (Job job : List.copyOf(ACTIVE.values())) {
            if (job.level.getServer() == event.getServer()) job.finish(false, "Server stopped during commissioning");
        }
        RESULTS.keySet().removeIf(level -> level.getServer() == event.getServer());
        LIGHTING_RESULTS.keySet().removeIf(level -> level.getServer() == event.getServer());
    }

    public record Result(UUID courseId, boolean passed, String message, long ticks, double length,
                         double maxSpeed, double minHeight, double maxHeight, int cars) {
        @Override public String toString() {
            return String.format(Locale.ROOT, "%s course=%s; %s; empty train, %d cars, %.1f blocks, %d ticks (%.1f s), max %.1f km/h, height range %.1f blocks",
                    passed ? "PASSED" : "FAILED", courseId, message, cars, length, ticks, ticks / 20.0,
                    maxSpeed * 72, maxHeight - minHeight);
        }
    }

    /** Exposure is time weighted: every seat contributes one reading per ordinary world tick. */
    public record LightingResult(UUID courseId, boolean passed, long ticks, int cars,
                                 Map<String, LightDistribution> exposure, String limitation) {
        public LightingResult { exposure = Map.copyOf(exposure); }
    }

    public record LightDistribution(long samples, List<Long> blockHistogram, List<Long> skyHistogram,
                                    double blockMean, double skyMean, double combinedDayMean,
                                    double combinedDayDarkFraction) {
        public LightDistribution {
            blockHistogram = List.copyOf(blockHistogram);
            skyHistogram = List.copyOf(skyHistogram);
        }
    }

    private static final class LightAccumulator {
        long samples, blockSum, skySum, combinedSum, darkSamples;
        final long[] block = new long[16], sky = new long[16];
        void add(int blockLight, int skyLight) {
            if (blockLight < 0 || blockLight > 15 || skyLight < 0 || skyLight > 15)
                throw invalid("The live light engine returned an invalid brightness");
            samples++;
            block[blockLight]++;
            sky[skyLight]++;
            blockSum += blockLight;
            skySum += skyLight;
            int combined = Math.max(blockLight, skyLight);
            combinedSum += combined;
            if (combined <= 3) darkSamples++;
        }
        LightDistribution result() {
            List<Long> blockValues = new ArrayList<>(), skyValues = new ArrayList<>();
            for (int i = 0; i < 16; i++) { blockValues.add(block[i]); skyValues.add(sky[i]); }
            return new LightDistribution(samples, blockValues, skyValues, samples == 0 ? 0 : (double) blockSum / samples,
                    samples == 0 ? 0 : (double) skySum / samples, samples == 0 ? 0 : (double) combinedSum / samples,
                    samples == 0 ? 0 : (double) darkSamples / samples);
        }
    }

    private static final class Job {
        private final ServerLevel level;
        private final Course course;
        private final UUID leaderId;
        private final List<UUID> carIds;
        private final UUID ticketId = UUID.randomUUID();
        private final Set<ChunkPos> footprint;
        private final Map<ChunkPos, CompletableFuture<Optional<CompoundTag>>> diskChecks = new LinkedHashMap<>();
        private final Set<ChunkPos> heldTickets = new LinkedHashSet<>();
        private final long requestedAt;
        private long rideStartedAt = -1;
        private long lastMotionAt;
        private int initialLaps;
        private double previousDistance;
        private double maxSpeed;
        private double minHeight = Double.POSITIVE_INFINITY;
        private double maxHeight = Double.NEGATIVE_INFINITY;
        private String phase = "checking existing chunks";
        private final Map<String, LightAccumulator> lightExposure = new LinkedHashMap<>();

        Job(ServerLevel level, Course course, CoasterEntity leader) {
            this.level = level;
            this.course = course;
            leaderId = leader.getUUID();
            carIds = leader.getLoadedFormation().stream().map(Entity::getUUID).toList();
            requestedAt = level.getGameTime();
            footprint = footprint(level, course.track());
            Set<ChunkPos> fullHalo = new LinkedHashSet<>();
            // An entity-ticking level31 region ticket also loads FULL level33
            // neighbors. Verify that halo first, so this diagnostic does not
            // generate arbitrary missing chunks around a saved route.
            for (ChunkPos pos : footprint) for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                fullHalo.add(new ChunkPos(pos.x + dx, pos.z + dz));
                if (fullHalo.size() > MAX_CHUNKS) throw invalid("Course chunk halo exceeds the bounded validation budget");
            }
            for (ChunkPos pos : fullHalo) {
                if (level.getChunkSource().getChunkNow(pos.x, pos.z) == null)
                    diskChecks.put(pos, level.getChunkSource().chunkMap.read(pos));
            }
        }

        void tick() {
            CoasterSavedData data = CoasterSavedData.get(level);
            if (data.getCourse(course.id()) != course || !leaderId.equals(data.vehicleId(course.id())))
                throw invalid("The saved course or reserved train changed during commissioning");
            if (data.isEmergency(course.id())) throw invalid("The course emergency alarm was latched during commissioning");
            if (rideStartedAt < 0) {
                prepare();
                return;
            }
            CoasterEntity leader = leader(level, course.id());
            List<CoasterEntity> cars = formation(leader);
            if (cars.stream().anyMatch(Entity::isVehicle)) throw invalid("A player boarded during the empty-train commissioning run");
            observe(cars, leader);
            long elapsed = level.getGameTime() - rideStartedAt;
            if (leader.getLaps() == initialLaps + 1) {
                if (leader.isRunning() || Math.abs(leader.getDistance()) > 1.0E-6 || leader.getSpeed() != 0
                        || cars.stream().anyMatch(car -> car.isRunning() || car.getSpeed() != 0 || car.getLaps() != initialLaps + 1))
                    throw invalid("The completed formation failed to park exactly at the station");
                finish(true, "One complete live-world lap and exact station stop verified");
                return;
            }
            if (leader.getLaps() != initialLaps || cars.stream().anyMatch(car -> !car.isRunning()))
                throw invalid("The actual formation stopped before finishing the course: " + diagnostics(cars));
            if (leader.getDistance() + 1.0E-6 < previousDistance) throw invalid("Continuous leader distance regressed before the finish");
            if (leader.getDistance() > previousDistance + 1.0E-5) lastMotionAt = level.getGameTime();
            previousDistance = leader.getDistance();
            if (level.getGameTime() - lastMotionAt > 600) throw invalid("The running formation made no progress for600 actual world ticks");
            if (elapsed > RIDE_TIMEOUT) throw invalid("Live-world ride exceeded the bounded commissioning timeout");
            if (elapsed % 400 == 0) CoasterEngineering.LOGGER.info("VOLCANIC_RIDE_PROGRESS {}", status());
        }

        private void prepare() {
            if (level.getGameTime() - requestedAt > LOAD_TIMEOUT) throw invalid("Existing chunks did not become tickable within1200 world ticks");
            if (heldTickets.isEmpty()) {
                for (var check : diskChecks.entrySet()) {
                    if (!check.getValue().isDone()) return;
                    Optional<CompoundTag> saved = check.getValue().join();
                    if (saved.isEmpty() || ChunkStatus.byName(saved.get().getString("Status")) != ChunkStatus.FULL)
                        throw invalid("Missing or unfinished saved chunk " + check.getKey() + "; validation will not generate it");
                }
                for (ChunkPos pos : footprint) {
                    level.getChunkSource().addRegionTicket(TICKET, pos, TICKET_DISTANCE, ticketId);
                    heldTickets.add(pos);
                }
                phase = "loading existing temporary chunks";
            }
            for (ChunkPos pos : footprint) {
                if (level.getChunkSource().getChunkNow(pos.x, pos.z) == null
                        || !level.getChunkSource().isPositionTicking(pos.toLong())) return;
            }
            CoasterEntity leader = leader(level, course.id());
            requirePausedEmptyFormation(level, course, leader);
            formation(leader);
            if (!leader.resetToStation() || !leader.startRide())
                throw invalid("Dispatch was refused by the actual station/body/chunk safety checks: " + diagnostics(leader.getLoadedFormation()));
            initialLaps = leader.getLaps();
            previousDistance = 0;
            rideStartedAt = lastMotionAt = level.getGameTime();
            phase = "running actual empty formation";
            observe(leader.getLoadedFormation(), leader);
        }

        private List<CoasterEntity> formation(CoasterEntity leader) {
            List<CoasterEntity> cars = leader.getLoadedFormation();
            if (!leaderId.equals(leader.getUUID()) || !cars.stream().map(Entity::getUUID).toList().equals(carIds))
                throw invalid("A saved formation member disappeared or was replaced");
            for (Entity entity : level.getAllEntities()) {
                if (entity instanceof CoasterEntity car && course.id().equals(car.courseId())
                        && !car.isRemoved() && !carIds.contains(car.getUUID()))
                    throw invalid("An extra vehicle appeared on the uniquely reserved course");
            }
            return cars;
        }

        private void observe(List<CoasterEntity> cars, CoasterEntity leader) {
            SplineTrack track = course.track();
            for (int index = 0; index < cars.size(); index++) {
                CoasterEntity car = cars.get(index);
                double distance = car.getDistance();
                double speed = car.getSpeed();
                if (!Double.isFinite(distance) || !Double.isFinite(speed) || speed < 0 || speed > CoasterEntity.MAX_SPEED + 1.0E-6)
                    throw invalid("Nonfinite or excessive actual movement in car " + index);
                double expected = TrainSpacing.distance(track, leader.getDistance(), index, leader.carSpacing());
                double error = Math.abs(distance - expected);
                error = Math.min(error, Math.abs(track.length() - error));
                TrackVec3 position = track.sample(distance).position();
                if (error > .05 || car.position().distanceTo(new Vec3(position.x(), position.y(), position.z())) > .05
                        || Math.abs(speed - leader.getSpeed()) > 1.0E-6)
                    throw invalid("Actual car " + index + " left its own arc, spacing or shared velocity");
                maxSpeed = Math.max(maxSpeed, speed);
                minHeight = Math.min(minHeight, car.getY());
                maxHeight = Math.max(maxHeight, car.getY());
                // The dispatch preflight also calls observe at elapsed0. Only
                // subsequent ordinary ride ticks contribute exposure duration.
                if (level.getGameTime() > rideStartedAt) observeLighting(track.sample(distance), distance);
            }
        }

        private void observeLighting(TrackSample sample, double distance) {
            TrackFrame frame = TrackFrame.from(sample);
            for (double seat : new double[] {-.45, .45}) {
                // Passenger feet follow banked seat axes; Minecraft player eyes
                // remain upright1.62 blocks above those feet, matching entity seats.
                TrackVec3 eye = sample.position().add(frame.right().scale(seat))
                        .add(frame.up().scale(.45)).add(new TrackVec3(0, 1.62, 0));
                BlockPos pos = BlockPos.containing(eye.x(), eye.y(), eye.z());
                if (!level.hasChunkAt(pos)) throw invalid("Seat-eye lighting chunk unloaded during live validation");
                int block = level.getBrightness(LightLayer.BLOCK, pos);
                int sky = level.getBrightness(LightLayer.SKY, pos);
                lightExposure.computeIfAbsent("OVERALL", ignored -> new LightAccumulator()).add(block, sky);
                if (course.id().equals(VolcanicWorldBuilder.COURSE_ID) && course.track().points().size() == 45)
                    lightExposure.computeIfAbsent(lightingStage(distance), ignored -> new LightAccumulator()).add(block, sky);
            }
        }

        private String lightingStage(double distance) {
            int[] starts = {0, 6, 8, 11, 14, 22, 37};
            String[] names = {"EXPLORE", "ANOMALY", "DROP", "MONSTER", "CAVERN", "CLIMAX", "RETURN"};
            for (int i = starts.length - 1; i >= 0; i--)
                if (distance >= course.track().controlPointDistance(starts[i])) return names[i];
            return names[0];
        }

        String status() {
            CoasterEntity leader = ownLeader();
            return String.format(Locale.ROOT, "%s; course=%s; %.1f/%.1f blocks; %d actual ride ticks; max %.1f km/h; %d temporary chunks; empty train",
                    phase, course.id(), leader == null ? previousDistance : leader.getDistance(), course.track().length(),
                    rideStartedAt < 0 ? 0 : level.getGameTime() - rideStartedAt, maxSpeed * 72, heldTickets.size());
        }

        void finish(boolean passed, String reason) {
            if (ACTIVE.get(level) != this) return;
            try {
                CoasterEntity leader = ownLeader();
                if (leader != null) {
                    leader.emergencyStop();
                    List<CoasterEntity> cars = leader.getLoadedFormation();
                    if (CoasterSavedData.get(level).getCourse(course.id()) == course
                            && leaderId.equals(CoasterSavedData.get(level).vehicleId(course.id()))
                            && !cars.isEmpty() && cars.stream().noneMatch(Entity::isVehicle)) {
                        if (!leader.resetToStation() && passed) {
                            passed = false;
                            reason = "Completed lap could not safely reset the unchanged empty formation";
                        }
                    }
                }
            } catch (RuntimeException cleanupFailure) {
                passed = false;
                reason += "; reset failed: " + message(cleanupFailure);
            } finally {
                for (ChunkPos pos : heldTickets)
                    level.getChunkSource().removeRegionTicket(TICKET, pos, TICKET_DISTANCE, ticketId);
                heldTickets.clear();
                ACTIVE.remove(level);
            }
            Result result = new Result(course.id(), passed, reason,
                    rideStartedAt < 0 ? 0 : level.getGameTime() - rideStartedAt, course.track().length(), maxSpeed,
                    Double.isFinite(minHeight) ? minHeight : 0, Double.isFinite(maxHeight) ? maxHeight : 0, carIds.size());
            RESULTS.put(level, result);
            Map<String, LightDistribution> distributions = new LinkedHashMap<>();
            lightExposure.forEach((stage, accumulator) -> distributions.put(stage, accumulator.result()));
            LightingResult lighting = new LightingResult(course.id(), passed, result.ticks(), carIds.size(), distributions,
                    "Raw BLOCK and SKY exposure at two upright rider eyes per car; SKY is before day/night subtraction. "
                            + "Bright eyes do not certify visible cave landmarks or scenery quality; human viewing remains necessary.");
            LIGHTING_RESULTS.put(level, lighting);
            CoasterEngineering.LOGGER.info("COASTER_RIDE_LIGHTING {}", new Gson().toJson(lighting));
            if (passed) CoasterEngineering.LOGGER.info("VOLCANIC_RIDE_VALIDATED {}", result);
            else CoasterEngineering.LOGGER.error("VOLCANIC_RIDE_VALIDATION_FAILED {}", result);
        }

        private CoasterEntity ownLeader() {
            Entity entity = level.getEntity(leaderId);
            return entity instanceof CoasterEntity car && !car.isRemoved() && car.isTrainLeader() ? car : null;
        }

        private String diagnostics(List<CoasterEntity> cars) {
            ArrayList<String> details = new ArrayList<>();
            for (CoasterEntity car : cars) {
                ArrayList<String> blocks = new ArrayList<>();
                ArrayList<String> poses = new ArrayList<>();
                for (double offset = 0; offset <= 2; offset += SAMPLE_INTERVAL) {
                    TrackSample next = course.track().sample(car.getDistance() + offset);
                    poses.add("distance=" + (car.getDistance() + offset) + ", clear=" + car.canUseTrackSample(next)
                            + ", position=" + next.position());
                }
                BlockPos anchor = car.blockPosition();
                for (BlockPos pos : BlockPos.betweenClosed(anchor.offset(-3, -3, -3), anchor.offset(3, 4, 3))) {
                    if (!level.hasChunkAt(pos)) continue;
                    BlockState state = level.getBlockState(pos);
                    if (!state.getCollisionShape(level, pos).isEmpty() || !state.getFluidState().isEmpty()) {
                        blocks.add(pos.toShortString() + "=" + state);
                        if (blocks.size() >= 24) break;
                    }
                }
                details.add("car=" + car.carIndex() + " position=" + car.position() + " distance=" + car.getDistance()
                        + " speed=" + car.getSpeed() + " loaded=" + level.hasChunkAt(anchor) + " upcomingPoses=" + poses
                        + " nearbyCollisionBlocks=" + blocks);
            }
            return String.join(" | ", details);
        }
    }

    private static Set<ChunkPos> footprint(ServerLevel level, SplineTrack track) {
        LinkedHashSet<ChunkPos> chunks = new LinkedHashSet<>();
        int steps = (int) Math.ceil(track.length() / SAMPLE_INTERVAL);
        for (int step = 0; step <= steps; step++) {
            TrackSample sample = track.sample(Math.min(track.length(), step * SAMPLE_INTERVAL));
            TrackVec3 p = sample.position();
            if (!Double.isFinite(p.x()) || !Double.isFinite(p.y()) || !Double.isFinite(p.z())
                    || p.y() - FOOTPRINT_MARGIN < level.getMinBuildHeight() || p.y() + FOOTPRINT_MARGIN > level.getMaxBuildHeight()
                    || !level.getWorldBorder().isWithinBounds(BlockPos.containing(p.x() - FOOTPRINT_MARGIN, p.y(), p.z() - FOOTPRINT_MARGIN))
                    || !level.getWorldBorder().isWithinBounds(BlockPos.containing(p.x() + FOOTPRINT_MARGIN, p.y(), p.z() + FOOTPRINT_MARGIN)))
                throw invalid("Course cart/rider footprint exceeds the world bounds");
            int minX = Mth.floor(p.x() - FOOTPRINT_MARGIN) >> 4, maxX = Mth.floor(p.x() + FOOTPRINT_MARGIN) >> 4;
            int minZ = Mth.floor(p.z() - FOOTPRINT_MARGIN) >> 4, maxZ = Mth.floor(p.z() + FOOTPRINT_MARGIN) >> 4;
            for (int x = minX; x <= maxX; x++) for (int z = minZ; z <= maxZ; z++) {
                chunks.add(new ChunkPos(x, z));
                if (chunks.size() > MAX_CHUNKS) throw invalid("Course footprint exceeds the bounded chunk budget");
            }
        }
        return chunks;
    }

    private static void requirePausedEmptyFormation(ServerLevel level, Course course, CoasterEntity leader) {
        if (CoasterSavedData.get(level).isEmergency(course.id())) throw invalid("Clear the course emergency explicitly before commissioning");
        List<CoasterEntity> cars = leader.getLoadedFormation();
        if (cars.isEmpty() || cars.size() != leader.carCount() || cars.stream().anyMatch(car -> car.isRunning() || car.isVehicle() || car.getSpeed() != 0))
            throw invalid("The reserved complete formation must be loaded, paused and empty");
        if (Math.abs(leader.getDistance()) > 1.0E-6) throw invalid("Return the paused empty train to its station before commissioning");
    }

    private static CoasterEntity leader(ServerLevel level, UUID courseId) {
        CoasterEntity leader = leaderOrNull(level, courseId);
        if (leader == null) throw invalid("The course has no loaded reserved leader; validation never spawns a replacement");
        return leader;
    }

    private static CoasterEntity leaderOrNull(ServerLevel level, UUID courseId) {
        UUID id = CoasterSavedData.get(level).vehicleId(courseId);
        Entity entity = id == null ? null : level.getEntity(id);
        return entity instanceof CoasterEntity car && !car.isRemoved() && car.isTrainLeader()
                && courseId.equals(car.courseId()) ? car : null;
    }

    private static IllegalStateException invalid(String message) { return new IllegalStateException(message); }
    private static String message(RuntimeException error) { return error.getMessage() == null ? error.toString() : error.getMessage(); }
}
