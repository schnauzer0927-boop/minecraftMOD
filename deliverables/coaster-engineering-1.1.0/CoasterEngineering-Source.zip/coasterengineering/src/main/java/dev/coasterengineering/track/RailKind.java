package dev.coasterengineering.track;

/** Independent coaster segment roles; these are never vanilla minecart rails. */
public enum RailKind {
    NORMAL, BOOST, BRAKE, LIFT, STATION
}
