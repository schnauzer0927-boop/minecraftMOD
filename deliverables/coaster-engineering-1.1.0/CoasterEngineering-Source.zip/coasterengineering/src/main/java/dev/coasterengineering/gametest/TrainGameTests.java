package dev.coasterengineering.gametest;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import dev.coasterengineering.world.TrainService;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/** Three-car tests use actual world ticks and a single persisted leader reservation. */
@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class TrainGameTests {
    // Forge 47.4.10 supplies the GameTestHolder namespace to this relative name.
    private static final String TEMPLATE = "empty";
    private static final double CAR_SPACING = 4.0;
    private static final double POSITION_TOLERANCE = .05;

    private TrainGameTests() { }

    @GameTest(template = TEMPLATE, timeoutTicks = 620)
    public static void threeCarFormationMaintainsArcSpacingAndParksTogether(GameTestHelper helper) {
        TrainFixture fixture = fixture(helper);
        helper.assertTrue(fixture.leader.startRide(), "A complete three-car train must dispatch");
        boolean[] finished = {false};
        for (int tick = 1; tick <= 600; tick++) {
            int elapsed = tick;
            helper.runAfterDelay(tick, () -> {
                if (finished[0]) return;
                assertFormation(helper, fixture);
                if (elapsed == 40) {
                    helper.assertTrue(fixture.leader.getDistance() > 5 && fixture.leader.getSpeed() > 0,
                            "Formation test must exercise live motion beyond the station");
                }
                if (fixture.leader.getLaps() >= 1 && !fixture.leader.isRunning()) {
                    near(helper, fixture.leader.getDistance(), 0, "Returned train leader station distance");
                    for (CoasterEntity car : fixture.cars) {
                        helper.assertFalse(car.isRunning(), "Every car must park when the leader completes its lap");
                        near(helper, car.getSpeed(), 0, "Every parked car speed");
                    }
                    finished[0] = true;
                    List<Vec3> parkedPositions = positions(fixture.cars);
                    GameTestScheduling.after(helper, 10, () -> {
                        assertFormation(helper, fixture);
                        assertHeld(helper, fixture.cars, parkedPositions);
                        cleanup(helper, fixture);
                        helper.succeed();
                    });
                } else if (elapsed == 600) {
                    helper.assertTrue(false, "The complete train must finish a lap and park within600ticks");
                }
            });
        }
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 40)
    public static void sixPassengersBoardTwoDistinctSeatsPerCar(GameTestHelper helper) {
        TrainFixture fixture = fixture(helper);
        List<Player> riders = new ArrayList<>();
        for (CoasterEntity car : fixture.cars) {
            Player first = playerAt(helper, car);
            Player second = playerAt(helper, car);
            Player third = playerAt(helper, car);
            helper.assertTrue(car.interact(first, InteractionHand.MAIN_HAND).consumesAction(),
                    "Every car must accept its first rider");
            helper.assertTrue(car.interact(second, InteractionHand.MAIN_HAND).consumesAction(),
                    "Every car must accept its second rider");
            car.interact(third, InteractionHand.MAIN_HAND);
            helper.assertTrue(first.getVehicle() == car && second.getVehicle() == car,
                    "Accepted riders must mount their selected car, rather than transfer to the leader");
            helper.assertTrue(third.getVehicle() == null && car.getPassengers().size() == 2,
                    "Each car must enforce its own two-seat capacity");
            car.positionRider(first);
            car.positionRider(second);
            helper.assertTrue(first.position().distanceTo(second.position()) > .25,
                    "Both riders must occupy distinct seats in each car");
            riders.add(first);
            riders.add(second);
        }
        helper.assertTrue(riders.size() == 6 && fixture.cars.stream().mapToInt(car -> car.getPassengers().size()).sum() == 6,
                "The actual three-car formation must carry six mounted players");
        for (Player player : riders) player.stopRiding();
        helper.assertTrue(fixture.cars.stream().allMatch(car -> car.getPassengers().isEmpty()),
                "Dismounting all six players must release every car's seats");
        cleanup(helper, fixture);
        helper.succeed();
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 90)
    public static void emergencyStopFromFollowerHoldsWholeFormation(GameTestHelper helper) {
        TrainFixture fixture = fixture(helper);
        helper.assertTrue(fixture.leader.startRide(), "Emergency-stop train must initially move");
        helper.runAfterDelay(30, () -> {
            assertFormation(helper, fixture);
            helper.assertTrue(fixture.leader.getSpeed() > 0, "Emergency stop must interrupt actual movement");
            List<Vec3> safePositions = positions(fixture.cars);
            double safeDistance = fixture.leader.getDistance();
            fixture.cars.get(2).emergencyStop();
            for (CoasterEntity car : fixture.cars) {
                helper.assertFalse(car.isRunning(), "Stop requested on a follower must immediately stop every car");
                near(helper, car.getSpeed(), 0, "Synchronous whole-train emergency speed");
            }
            for (int delay = 1; delay <= 30; delay++) {
                int elapsed = delay;
                GameTestScheduling.after(helper, delay, () -> {
                    near(helper, fixture.leader.getDistance(), safeDistance, "Stopped formation leader distance");
                    assertHeld(helper, fixture.cars, safePositions);
                    assertFormation(helper, fixture);
                    if (elapsed == 30) {
                        cleanup(helper, fixture);
                        helper.succeed();
                    }
                });
            }
        });
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 95)
    public static void missingFollowerStopsWithoutSpawningReplacementOrSecondLeader(GameTestHelper helper) {
        TrainFixture fixture = fixture(helper);
        helper.assertTrue(fixture.leader.startRide(), "Missing-car train must initially move");
        helper.runAfterDelay(30, () -> {
            helper.assertTrue(fixture.leader.getSpeed() > 0, "Follower removal must interrupt a moving train");
            CoasterEntity removed = fixture.cars.get(2);
            UUID missingId = removed.getUUID();
            List<CoasterEntity> survivors = fixture.cars.subList(0, 2);
            List<Vec3> safePositions = positions(survivors);
            double safeDistance = fixture.leader.getDistance();
            removed.discard();
            for (int delay = 1; delay <= 30; delay++) {
                int elapsed = delay;
                GameTestScheduling.after(helper, delay, () -> {
                    near(helper, fixture.leader.getDistance(), safeDistance,
                            "Missing follower must halt the leader before committing any subsequent movement");
                    assertHeld(helper, survivors, safePositions);
                    helper.assertTrue(fixture.leader.getLoadedFormation().isEmpty(),
                            "A missing car must invalidate the complete loaded formation");
                    helper.assertTrue(helper.getLevel().getEntity(missingId) == null,
                            "Safety handling must not regenerate a missing follower");
                    long existingCars = 0;
                    for (Entity entity : helper.getLevel().getAllEntities()) {
                        if (entity instanceof CoasterEntity car && fixture.course.id().equals(car.courseId()) && !car.isRemoved())
                            existingCars++;
                    }
                    helper.assertTrue(existingCars == 2, "Safety handling must not silently add replacement cars or a second leader");
                    helper.assertTrue(fixture.leader.getUUID().equals(CoasterSavedData.get(helper.getLevel()).vehicleId(fixture.course.id())),
                            "An incomplete formation must preserve its original persisted leader reservation");
                    if (elapsed == 30) {
                        helper.assertFalse(fixture.leader.startRide(), "Incomplete formation must refuse redispatch");
                        CoasterEntity duplicate = createVehicle(helper);
                        duplicate.setCourse(fixture.course.id());
                        helper.assertFalse(duplicate.startRide(), "Missing-car safety must not permit a second course leader");
                        duplicate.discard();
                        cleanup(helper, fixture);
                        helper.succeed();
                    }
                });
            }
        });
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 105)
    public static void leaderAndFollowersReloadPausedWithStableLinksAndReservation(GameTestHelper helper) {
        TrainFixture fixture = fixture(helper);
        helper.assertTrue(fixture.leader.startRide(), "Persistence train must initially move");
        helper.runAfterDelay(30, () -> {
            helper.assertTrue(fixture.leader.getSpeed() > 0, "Persistence must snapshot an in-progress train");
            List<CompoundTag> snapshots = fixture.cars.stream().map(car -> car.saveWithoutId(new CompoundTag())).toList();
            List<UUID> carIds = fixture.cars.stream().map(Entity::getUUID).toList();
            List<Double> savedDistances = fixture.cars.stream().map(CoasterEntity::getDistance).toList();
            CoasterSavedData savedData = CoasterSavedData.load(CoasterSavedData.get(helper.getLevel()).save(new CompoundTag()));
            helper.assertTrue(carIds.get(0).equals(savedData.vehicleId(fixture.course.id())),
                    "World-data NBT must preserve the single leader reservation");
            // Use actual unload semantics so this exercises the UUID links across
            // new entity instances without destroying the persisted reservation.
            for (CoasterEntity car : fixture.cars) car.remove(Entity.RemovalReason.UNLOADED_TO_CHUNK);
            GameTestScheduling.after(helper, 2, () -> {
                List<CoasterEntity> restoredCars = new ArrayList<>();
                for (int index = 0; index < snapshots.size(); index++) {
                    CoasterEntity restored = createVehicle(helper);
                    restored.load(snapshots.get(index));
                    helper.assertTrue(restored.getUUID().equals(carIds.get(index)), "Each loaded car must retain its own UUID");
                    helper.assertTrue(fixture.course.id().equals(restored.courseId()), "Each loaded car must retain its course link");
                    near(helper, restored.getDistance(), savedDistances.get(index), "Each loaded car's continuous distance");
                    helper.assertFalse(restored.isRunning(), "Every loaded car must initially pause");
                    near(helper, restored.getSpeed(), 0, "Every loaded car must initially have zero speed");
                    helper.assertTrue(restored.carIndex() == index, "Car indices must retain their original formation order");
                    helper.assertTrue(helper.getLevel().addFreshEntity(restored), "World must accept the restored car's stable UUID");
                    restoredCars.add(restored);
                }
                CoasterEntity restoredLeader = restoredCars.get(0);
                helper.assertTrue(restoredLeader.isTrainLeader() && restoredLeader.carCount() == 3,
                        "Restored leader must retain its original three-car formation");
                helper.assertTrue(restoredLeader.followerIds().equals(carIds.subList(1, 3)),
                        "Restored leader must retain both follower UUID links in order");
                for (int index = 1; index < restoredCars.size(); index++) {
                    CoasterEntity follower = restoredCars.get(index);
                    helper.assertFalse(follower.isTrainLeader(), "Loaded followers must never become independent leaders");
                    helper.assertTrue(carIds.get(0).equals(follower.leaderId()) && follower.resolveLeader() == restoredLeader,
                            "Both loaded followers must resolve their original loaded leader");
                }
                TrainFixture restoredFixture = new TrainFixture(fixture.course, restoredLeader, List.copyOf(restoredCars));
                assertFormation(helper, restoredFixture);
                List<Vec3> pausedPositions = positions(restoredCars);
                GameTestScheduling.after(helper, 10, () -> {
                    assertHeld(helper, restoredCars, pausedPositions);
                    helper.assertTrue(restoredLeader.startRide(), "A complete safely reloaded formation must accept explicit resume");
                    GameTestScheduling.after(helper, 10, () -> {
                        helper.assertTrue(restoredLeader.getSpeed() > 0 && restoredLeader.getDistance() > savedDistances.get(0),
                                "Explicit resume must move the restored actual world formation");
                        assertFormation(helper, restoredFixture);
                        cleanup(helper, restoredFixture);
                        helper.succeed();
                    });
                });
            });
        });
    }

    private static TrainFixture fixture(GameTestHelper helper) {
        double[][] coordinates = {
                {8.5, 3, 6.5}, {16.5, 3, 6.5}, {23.5, 4, 9.5}, {24.5, 8, 16.5},
                {20.5, 10, 23.5}, {12.5, 7, 24.5}, {6.5, 3, 20.5}, {5.5, 3, 12.5}
        };
        RailKind[] kinds = {RailKind.STATION, RailKind.BOOST, RailKind.BOOST, RailKind.LIFT,
                RailKind.BOOST, RailKind.BRAKE, RailKind.BOOST, RailKind.BOOST};
        List<ControlPoint> points = new ArrayList<>();
        for (int i = 0; i < coordinates.length; i++) {
            Vec3 absolute = helper.absoluteVec(new Vec3(coordinates[i][0], coordinates[i][1], coordinates[i][2]));
            points.add(new ControlPoint(new TrackVec3(absolute.x, absolute.y, absolute.z),
                    i == 2 || i == 5 ? 20 : 0, kinds[i], i == 0 ? .32 : .6));
        }
        Course course = new Course(UUID.randomUUID(), "GameTest three-car elevated loop", new SplineTrack(points, true),
                helper.absolutePos(new BlockPos(8, 2, 4)), true);
        CoasterSavedData.get(helper.getLevel()).putCourse(course);
        CoasterEntity leader = createVehicle(helper);
        leader.setCourse(course.id());
        helper.assertTrue(leader.resetToStation(), "Train fixture leader must safely park at its registered station");
        helper.assertTrue(helper.getLevel().addFreshEntity(leader), "Train fixture must insert its actual leader entity");
        helper.assertTrue(TrainService.setCarCount(leader, 3), "Stopped leader must form a real three-car train");
        List<CoasterEntity> cars = List.copyOf(leader.getLoadedFormation());
        helper.assertTrue(cars.size() == 3 && cars.get(0) == leader, "All three cars must exist with the leader first");
        return new TrainFixture(course, leader, cars);
    }

    private static void assertFormation(GameTestHelper helper, TrainFixture fixture) {
        List<CoasterEntity> current = fixture.leader.getLoadedFormation();
        helper.assertTrue(current.size() == 3, "All three formation members must remain loaded and present");
        double length = fixture.course.track().length();
        for (int index = 0; index < current.size(); index++) {
            CoasterEntity car = current.get(index);
            double expectedDistance = (fixture.leader.getDistance() - index * CAR_SPACING) % length;
            if (expectedDistance < 0) expectedDistance += length;
            near(helper, car.getDistance(), expectedDistance, "Continuous arc spacing for car" + index);
            near(helper, car.getSpeed(), fixture.leader.getSpeed(), "Synchronized speed for car" + index);
            helper.assertTrue(car.isRunning() == fixture.leader.isRunning(), "Every car must share the leader's running state");
            helper.assertTrue(car.carIndex() == index, "Car order must remain stable");
            helper.assertTrue(car.position().distanceTo(toVec3(fixture.course.track().sample(expectedDistance).position())) < POSITION_TOLERANCE,
                    "Every car must follow its own spline pose, including banked/elevated arcs");
            helper.assertTrue(Double.isFinite(car.getDistance()) && Double.isFinite(car.getSpeed())
                            && Float.isFinite(car.getXRot()) && Float.isFinite(car.getYRot()) && Float.isFinite(car.getBank()),
                    "Every train car must preserve finite continuous state and attitude");
        }
        helper.assertTrue(fixture.leader.getUUID().equals(CoasterSavedData.get(helper.getLevel()).vehicleId(fixture.course.id())),
                "The persisted course reservation must always identify only the formation leader");
    }

    private static void assertHeld(GameTestHelper helper, List<CoasterEntity> cars, List<Vec3> expectedPositions) {
        for (int index = 0; index < cars.size(); index++) {
            CoasterEntity car = cars.get(index);
            helper.assertFalse(car.isRunning(), "Every held car must remain stopped");
            near(helper, car.getSpeed(), 0, "Every held car speed");
            helper.assertTrue(car.position().distanceTo(expectedPositions.get(index)) < POSITION_TOLERANCE,
                    "Every stopped car must retain its pose without drifting or falling");
        }
    }

    private static List<Vec3> positions(List<CoasterEntity> cars) {
        return cars.stream().map(Entity::position).toList();
    }

    private static CoasterEntity createVehicle(GameTestHelper helper) {
        return new CoasterEntity(CoasterRegistries.COASTER.get(), helper.getLevel());
    }

    private static Player playerAt(GameTestHelper helper, CoasterEntity car) {
        Player player = helper.makeMockSurvivalPlayer();
        player.moveTo(car.position().add(0, 0, 1));
        return player;
    }

    private static Vec3 toVec3(TrackVec3 vector) {
        return new Vec3(vector.x(), vector.y(), vector.z());
    }

    private static void near(GameTestHelper helper, double actual, double expected, String description) {
        helper.assertTrue(Double.isFinite(actual) && Math.abs(actual - expected) < .001,
                description + ": expected " + expected + ", actual " + actual);
    }

    private static void cleanup(GameTestHelper helper, TrainFixture fixture) {
        for (CoasterEntity car : fixture.cars) {
            car.ejectPassengers();
            if (!car.isRemoved()) car.discard();
        }
        CoasterSavedData.get(helper.getLevel()).removeCourse(fixture.course.id());
    }

    private record TrainFixture(Course course, CoasterEntity leader, List<CoasterEntity> cars) { }
}
