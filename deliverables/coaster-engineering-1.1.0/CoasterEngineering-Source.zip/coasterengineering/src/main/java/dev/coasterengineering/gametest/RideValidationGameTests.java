package dev.coasterengineering.gametest;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.RideValidationService;
import dev.coasterengineering.world.TrainService;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class RideValidationGameTests {
    private RideValidationGameTests() { }

    @GameTest(template = "empty", timeoutTicks = 1500)
    public static void commissioningRejectsUnsafeDispatchThenVerifiesTheRealUnchangedTrain(GameTestHelper helper) {
        ServerCourseFixture fixture = ServerCourseFixture.create(helper);
        CoasterSavedData data = CoasterSavedData.get(helper.getLevel());
        UUID courseId = fixture.course().id();
        helper.assertTrue(TrainService.setCarCount(fixture.vehicle(), 3),
                "Commissioning fixture must contain three actual linked cars");
        List<CoasterEntity> cars = fixture.vehicle().getLoadedFormation();
        List<UUID> originalIds = cars.stream().map(Entity::getUUID).toList();
        Player rider = fixture.rider(helper);
        helper.assertFalse(RideValidationService.begin(helper.getLevel(), courseId),
                "Empty-train commissioning must reject a real occupied train without ejecting its rider");
        helper.assertTrue(rider.getVehicle() == fixture.vehicle() && !fixture.vehicle().isRunning(),
                "Rejected occupied commissioning must preserve the rider and stopped train");
        rider.stopRiding();
        data.setEmergency(courseId, true);
        helper.assertFalse(RideValidationService.begin(helper.getLevel(), courseId),
                "Commissioning must not bypass the authoritative course emergency alarm");
        helper.assertTrue(data.isEmergency(courseId) && !fixture.vehicle().isRunning(),
                "Rejected alarm commissioning must leave the actual alarm and paused state intact");
        data.setEmergency(courseId, false);
        BlockPos light = helper.absolutePos(new BlockPos(8, 8, 6));
        BlockState previous = helper.getLevel().getBlockState(light);
        helper.assertTrue(previous.isAir(), "Lighting fixture must add a real source above the safe rider envelope");
        helper.getLevel().setBlock(light, Blocks.SEA_LANTERN.defaultBlockState(), 3);
        for (double d = 0; d < fixture.course().track().length(); d += .25)
            helper.assertTrue(fixture.vehicle().canUseTrackSample(fixture.course().track().sample(d)),
                    "The real lighting source must not obstruct any part of the original swept path");
        helper.assertTrue(RideValidationService.begin(helper.getLevel(), courseId),
                "A complete paused empty train must accept an actual asynchronous commissioning job");
        boolean[] completed = {false};
        for (int tick = 1; tick <= 1480; tick++) {
            int elapsed = tick;
            helper.runAfterDelay(tick, () -> {
                if (completed[0]) return;
                RideValidationService.Result result = RideValidationService.lastResult(helper.getLevel());
                if (result == null || !result.courseId().equals(courseId)) {
                    helper.assertTrue(fixture.vehicle().getLaps() == 0,
                            "A commissioning result must be produced when the real train completes its lap");
                    helper.assertTrue(elapsed < 1480,
                            "Commissioning must finish within its bounded load and ride interval: "
                                    + RideValidationService.status(helper.getLevel()));
                    return;
                }
                helper.assertTrue(result.passed(), "Actual commissioning must pass: " + result);
                helper.assertTrue(result.cars() == 3 && result.ticks() > 40 && result.maxSpeed() > .2,
                        "Commissioning evidence must come from meaningful real movement of all three cars");
                helper.assertTrue(Math.abs(result.length() - fixture.course().track().length()) < .001
                                && result.maxHeight() - result.minHeight() > 5,
                        "Commissioning evidence must report the actual route length and traversed height change");
                helper.assertTrue(fixture.vehicle().getLoadedFormation().stream().map(Entity::getUUID).toList().equals(originalIds),
                        "Commissioning must retain every original formation UUID without spawning replacements");
                helper.assertTrue(fixture.vehicle().getLaps() == 1 && !fixture.vehicle().isRunning()
                                && fixture.vehicle().getDistance() == 0 && cars.stream().allMatch(car -> car.getSpeed() == 0 && !car.isRunning()),
                        "A successful actual commissioning must leave the complete same formation parked at the station");
                RideValidationService.LightingResult lighting = RideValidationService.lastLightingResult(helper.getLevel());
                helper.assertTrue(lighting != null && lighting.passed() && lighting.courseId().equals(courseId),
                        "The actual ride must produce separate authoritative seat-eye lighting evidence");
                RideValidationService.LightDistribution exposure = lighting.exposure().get("OVERALL");
                helper.assertTrue(exposure != null && exposure.samples() == result.ticks() * 6
                                && exposure.blockHistogram().stream().mapToLong(Long::longValue).sum() == exposure.samples()
                                && exposure.skyHistogram().stream().mapToLong(Long::longValue).sum() == exposure.samples(),
                        "Every ordinary world tick must measure both real light layers at both seats in all three cars exactly once");
                helper.assertTrue(exposure.blockHistogram().subList(1, 16).stream().mapToLong(Long::longValue).sum() > 0
                                && helper.getLevel().getBrightness(LightLayer.BLOCK, light.below(3)) >= 8,
                        "Exposure must include propagated light from the real lamp, rather than fabricated zero or sky-only readings");
                helper.getLevel().setBlock(light, previous, 3);
                completed[0] = true;
                fixture.cleanup(helper);
                helper.succeed();
            });
        }
    }
}
