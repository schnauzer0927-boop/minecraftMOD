package dev.coasterengineering.client;

import dev.coasterengineering.registry.CoasterRegistries;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;

@Mod.EventBusSubscriber(modid = "coasterengineering", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class CoasterScreens {
    private CoasterScreens() { }

    @SubscribeEvent
    public static void setup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> MenuScreens.register(CoasterRegistries.STATION_MENU.get(), StationScreen::new));
    }
}
