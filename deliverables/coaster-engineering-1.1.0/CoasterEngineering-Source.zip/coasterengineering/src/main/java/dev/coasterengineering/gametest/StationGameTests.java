package dev.coasterengineering.gametest;

import com.mojang.authlib.GameProfile;
import dev.coasterengineering.menu.StationMenu;
import dev.coasterengineering.network.StationActionPacket;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.station.StationControllerBlockEntity;
import dev.coasterengineering.world.CoasterSavedData;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.Connection;
import net.minecraft.network.protocol.PacketFlow;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.network.ServerGamePacketListenerImpl;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class StationGameTests {
    private StationGameTests() { }

    @GameTest(template = "empty", timeoutTicks = 360)
    public static void automaticDepartureRequiresRiderAndFullDwell(GameTestHelper helper) {
        StationFixture fixture = fixture(helper);
        fixture.controller.setDwellTicks(140);
        fixture.controller.setAutoDeparture(true);
        helper.runAfterDelay(160, () -> {
            helper.assertFalse(fixture.course.vehicle().isRunning(), "Automatic station must not dispatch an empty coaster");
            near(helper, fixture.course.vehicle().getDistance(), 0, "Empty station must retain boarding distance");
            fixture.course.rider(helper);
        });
        helper.runAfterDelay(200, () -> {
            helper.assertFalse(fixture.course.vehicle().isRunning(), "A newly boarded rider must receive the complete dwell interval");
            helper.assertTrue(fixture.controller.countdownTicks() > 0, "Station must report a real remaining dwell countdown");
        });
        helper.runAfterDelay(325, () -> {
            helper.assertTrue(fixture.course.vehicle().isRunning() && fixture.course.vehicle().getSpeed() > 0,
                    "Occupied complete station must automatically dispatch after its full140tick dwell");
            helper.assertTrue(fixture.course.vehicle().getPassengers().size() == 1,
                    "Automatic departure must retain the actual mounted rider");
            cleanup(helper, fixture);
            helper.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 230)
    public static void physicalRedstoneDispatchesOnlyOnFreshRisingEdges(GameTestHelper helper) {
        StationFixture fixture = fixture(helper);
        BlockPos signal = fixture.controller.getBlockPos().west();
        helper.runAfterDelay(5, () -> helper.getLevel().setBlock(signal, Blocks.REDSTONE_BLOCK.defaultBlockState(), 3));
        helper.runAfterDelay(25, () -> helper.assertTrue(fixture.course.vehicle().isRunning()
                        && fixture.course.vehicle().getDistance() > 0,
                "A physical low-to-high redstone edge must dispatch the actual station vehicle"));
        helper.runAfterDelay(170, () -> {
            helper.assertTrue(fixture.course.vehicle().getLaps() == 1 && !fixture.course.vehicle().isRunning(),
                    "A continuously high input must leave the returned vehicle stopped after exactlyone lap");
            near(helper, fixture.course.vehicle().getDistance(), 0, "High-input returned station distance");
        });
        helper.runAfterDelay(171, () -> helper.getLevel().setBlock(signal, Blocks.AIR.defaultBlockState(), 3));
        helper.runAfterDelay(175, () -> helper.getLevel().setBlock(signal, Blocks.REDSTONE_BLOCK.defaultBlockState(), 3));
        helper.runAfterDelay(200, () -> {
            helper.assertTrue(fixture.course.vehicle().getLaps() == 1 && fixture.course.vehicle().isRunning()
                            && fixture.course.vehicle().getDistance() > 0,
                    "A subsequent genuine low-to-high edge must dispatch the same reserved vehicle again");
            helper.getLevel().setBlock(signal, Blocks.AIR.defaultBlockState(), 3);
            cleanup(helper, fixture);
            helper.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 90)
    public static void emergencyLatchRejectsManualAndRedstoneUntilExplicitClear(GameTestHelper helper) {
        StationFixture fixture = fixture(helper);
        BlockPos signal = fixture.controller.getBlockPos().west();
        helper.assertTrue(fixture.controller.dispatch(), "Emergency-latch fixture must initially dispatch");
        Vec3[] stoppedPosition = {null};
        double[] stoppedDistance = {0};
        helper.runAfterDelay(20, () -> {
            helper.assertTrue(fixture.course.vehicle().getSpeed() > 0, "Station emergency must interrupt real motion");
            stoppedPosition[0] = fixture.course.vehicle().position();
            stoppedDistance[0] = fixture.course.vehicle().getDistance();
            fixture.controller.stopEmergency();
            helper.assertTrue(fixture.controller.emergencyLatched(), "Station emergency stop must latch visibly");
        });
        for (int tick = 21; tick <= 49; tick++) {
            helper.runAfterDelay(tick, () -> {
                helper.assertFalse(fixture.course.vehicle().isRunning(), "Latched station must keep its vehicle stopped");
                near(helper, fixture.course.vehicle().getSpeed(), 0, "Latched emergency speed");
                near(helper, fixture.course.vehicle().getDistance(), stoppedDistance[0], "Latched emergency continuous distance");
                helper.assertTrue(fixture.course.vehicle().position().distanceTo(stoppedPosition[0]) < .05,
                        "Latched emergency must hold the actual coaster pose without falling");
            });
        }
        helper.runAfterDelay(30, () -> {
            helper.assertFalse(fixture.controller.dispatch(), "Manual dispatch must not bypass a latched station emergency");
            helper.assertFalse(fixture.course.vehicle().startRide(), "Direct vehicle dispatch must not bypass the authoritative course emergency");
        });
        helper.runAfterDelay(32, () -> helper.getLevel().setBlock(signal, Blocks.REDSTONE_BLOCK.defaultBlockState(), 3));
        helper.runAfterDelay(50, () -> {
            helper.assertTrue(fixture.controller.emergencyLatched(), "Redstone must not clear the emergency latch");
            fixture.controller.clearEmergency();
            helper.assertFalse(fixture.controller.emergencyLatched(), "Explicit emergency clear must release the latch");
            helper.assertFalse(fixture.course.vehicle().isRunning(), "Clearing the latch must not itself start movement");
            helper.assertTrue(fixture.controller.dispatch(), "Separate explicit dispatch must resume after emergency clear");
        });
        helper.runAfterDelay(65, () -> {
            helper.assertTrue(fixture.course.vehicle().isRunning() && fixture.course.vehicle().getSpeed() > 0,
                    "Cleared station must resume the same reserved vehicle safely");
            helper.getLevel().setBlock(signal, Blocks.AIR.defaultBlockState(), 3);
            cleanup(helper, fixture);
            helper.succeed();
        });
    }

    @GameTest(template = "empty")
    public static void controllerSettingsEmergencyAndUniqueBindingSurviveNbt(GameTestHelper helper) {
        StationFixture fixture = fixture(helper);
        fixture.controller.setAutoDeparture(true);
        fixture.controller.setDwellTicks(360);
        fixture.controller.stopEmergency();
        CompoundTag saved = fixture.controller.saveWithFullMetadata();
        BlockEntity loaded = BlockEntity.loadStatic(fixture.controller.getBlockPos(), fixture.controller.getBlockState(), saved);
        helper.assertTrue(loaded instanceof StationControllerBlockEntity,
                "Registered block-entity factory must restore the real station controller");
        StationControllerBlockEntity restored = (StationControllerBlockEntity) loaded;
        helper.assertTrue(fixture.course.course().id().equals(restored.courseId()), "Station course binding must survive block-entity NBT");
        helper.assertTrue(restored.autoDeparture() && restored.emergencyLatched(), "Station automatic setting and emergency latch must survive NBT");
        helper.assertTrue(restored.dwellTicks() == 360, "Station dwell setting must survive NBT");
        CoasterSavedData data = CoasterSavedData.get(helper.getLevel());
        helper.assertTrue(fixture.controller.getBlockPos().equals(data.controllerPos(fixture.course.course().id())),
                "The running dimension must reserve exactly this controller position");
        CoasterSavedData reloadedData = CoasterSavedData.load(data.save(new CompoundTag()));
        helper.assertTrue(fixture.controller.getBlockPos().equals(reloadedData.controllerPos(fixture.course.course().id())),
                "World-data NBT must preserve the unique controller reservation");
        helper.assertTrue(reloadedData.isEmergency(fixture.course.course().id()),
                "World-data NBT must preserve the authoritative emergency independently of the console");
        helper.assertFalse(data.claimController(fixture.course.course().id(), fixture.controller.getBlockPos().offset(2, 0, 0)),
                "A second station position must not claim an alreadybound course");
        cleanup(helper, fixture);
        helper.succeed();
    }

    @GameTest(template = "empty", timeoutTicks = 45)
    public static void modernSavedConsoleCannotRelatchAnExplicitlyClearedWorldAlarm(GameTestHelper helper) {
        StationFixture fixture = fixture(helper);
        UUID courseId = fixture.course.course().id();
        CoasterSavedData data = CoasterSavedData.get(helper.getLevel());
        BlockPos position = fixture.controller.getBlockPos();
        fixture.controller.stopEmergency();
        CompoundTag latchedSnapshot = fixture.controller.saveWithFullMetadata();
        helper.assertTrue(latchedSnapshot.getInt("AlarmFormatVersion") == 2
                        && latchedSnapshot.getBoolean("EmergencyLatched"),
                "Regression must restore a genuinely latched modern console snapshot");
        helper.getLevel().setBlock(position, Blocks.AIR.defaultBlockState(), 3);
        helper.assertTrue(data.controllerPos(courseId) == null && data.isEmergency(courseId),
                "Removing the console must release only its claim while retaining the authoritative course alarm");
        helper.assertFalse(fixture.course.vehicle().startRide(),
                "Removing an emergency console must not permit direct vehicle dispatch");

        // An operator clears the saved course while this console is absent.
        // Reloading its old local true flag must not undo that explicit action.
        data.setEmergency(courseId, false);
        helper.getLevel().setBlock(position, CoasterRegistries.STATION_CONTROLLER.get().defaultBlockState(), 3);
        BlockEntity blockEntity = helper.getLevel().getBlockEntity(position);
        helper.assertTrue(blockEntity instanceof StationControllerBlockEntity,
                "Modern alarm regression must restore the real registered controller");
        StationControllerBlockEntity restored = (StationControllerBlockEntity) blockEntity;
        restored.load(latchedSnapshot);
        helper.assertFalse(restored.emergencyLatched(),
                "A server-bound modern console must immediately read the cleared authoritative alarm");
        helper.runAfterDelay(3, () -> {
            helper.assertTrue(position.equals(data.controllerPos(courseId)),
                    "Actual station ticks must restore the saved unique console binding");
            helper.assertFalse(restored.emergencyLatched() || data.isEmergency(courseId),
                    "Actual station ticks must not relatch the course from a stale modern local snapshot");
            helper.assertFalse(fixture.course.vehicle().isRunning(),
                    "Restoring a cleared console must leave the train paused until a separate dispatch");
            helper.assertTrue(restored.dispatch(),
                    "A separate explicit dispatch must work after the authoritative alarm was cleared");
        });
        helper.runAfterDelay(20, () -> {
            helper.assertTrue(fixture.course.vehicle().isRunning() && fixture.course.vehicle().getSpeed() > 0,
                    "Explicit dispatch after stale-console reload must move the original reserved train");
            cleanup(helper, new StationFixture(fixture.course, restored));
            helper.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 45)
    public static void forgedStationRequestsCannotOperateUnboundMenuOrAnotherCourse(GameTestHelper helper) {
        StationFixture fixture = fixture(helper);
        // The vanilla helper logs a channel-less mock into PlayerList. Forge
        // login synchronization requires a real Netty pipeline and cannot use
        // that helper. This genuine ServerPlayer owns a normal packet listener
        // and queued connection, without performing an artificial network login.
        ServerPlayer player = new ServerPlayer(helper.getLevel().getServer(), helper.getLevel(),
                new GameProfile(UUID.randomUUID(), "station-test-rider"));
        new ServerGamePacketListenerImpl(helper.getLevel().getServer(), new Connection(PacketFlow.SERVERBOUND), player);
        player.moveTo(fixture.course.vehicle().position());
        UUID courseId = fixture.course.course().id();
        BlockPos controllerPos = fixture.controller.getBlockPos();
        helper.assertFalse(StationActionPacket.apply(player, new StationActionPacket(controllerPos, courseId, 0, 0)),
                "A station packet without an open station menu must be rejected");
        helper.assertTrue(player.startRiding(fixture.course.vehicle()), "Authorized rider fixture must actually mount the bound coaster");
        StationMenu menu = new StationMenu(1, player.getInventory(), fixture.controller);
        player.containerMenu = menu;
        helper.assertTrue(menu.mayOperate() && !menu.mayManage(),
                "Forgery fixture must be an ordinary mounted rider with operating rights and no management rights");
        helper.assertFalse(StationActionPacket.apply(player, new StationActionPacket(controllerPos.offset(1, 0, 0), courseId, 0, 0)),
                "A packet claiming another controller must not escape its open menu binding");
        helper.assertFalse(StationActionPacket.apply(player, new StationActionPacket(controllerPos, UUID.randomUUID(), 0, 0)),
                "A packet claiming another course must be rejected");
        helper.assertFalse(StationActionPacket.apply(player, new StationActionPacket(controllerPos, courseId, 255, 0)),
                "An unknown action must be rejected");
        helper.assertFalse(StationActionPacket.apply(player, new StationActionPacket(controllerPos, courseId, 3, 1)),
                "An ordinary mounted rider must not change automatic dispatch policy");
        helper.assertFalse(StationActionPacket.apply(player, new StationActionPacket(controllerPos, courseId, 5, 0)),
                "An ordinary mounted rider must not clear the management emergency latch");
        helper.assertFalse(fixture.controller.autoDeparture(),
                "A rejected management packet must retain the controller's real dispatch policy");
        Vec3 boardingPosition = player.position();
        player.moveTo(controllerPos.getX() + 20, controllerPos.getY() + .5, controllerPos.getZ() + .5);
        helper.assertFalse(StationActionPacket.apply(player, new StationActionPacket(controllerPos, courseId, 0, 0)),
                "A mounted rider beyond the station's interaction range must not dispatch through a stale menu");
        player.moveTo(boardingPosition);
        helper.assertFalse(fixture.course.vehicle().isRunning(), "All forged requests must leave the real coaster stopped");
        helper.assertTrue(StationActionPacket.apply(player, new StationActionPacket(controllerPos, courseId, 0, 0)),
                "A correctlybound nearby mounted rider must be able to dispatch through the actual server packet path");
        helper.assertTrue(fixture.course.vehicle().isRunning(), "Accepted server packet must operate the actual vehicle");
        player.containerMenu = player.inventoryMenu;
        player.stopRiding();
        player.discard();
        cleanup(helper, fixture);
        helper.succeed();
    }

    private static StationFixture fixture(GameTestHelper helper) {
        ServerCourseFixture course = ServerCourseFixture.create(helper);
        BlockPos position = helper.absolutePos(new BlockPos(4, 2, 3));
        helper.getLevel().setBlock(position, CoasterRegistries.STATION_CONTROLLER.get().defaultBlockState(), 3);
        BlockEntity blockEntity = helper.getLevel().getBlockEntity(position);
        helper.assertTrue(blockEntity instanceof StationControllerBlockEntity, "Registered station block must create its server-owned controller");
        StationControllerBlockEntity controller = (StationControllerBlockEntity) blockEntity;
        controller.bind(course.course().id());
        helper.assertTrue(course.course().id().equals(controller.courseId()), "Station fixture must bind its actual saved course");
        return new StationFixture(course, controller);
    }

    private static void cleanup(GameTestHelper helper, StationFixture fixture) {
        fixture.controller.stopEmergency();
        helper.getLevel().setBlock(fixture.controller.getBlockPos(), Blocks.AIR.defaultBlockState(), 3);
        fixture.course.cleanup(helper);
    }

    private static void near(GameTestHelper helper, double actual, double expected, String description) {
        helper.assertTrue(Double.isFinite(actual) && Math.abs(actual - expected) < .001,
                description + ": expected " + expected + ", actual " + actual);
    }

    private record StationFixture(ServerCourseFixture course, StationControllerBlockEntity controller) { }
}
