package dev.coasterengineering.gametest;

import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.track.VolcanicCourseDesign;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.ParkStructures;
import dev.coasterengineering.world.QualityLightingPlan;
import dev.coasterengineering.world.WorldQualityUpgradeService;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class QualityUpgradeGameTests {
    private QualityUpgradeGameTests() { }

    @GameTest(template = "empty")
    public static void qualityGeometryGuardAcceptsSpeedProfileButRejectsCoordinateBankAndClosureChanges(GameTestHelper helper) {
        ServerCourseFixture fixture = ServerCourseFixture.create(helper);
        SplineTrack original = fixture.course().track();
        List<ControlPoint> profile = original.points().stream()
                .map(p -> new ControlPoint(p.position(), p.bankDegrees(), RailKind.BOOST, .75)).toList();
        WorldQualityUpgradeService.requireSameGeometry(original, new SplineTrack(profile, true));
        List<ControlPoint> moved = new ArrayList<>(profile);
        ControlPoint point = moved.get(2);
        moved.set(2, new ControlPoint(point.position().add(new TrackVec3(.01, 0, 0)), point.bankDegrees(), point.kind(), point.targetSpeed()));
        rejects(helper, () -> WorldQualityUpgradeService.requireSameGeometry(original, new SplineTrack(moved, true)),
                "Even a small coordinate drift must be rejected before a quality profile can replace the existing course");
        List<ControlPoint> banked = new ArrayList<>(profile);
        banked.set(2, new ControlPoint(point.position(), point.bankDegrees() + .01, point.kind(), point.targetSpeed()));
        rejects(helper, () -> WorldQualityUpgradeService.requireSameGeometry(original, new SplineTrack(banked, true)),
                "A quality update must preserve the exact existing rider bank");
        rejects(helper, () -> WorldQualityUpgradeService.requireSameGeometry(original, new SplineTrack(profile, false)),
                "A quality update must not silently open the saved circuit");
        helper.assertTrue(CoasterSavedData.get(helper.getLevel()).getCourse(fixture.course().id()) == fixture.course()
                        && fixture.vehicle().getDistance() == 0 && !fixture.vehicle().isRunning(),
                "The geometry protection checks must leave the authoritative old course and actual parked train untouched");
        fixture.cleanup(helper);
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void missingOriginalAttractionRefusesUpgradeWithoutEjectingExistingRiderOrChangingData(GameTestHelper helper) {
        ServerCourseFixture fixture = ServerCourseFixture.create(helper);
        Player rider = fixture.rider(helper);
        CoasterSavedData data = CoasterSavedData.get(helper.getLevel());
        CompoundTag originalData = data.save(new CompoundTag());
        Vec3 parked = fixture.vehicle().position();
        BlockPos marker = helper.absolutePos(new BlockPos(12, 2, 12));
        BlockState originalBlock = helper.getLevel().getBlockState(marker);
        helper.assertFalse(WorldQualityUpgradeService.begin(helper.getLevel()),
                "An ordinary world lacking the original volcanic attraction must refuse the fixed-world update");
        helper.assertFalse(WorldQualityUpgradeService.isActive(helper.getLevel(), fixture.course().id()),
                "Rejected quality updates must not create an implicit replacement course or construction job");
        helper.assertTrue(data.save(new CompoundTag()).equals(originalData),
                "Preflight refusal must preserve every actual course record and vehicle reservation");
        helper.assertTrue(fixture.vehicle().position().distanceTo(parked) == 0
                        && rider.getVehicle() == fixture.vehicle() && !fixture.vehicle().isRunning(),
                "Rejected fixed-world upgrades must preserve an unrelated real rider, exact seat/car location and station stop");
        helper.assertTrue(helper.getLevel().getBlockState(marker).equals(originalBlock),
                "Preflight refusal must not begin construction in the existing world");
        rider.stopRiding();
        fixture.cleanup(helper);
        helper.succeed();
    }

    @GameTest(template = "empty")
    public static void originalTunnelRepairPlanPreservesEverySeatEnvelopeAndStationOpening(GameTestHelper helper) {
        SplineTrack original = VolcanicCourseDesign.create(new TrackVec3(.5, 82, .5));
        Set<BlockPos> swept = QualityLightingPlan.protectedCells(original);
        Map<BlockPos, BlockState> station = ParkStructures.station(original);
        Map<BlockPos, BlockState> repairs = WorldQualityUpgradeService.tunnelRepairs(original, swept);
        helper.assertTrue(!repairs.isEmpty(), "The original world must receive genuine shell-junction repair candidates");
        helper.assertTrue(station.values().stream().anyMatch(BlockState::isAir),
                "The original station plan must include its real intentional doors and open circulation cells");
        for (var entry : repairs.entrySet()) {
            helper.assertFalse(swept.contains(entry.getKey()),
                    "A shell repair must never intersect either upright rider or the whole banked original car sweep: " + entry.getKey());
            helper.assertFalse(station.containsKey(entry.getKey()),
                    "A shell repair must preserve original station structures, doors, windows and intentional air: " + entry.getKey());
            helper.assertFalse(entry.getValue().isAir(),
                    "Shell repair is additive enclosure and must not plan a new carved hole");
        }
        helper.succeed();
    }

    private static void rejects(GameTestHelper helper, Runnable action, String message) {
        RuntimeException failure = null;
        try { action.run(); }
        catch (RuntimeException exception) { failure = exception; }
        helper.assertTrue(failure != null, message);
    }
}
