package dev.coasterengineering.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.coasterengineering.entity.CoasterEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Original two-seat, gunmetal vehicle. Coordinates use world-up Y and forward +Z. */
public final class CoasterModel extends EntityModel<CoasterEntity> {
    private final ModelPart chassis;
    private final ModelPart shell;
    private final ModelPart seats;
    private final ModelPart trim;
    private final ModelPart[] wheels;
    private final ModelPart[] bars;

    public CoasterModel(ModelPart root) {
        chassis = root.getChild("chassis");
        shell = root.getChild("shell");
        seats = root.getChild("seats");
        trim = root.getChild("trim");
        wheels = new ModelPart[] {root.getChild("wheel_0"), root.getChild("wheel_1"),
                root.getChild("wheel_2"), root.getChild("wheel_3")};
        bars = new ModelPart[] {root.getChild("bar_0"), root.getChild("bar_1")};
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        root.addOrReplaceChild("chassis", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-12, 1, -22, 24, 3, 44)
                .addBox(-12, 0, -16, 24, 2, 2)
                .addBox(-12, 0, 14, 24, 2, 2), PartPose.ZERO);
        root.addOrReplaceChild("shell", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-14, 4, -23, 3, 8, 43)
                .addBox(11, 4, -23, 3, 8, 43)
                .addBox(-14, 4, -24, 28, 12, 3)
                .addBox(-14, 4, 20, 28, 5, 4)
                .addBox(-12, 4, 16, 24, 3, 5), PartPose.ZERO);
        root.addOrReplaceChild("seats", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-11, 5, -6, 9, 3, 12)
                .addBox(2, 5, -6, 9, 3, 12)
                .addBox(-11, 8, -8, 9, 10, 3)
                .addBox(2, 8, -8, 9, 10, 3)
                .addBox(-10, 18, -8, 7, 1, 3)
                .addBox(3, 18, -8, 7, 1, 3), PartPose.ZERO);
        root.addOrReplaceChild("trim", CubeListBuilder.create().texOffs(0, 0)
                .addBox(-14.1F, 10, -20, 0.3F, 1, 35)
                .addBox(13.8F, 10, -20, 0.3F, 1, 35)
                .addBox(-10, 8, 23.8F, 5, 1, 0.3F)
                .addBox(5, 8, 23.8F, 5, 1, 0.3F), PartPose.ZERO);
        for (int i = 0; i < 4; i++) {
            root.addOrReplaceChild("wheel_" + i, CubeListBuilder.create().texOffs(0, 0)
                    .addBox(-1.5F, -2.5F, -2.5F, 3, 5, 5),
                    PartPose.offset(i % 2 == 0 ? -10 : 10, 2, i < 2 ? -15 : 15));
        }
        for (int i = 0; i < 2; i++) {
            root.addOrReplaceChild("bar_" + i, CubeListBuilder.create().texOffs(0, 0)
                    .addBox(-5, -1, 0, 1, 1, 10)
                    .addBox(4, -1, 0, 1, 1, 10)
                    .addBox(-5, -1, 9, 10, 1, 1),
                    PartPose.offset(i == 0 ? -7 : 7, 13, -3));
        }
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(CoasterEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        double partialTick = ageInTicks - entity.tickCount;
        float rotation = (float) ((entity.getDistance() + entity.interpolatedSpeed((float) partialTick) * partialTick) / 0.16);
        for (ModelPart wheel : wheels) wheel.xRot = rotation;
        for (ModelPart bar : bars) bar.xRot = entity.isVehicle() || entity.isRunning() ? 0 : -1.1F;
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer vertices, int light, int overlay,
                               float red, float green, float blue, float alpha) {
        chassis.render(pose, vertices, light, overlay, .38F, .42F, .47F, alpha);
        shell.render(pose, vertices, light, overlay, .13F, .16F, .2F, alpha);
        seats.render(pose, vertices, light, overlay, .075F, .09F, .12F, alpha);
        for (ModelPart wheel : wheels) wheel.render(pose, vertices, light, overlay, .24F, .28F, .33F, alpha);
        for (ModelPart bar : bars) bar.render(pose, vertices, light, overlay, .62F, .68F, .74F, alpha);
        trim.render(pose, vertices, 15728880, overlay, .08F, .85F, 1F, alpha);
    }
}
