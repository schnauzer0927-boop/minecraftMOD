package dev.coasterengineering.client;

import dev.coasterengineering.CoasterConfig;
import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.registry.CoasterSounds;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.track.VolcanicCourseDesign;
import dev.coasterengineering.world.VolcanicWorldBuilder;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RegisterClientReloadListenersEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Vector3f;

/** Client-only presentation: no block writes, entity movement or ride-state authority. */
@Mod.EventBusSubscriber(modid = "coasterengineering", value = Dist.CLIENT)
public final class CoasterEffects {
    private static final int FADE_TICKS = 40;
    private static final Map<Zone, RideLoop> MUSIC = new EnumMap<>(Zone.class);
    private static final Map<Motion, RideLoop> MOTION = new EnumMap<>(Motion.class);
    private static final RandomSource RANDOM = RandomSource.create(0x5CE20265L);
    private static final Set<Integer> FIRED = new HashSet<>();
    private static UUID vehicleId;
    private static SplineTrack currentTrack;
    private static List<Cue> cues = List.of();
    private static double previousDistance;
    private static int previousLaps;
    private static boolean previousRunning;
    private static Zone zone = Zone.NONE;
    private static long eventCount;
    private static long clientTicks;
    private static long lastErrorTick = -600;
    private static int flashTicks;

    private CoasterEffects() { }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        clientTicks++;
        Minecraft minecraft = Minecraft.getInstance();
        try {
            if (minecraft.player == null || minecraft.level == null) {
                if (vehicleId != null || !MUSIC.isEmpty() || !MOTION.isEmpty()) reset();
                return;
            }
            if (minecraft.isPaused()) return;
            cleanAudio(minecraft, MUSIC);
            cleanAudio(minecraft, MOTION);
            if (!(minecraft.player.getVehicle() instanceof CoasterEntity coaster)) {
                if (vehicleId != null) {
                    clearRideState();
                    fadeAudio();
                }
                return;
            }
            SplineTrack track = ClientCourses.all().get(coaster.courseId());
            if (track == null) {
                clearRideState();
                fadeAudio();
                return;
            }
            // Followers parked behind the station have distances near the course
            // end. Reconstruct formation progress; paused trains use station music.
            double distance = track.normalizeDistance(coaster.getDistance() + coaster.carIndex() * coaster.carSpacing());
            VolcanicCourseDesign.Profile qualityProfile = VolcanicWorldBuilder.COURSE_ID.equals(coaster.courseId())
                    ? VolcanicCourseDesign.profileIfUpdated(track) : null;
            if (!coaster.getUUID().equals(vehicleId) || track != currentTrack) {
                clearRideState();
                vehicleId = coaster.getUUID();
                currentTrack = track;
                cues = buildCues(track, qualityProfile);
                previousDistance = distance;
                previousLaps = coaster.getLaps();
                previousRunning = coaster.isRunning();
                markPassed(distance);
            }
            boolean newLap = coaster.getLaps() != previousLaps;
            boolean rewound = distance + 2 < previousDistance;
            if (newLap || rewound) {
                FIRED.clear();
                markPassed(distance);
            } else if (coaster.isRunning()) {
                for (int i = 0; i < cues.size(); i++) {
                    Cue cue = cues.get(i);
                    if (!FIRED.contains(i) && previousDistance < cue.distance && distance >= cue.distance) {
                        FIRED.add(i);
                        playCue(cue.kind, coaster);
                    }
                }
            }
            if (previousRunning && !coaster.isRunning() && !newLap && !rewound && distance > 2) {
                playCue(CueKind.ALARM, coaster);
            }
            double abyssStart = qualityProfile == null ? track.length() * .20
                    : qualityProfile.stageStart(VolcanicCourseDesign.Stage.ANOMALY);
            double escapeStart = qualityProfile == null ? track.length() * .72
                    : qualityProfile.stageStart(VolcanicCourseDesign.Stage.CLIMAX);
            zone = !coaster.isRunning() || distance < abyssStart ? Zone.RESEARCH
                    : distance < escapeStart ? Zone.ABYSS : Zone.ESCAPE;
            updateMusic(minecraft);
            updateMotion(minecraft, coaster);
            float intensity = CoasterConfig.EFFECTS_INTENSITY.get().floatValue();
            if (intensity > 0 && coaster.isRunning() && clientTicks % 3 == 0
                    && track.sample(coaster.getDistance()).kind() == RailKind.BOOST && coaster.getSpeed() > .7) {
                burst(coaster, ParticleTypes.ELECTRIC_SPARK, Math.max(1, Math.round(3 * intensity)), false);
            }
            previousDistance = distance;
            previousLaps = coaster.getLaps();
            previousRunning = coaster.isRunning();
            if (flashTicks > 0) flashTicks--;
        } catch (RuntimeException failure) {
            reportFailure(failure);
            stopAudio();
        }
    }

    private static List<Cue> buildCues(SplineTrack track, VolcanicCourseDesign.Profile qualityProfile) {
        List<Cue> result = new ArrayList<>();
        RailKind previous = track.sample(0).kind();
        double launch = -1, firstBrake = -1;
        double closestMonster = Double.POSITIVE_INFINITY, monsterDistance = -1;
        TrackVec3 sentinel = new TrackVec3(-29, 83, 10);
        for (double distance = 1; distance < track.length(); distance += 1) {
            TrackSample sample = track.sample(distance);
            if (sample.kind() != previous) {
                if (sample.kind() == RailKind.BOOST) {
                    result.add(new Cue(distance, CueKind.LAUNCH));
                    if (launch < 0) launch = distance;
                } else if (sample.kind() == RailKind.BRAKE) {
                    result.add(new Cue(distance, CueKind.BRAKE));
                    if (launch >= 0 && firstBrake < 0) firstBrake = distance;
                }
                previous = sample.kind();
            }
            double proximity = sample.position().subtract(sentinel).length();
            if (proximity < closestMonster) {
                closestMonster = proximity;
                monsterDistance = distance;
            }
        }
        if (launch >= 0 && firstBrake > launch + 20) result.add(new Cue(launch + (firstBrake - launch) * .45, CueKind.ROCKS));
        if (closestMonster < 26) result.add(new Cue(monsterDistance, CueKind.MONSTER));
        result.add(new Cue(track.length() * .38, CueKind.STEAM));
        if (qualityProfile == null) {
            result.add(new Cue(track.length() * .20, CueKind.LIGHT));
            result.add(new Cue(track.length() * .72, CueKind.LIGHT));
        } else {
            double anomaly = qualityProfile.stageStart(VolcanicCourseDesign.Stage.ANOMALY);
            // This alarm is a presentation cue only; it never sets the server's
            // emergency latch or changes the formation's speed or route.
            result.add(new Cue(anomaly, CueKind.ALARM));
            result.add(new Cue(anomaly, CueKind.LIGHT));
            result.add(new Cue(anomaly, CueKind.ROCKS));
            result.add(new Cue(qualityProfile.stageStart(VolcanicCourseDesign.Stage.CLIMAX), CueKind.LIGHT));
        }
        result.sort(Comparator.comparingDouble(Cue::distance));
        return List.copyOf(result);
    }

    private static void markPassed(double distance) {
        for (int i = 0; i < cues.size(); i++) if (cues.get(i).distance <= distance) FIRED.add(i);
    }

    private static void playCue(CueKind kind, CoasterEntity coaster) {
        eventCount++;
        float intensity = CoasterConfig.EFFECTS_INTENSITY.get().floatValue();
        if (intensity <= 0) return;
        SoundEvent sound = switch (kind) {
            case LAUNCH -> CoasterSounds.LAUNCH.get();
            case BRAKE -> CoasterSounds.BRAKE.get();
            case ALARM -> CoasterSounds.ALARM.get();
            case MONSTER -> CoasterSounds.MONSTER.get();
            default -> null;
        };
        if (sound != null) Minecraft.getInstance().getSoundManager().play(
                SimpleSoundInstance.forLocalAmbience(sound, .65F * intensity, 1));
        int count = Math.max(1, Math.round(18 * intensity));
        switch (kind) {
            case LAUNCH -> {
                burst(coaster, ParticleTypes.ELECTRIC_SPARK, count, false);
                burst(coaster, ParticleTypes.SMOKE, count / 2, false);
            }
            case BRAKE -> burst(coaster, ParticleTypes.SMOKE, count / 2, false);
            case STEAM -> burst(coaster, ParticleTypes.CLOUD, count, false);
            case ROCKS -> burst(coaster, new BlockParticleOption(ParticleTypes.FALLING_DUST,
                    Blocks.BASALT.defaultBlockState()), count, true);
            case MONSTER -> {
                for (int i = 0; i < count; i++) for (int side : new int[] {-1, 1})
                    Minecraft.getInstance().level.addParticle(new DustParticleOptions(new Vector3f(1, .2F, .05F), 1.2F),
                            -29 + side * 2 + RANDOM.nextDouble() * .4, 91 + RANDOM.nextDouble(), 17.6,
                            0, .02, 0);
                flashTicks = 10;
            }
            case LIGHT, ALARM -> flashTicks = 10;
        }
    }

    private static void burst(CoasterEntity coaster, ParticleOptions particle, int count, boolean overhead) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null) return;
        for (int i = 0; i < count; i++) {
            double x = coaster.getX() + (RANDOM.nextDouble() - .5) * 5;
            double z = coaster.getZ() + (RANDOM.nextDouble() - .5) * 5;
            minecraft.level.addParticle(particle, x, coaster.getY() + (overhead ? 5 : .5), z,
                    (RANDOM.nextDouble() - .5) * .04, overhead ? -.03 : .04, (RANDOM.nextDouble() - .5) * .04);
        }
    }

    private static void updateMusic(Minecraft minecraft) {
        if (!CoasterConfig.MUSIC_ENABLED.get() || CoasterConfig.MUSIC_VOLUME.get() <= 0
                || minecraft.options.getSoundSourceVolume(SoundSource.MUSIC) <= 0
                || minecraft.options.getSoundSourceVolume(SoundSource.MASTER) <= 0) {
            stopMusic();
            return;
        }
        if (!MUSIC.containsKey(zone)) {
            SoundEvent sound = switch (zone) {
                case RESEARCH -> CoasterSounds.MUSIC_RESEARCH.get();
                case ABYSS -> CoasterSounds.MUSIC_ABYSS.get();
                case ESCAPE -> CoasterSounds.MUSIC_ESCAPE.get();
                default -> null;
            };
            if (sound != null && minecraft.getSoundManager().getSoundEvent(sound.getLocation()) != null) {
                RideLoop music = new RideLoop(sound);
                music.setTarget(CoasterConfig.MUSIC_VOLUME.get().floatValue());
                MUSIC.put(zone, music);
                minecraft.getMusicManager().stopPlaying();
                minecraft.getSoundManager().play(music);
            }
        }
        // MusicManager only owns vanilla background music. Test for an actual
        // playing song before stopping, so an idle manager's delay is preserved.
        if (clientTicks % 20 == 0 && minecraft.getMusicManager().isPlayingMusic(minecraft.getSituationalMusic()))
            minecraft.getMusicManager().stopPlaying();
        for (Map.Entry<Zone, RideLoop> entry : MUSIC.entrySet())
            entry.getValue().setTarget(entry.getKey() == zone ? CoasterConfig.MUSIC_VOLUME.get().floatValue() : 0);
    }

    private static void updateMotion(Minecraft minecraft, CoasterEntity coaster) {
        if (!CoasterConfig.RIDE_SOUNDS.get() || CoasterConfig.RIDE_SOUND_VOLUME.get() <= 0
                || minecraft.options.getSoundSourceVolume(SoundSource.MUSIC) <= 0
                || minecraft.options.getSoundSourceVolume(SoundSource.MASTER) <= 0) {
            stopLoops(MOTION);
            return;
        }
        float speed = Mth.clamp((float) (coaster.getSpeed() * 72 / 120), 0, 1);
        float configured = CoasterConfig.RIDE_SOUND_VOLUME.get().floatValue();
        // These quieter loops share the Music slider with the themes. If the
        // attraction music is reduced, lower the bed proportionally as well.
        float balance = CoasterConfig.MUSIC_ENABLED.get() && CoasterConfig.MUSIC_VOLUME.get() > 0
                ? Math.min(1, CoasterConfig.MUSIC_VOLUME.get().floatValue() / .8F) : 1;
        for (Motion motion : Motion.values()) {
            float target = speed <= .015F ? 0 : configured * balance * (motion == Motion.WIND
                    ? .42F * (float) Math.pow(speed, 1.45) : .32F * (float) Math.pow(speed, .8));
            RideLoop loop = MOTION.get(motion);
            if (loop == null && target > .001F) {
                SoundEvent sound = (motion == Motion.WIND ? CoasterSounds.WIND : CoasterSounds.WHEELS).get();
                if (minecraft.getSoundManager().getSoundEvent(sound.getLocation()) == null) continue;
                loop = new RideLoop(sound);
                loop.setPitchNow(motion == Motion.WIND ? .8F : .7F);
                loop.setTarget(target);
                MOTION.put(motion, loop);
                minecraft.getSoundManager().play(loop);
            }
            if (loop != null) {
                loop.setTarget(target);
                loop.targetPitch = motion == Motion.WIND ? .8F + .25F * speed : .7F + .45F * speed;
            }
        }
    }

    private static <K> void cleanAudio(Minecraft minecraft, Map<K, RideLoop> loops) {
        // A zero slider or audio-device reload can discard a stream without
        // setting its stopped flag. Retire stale instances after a startup grace
        // period; mounted playback can then create a fresh instance safely.
        loops.entrySet().removeIf(entry -> {
            RideLoop loop = entry.getValue();
            if (!loop.isStopped() && (clientTicks - loop.createdTick <= FADE_TICKS
                    || minecraft.getSoundManager().isActive(loop))) return false;
            loop.finish();
            minecraft.getSoundManager().stop(loop);
            return true;
        });
    }

    @SubscribeEvent
    public static void flash(RenderGuiEvent.Post event) {
        if (flashTicks <= 0 || vehicleId == null || Minecraft.getInstance().options.hideGui) return;
        try {
            int alpha = Math.round(24 * CoasterConfig.EFFECTS_INTENSITY.get().floatValue() * flashTicks / 10);
            int color = (alpha << 24) | (zone == Zone.ESCAPE ? 0xBCEFFF : 0xFFC77A);
            int width = event.getGuiGraphics().guiWidth(), height = event.getGuiGraphics().guiHeight();
            // A soft three-pixel edge glow avoids full-screen flashes or camera shake.
            event.getGuiGraphics().fill(0, 0, width, 3, color);
            event.getGuiGraphics().fill(0, height - 3, width, height, color);
            event.getGuiGraphics().fill(0, 3, 3, height - 3, color);
            event.getGuiGraphics().fill(width - 3, 3, width, height - 3, color);
        } catch (RuntimeException failure) { reportFailure(failure); }
    }

    @SubscribeEvent
    public static void logout(ClientPlayerNetworkEvent.LoggingOut event) { reset(); }

    private static void reset() {
        stopAudio();
        clearRideState();
    }

    private static void clearRideState() {
        vehicleId = null;
        currentTrack = null;
        cues = List.of();
        FIRED.clear();
        zone = Zone.NONE;
        eventCount = 0;
        flashTicks = 0;
    }

    private static void stopMusic() {
        stopLoops(MUSIC);
    }

    private static void stopAudio() {
        stopLoops(MUSIC);
        stopLoops(MOTION);
    }

    private static void fadeAudio() {
        for (RideLoop loop : MUSIC.values()) loop.setTarget(0);
        for (RideLoop loop : MOTION.values()) loop.setTarget(0);
    }

    private static void stopLoops(Map<?, RideLoop> loops) {
        for (RideLoop loop : loops.values()) {
            loop.finish();
            try { Minecraft.getInstance().getSoundManager().stop(loop); }
            catch (RuntimeException failure) { reportFailure(failure); }
        }
        loops.clear();
    }

    private static void reportFailure(RuntimeException failure) {
        if (clientTicks - lastErrorTick < 600) return;
        lastErrorTick = clientTicks;
        CoasterEngineering.LOGGER.warn("Coaster cosmetic presentation failed; disabling current audio", failure);
    }

    public static String diagnostics() {
        try {
            Minecraft minecraft = Minecraft.getInstance();
            int active = 0, motion = 0, assets = 0;
            for (RideLoop music : MUSIC.values()) if (minecraft.getSoundManager().isActive(music)) active++;
            for (RideLoop loop : MOTION.values()) if (minecraft.getSoundManager().isActive(loop)) motion++;
            String[] paths = {"music/research", "music/abyss", "music/escape", "coaster/launch", "coaster/brake", "coaster/alarm", "abyss/monster", "coaster/wind", "coaster/wheels"};
            for (String path : paths) if (minecraft.getResourceManager().getResource(
                    new ResourceLocation("coasterengineering", "sounds/" + path + ".ogg")).isPresent()
                    && minecraft.getSoundManager().getSoundEvent(new ResourceLocation("coasterengineering", path.replace('/', '.'))) != null) assets++;
            return String.format(Locale.ROOT, "Client FX zone=%s | active music=%d | motion=%d | events=%d | sound assets=%d/9",
                    zone.name().toLowerCase(Locale.ROOT), active, motion, eventCount, assets);
        } catch (RuntimeException failure) {
            reportFailure(failure);
            return "Client FX diagnostics unavailable";
        }
    }

    @Mod.EventBusSubscriber(modid = "coasterengineering", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static final class ReloadHooks {
        @SubscribeEvent
        public static void register(RegisterClientReloadListenersEvent event) {
            event.registerReloadListener((ResourceManagerReloadListener) manager -> stopAudio());
        }
    }

    private static final class RideLoop extends AbstractTickableSoundInstance {
        private float target;
        private float targetPitch = 1;
        private int fadeRemaining;
        private final long createdTick = clientTicks;

        private RideLoop(SoundEvent sound) {
            super(sound, SoundSource.MUSIC, SoundInstance.createUnseededRandom());
            looping = true;
            delay = 0;
            relative = true;
            attenuation = SoundInstance.Attenuation.NONE;
            volume = 0;
            pitch = 1;
        }

        @Override public boolean canStartSilent() { return true; }

        private void setTarget(float requested) {
            requested = Mth.clamp(requested, 0, 1);
            if (Float.compare(target, requested) == 0) return;
            target = requested;
            fadeRemaining = FADE_TICKS;
        }

        private void setPitchNow(float requested) {
            pitch = requested;
            targetPitch = requested;
        }

        @Override public void tick() {
            if (fadeRemaining > 0) {
                volume += (target - volume) / fadeRemaining;
                fadeRemaining--;
            } else volume = target;
            pitch = Mth.approach(pitch, targetPitch, .01F);
            if (target <= 0 && fadeRemaining == 0) stop();
        }

        private void finish() { stop(); }
    }

    private enum Zone { NONE, RESEARCH, ABYSS, ESCAPE }
    private enum Motion { WIND, WHEELS }
    private enum CueKind { LAUNCH, BRAKE, ALARM, ROCKS, STEAM, MONSTER, LIGHT }
    private record Cue(double distance, CueKind kind) { }
}
