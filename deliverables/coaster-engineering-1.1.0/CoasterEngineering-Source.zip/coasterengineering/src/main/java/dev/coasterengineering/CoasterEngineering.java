package dev.coasterengineering;

import com.mojang.logging.LogUtils;
import dev.coasterengineering.network.CoasterNetwork;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.registry.CoasterSounds;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

@Mod(CoasterEngineering.MOD_ID)
public final class CoasterEngineering {
    public static final String MOD_ID = "coasterengineering";
    public static final Logger LOGGER = LogUtils.getLogger();

    public CoasterEngineering() {
        var bus = FMLJavaModLoadingContext.get().getModEventBus();
        CoasterRegistries.BLOCKS.register(bus);
        CoasterRegistries.ITEMS.register(bus);
        CoasterRegistries.ENTITIES.register(bus);
        CoasterRegistries.BLOCK_ENTITIES.register(bus);
        CoasterRegistries.MENUS.register(bus);
        CoasterSounds.SOUNDS.register(bus);
        bus.addListener(this::creativeItems);
        CoasterNetwork.register();
        ModLoadingContext.get().registerConfig(ModConfig.Type.SERVER, CoasterConfig.SERVER_SPEC);
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, CoasterConfig.CLIENT_SPEC);
    }

    private void creativeItems(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
            event.accept(CoasterRegistries.COURSE_EDITOR);
            event.accept(CoasterRegistries.COASTER_VEHICLE);
            event.accept(CoasterRegistries.RAIL.get().asItem());
            event.accept(CoasterRegistries.BOOST_RAIL.get().asItem());
            event.accept(CoasterRegistries.BRAKE_RAIL.get().asItem());
            event.accept(CoasterRegistries.LIFT_RAIL.get().asItem());
            event.accept(CoasterRegistries.STATION_RAIL.get().asItem());
            event.accept(CoasterRegistries.SUPPORT_BEAM.get().asItem());
            event.accept(CoasterRegistries.STATION_CONTROLLER_ITEM);
        }
    }
}
