package dev.coasterengineering.item;

import dev.coasterengineering.command.CoasterCommands;
import dev.coasterengineering.world.Course;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;

/** Places an original coaster, never a vanilla minecart, at a saved course's station. */
public final class CoasterVehicleItem extends Item {
    public CoasterVehicleItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Player player = context.getPlayer();
        if (player == null) return InteractionResult.FAIL;
        if (context.getLevel().isClientSide) return InteractionResult.SUCCESS;
        if (!player.hasPermissions(2)) {
            player.sendSystemMessage(Component.literal("Placing a coaster requires operator permission level 2. Anyone can board an existing coaster."));
            return InteractionResult.FAIL;
        }
        if (!(context.getLevel() instanceof ServerLevel level)) return InteractionResult.FAIL;
        Course course = CoasterCommands.nearestCourse(level, context.getClickLocation(), 4.0);
        if (course == null) {
            player.sendSystemMessage(Component.literal("Click within four blocks of a saved coaster course. Create a course with /coaster create <name> or /coaster demo first."));
            return InteractionResult.FAIL;
        }
        String error = CoasterCommands.spawnVehicle(level, course);
        if (error != null) {
            player.sendSystemMessage(Component.literal(error));
            return InteractionResult.FAIL;
        }
        if (!player.getAbilities().instabuild) context.getItemInHand().shrink(1);
        player.sendSystemMessage(Component.literal("Placed a two-seat coaster at " + course.name() + "'s station. Right-click it to board."));
        return InteractionResult.CONSUME;
    }
}
