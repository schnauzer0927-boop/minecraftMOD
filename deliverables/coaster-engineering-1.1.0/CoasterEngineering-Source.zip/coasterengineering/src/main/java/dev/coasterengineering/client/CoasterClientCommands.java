package dev.coasterengineering.client;

import dev.coasterengineering.entity.CoasterEntity;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterClientCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Read-only local diagnostics: does not trust server rider counts as client state. */
@Mod.EventBusSubscriber(modid = "coasterengineering", value = Dist.CLIENT)
public final class CoasterClientCommands {
    private CoasterClientCommands() { }

    @SubscribeEvent
    public static void register(RegisterClientCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("coasterclient")
                .then(Commands.literal("status").executes(context -> status(context.getSource()))));
    }

    private static int status(CommandSourceStack source) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) {
            source.sendFailure(Component.literal("Client has no loaded player/world."));
            return 0;
        }
        int loadedEntities = 0;
        int loadedCoasters = 0;
        for (Entity entity : minecraft.level.entitiesForRendering()) {
            loadedEntities++;
            if (entity instanceof CoasterEntity) loadedCoasters++;
        }
        final String counts = "Client loaded entities=" + loadedEntities + ", coasters=" + loadedCoasters
                + ", courses=" + ClientCourses.all().size() + ", HUD hidden=" + minecraft.options.hideGui;
        source.sendSuccess(() -> Component.literal(counts), false);
        source.sendSuccess(() -> Component.literal(CoasterEffects.diagnostics()), false);
        Entity vehicle = minecraft.player.getVehicle();
        if (vehicle == null) {
            source.sendSuccess(() -> Component.literal("Client mount=none; player passenger="
                    + minecraft.player.isPassenger()), false);
            return 1;
        }
        String mounted = "Client mount=" + BuiltInRegistries.ENTITY_TYPE.getKey(vehicle.getType())
                + ", id=" + vehicle.getId() + ", UUID=" + vehicle.getUUID();
        source.sendSuccess(() -> Component.literal(mounted), false);
        if (vehicle instanceof CoasterEntity coaster) {
            String state = String.format(Locale.ROOT,
                    "Client course=%s | running=%s | %.1f km/h | bank=%.1f | laps=%d | riders=%d/2 | car=%d/%d",
                    coaster.courseId(), coaster.isRunning(), coaster.getSpeed() * 72, coaster.getBank(),
                    coaster.getLaps(), coaster.getPassengers().size(), coaster.carIndex() + 1, coaster.carCount());
            source.sendSuccess(() -> Component.literal(state), false);
        }
        return 1;
    }
}
