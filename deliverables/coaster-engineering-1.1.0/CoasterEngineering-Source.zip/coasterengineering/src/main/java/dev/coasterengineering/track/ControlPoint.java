package dev.coasterengineering.track;

import java.util.Objects;

/** The segment beginning at this point uses its kind and target speed (blocks/tick). */
public record ControlPoint(TrackVec3 position, double bankDegrees, RailKind kind, double targetSpeed) {
    public ControlPoint {
        Objects.requireNonNull(position, "position");
        Objects.requireNonNull(kind, "kind");
        if (!Double.isFinite(bankDegrees)) throw new IllegalArgumentException("Bank must be finite");
        if (!Double.isFinite(targetSpeed) || targetSpeed < 0) {
            throw new IllegalArgumentException("Target speed must be finite and nonnegative");
        }
    }
}
