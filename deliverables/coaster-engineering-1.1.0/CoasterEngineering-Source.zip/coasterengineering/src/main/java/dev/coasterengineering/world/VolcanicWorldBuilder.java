package dev.coasterengineering.world;

import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.network.CoasterNetwork;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.station.StationControllerBlockEntity;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.track.VolcanicCourseDesign;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import com.mojang.datafixers.util.Either;
import net.minecraft.core.BlockPos;
import net.minecraft.Util;
import net.minecraft.server.level.ChunkHolder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.FlatLevelSource;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Budgeted, deterministic construction in a dedicated empty flat world.
 * Chunk generation is intentional during construction; ordinary ride physics
 * still stops at unloaded chunks. No persistent forced-chunk records are used.
 */
@Mod.EventBusSubscriber(modid = CoasterEngineering.MOD_ID)
public final class VolcanicWorldBuilder {
    public static final UUID COURSE_ID = UUID.nameUUIDFromBytes(
            "coasterengineering:volcanic_abyss:v1".getBytes(StandardCharsets.UTF_8));
    public static final long WORLD_SEED = 20261011L;
    private static final TrackVec3 ORIGIN = new TrackVec3(.5, 82, .5);
    private static final BlockPos LANDING = new BlockPos(-3, 94, -96);
    private static final BlockPos CONTROLLER = new BlockPos(-6, 94, -96);
    private static final int MIN_X = -145, MAX_X = 145, MIN_Z = -165, MAX_Z = 145;
    private static final int MIN_Y = 64, MAX_Y = 180;
    private static final int WIDTH = MAX_X - MIN_X + 1, DEPTH = MAX_Z - MIN_Z + 1;
    private static final int HANDOFF_TICKS = 1200;
    private static final TicketType<UUID> BUILD_TICKET = TicketType.create(
            "coasterengineering_volcanic_build", Comparator.<UUID>naturalOrder());
    private static final Map<ServerLevel, Job> JOBS = new IdentityHashMap<>();
    private static final Map<ServerLevel, String> STATUS = new IdentityHashMap<>();
    private static final Map<ServerLevel, Retention> RETAINED = new IdentityHashMap<>();
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();

    private VolcanicWorldBuilder() { }

    public static boolean begin(ServerLevel level) {
        if (level == null) {
            CoasterEngineering.LOGGER.warn("Volcanic construction command received before the server world was ready");
            return false;
        }
        if (JOBS.containsKey(level)) return reject(level, "A Volcanic Abyss build is already running");
        if (!level.dimension().equals(Level.OVERWORLD)) return reject(level, "Use the Overworld for this dedicated attraction");
        if (level.getSeed() != WORLD_SEED) return reject(level, "Create the dedicated flat world with seed 20261011");
        if (!(level.getChunkSource().getGenerator() instanceof FlatLevelSource))
            return reject(level, "Create an empty flat world with grass at Y63 (128 total layers)");
        if (!CoasterSavedData.get(level).courses().isEmpty())
            return reject(level, "The dedicated world must have no existing coaster courses");
        if (level.getMinBuildHeight() > MIN_Y || level.getMaxBuildHeight() <= MAX_Y
                || !level.getWorldBorder().isWithinBounds(new BlockPos(MIN_X, MIN_Y, MIN_Z))
                || !level.getWorldBorder().isWithinBounds(new BlockPos(MAX_X, MAX_Y, MAX_Z)))
            return reject(level, "The entire attraction footprint must be inside world limits");
        try {
            Job job = new Job(level);
            JOBS.put(level, job);
            job.enter(Stage.CHUNKS);
            return true;
        } catch (RuntimeException failure) {
            return reject(level, "Could not prepare attraction: " + failure.getMessage());
        }
    }

    public static String status(ServerLevel level) {
        if (level == null) return "The server world is not ready; retry after the server reports Done";
        Job job = JOBS.get(level);
        if (job != null) return job.describe();
        if (CoasterSavedData.get(level).getCourse(COURSE_ID) != null) {
            if (WorldQualityUpgradeService.isActive(level, COURSE_ID))
                return "CONSTRUCTED; waiting for final quality update: " + WorldQualityUpgradeService.status(level);
            if (!WorldQualityUpgradeData.get(level).isApplied())
                return "CONSTRUCTED; quality update incomplete; inspect /coaster upgrade volcano status and retry it before riding";
        }
        return STATUS.getOrDefault(level, "No Volcanic Abyss build has been started");
    }

    public static boolean cancel(ServerLevel level) {
        Job job = JOBS.remove(level);
        if (job != null) {
            job.rollbackCourse();
            release(level, job.chunks);
            STATUS.put(level, "Cancelled; any generated scenery remains in this dedicated world");
            CoasterEngineering.LOGGER.info("Volcanic builder cancelled at {}", job.stage);
            return true;
        }
        Retention retention = RETAINED.remove(level);
        if (retention == null) return false;
        release(level, retention.chunks);
        STATUS.put(level, "READY; temporary construction tickets released");
        return true;
    }

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        for (Job job : new ArrayList<>(JOBS.values())) {
            if (job.level.getServer() != event.getServer()) continue;
            try {
                job.tick();
            } catch (RuntimeException failure) {
                JOBS.remove(job.level);
                job.rollbackCourse();
                release(job.level, job.chunks);
                STATUS.put(job.level, "FAILED at " + job.stage + ": " + failure.getMessage()
                        + "; recreate a fresh dedicated world before retrying");
                CoasterEngineering.LOGGER.error("Volcanic builder failed at {}", job.stage, failure);
            }
        }
        Iterator<Map.Entry<ServerLevel, Retention>> iterator = RETAINED.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<ServerLevel, Retention> entry = iterator.next();
            if (entry.getKey().getServer() == event.getServer()
                    && entry.getKey().getGameTime() >= entry.getValue().untilTick) {
                release(entry.getKey(), entry.getValue().chunks);
                STATUS.put(entry.getKey(), "READY; temporary construction tickets released");
                CoasterEngineering.LOGGER.info("Volcanic builder temporary construction tickets released");
                iterator.remove();
            }
        }
    }

    @SubscribeEvent
    public static void serverStopping(ServerStoppingEvent event) {
        for (Job job : new ArrayList<>(JOBS.values())) {
            if (job.level.getServer() != event.getServer()) continue;
            job.rollbackCourse();
            release(job.level, job.chunks);
            JOBS.remove(job.level);
            STATUS.remove(job.level);
        }
        Iterator<Map.Entry<ServerLevel, Retention>> iterator = RETAINED.entrySet().iterator();
        while (iterator.hasNext()) {
            var entry = iterator.next();
            if (entry.getKey().getServer() == event.getServer()) {
                release(entry.getKey(), entry.getValue().chunks);
                iterator.remove();
                STATUS.remove(entry.getKey());
            }
        }
        STATUS.keySet().removeIf(level -> level.getServer() == event.getServer());
    }

    private static boolean reject(ServerLevel level, String reason) {
        STATUS.put(level, reason);
        return false;
    }

    private static void release(ServerLevel level, List<ChunkPos> chunks) {
        for (ChunkPos chunk : chunks) level.getChunkSource().removeRegionTicket(BUILD_TICKET, chunk, 2, COURSE_ID);
    }

    private record Retention(List<ChunkPos> chunks, long untilTick) { }
    private enum Stage { CHUNKS, PREFLIGHT, SHELL, CHAMBERS, TUNNELS, DECOR, CLEARANCE, STATION, SUPPORTS, VALIDATE, COMMIT }

    private static final class Budget {
        final long deadline = System.nanoTime() + 15_000_000L;
        int checks, writes, chunks;
        boolean room() { return checks < 20_000 && writes < 4096 && System.nanoTime() < deadline; }
    }

    private static final class Job {
        final ServerLevel level;
        final SplineTrack track = VolcanicCourseDesign.create(ORIGIN);
        final List<ChunkPos> chunks = new ArrayList<>();
        final CoasterEntity probe;
        Stage stage;
        int cursor, innerCursor;
        int preflightY = 63;
        int shellY;
        int roomIndex;
        double sampleDistance;
        long checked, placed;
        long lastProgress;
        boolean committed;
        CoasterEntity leader;
        CompletableFuture<Either<ChunkAccess, ChunkHolder.ChunkLoadingFailure>> pendingChunk;
        CompletableFuture<Map<BlockPos, BlockState>> pendingPlan;
        boolean waiting;
        Iterator<Map.Entry<BlockPos, BlockState>> plan;
        TrackSample activeSample;
        AABB[] envelopes;
        final BlockPos.MutableBlockPos position = new BlockPos.MutableBlockPos();
        // x, y, z, horizontal/vertical radii: original broad cavern rooms.
        final double[][] rooms = {{-72, 80, 15, 24, 16, 24}, {45, 83, 40, 24, 19, 24}, {-29, 83, 10, 22, 22, 22}};

        Job(ServerLevel level) {
            this.level = level;
            probe = CoasterRegistries.COASTER.get().create(level);
            if (probe == null) throw new IllegalStateException("Could not create geometry validator");
        }

        void enter(Stage next) {
            stage = next;
            cursor = innerCursor = 0;
            sampleDistance = 0;
            activeSample = null;
            plan = null;
            pendingPlan = null;
            STATUS.put(level, describe());
            CoasterEngineering.LOGGER.info("Volcanic builder stage={} checked={} placed={}", stage, checked, placed);
        }

        String describe() {
            return "Volcanic Abyss " + stage + "; checked=" + checked + ", placed=" + placed
                    + (stage == Stage.CHUNKS ? ", generated=" + cursor + "/420 chunks" : "");
        }

        void tick() {
            Budget budget = new Budget();
            waiting = false;
            while (budget.room()) {
                Stage before = stage;
                switch (stage) {
                    case CHUNKS -> chunks(budget);
                    case PREFLIGHT -> preflight(budget);
                    case SHELL -> shell(budget);
                    case CHAMBERS -> chambers(budget);
                    case TUNNELS -> tunnels(budget);
                    case DECOR -> planned(budget, Stage.CLEARANCE, false);
                    case CLEARANCE -> clearance(budget);
                    case STATION -> planned(budget, Stage.SUPPORTS, true);
                    case SUPPORTS -> supports(budget);
                    case VALIDATE -> validate(budget);
                    case COMMIT -> { commit(); return; }
                }
                if (waiting) break;
                if (stage == Stage.CHUNKS && before == stage && (pendingChunk != null || budget.chunks >= 2)) break;
            }
            if (level.getGameTime() - lastProgress >= 200) {
                CoasterEngineering.LOGGER.info("{}", describe());
                lastProgress = level.getGameTime();
            }
        }

        void chunks(Budget budget) {
            int minChunkX = MIN_X >> 4, maxChunkX = MAX_X >> 4;
            int minChunkZ = MIN_Z >> 4, maxChunkZ = MAX_Z >> 4;
            int width = maxChunkX - minChunkX + 1, total = width * (maxChunkZ - minChunkZ + 1);
            if (pendingChunk != null) {
                if (!pendingChunk.isDone()) return;
                if (pendingChunk.join().left().isEmpty()) throw new IllegalStateException("Construction chunk could not load");
                pendingChunk = null;
                cursor++;
                budget.chunks++;
            }
            if (cursor >= total) { enter(Stage.PREFLIGHT); return; }
            if (budget.chunks >= 2) return;
            ChunkPos chunk = new ChunkPos(minChunkX + cursor % width, minChunkZ + cursor / width);
            level.getChunkSource().addRegionTicket(BUILD_TICKET, chunk, 2, COURSE_ID);
            chunks.add(chunk);
            pendingChunk = level.getChunkSource().getChunkFuture(chunk.x, chunk.z, ChunkStatus.FULL, true);
        }

        void preflight(Budget budget) {
            if (cursor >= WIDTH * DEPTH) {
                if (!CoasterSavedData.get(level).courses().isEmpty()) throw new IllegalStateException("Another course appeared during preflight");
                enter(Stage.SHELL);
                return;
            }
            int x = MIN_X + cursor % WIDTH, z = MIN_Z + cursor / WIDTH;
            LevelChunk chunk = level.getChunkSource().getChunkNow(x >> 4, z >> 4);
            if (chunk == null) throw new IllegalStateException("Preflight chunk unloaded unexpectedly");
            position.set(x, preflightY, z);
            budget.checks++;
            if (preflightY == 63) {
                if (!chunk.getBlockState(position).is(Blocks.GRASS_BLOCK))
                    throw new IllegalArgumentException("Expected untouched flat grass at " + position.toShortString());
                preflightY = MIN_Y;
                checked++;
            } else {
                var section = chunk.getSections()[level.getSectionIndex(preflightY)];
                if (section.hasOnlyAir()) {
                    int end = Math.min((preflightY | 15) + 1, level.getMaxBuildHeight());
                    checked += end - preflightY;
                    preflightY = end;
                } else {
                    if (!chunk.getBlockState(position).isAir() || chunk.getBlockEntity(position) != null)
                        throw new IllegalArgumentException("The dedicated footprint is not empty at " + position.toShortString());
                    preflightY++;
                    checked++;
                }
            }
            if (preflightY >= level.getMaxBuildHeight()) { cursor++; preflightY = 63; }
        }

        void shell(Budget budget) {
            if (cursor >= 281 * 281) { enter(Stage.CHAMBERS); return; }
            int x = -140 + cursor % 281, z = -140 + cursor / 281;
            double r = Math.hypot(x - .5, z - .5);
            if (r > 140 || r < 24) { cursor++; innerCursor = 0; budget.checks++; return; }
            int top = surfaceHeight(x + .5, z + .5);
            position.set(x, Math.max(MIN_Y, top - 2 + innerCursor), z);
            place(position, stone(x, position.getY(), z), budget);
            if (++innerCursor >= 3) { innerCursor = 0; cursor++; }
        }

        void chambers(Budget budget) {
            if (roomIndex >= rooms.length) { enter(Stage.TUNNELS); return; }
            double[] room = rooms[roomIndex];
            int rx = (int) room[3], ry = (int) room[4], rz = (int) room[5];
            int width = rx * 2 + 1, height = ry * 2 + 1, depth = rz * 2 + 1;
            if (cursor >= width * height * depth) { roomIndex++; cursor = 0; return; }
            int dx = cursor % width - rx, dy = cursor / width % height - ry, dz = cursor / (width * height) - rz;
            cursor++;
            budget.checks++; checked++;
            double normalized = (double) dx * dx / (rx * rx) + (double) dy * dy / (ry * ry) + (double) dz * dz / (rz * rz);
            if (normalized < .77 || normalized > 1) return;
            position.set((int) room[0] + dx, (int) room[1] + dy, (int) room[2] + dz);
            if (position.getY() < MIN_Y) return;
            place(position, stone(position.getX(), position.getY(), position.getZ()), budget);
        }

        void tunnels(Budget budget) {
            if (sampleDistance >= track.length()) { enter(Stage.DECOR); return; }
            if (activeSample == null) {
                activeSample = track.sample(sampleDistance);
                TrackVec3 p = activeSample.position();
                if (insideRoom(p) || p.y() >= surfaceHeight(p.x(), p.z()) - 6) {
                    sampleDistance += 1.5;
                    activeSample = null;
                    budget.checks++;
                    return;
                }
            }
            int dx = innerCursor % 17 - 8, dy = innerCursor / 17 % 17 - 8, dz = innerCursor / (17 * 17) - 8;
            innerCursor++;
            budget.checks++; checked++;
            int square = dx * dx + dy * dy + dz * dz;
            if (square >= 49 && square <= 64) {
                TrackVec3 p = activeSample.position();
                position.set((int) Math.floor(p.x()) + dx, (int) Math.floor(p.y()) + dy, (int) Math.floor(p.z()) + dz);
                if (insideFootprint(position)) place(position, stone(position.getX(), position.getY(), position.getZ()), budget);
            }
            if (innerCursor >= 17 * 17 * 17) {
                innerCursor = 0;
                sampleDistance += 1.5;
                activeSample = null;
            }
        }

        void planned(Budget budget, Stage next, boolean station) {
            if (plan == null) {
                // These helpers only read the immutable spline and registered
                // block states. Generate their maps off the server thread;
                // every actual world write still happens here within budget.
                if (pendingPlan == null) pendingPlan = CompletableFuture.supplyAsync(
                        () -> station ? ParkStructures.station(track) : VolcanicDecor.plan(track), Util.backgroundExecutor());
                if (!pendingPlan.isDone()) { waiting = true; return; }
                plan = pendingPlan.join().entrySet().iterator();
                pendingPlan = null;
            }
            if (!plan.hasNext()) { enter(next); return; }
            var entry = plan.next();
            place(entry.getKey(), entry.getValue(), budget);
        }

        void clearance(Budget budget) {
            if (sampleDistance > track.length()) { enter(Stage.STATION); return; }
            if (activeSample == null) {
                activeSample = track.sample(sampleDistance);
                envelopes = envelopes(activeSample);
            }
            int dx = innerCursor % 13 - 6, dy = innerCursor / 13 % 13 - 6, dz = innerCursor / (13 * 13) - 6;
            innerCursor++;
            budget.checks++; checked++;
            TrackVec3 p = activeSample.position();
            int x = (int) Math.floor(p.x()) + dx, y = (int) Math.floor(p.y()) + dy, z = (int) Math.floor(p.z()) + dz;
            double cx = x + .5 - p.x(), cy = y + .5 - p.y(), cz = z + .5 - p.z();
            AABB cell = new AABB(x, y, z, x + 1, y + 1, z + 1);
            boolean clear = cx * cx + cy * cy + cz * cz <= 25;
            if (!clear) for (AABB envelope : envelopes) if (envelope.intersects(cell)) { clear = true; break; }
            if (clear) {
                position.set(x, y, z);
                if (insideFootprint(position)) place(position, AIR, budget);
            }
            if (innerCursor >= 13 * 13 * 13) {
                innerCursor = 0;
                sampleDistance += .5;
                activeSample = null;
            }
        }

        void supports(Budget budget) {
            if (sampleDistance >= track.length()) {
                if (cursor < track.points().size()) {
                    ControlPoint point = track.points().get(cursor++);
                    TrackVec3 p = point.position();
                    position.set((int) Math.floor(p.x()), (int) Math.floor(p.y()), (int) Math.floor(p.z()));
                    place(position, rail(point.kind()).defaultBlockState(), budget);
                    return;
                }
                enter(Stage.VALIDATE);
                return;
            }
            TrackVec3 p = track.sample(sampleDistance).position();
            if (shellY == 0) shellY = MIN_Y;
            if (shellY < Math.floor(p.y()) - 1) {
                position.set((int) Math.floor(p.x()), shellY++, (int) Math.floor(p.z()));
                if (level.getBlockState(position).isAir()) place(position, CoasterRegistries.SUPPORT_BEAM.get().defaultBlockState(), budget);
                else { budget.checks++; checked++; }
            } else {
                shellY = 0;
                sampleDistance += 8;
            }
        }

        void validate(Budget budget) {
            if (sampleDistance > track.length()) { enter(Stage.COMMIT); return; }
            budget.checks++; checked++;
            if (!probe.canUseTrackSample(track.sample(sampleDistance)))
                throw new IllegalStateException("Ride clearance failed at distance " + sampleDistance);
            sampleDistance += .25;
        }

        void place(BlockPos pos, BlockState state, Budget budget) {
            if (!insideFootprint(pos)) throw new IllegalArgumentException("Generated block outside approved footprint: " + pos.toShortString());
            budget.checks++; checked++;
            if (level.getBlockState(pos) == state) return;
            if (!level.setBlock(pos, state, Block.UPDATE_CLIENTS))
                throw new IllegalStateException("Could not place generated block at " + pos.toShortString());
            budget.writes++;
            placed++;
        }

        void commit() {
            CoasterSavedData data = CoasterSavedData.get(level);
            if (!data.courses().isEmpty()) throw new IllegalStateException("A course appeared before final commit");
            Course course = new Course(COURSE_ID, "Volcanic Abyss", track, LANDING, true);
            leader = CoasterRegistries.COASTER.get().create(level);
            if (leader == null) throw new IllegalStateException("Could not create completed ride train");
            data.putCourse(course);
            committed = true;
            leader.setCourse(COURSE_ID);
            if (!data.claimVehicle(COURSE_ID, leader.getUUID()) || !leader.resetToStation() || !level.addFreshEntity(leader))
                throw new IllegalStateException("Could not place the completed ride leader");
            if (!TrainService.setCarCount(leader, 3)) throw new IllegalStateException("Could not place the three-car formation");
            if (!(level.getBlockEntity(CONTROLLER) instanceof StationControllerBlockEntity controller)
                    || !controller.bind(COURSE_ID)) throw new IllegalStateException("Could not bind the completed station controller");
            controller.setDwellTicks(VolcanicCourseDesign.STATION_DWELL_TICKS);
            controller.setAutoDeparture(true);
            level.setDefaultSpawnPos(LANDING, 90);
            GameRules rules = level.getGameRules();
            rules.getRule(GameRules.RULE_SPAWN_RADIUS).set(0, level.getServer());
            rules.getRule(GameRules.RULE_DOMOBSPAWNING).set(false, level.getServer());
            rules.getRule(GameRules.RULE_DOFIRETICK).set(false, level.getServer());
            rules.getRule(GameRules.RULE_MOBGRIEFING).set(false, level.getServer());
            rules.getRule(GameRules.RULE_DAYLIGHT).set(false, level.getServer());
            rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(false, level.getServer());
            rules.getRule(GameRules.RULE_DOINSOMNIA).set(false, level.getServer());
            rules.getRule(GameRules.RULE_DO_PATROL_SPAWNING).set(false, level.getServer());
            rules.getRule(GameRules.RULE_DO_TRADER_SPAWNING).set(false, level.getServer());
            level.setDayTime(6000);
            level.setWeatherParameters(6000, 0, false, false);
            CoasterNetwork.broadcastCourse(level, course);
            RETAINED.put(level, new Retention(List.copyOf(chunks), level.getGameTime() + HANDOFF_TICKS));
            JOBS.remove(level);
            STATUS.put(level, "READY Volcanic Abyss; three cars/six seats; temporary ticket handoff expires in 60 seconds");
            VolcanicCourseDesign.Metrics metrics = VolcanicCourseDesign.measure(track);
            CoasterEngineering.LOGGER.info("VOLCANIC_WORLD_READY course={} placed={} length={} elevationRange={} travelTicks={} peakKmh={}",
                    COURSE_ID, placed, metrics.length(), metrics.elevationRange(), metrics.travelTicks(), metrics.maximumKmh());
            // Post-carve lighting must run after CLEARANCE and SUPPORTS. The quality
            // marker is committed by that service only after its live clearance check.
            if (!WorldQualityUpgradeService.begin(level))
                CoasterEngineering.LOGGER.warn("Volcanic scenery built; quality update requires operator retry: {}", WorldQualityUpgradeService.status(level));
        }

        void rollbackCourse() {
            if (!committed) return;
            if (leader != null) {
                for (CoasterEntity car : leader.getLoadedFormation()) car.discard();
                leader.discard();
            }
            CoasterSavedData.get(level).removeCourse(COURSE_ID);
            committed = false;
        }

        boolean insideRoom(TrackVec3 point) {
            for (double[] room : rooms) {
                double dx = (point.x() - room[0]) / (room[3] + 7);
                double dy = (point.y() - room[1]) / (room[4] + 7);
                double dz = (point.z() - room[2]) / (room[5] + 7);
                if (dx * dx + dy * dy + dz * dz <= 1) return true;
            }
            return false;
        }
    }

    private static boolean insideFootprint(BlockPos pos) {
        return pos.getX() >= MIN_X && pos.getX() <= MAX_X && pos.getZ() >= MIN_Z && pos.getZ() <= MAX_Z
                && pos.getY() >= MIN_Y && pos.getY() <= MAX_Y;
    }

    private static int surfaceHeight(double x, double z) {
        double radius = Math.hypot(x - .5, z - .5);
        double rim = 5 * Math.exp(-Math.pow((radius - 28) / 7, 2));
        return (int) Math.floor(Math.max(MIN_Y, Math.min(174, 174 - 110 * radius * radius / (140 * 140) + rim)));
    }

    private static BlockState stone(int x, int y, int z) {
        long hash = WORLD_SEED ^ (x * 341873128712L) ^ (y * 132897987541L) ^ (z * 42317861L);
        hash ^= hash >>> 33;
        int choice = (int) Math.floorMod(hash, 100L);
        return (choice < 70 ? Blocks.BASALT : choice < 90 ? Blocks.DEEPSLATE : Blocks.BLACKSTONE).defaultBlockState();
    }

    private static Block rail(RailKind kind) {
        return switch (kind) {
            case NORMAL -> CoasterRegistries.RAIL.get();
            case BOOST -> CoasterRegistries.BOOST_RAIL.get();
            case BRAKE -> CoasterRegistries.BRAKE_RAIL.get();
            case LIFT -> CoasterRegistries.LIFT_RAIL.get();
            case STATION -> CoasterRegistries.STATION_RAIL.get();
        };
    }

    /** Same rotated body corners and upright rider boxes checked by CoasterEntity. */
    private static AABB[] envelopes(TrackSample sample) {
        TrackFrame frame = TrackFrame.from(sample);
        TrackVec3 anchor = sample.position();
        double minX = Double.POSITIVE_INFINITY, minY = Double.POSITIVE_INFINITY, minZ = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY, maxZ = Double.NEGATIVE_INFINITY;
        for (double x : new double[] {-.9, .9}) for (double y : new double[] {-.05, 1.2}) for (double z : new double[] {-1.5, 1.5}) {
            TrackVec3 corner = anchor.add(frame.right().scale(x)).add(frame.up().scale(y)).add(frame.forward().scale(z));
            minX = Math.min(minX, corner.x()); minY = Math.min(minY, corner.y()); minZ = Math.min(minZ, corner.z());
            maxX = Math.max(maxX, corner.x()); maxY = Math.max(maxY, corner.y()); maxZ = Math.max(maxZ, corner.z());
        }
        AABB[] boxes = new AABB[3];
        boxes[0] = new AABB(minX, minY, minZ, maxX, maxY, maxZ).inflate(.15);
        for (int seat = 0; seat < 2; seat++) {
            TrackVec3 feet = anchor.add(frame.right().scale(seat == 0 ? -.45 : .45)).add(frame.up().scale(.45));
            boxes[seat + 1] = new AABB(feet.x() - .3, feet.y(), feet.z() - .3,
                    feet.x() + .3, feet.y() + 1.8, feet.z() + .3).inflate(.15);
        }
        return boxes;
    }
}
