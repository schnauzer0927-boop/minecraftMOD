package dev.coasterengineering.gametest;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.RideDynamics;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.AbstractMinecart;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;
import net.minecraftforge.registries.ForgeRegistries;

/**
 * Server integration checks, using actual Forge entities, ticking, passengers and NBT.
 * Client model rendering, camera motion and human play remain separate manual checks.
 */
@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class CoasterGameTests {
    // Forge 47.4.10 adds GameTestHolder's namespace itself.
    private static final String TEMPLATE = "empty";
    private static final double POSITION_TOLERANCE = .05;

    private CoasterGameTests() { }

    @GameTest(template = TEMPLATE)
    public static void independentEntityAndRailRegistration(GameTestHelper helper) {
        CoasterEntity vehicle = createVehicle(helper);
        helper.assertTrue(new ResourceLocation("coasterengineering", "coaster").equals(
                ForgeRegistries.ENTITY_TYPES.getKey(CoasterRegistries.COASTER.get())),
                "Coaster must use its independent mod entity ID");
        helper.assertFalse((Object) vehicle instanceof AbstractMinecart,
                "Coaster implementation must not inherit a vanilla minecart");
        List.of(CoasterRegistries.RAIL, CoasterRegistries.BOOST_RAIL,
                CoasterRegistries.BRAKE_RAIL, CoasterRegistries.LIFT_RAIL,
                CoasterRegistries.STATION_RAIL).forEach(rail -> {
                    ResourceLocation id = ForgeRegistries.BLOCKS.getKey(rail.get());
                    helper.assertTrue(id != null && "coasterengineering".equals(id.getNamespace()),
                            "Every rail variant must be an independently registered coaster block");
                });
        helper.assertTrue(ForgeRegistries.ITEMS.containsKey(new ResourceLocation("coasterengineering", "course_editor")),
                "Course editing item must be registered");
        helper.assertTrue(vehicle.getBbWidth() > 1 && vehicle.getBbHeight() > .5,
                "Dedicated vehicle must have a useful seat-sized collision body");
        vehicle.discard();
        helper.succeed();
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 145)
    public static void elevatedSplineMotionStaysOnTrack(GameTestHelper helper) {
        Fixture fixture = fixture(helper);
        helper.assertTrue(fixture.vehicle.startRide(), "A complete closed course must permit departure");
        double[] highestY = {fixture.vehicle.getY()};
        for (int tick = 1; tick <= 120; tick++) {
            int elapsed = tick;
            helper.runAfterDelay(tick, () -> {
                assertOnTrack(helper, fixture);
                highestY[0] = Math.max(highestY[0], fixture.vehicle.getY());
                if (elapsed == 40) {
                    helper.assertTrue(fixture.vehicle.getDistance() > 5,
                            "Live server ticks must advance continuous distance beyond the station");
                    helper.assertTrue(fixture.vehicle.getSpeed() > 0,
                            "Boost/lift segments must propel the vehicle");
                }
                if (elapsed == 120) {
                    helper.assertTrue(highestY[0] > fixture.course.track().sample(0).position().y() + 2,
                            "The test must actually traverse elevated track, rather than only flat station track");
                    cleanup(helper, fixture);
                    helper.succeed();
                }
            });
        }
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 80)
    public static void emergencyStopHoldsDistanceAndPosition(GameTestHelper helper) {
        Fixture fixture = fixture(helper);
        helper.assertTrue(fixture.vehicle.startRide(), "Test course must start");
        helper.runAfterDelay(25, () -> {
            helper.assertTrue(fixture.vehicle.getDistance() > 0 && fixture.vehicle.getSpeed() > 0,
                    "Emergency stop must be exercised while the coaster is moving");
            fixture.vehicle.emergencyStop();
            double distance = fixture.vehicle.getDistance();
            Vec3 position = fixture.vehicle.position();
            helper.assertFalse(fixture.vehicle.isRunning(), "Emergency stop must immediately clear running state");
            near(helper, fixture.vehicle.getSpeed(), 0, "Emergency-stop speed");
            for (int delay = 1; delay <= 30; delay++) {
                int elapsed = delay;
                GameTestScheduling.after(helper, delay, () -> {
                    near(helper, fixture.vehicle.getDistance(), distance, "Emergency stop must hold distance");
                    helper.assertTrue(fixture.vehicle.position().distanceTo(position) < POSITION_TOLERANCE,
                            "Emergency stop must not let gravity drop or drift the vehicle");
                    near(helper, fixture.vehicle.getSpeed(), 0, "Stopped speed must remain zero");
                    if (elapsed == 30) {
                        cleanup(helper, fixture);
                        helper.succeed();
                    }
                });
            }
        });
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 620)
    public static void completeLapReturnsAndStopsAtStation(GameTestHelper helper) {
        Fixture fixture = fixture(helper);
        helper.assertTrue(fixture.vehicle.startRide(), "Test course must depart");
        CoasterEntity duplicate = createVehicle(helper);
        duplicate.setCourse(fixture.course.id());
        helper.assertFalse(duplicate.startRide(), "A second train must not dispatch onto an occupied single-train course");
        duplicate.discard();
        boolean[] finished = {false};
        for (int tick = 1; tick <= 600; tick++) {
            int elapsed = tick;
            helper.runAfterDelay(tick, () -> {
                if (finished[0]) return;
                assertOnTrack(helper, fixture);
                if (fixture.vehicle.getLaps() >= 1 && !fixture.vehicle.isRunning()) {
                    helper.assertTrue(fixture.vehicle.getLaps() == 1,
                            "One dispatch must complete exactly one lap");
                    near(helper, fixture.vehicle.getSpeed(), 0, "Returned station speed");
                    near(helper, fixture.vehicle.getDistance(), 0, "Station return must reset distance");
                    TrackVec3 start = fixture.course.track().sample(0).position();
                    helper.assertTrue(fixture.vehicle.position().distanceTo(toVec3(start)) < POSITION_TOLERANCE,
                            "Station stop must place the vehicle at the boarding point");
                    finished[0] = true;
                    cleanup(helper, fixture);
                    helper.succeed();
                } else if (elapsed == 600) {
                    helper.assertTrue(false, "Coaster must complete a lap and stop within 600 server ticks; distance="
                            + fixture.vehicle.getDistance() + ", speed=" + fixture.vehicle.getSpeed()
                            + ", laps=" + fixture.vehicle.getLaps());
                }
            });
        }
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 60)
    public static void courseAndRidePositionSurviveNbtRoundTripSafelyPaused(GameTestHelper helper) {
        Fixture fixture = fixture(helper);
        helper.assertTrue(fixture.vehicle.startRide(), "Persistence fixture must depart");
        helper.runAfterDelay(25, () -> {
            helper.assertTrue(fixture.vehicle.getSpeed() > 0 && fixture.vehicle.getDistance() > 0,
                    "Round trip must preserve actual in-progress ride state");
            CompoundTag courseTag = CoasterSavedData.get(helper.getLevel()).save(new CompoundTag());
            CoasterSavedData restoredData = CoasterSavedData.load(courseTag);
            Course restoredCourse = restoredData.getCourse(fixture.course.id());
            helper.assertTrue(restoredCourse != null, "Saved course UUID must survive world-data loading");
            helper.assertTrue(restoredCourse.name().equals(fixture.course.name()), "Course name must be preserved");
            helper.assertTrue(restoredCourse.station().equals(fixture.course.station()), "Safe station landing must be preserved");
            helper.assertTrue(restoredCourse.enabled() == fixture.course.enabled(), "Enabled state must be preserved");
            helper.assertTrue(restoredCourse.track().closed(), "Closed-path flag must be preserved");
            helper.assertTrue(restoredCourse.track().points().equals(fixture.course.track().points()),
                    "All 3D nodes, bank angles, rail kinds and target speeds must be preserved");
            near(helper, restoredCourse.track().length(), fixture.course.track().length(), "Restored spline length");
            CompoundTag vehicleTag = fixture.vehicle.saveWithoutId(new CompoundTag());
            CoasterEntity restoredVehicle = createVehicle(helper);
            restoredVehicle.load(vehicleTag);
            helper.assertTrue(fixture.course.id().equals(restoredVehicle.courseId()), "Vehicle course link must be preserved");
            near(helper, restoredVehicle.getDistance(), fixture.vehicle.getDistance(), "Saved continuous ride distance");
            helper.assertTrue(restoredVehicle.getLaps() == fixture.vehicle.getLaps(), "Saved lap counter must be preserved");
            near(helper, restoredVehicle.getSpeed(), 0, "Reload must pause speed until chunks and riders are ready");
            helper.assertFalse(restoredVehicle.isRunning(), "Reload must require an explicit safe dispatch");
            restoredVehicle.discard();
            cleanup(helper, fixture);
            helper.succeed();
        });
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 85)
    public static void unassignedOrRemovedCourseSafelyHoldsVehicle(GameTestHelper helper) {
        CoasterEntity unassigned = createVehicle(helper);
        unassigned.moveTo(helper.absoluteVec(new Vec3(10.5, 6, 10.5)));
        helper.getLevel().addFreshEntity(unassigned);
        Vec3 unassignedPosition = unassigned.position();
        helper.assertFalse(unassigned.startRide(), "A vehicle without a course must refuse dispatch");
        Fixture fixture = fixture(helper);
        helper.assertTrue(fixture.vehicle.startRide(), "Course-removal fixture must initially run");
        helper.runAfterDelay(20, () -> {
            helper.assertTrue(fixture.vehicle.getSpeed() > 0, "The deleted course must be carrying a moving vehicle");
            CoasterSavedData.get(helper.getLevel()).removeCourse(fixture.course.id());
            Vec3 removalPosition = fixture.vehicle.position();
            double removalDistance = fixture.vehicle.getDistance();
            for (int delay = 1; delay <= 30; delay++) {
                int elapsed = delay;
                GameTestScheduling.after(helper, delay, () -> {
                    helper.assertFalse(fixture.vehicle.isRunning(), "Missing-course safety must clear running state");
                    near(helper, fixture.vehicle.getSpeed(), 0, "Missing-course safety speed");
                    near(helper, fixture.vehicle.getDistance(), removalDistance, "Missing-course safety distance");
                    helper.assertTrue(fixture.vehicle.position().distanceTo(removalPosition) < POSITION_TOLERANCE,
                            "A removed course must not cause falling or movement outside the world");
                    helper.assertTrue(unassigned.position().distanceTo(unassignedPosition) < POSITION_TOLERANCE,
                            "An unassigned coaster must remain suspended safely without gravity drift");
                    if (elapsed == 30) {
                        unassigned.discard();
                        fixture.vehicle.discard();
                        helper.succeed();
                    }
                });
            }
        });
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 75)
    public static void newlyPlacedWallStopsBeforeCommittingNextPose(GameTestHelper helper) {
        Fixture fixture = fixture(helper);
        helper.assertTrue(fixture.vehicle.startRide(), "Obstacle fixture must initially depart");
        helper.runAfterDelay(25, () -> {
            CoasterEntity vehicle = fixture.vehicle;
            helper.assertTrue(vehicle.isRunning() && vehicle.getSpeed() > 0,
                    "The obstacle must be introduced during actual server-driven motion");
            RideDynamics.Step predicted = RideDynamics.advance(fixture.course.track(), vehicle.getDistance(),
                    vehicle.getSpeed(), true, CoasterEntity.MAX_SPEED);
            TrackSample next = fixture.course.track().sample(predicted.distance());
            BlockPos base = BlockPos.containing(toVec3(next.position()));
            Map<BlockPos, BlockState> originalBlocks = new LinkedHashMap<>();
            boolean crossesX = Math.abs(next.tangent().x()) >= Math.abs(next.tangent().z());
            // An actual solid wall spans the next cart/rider headroom. Keep its
            // original states so this test restores every block it changes.
            for (int horizontal = -1; horizontal <= 1; horizontal++) {
                for (int height = 1; height <= 3; height++) {
                    BlockPos wall = crossesX ? base.offset(0, height, horizontal)
                            : base.offset(horizontal, height, 0);
                    originalBlocks.put(wall, helper.getLevel().getBlockState(wall));
                    helper.getLevel().setBlock(wall, Blocks.STONE.defaultBlockState(), 3);
                }
            }
            helper.assertTrue(helper.getLevel().getBlockState(base.above()).is(Blocks.STONE),
                    "Next-pose obstacle must exist as real collidable world blocks");
            double safeDistance = vehicle.getDistance();
            Vec3 safePosition = vehicle.position();
            for (int delay = 1; delay <= 20; delay++) {
                int elapsed = delay;
                GameTestScheduling.after(helper, delay, () -> {
                    helper.assertFalse(vehicle.isRunning(), "Solid headroom obstruction must trigger safety stop");
                    near(helper, vehicle.getSpeed(), 0, "Obstacle-stop speed");
                    near(helper, vehicle.getDistance(), safeDistance,
                            "Blocked next pose must be rejected before changing continuous distance");
                    helper.assertTrue(vehicle.position().distanceTo(safePosition) < POSITION_TOLERANCE,
                            "Blocked coaster must hold its last pose without falling or penetrating farther");
                    if (elapsed == 20) {
                        originalBlocks.forEach((position, state) -> helper.getLevel().setBlock(position, state, 3));
                        cleanup(helper, fixture);
                        helper.succeed();
                    }
                });
            }
        });
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 45)
    public static void distantUnloadedStartRefusesDispatchWithoutLoadingChunks(GameTestHelper helper) {
        final double distantX = 1_000_000;
        final double distantZ = 1_000_000;
        List<ControlPoint> points = List.of(
                new ControlPoint(new TrackVec3(distantX + 8.5, 80, distantZ + 6.5), 0, RailKind.STATION, .32),
                new ControlPoint(new TrackVec3(distantX + 24.5, 80, distantZ + 6.5), 0, RailKind.BOOST, .6),
                new ControlPoint(new TrackVec3(distantX + 24.5, 80, distantZ + 24.5), 0, RailKind.BOOST, .6),
                new ControlPoint(new TrackVec3(distantX + 8.5, 80, distantZ + 24.5), 0, RailKind.BOOST, .6));
        Course distantCourse = new Course(UUID.randomUUID(), "GameTest distant unloaded loop",
                new SplineTrack(points, true), helper.absolutePos(new BlockPos(8, 2, 4)), true);
        BlockPos distantStart = BlockPos.containing(toVec3(distantCourse.track().sample(0).position()));
        helper.assertTrue(helper.getLevel().getWorldBorder().isWithinBounds(distantStart),
                "Unloaded-chunk fixture must be inside the valid world border");
        helper.assertFalse(helper.getLevel().hasChunkAt(distantStart),
                "The distant fixture must begin in a chunk the test server has not loaded");
        CoasterSavedData.get(helper.getLevel()).putCourse(distantCourse);
        CoasterEntity vehicle = createVehicle(helper);
        vehicle.moveTo(helper.absoluteVec(new Vec3(8.5, 3, 6.5)));
        vehicle.setCourse(distantCourse.id());
        helper.assertTrue(helper.getLevel().addFreshEntity(vehicle),
                "Unloaded-course vehicle must exist in the nearby loaded test area");
        Vec3 originalPosition = vehicle.position();
        helper.assertFalse(vehicle.resetToStation(), "Reset must refuse to teleport into an unloaded rail chunk");
        helper.assertFalse(vehicle.startRide(), "Dispatch must refuse an unloaded course start");
        for (int delay = 1; delay <= 20; delay++) {
            int elapsed = delay;
            helper.runAfterDelay(delay, () -> {
                helper.assertFalse(helper.getLevel().hasChunkAt(distantStart),
                        "Rail reset, dispatch and subsequent ticks must never force-load the distant chunk");
                helper.assertFalse(vehicle.isRunning(), "Unloaded start must remain safely stopped");
                near(helper, vehicle.getSpeed(), 0, "Unloaded-start speed");
                near(helper, vehicle.getDistance(), 0, "Unloaded-start distance");
                helper.assertTrue(vehicle.position().distanceTo(originalPosition) < POSITION_TOLERANCE,
                        "Unloaded course must not teleport, drift or drop its vehicle");
                if (elapsed == 20) {
                    vehicle.discard();
                    CoasterSavedData.get(helper.getLevel()).removeCourse(distantCourse.id());
                    helper.succeed();
                }
            });
        }
    }

    @GameTest(template = TEMPLATE, timeoutTicks = 40)
    public static void twoPassengersBoardDistinctSeatsAndDismount(GameTestHelper helper) {
        Fixture fixture = fixture(helper);
        Player first = passenger(helper, fixture.vehicle);
        Player second = passenger(helper, fixture.vehicle);
        Player third = passenger(helper, fixture.vehicle);
        helper.assertTrue(fixture.vehicle.interact(first, InteractionHand.MAIN_HAND).consumesAction(),
                "Right-click interaction must accept the first passenger");
        helper.assertTrue(fixture.vehicle.interact(second, InteractionHand.MAIN_HAND).consumesAction(),
                "Right-click interaction must accept the second passenger");
        fixture.vehicle.interact(third, InteractionHand.MAIN_HAND);
        helper.assertTrue(first.getVehicle() == fixture.vehicle && second.getVehicle() == fixture.vehicle,
                "Both accepted riders must actually be mounted on the dedicated entity");
        helper.assertTrue(third.getVehicle() != fixture.vehicle && fixture.vehicle.getPassengers().size() == 2,
                "A two-seat vehicle must reject a third rider");
        fixture.vehicle.positionRider(first);
        fixture.vehicle.positionRider(second);
        helper.assertTrue(first.position().distanceTo(second.position()) > .25,
                "Passengers must occupy distinct seat positions");
        helper.assertTrue(first.position().distanceTo(fixture.vehicle.position()) < 2
                        && second.position().distanceTo(fixture.vehicle.position()) < 2,
                "Seat positions must stay within the dedicated vehicle's body");
        first.stopRiding();
        helper.assertTrue(first.getVehicle() == null && fixture.vehicle.getPassengers().size() == 1,
                "Dismount must release exactly one seat");
        helper.assertTrue(helper.getLevel().noCollision(first, first.getBoundingBox()),
                "Stopped-station dismount must land outside solid blocks");
        second.stopRiding();
        cleanup(helper, fixture);
        helper.succeed();
    }

    private static CoasterEntity createVehicle(GameTestHelper helper) {
        return new CoasterEntity(CoasterRegistries.COASTER.get(), helper.getLevel());
    }

    private static Fixture fixture(GameTestHelper helper) {
        double[][] coordinates = {
                {8.5, 3, 6.5}, {16.5, 3, 6.5}, {23.5, 4, 9.5}, {24.5, 8, 16.5},
                {20.5, 10, 23.5}, {12.5, 7, 24.5}, {6.5, 3, 20.5}, {5.5, 3, 12.5}
        };
        RailKind[] kinds = {RailKind.STATION, RailKind.BOOST, RailKind.BOOST, RailKind.LIFT,
                RailKind.BOOST, RailKind.BRAKE, RailKind.BOOST, RailKind.BOOST};
        List<ControlPoint> points = new ArrayList<>();
        for (int i = 0; i < coordinates.length; i++) {
            Vec3 absolute = helper.absoluteVec(new Vec3(coordinates[i][0], coordinates[i][1], coordinates[i][2]));
            points.add(new ControlPoint(new TrackVec3(absolute.x, absolute.y, absolute.z),
                    i == 2 || i == 5 ? 20 : 0, kinds[i], kinds[i] == RailKind.STATION ? .32 : .6));
        }
        Course course = new Course(UUID.randomUUID(), "GameTest elevated loop", new SplineTrack(points, true),
                helper.absolutePos(new BlockPos(8, 2, 4)), true);
        CoasterSavedData.get(helper.getLevel()).putCourse(course);
        CoasterEntity vehicle = createVehicle(helper);
        vehicle.setCourse(course.id());
        helper.assertTrue(vehicle.resetToStation(), "Registered complete course must place its vehicle at the station");
        helper.assertTrue(helper.getLevel().addFreshEntity(vehicle), "Dedicated vehicle must be inserted into the real server level");
        return new Fixture(course, vehicle);
    }

    private static Player passenger(GameTestHelper helper, CoasterEntity vehicle) {
        Player player = helper.makeMockSurvivalPlayer();
        player.moveTo(vehicle.position().add(0, 0, 1));
        return player;
    }

    private static void assertOnTrack(GameTestHelper helper, Fixture fixture) {
        CoasterEntity vehicle = fixture.vehicle;
        helper.assertTrue(Double.isFinite(vehicle.getDistance()) && Double.isFinite(vehicle.getSpeed())
                        && Double.isFinite(vehicle.getX()) && Double.isFinite(vehicle.getY()) && Double.isFinite(vehicle.getZ()),
                "Distance, speed and world position must remain finite at every server tick");
        helper.assertTrue(vehicle.getSpeed() >= 0 && vehicle.getSpeed() <= 120.0 / 72.0 + .001,
                "Internal speed must remain nonnegative and within the 120 km/h equivalent limit");
        helper.assertTrue(vehicle.position().distanceTo(toVec3(fixture.course.track().sample(vehicle.getDistance()).position()))
                        < POSITION_TOLERANCE,
                "Vehicle must follow the actual continuous spline sample without falling or derailing");
        helper.assertTrue(Float.isFinite(vehicle.getXRot()) && Float.isFinite(vehicle.getYRot()),
                "Track-driven pitch and yaw must remain finite");
    }

    private static Vec3 toVec3(TrackVec3 vector) {
        return new Vec3(vector.x(), vector.y(), vector.z());
    }

    private static void near(GameTestHelper helper, double actual, double expected, String description) {
        helper.assertTrue(Double.isFinite(actual) && Math.abs(actual - expected) < .001,
                description + ": expected " + expected + ", actual " + actual);
    }

    private static void cleanup(GameTestHelper helper, Fixture fixture) {
        fixture.vehicle.discard();
        CoasterSavedData.get(helper.getLevel()).removeCourse(fixture.course.id());
    }

    private record Fixture(Course course, CoasterEntity vehicle) { }
}
