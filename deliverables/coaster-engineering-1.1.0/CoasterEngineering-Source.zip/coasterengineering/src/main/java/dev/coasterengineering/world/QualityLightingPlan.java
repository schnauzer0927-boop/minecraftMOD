package dev.coasterengineering.world;

import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Small deterministic lighting additions, independent of construction or ride
 * authority. Invisible LIGHT candidates must only replace air or existing LIGHT
 * when applied: replacing rock with a non-solid light would puncture the shell.
 * Every candidate also avoids the complete car and upright passenger envelope.
 */
public final class QualityLightingPlan {
    private static final double SWEEP_STEP = .25;
    private static final double CLEARANCE_MARGIN = .25;
    private static final BlockState COLD = Blocks.SEA_LANTERN.defaultBlockState();
    private static final BlockState HOT = Blocks.SHROOMLIGHT.defaultBlockState();
    private static final BlockState CYAN = Blocks.CYAN_STAINED_GLASS.defaultBlockState();
    private static final BlockState ORANGE = Blocks.ORANGE_STAINED_GLASS.defaultBlockState();

    private QualityLightingPlan() { }

    /** Shared immutable protection for lighting and the separate shell repair. */
    public static Set<BlockPos> protectedCells(SplineTrack track) {
        Objects.requireNonNull(track, "track");
        HashSet<BlockPos> cells = new HashSet<>();
        for (double distance = 0; distance < track.length(); distance += SWEEP_STEP)
            protectSample(cells, track.sample(distance));
        protectSample(cells, track.sample(track.length()));
        return Set.copyOf(cells);
    }

    private static void protectSample(Set<BlockPos> cells, TrackSample sample) {
        TrackFrame frame = TrackFrame.from(sample);
        TrackVec3 anchor = sample.position();
        double minX = Double.POSITIVE_INFINITY, minY = Double.POSITIVE_INFINITY, minZ = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY, maxZ = Double.NEGATIVE_INFINITY;
        for (double x : new double[] {-.9, .9}) for (double y : new double[] {-.05, 1.2})
            for (double z : new double[] {-1.5, 1.5}) {
                TrackVec3 p = local(anchor, frame, x, y, z);
                minX = Math.min(minX, p.x()); minY = Math.min(minY, p.y()); minZ = Math.min(minZ, p.z());
                maxX = Math.max(maxX, p.x()); maxY = Math.max(maxY, p.y()); maxZ = Math.max(maxZ, p.z());
            }
        protectBox(cells, minX, minY, minZ, maxX, maxY, maxZ);
        for (double x : new double[] {-.45, .45}) {
            TrackVec3 feet = local(anchor, frame, x, .45, 0);
            // Passenger bodies stay upright even when the vehicle banks.
            protectBox(cells, feet.x() - .30, feet.y(), feet.z() - .30,
                    feet.x() + .30, feet.y() + 1.8, feet.z() + .30);
        }
    }

    private static void protectBox(Set<BlockPos> cells, double minX, double minY, double minZ,
                                   double maxX, double maxY, double maxZ) {
        for (BlockPos p : BlockPos.betweenClosed(Mth.floor(minX - CLEARANCE_MARGIN),
                Mth.floor(minY - CLEARANCE_MARGIN), Mth.floor(minZ - CLEARANCE_MARGIN),
                Mth.floor(maxX + CLEARANCE_MARGIN - 1.0E-7),
                Mth.floor(maxY + CLEARANCE_MARGIN - 1.0E-7),
                Mth.floor(maxZ + CLEARANCE_MARGIN - 1.0E-7))) cells.add(p.immutable());
    }

    /** Generic route lights, also usable on small low-altitude GameTest courses. */
    public static Map<BlockPos, BlockState> rideLighting(SplineTrack track) {
        return rideLighting(track, protectedCells(track));
    }

    public static Map<BlockPos, BlockState> rideLighting(SplineTrack track, Set<BlockPos> protectedCells) {
        Objects.requireNonNull(track, "track");
        Planner plan = new Planner(protectedCells, false);
        for (double distance = 0; distance < track.length(); distance += 4) {
            TrackSample sample = track.sample(distance);
            TrackFrame frame = TrackFrame.from(sample);
            TrackVec3 anchor = sample.position();
            int level = sample.kind() == RailKind.STATION || sample.kind() == RailKind.BOOST
                    || anchor.y() < 106 ? 12 : 11;
            // World-up overhead sources illuminate upright eyes on steep rails;
            // paired side sources keep banks and corners from producing gaps.
            plan.light(anchor.add(new TrackVec3(0, 3.4, 0)), level);
            for (int side : new int[] {-1, 1})
                plan.light(anchor.add(frame.right().scale(side * 2.8)).add(new TrackVec3(0, 1.2, 0)), level);
        }
        // On a steep grade, world-up lamps can occupy the swept space of the
        // next car pose and correctly get filtered out. Follow the track-normal
        // ceiling instead, with closer spacing through climbs, descents and
        // banked bends where inner-wall shadows can hide the passenger view.
        for (double distance = 0; distance < track.length(); distance += 2) {
            TrackSample sample = track.sample(distance);
            if (Math.abs(sample.tangent().y()) <= .15 && Math.abs(sample.bankDegrees()) <= 8) continue;
            TrackFrame frame = TrackFrame.from(sample);
            TrackVec3 anchor = sample.position();
            plan.light(anchor.add(frame.up().scale(3.4)), 13);
            for (int side : new int[] {-1, 1})
                plan.light(anchor.add(frame.right().scale(side * 3.4))
                        .add(frame.up().scale(1.2)), 13);
        }
        for (double distance = 0; distance < track.length(); distance += 2) {
            TrackSample sample = track.sample(distance);
            if (sample.kind() != RailKind.STATION) continue;
            TrackFrame frame = TrackFrame.from(sample);
            plan.light(sample.position().add(frame.up().scale(3.4)), 13);
            for (int side : new int[] {-1, 1})
                plan.light(sample.position().add(frame.right().scale(side * 3.4))
                        .add(frame.up().scale(1.2)), 13);
        }
        // A continuous cyan guide makes the fast section readable without a
        // new wall, arch, rail geometry or gameplay light attachment.
        for (double distance = 0; distance < track.length(); distance += 2) {
            TrackSample sample = track.sample(distance);
            if (sample.kind() != RailKind.BOOST) continue;
            TrackFrame frame = TrackFrame.from(sample);
            boolean emitter = ((int) Math.round(distance / 2) & 1) == 0;
            for (int side : new int[] {-1, 1}) {
                TrackVec3 p = sample.position().add(frame.right().scale(side * 3.8))
                        .add(new TrackVec3(0, -.35, 0));
                plan.put(BlockPos.containing(p.x(), p.y(), p.z()), emitter ? COLD : CYAN);
            }
        }
        return Map.copyOf(plan.blocks);
    }

    /** Original fixed scenery accents plus the post-carve route lighting. */
    public static Map<BlockPos, BlockState> volcanicLighting(SplineTrack track, Set<BlockPos> protectedCells) {
        Planner plan = new Planner(protectedCells, true);
        rideLighting(track, protectedCells).forEach(plan::put);

        // Existing blue/orange glass surfaces remain the same; emitters move
        // closer beneath selected cells rather than rebuilding either basin.
        for (int x = -88; x <= -56; x += 8) for (int z = 3; z <= 27; z += 6) {
            plan.put(new BlockPos(x, 73, z), COLD);
            plan.light(new TrackVec3(x + .5, 79, z + .5), 10);
        }
        for (int x = 32; x <= 56; x += 8) for (int z = 28; z <= 52; z += 8) {
            plan.put(new BlockPos(x, 73, z), HOT);
            plan.light(new TrackVec3(x + .5, 79, z + .5), 11);
        }

        allChambers(plan);

        // Front/side fill reveals the existing sentinel's silhouette, teeth and
        // hands. Its sculpture and eye blocks are deliberately not rewritten.
        for (int x : new int[] {-39, -29, -19}) for (int y : new int[] {78, 85, 92}) {
            plan.light(new TrackVec3(x + .5, y, 20.5), 12);
            plan.light(new TrackVec3(x + .5, y, 1.5), 10);
        }
        for (int x : new int[] {-39, -19}) {
            plan.put(new BlockPos(x, 71, 9), HOT);
            plan.light(new TrackVec3(x + .5, 76, 9.5), 11);
        }
        return Map.copyOf(plan.blocks);
    }

    /** Sparse shell fixtures may replace stone, never an intentional open cell. */
    public static boolean requiresExistingSolid(BlockPos position) {
        return FixtureCells.CELLS.contains(position);
    }

    private static void allChambers(Planner plan) {
        chamber(plan, -72, 80, 15, 24, 16, 24, COLD, CYAN);
        chamber(plan, 45, 83, 40, 24, 19, 24, HOT, ORANGE);
        chamber(plan, -29, 83, 10, 22, 22, 22, COLD, CYAN);
    }

    private static final class FixtureCells {
        static final Set<BlockPos> CELLS = cells();
        private static Set<BlockPos> cells() {
            Planner plan = new Planner(Set.of(), true);
            allChambers(plan);
            HashSet<BlockPos> result = new HashSet<>();
            plan.blocks.forEach((position, state) -> { if (!state.is(Blocks.LIGHT)) result.add(position); });
            return Set.copyOf(result);
        }
    }

    private static void chamber(Planner plan, int x, int y, int z, int rx, int ry, int rz,
                                BlockState emitter, BlockState glass) {
        for (int dx = -12; dx <= 12; dx += 6) for (int dz = -12; dz <= 12; dz += 6)
            for (int dy : new int[] {-2, 5, 11}) {
                double radius = square((double) dx / rx) + square((double) dy / ry) + square((double) dz / rz);
                if (radius < .68) plan.light(new TrackVec3(x + dx + .5, y + dy, z + dz + .5), 11);
            }
        // Sparse fixtures articulate walls and ceiling while preserving dark
        // stone between the lamps and the original intentional openings.
        for (int n = 0; n < 12; n++) for (int dy : new int[] {-4, 6}) {
            double angle = n * Math.PI / 6;
            double scale = Math.sqrt(1 - square((double) dy / ry)) * .94;
            int dx = (int) Math.round(rx * scale * Math.cos(angle));
            int dz = (int) Math.round(rz * scale * Math.sin(angle));
            plan.put(new BlockPos(x + dx, y + dy, z + dz), emitter);
            int insetX = (int) Math.round(dx * .96), insetZ = (int) Math.round(dz * .96);
            if (insetX != dx || insetZ != dz) plan.put(new BlockPos(x + insetX, y + dy, z + insetZ), glass);
        }
        for (int dx : new int[] {-8, 0, 8}) for (int dz : new int[] {-8, 0, 8}) {
            int top = y + (int) Math.floor(ry * Math.sqrt(1 - square((double) dx / rx) - square((double) dz / rz))) - 1;
            plan.put(new BlockPos(x + dx, top, z + dz), emitter);
            plan.put(new BlockPos(x + dx, top - 1, z + dz), glass);
        }
    }

    /** Station low-level lights; no window, entrance, tread or vehicle changes. */
    public static Map<BlockPos, BlockState> stationLighting(SplineTrack track, Set<BlockPos> protectedCells) {
        Objects.requireNonNull(track, "track");
        Planner plan = new Planner(protectedCells, true);
        for (int z = -110; z <= -90; z += 4) {
            for (int x : new int[] {-8, -4}) {
                plan.put(new BlockPos(x, 92, z), COLD);
                plan.put(new BlockPos(x, 93, z), CYAN);
            }
            plan.put(new BlockPos(-11, 95, z), COLD);
            plan.put(new BlockPos(-7, 103, z), COLD);
            plan.put(new BlockPos(-7, 102, z), CYAN);
            plan.light(new TrackVec3(-4.5, 96, z + .5), 11);
        }
        for (int z = -113; z <= -89; z += 3)
            plan.light(new TrackVec3(.5, 98, z + .5), 12);
        for (int step = 0; step <= 45; step += 3) {
            int z = -115 - step;
            int floor = 93 - step * 29 / 45;
            for (int x : new int[] {-10, -5}) plan.put(new BlockPos(x, floor + 2, z), COLD);
        }
        return Map.copyOf(plan.blocks);
    }

    /** Audit the real seat-eye cells after the server light engine propagates. */
    public static List<LightProbe> passengerLightProbes(SplineTrack track) {
        Objects.requireNonNull(track, "track");
        ArrayList<LightProbe> probes = new ArrayList<>();
        for (double distance = 0; distance < track.length(); distance += 2) {
            TrackSample sample = track.sample(distance);
            TrackFrame frame = TrackFrame.from(sample);
            String zone = zone(sample);
            for (int seat = 0; seat < 2; seat++) {
                TrackVec3 feet = local(sample.position(), frame, seat == 0 ? -.45 : .45, .45, 0);
                TrackVec3 eye = feet.add(new TrackVec3(0, 1.62, 0));
                probes.add(new LightProbe(distance, seat, BlockPos.containing(eye.x(), eye.y(), eye.z()),
                        zone.equals("station") ? 9 : 6, zone));
            }
        }
        return List.copyOf(probes);
    }

    private static String zone(TrackSample sample) {
        TrackVec3 p = sample.position();
        if (sample.kind() == RailKind.STATION) return "station";
        if (sample.kind() == RailKind.BOOST) return "cavern-speed";
        if (p.z() < -67) return "return";
        if (Math.hypot(p.x() + 29, p.z() - 10) < 27 && p.y() < 110) return "monster";
        if (Math.hypot(p.x() - 45, p.z() - 40) < 30 && p.y() < 108) return "magma";
        if (Math.hypot(p.x() + 72, p.z() - 15) < 30 && p.y() < 108) return "river";
        return "exploration";
    }

    private static TrackVec3 local(TrackVec3 anchor, TrackFrame frame, double x, double y, double z) {
        return anchor.add(frame.right().scale(x)).add(frame.up().scale(y)).add(frame.forward().scale(z));
    }

    private static double square(double value) { return value * value; }

    public record LightProbe(double distance, int seat, BlockPos position, int minimumBrightness, String zone) { }

    private static final class Planner {
        final LinkedHashMap<BlockPos, BlockState> blocks = new LinkedHashMap<>();
        final Set<BlockPos> protectedCells;
        final boolean volcanicBounds;

        Planner(Set<BlockPos> protectedCells, boolean volcanicBounds) {
            this.protectedCells = Objects.requireNonNull(protectedCells, "protectedCells");
            this.volcanicBounds = volcanicBounds;
        }

        void light(TrackVec3 p, int level) {
            put(BlockPos.containing(p.x(), p.y(), p.z()),
                    Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, level));
        }

        void put(BlockPos position, BlockState state) {
            if (protectedCells.contains(position) || position.getY() < -64 || position.getY() >= 320
                    || Math.abs((long) position.getX()) > 29_999_000 || Math.abs((long) position.getZ()) > 29_999_000) return;
            if (volcanicBounds && (position.getX() < -145 || position.getX() > 145
                    || position.getZ() < -165 || position.getZ() > 145
                    || position.getY() < 64 || position.getY() > 180)) return;
            BlockState previous = blocks.get(position);
            if (state.is(Blocks.LIGHT) && previous != null) {
                if (!previous.is(Blocks.LIGHT) || previous.getValue(LightBlock.LEVEL) >= state.getValue(LightBlock.LEVEL)) return;
            }
            blocks.put(position.immutable(), state);
        }
    }
}
