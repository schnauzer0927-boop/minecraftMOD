package dev.coasterengineering.track;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * Interpolating 3D Catmull-Rom track with an arc-length lookup table.
 * Distance and speed always use blocks and blocks/tick, not control-point indices.
 * Closed paths omit a duplicated final point; the last point connects to the first.
 */
public final class SplineTrack {
    private static final int SAMPLES_PER_SEGMENT = 128;
    private static final double MIN_POINT_DISTANCE = 1e-6;
    private final List<ControlPoint> points;
    private final boolean closed;
    private final int segmentCount;
    private final double[] distances;
    private final double length;

    public SplineTrack(List<ControlPoint> points, boolean closed) {
        Objects.requireNonNull(points, "points");
        if (points.size() < (closed ? 4 : 2)) {
            throw new IllegalArgumentException(closed ? "Closed tracks need at least four points"
                    : "Open tracks need at least two points");
        }
        // Limit untrusted saved/network data before allocating the lookup table.
        if (points.size() > 4096) throw new IllegalArgumentException("Track has too many points");
        this.points = List.copyOf(points);
        this.closed = closed;
        this.segmentCount = closed ? points.size() : points.size() - 1;
        for (int i = 0; i < segmentCount; i++) {
            if (point(i).position().subtract(point(i + 1).position()).length() < MIN_POINT_DISTANCE) {
                throw new IllegalArgumentException("Adjacent track points must be distinct");
            }
        }
        this.distances = new double[segmentCount * SAMPLES_PER_SEGMENT + 1];
        TrackVec3 previous = evaluate(0, 0);
        double accumulated = 0;
        for (int i = 1; i < distances.length; i++) {
            double parameter = (double) i / SAMPLES_PER_SEGMENT;
            int segment = Math.min((int) parameter, segmentCount - 1);
            double t = parameter - segment;
            TrackVec3 next = evaluate(segment, t);
            if (derivative(segment, t).length() < 1e-8) {
                throw new IllegalArgumentException("Track contains a stationary tangent or cusp");
            }
            double interval = next.subtract(previous).length();
            if (interval <= 0) throw new IllegalArgumentException("Track contains a degenerate interval");
            accumulated += interval;
            if (!Double.isFinite(accumulated)) throw new IllegalArgumentException("Track length overflow");
            distances[i] = accumulated;
            previous = next;
        }
        if (derivative(0, 0).length() < 1e-8 || accumulated < MIN_POINT_DISTANCE) {
            throw new IllegalArgumentException("Track has no usable direction or length");
        }
        this.length = accumulated;
    }

    public List<ControlPoint> points() { return points; }
    public boolean closed() { return closed; }
    public double length() { return length; }

    /** Exact existing arc-table distance at a control point; does not change geometry. */
    public double controlPointDistance(int index) {
        if (index < 0 || index >= points.size()) {
            throw new IllegalArgumentException("Control point index is outside the track");
        }
        return distances[index * SAMPLES_PER_SEGMENT];
    }

    public TrackSample sample(double distance) {
        double bounded = normalizeDistance(distance);
        int upper = Arrays.binarySearch(distances, bounded);
        double parameter;
        if (upper >= 0) {
            parameter = (double) upper / SAMPLES_PER_SEGMENT;
        } else {
            upper = -upper - 1;
            int lower = Math.max(0, upper - 1);
            upper = Math.min(upper, distances.length - 1);
            double span = distances[upper] - distances[lower];
            double fraction = span > 0 ? (bounded - distances[lower]) / span : 0;
            parameter = (lower + fraction) / SAMPLES_PER_SEGMENT;
        }
        int segment = Math.min((int) parameter, segmentCount - 1);
        double t = parameter - segment;
        ControlPoint from = point(segment);
        ControlPoint to = point(segment + 1);
        TrackVec3 tangent = derivative(segment, t);
        if (tangent.length() < 1e-8) throw new IllegalArgumentException("Track sample has no direction");
        double bank = normalizeDegrees(normalizeDegrees(from.bankDegrees())
                + shortestBankDelta(from.bankDegrees(), to.bankDegrees()) * t);
        ControlPoint metadata = !closed && segment == segmentCount - 1 && t >= 1 ? to : from;
        return new TrackSample(evaluate(segment, t), tangent.normalized(), bank,
                metadata.kind(), metadata.targetSpeed());
    }

    /** Wrap a closed course and clamp an open course, rejecting corrupt distances. */
    public double normalizeDistance(double distance) {
        if (!Double.isFinite(distance)) throw new IllegalArgumentException("Distance must be finite");
        if (!closed) return Math.max(0, Math.min(length, distance));
        double wrapped = distance % length;
        return wrapped < 0 ? wrapped + length : wrapped;
    }

    private ControlPoint point(int index) {
        if (closed) return points.get(Math.floorMod(index, points.size()));
        return points.get(Math.max(0, Math.min(points.size() - 1, index)));
    }

    private TrackVec3 position(int index) {
        if (closed || (index >= 0 && index < points.size())) return point(index).position();
        // Extrapolate open endpoints: a two-point track becomes an exact straight line.
        if (index < 0) return point(0).position().scale(2).subtract(point(1).position());
        int last = points.size() - 1;
        return point(last).position().scale(2).subtract(point(last - 1).position());
    }

    private TrackVec3 evaluate(int segment, double t) {
        TrackVec3 p0 = position(segment - 1), p1 = position(segment);
        TrackVec3 p2 = position(segment + 1), p3 = position(segment + 2);
        return new TrackVec3(cubic(p0.x(), p1.x(), p2.x(), p3.x(), t),
                cubic(p0.y(), p1.y(), p2.y(), p3.y(), t),
                cubic(p0.z(), p1.z(), p2.z(), p3.z(), t));
    }

    private TrackVec3 derivative(int segment, double t) {
        TrackVec3 p0 = position(segment - 1), p1 = position(segment);
        TrackVec3 p2 = position(segment + 1), p3 = position(segment + 2);
        return new TrackVec3(cubicDerivative(p0.x(), p1.x(), p2.x(), p3.x(), t),
                cubicDerivative(p0.y(), p1.y(), p2.y(), p3.y(), t),
                cubicDerivative(p0.z(), p1.z(), p2.z(), p3.z(), t));
    }

    private static double cubic(double p0, double p1, double p2, double p3, double t) {
        double a = -p0 + 3 * p1 - 3 * p2 + p3;
        double b = 2 * p0 - 5 * p1 + 4 * p2 - p3;
        double c = -p0 + p2;
        return 0.5 * (((a * t + b) * t + c) * t + 2 * p1);
    }

    private static double cubicDerivative(double p0, double p1, double p2, double p3, double t) {
        double a = -p0 + 3 * p1 - 3 * p2 + p3;
        double b = 2 * p0 - 5 * p1 + 4 * p2 - p3;
        return 0.5 * ((3 * a * t + 2 * b) * t - p0 + p2);
    }

    private static double shortestBankDelta(double from, double to) {
        return normalizeDegrees(normalizeDegrees(to) - normalizeDegrees(from));
    }

    private static double normalizeDegrees(double value) {
        double wrapped = value % 360;
        if (wrapped >= 180) wrapped -= 360;
        if (wrapped < -180) wrapped += 360;
        return wrapped;
    }
}
