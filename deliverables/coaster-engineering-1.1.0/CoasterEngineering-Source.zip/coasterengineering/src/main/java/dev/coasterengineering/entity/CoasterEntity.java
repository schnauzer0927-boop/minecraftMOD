package dev.coasterengineering.entity;

import dev.coasterengineering.CoasterConfig;
import dev.coasterengineering.track.RideDynamics;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.track.TrainSpacing;
import dev.coasterengineering.track.VolcanicCourseDesign;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import dev.coasterengineering.world.VolcanicWorldBuilder;
import dev.coasterengineering.world.WorldQualityUpgradeData;
import dev.coasterengineering.world.WorldQualityUpgradeService;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.RelativeMovement;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.common.util.ITeleporter;

import java.util.Optional;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * A purpose-built, two-seat coaster. The server owns its distance on the spline;
 * vanilla block movement and gravity never choose its trajectory.
 */
public final class CoasterEntity extends Entity {
    public static final double MAX_SPEED = 120.0 / 72.0;
    public static final int SEATS = 2;
    private static final double PATH_CHECK_SPACING = 0.40;
    private static final EntityDataAccessor<Optional<UUID>> COURSE =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Float> DISTANCE =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> SPEED =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> BANK =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> RUNNING =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> LAPS =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Optional<UUID>> LEADER =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Integer> CAR_INDEX =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> CAR_COUNT =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> SPACING =
            SynchedEntityData.defineId(CoasterEntity.class, EntityDataSerializers.FLOAT);

    private double distance;
    private double speed;
    private float previousBank;
    private float renderBank;
    private double previousSpeed;
    private double renderSpeed;
    private int lerpSteps;
    private double lerpX;
    private double lerpY;
    private double lerpZ;
    private float lerpYaw;
    private float lerpPitch;
    private BlockPos lastSafeExit;
    private final List<UUID> followers = new ArrayList<>();

    public CoasterEntity(EntityType<? extends CoasterEntity> type, Level level) {
        super(type, level);
        setNoGravity(true);
        noPhysics = true;
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(COURSE, Optional.empty());
        entityData.define(DISTANCE, 0.0F);
        entityData.define(SPEED, 0.0F);
        entityData.define(BANK, 0.0F);
        entityData.define(RUNNING, false);
        entityData.define(LAPS, 0);
        entityData.define(LEADER, Optional.empty());
        entityData.define(CAR_INDEX, 0);
        entityData.define(CAR_COUNT, 1);
        entityData.define(SPACING, (float) TrainSpacing.DEFAULT_SPACING);
    }

    public void setCourse(UUID id) {
        UUID previous = courseId();
        if (previous != null && !previous.equals(id) && level() instanceof ServerLevel server) {
            if (isVehicle()) ejectPassengers();
            if (isTrainLeader()) CoasterSavedData.get(server).releaseVehicle(previous, getUUID());
        }
        emergencyStop();
        distance = 0.0;
        entityData.set(DISTANCE, 0.0F);
        entityData.set(COURSE, Optional.ofNullable(id));
        lastSafeExit = null;
    }

    public UUID courseId() { return entityData.get(COURSE).orElse(null); }
    public double getDistance() { return level().isClientSide ? entityData.get(DISTANCE) : distance; }
    public double getSpeed() { return level().isClientSide ? entityData.get(SPEED) : speed; }
    public float getBank() { return entityData.get(BANK); }
    public int getLaps() { return entityData.get(LAPS); }
    public boolean isRunning() { return entityData.get(RUNNING); }
    public boolean hasFreeSeat() { return getPassengers().size() < SEATS; }
    public boolean isTrainLeader() { return leaderId() == null; }
    public UUID leaderId() { return entityData.get(LEADER).orElse(null); }
    public int carIndex() { return entityData.get(CAR_INDEX); }
    public int carCount() { return entityData.get(CAR_COUNT); }
    public double carSpacing() { return entityData.get(SPACING); }
    public List<UUID> followerIds() { return List.copyOf(followers); }

    public CoasterEntity resolveLeader() {
        if (isTrainLeader()) return this;
        if (!(level() instanceof ServerLevel server)) return null;
        Entity candidate = server.getEntity(leaderId());
        return candidate instanceof CoasterEntity leader && leader.isTrainLeader()
                && java.util.Objects.equals(leader.courseId(), courseId()) ? leader : null;
    }

    /** Empty means a persisted member is missing; never replace it automatically. */
    public List<CoasterEntity> getLoadedFormation() {
        CoasterEntity leader = resolveLeader();
        if (leader == null) return List.of();
        if (leader != this) return leader.getLoadedFormation();
        if (!(level() instanceof ServerLevel server)) return List.of(this);
        ArrayList<CoasterEntity> cars = new ArrayList<>();
        cars.add(this);
        for (int i = 0; i < followers.size(); i++) {
            Entity entity = server.getEntity(followers.get(i));
            if (!(entity instanceof CoasterEntity car) || car.isRemoved()
                    || !getUUID().equals(car.leaderId()) || car.carIndex() != i + 1
                    || !java.util.Objects.equals(courseId(), car.courseId())) return List.of();
            cars.add(car);
        }
        return List.copyOf(cars);
    }

    /** Service-side validation before any old or new train entities are changed. */
    public boolean canReplaceFollowers(List<CoasterEntity> replacement) {
        if (!(level() instanceof ServerLevel server) || !isTrainLeader() || isRunning()
                || replacement.size() >= TrainSpacing.MAX_CARS) return false;
        List<CoasterEntity> existing = getLoadedFormation();
        if (existing.isEmpty() || existing.stream().anyMatch(Entity::isVehicle)) return false;
        Course course = resolveCourse(server);
        if (course == null || (!replacement.isEmpty() && (!course.track().closed()
                || course.track().length() <= replacement.size() * TrainSpacing.DEFAULT_SPACING + 3.0))) return false;
        if (!sampleIsLoadedAndSafe(server, course.track().sample(distance))) return false;
        for (int i = 0; i < replacement.size(); i++) {
            CoasterEntity car = replacement.get(i);
            if (car.level() != server || car.isVehicle() || car.isRunning()
                    || !car.sampleIsLoadedAndSafe(server, course.track().sample(
                        TrainSpacing.distance(course.track(), distance, i + 1, TrainSpacing.DEFAULT_SPACING)))) return false;
        }
        return true;
    }

    /** Called only by TrainService after all candidate poses have been validated. */
    public void initializeFollower(CoasterEntity leader, int index) {
        if (index < 1 || index >= TrainSpacing.MAX_CARS || !leader.isTrainLeader())
            throw new IllegalArgumentException("Invalid train leader or car index");
        setCourse(leader.courseId());
        entityData.set(LEADER, Optional.of(leader.getUUID()));
        entityData.set(CAR_INDEX, index);
        entityData.set(CAR_COUNT, leader.carCount());
        entityData.set(SPACING, (float) leader.carSpacing());
        followers.clear();
        if (level() instanceof ServerLevel server) {
            Course course = leader.resolveCourse(server);
            if (course == null) throw new IllegalArgumentException("Missing train course");
            distance = TrainSpacing.distance(course.track(), leader.distance, index, TrainSpacing.DEFAULT_SPACING);
            applyPose(course.track().sample(distance));
            entityData.set(DISTANCE, (float) distance);
            lastSafeExit = leader.lastSafeExit;
        }
        stopLocal();
    }

    public void commitFollowers(List<CoasterEntity> replacement) {
        if (!isTrainLeader() || !(level() instanceof ServerLevel server))
            throw new IllegalStateException("Only the server leader can commit a formation");
        followers.clear();
        for (CoasterEntity car : replacement) followers.add(car.getUUID());
        entityData.set(CAR_COUNT, 1 + followers.size());
        Course course = resolveCourse(server);
        if (course == null) throw new IllegalStateException("Missing train course");
        ArrayList<CoasterEntity> cars = new ArrayList<>();
        cars.add(this);
        cars.addAll(replacement);
        applyFormation(cars, course.track(), distance, 0.0, false);
    }

    public float interpolatedBank(float partialTick) {
        return Mth.rotLerp(partialTick, previousBank, level().isClientSide ? renderBank : getBank());
    }

    public double interpolatedSpeed(float partialTick) {
        return Mth.lerp((double) partialTick, previousSpeed, level().isClientSide ? renderSpeed : speed);
    }

    /** Called after placing a cart; never forces an unloaded chunk to load. */
    public boolean resetToStation() {
        if (!(level() instanceof ServerLevel server)) return false;
        CoasterEntity leader = resolveLeader();
        if (leader == null) return false;
        if (leader != this) return leader.resetToStation();
        Course course = resolveCourse(server);
        if (course == null) return false;
        List<CoasterEntity> cars = getLoadedFormation();
        if (cars.isEmpty() || !formationFitsTrack(cars, course.track())
                || !formationIsSafe(server, cars, course.track(), 0.0)) return false;
        if (!CoasterSavedData.get(server).claimVehicle(course.id(), getUUID())) return false;
        emergencyStop();
        applyFormation(cars, course.track(), 0.0, 0.0, false);
        Vec3 exit = findExitNear(course.station(), null, 4, 5);
        if (exit != null) lastSafeExit = BlockPos.containing(exit);
        return true;
    }

    /** Dispatch or resume. A complete lap parks exactly at the first control point. */
    public boolean startRide() {
        if (!(level() instanceof ServerLevel server)) return false;
        if (WorldQualityUpgradeService.isActive(server, courseId())) return false;
        CoasterEntity leader = resolveLeader();
        if (leader == null) return false;
        if (leader != this) return leader.startRide();
        Course course = resolveCourse(server);
        if (course == null || !course.enabled() || CoasterSavedData.get(server).isEmergency(course.id())
                || course.track().length() < 2.0) return false;
        double nextDistance = course.track().closed() ? distance % course.track().length()
                : Math.min(distance, course.track().length());
        List<CoasterEntity> cars = getLoadedFormation();
        if (cars.isEmpty() || !formationFitsTrack(cars, course.track())
                || !formationIsSafe(server, cars, course.track(), nextDistance)) return false;
        if (!CoasterSavedData.get(server).claimVehicle(course.id(), getUUID())) return false;
        applyFormation(cars, course.track(), nextDistance, 0.0, true);
        return true;
    }

    /** Idempotent safety stop; preserves the last valid distance and position. */
    public void emergencyStop() {
        CoasterEntity leader = resolveLeader();
        if (leader != null && leader != this) {
            leader.emergencyStop();
            return;
        }
        stopLocal();
        if (isTrainLeader() && level() instanceof ServerLevel server) {
            for (UUID id : followers) {
                Entity entity = server.getEntity(id);
                if (entity instanceof CoasterEntity car && getUUID().equals(car.leaderId())) car.stopLocal();
            }
        }
    }

    private void stopLocal() {
        speed = 0.0;
        entityData.set(SPEED, 0.0F);
        entityData.set(RUNNING, false);
        setDeltaMovement(Vec3.ZERO);
    }

    @Override
    public void tick() {
        xo = getX();
        yo = getY();
        zo = getZ();
        yRotO = getYRot();
        xRotO = getXRot();
        previousBank = level().isClientSide ? renderBank : getBank();
        previousSpeed = level().isClientSide ? renderSpeed : speed;
        super.tick();
        setNoGravity(true);
        noPhysics = true;
        setDeltaMovement(Vec3.ZERO);
        fallDistance = 0;
        if (level().isClientSide) {
            interpolateClient();
            renderBank = Mth.rotLerp(0.45F, renderBank, getBank());
            renderSpeed = Mth.lerp(0.45, renderSpeed, getSpeed());
        } else if (level() instanceof ServerLevel server) {
            tickServer(server);
        }
        updateCartBounds();
    }

    private void tickServer(ServerLevel server) {
        if (!isTrainLeader()) {
            UUID reservedLeader = CoasterSavedData.get(server).vehicleId(courseId());
            if (!java.util.Objects.equals(reservedLeader, leaderId())) {
                stopLocal();
                ejectPassengers();
                discard();
                return;
            }
            CoasterEntity leader = resolveLeader();
            if (leader == null || !leader.followers.contains(getUUID())) stopLocal();
            return;
        }
        Course course = resolveCourse(server);
        if (course == null) {
            emergencyStop();
            return;
        }
        if (!CoasterSavedData.get(server).claimVehicle(course.id(), getUUID())) {
            emergencyStop();
            ejectPassengers();
            discard();
            return;
        }
        if (!course.enabled() || CoasterSavedData.get(server).isEmergency(course.id())) {
            emergencyStop();
            return;
        }
        SplineTrack track = course.track();
        List<CoasterEntity> cars = getLoadedFormation();
        if (cars.isEmpty() || !formationFitsTrack(cars, track)) {
            emergencyStop();
            return;
        }
        if (!isRunning()) {
            for (CoasterEntity car : cars) {
                if (!car.poseIsLoadedAndClear(server, car.position(), car.orientationBasis(), null) && car.isVehicle()) {
                    emergencyStop();
                    car.ejectPassengers();
                }
            }
            return;
        }
        try {
            double maxSpeed = Math.min(MAX_SPEED, CoasterConfig.MAX_SPEED_KMH.get() / 72.0);
            VolcanicCourseDesign.Profile profile = VolcanicWorldBuilder.COURSE_ID.equals(course.id())
                    && WorldQualityUpgradeData.get(server).isApplied(course.id())
                    ? VolcanicCourseDesign.profileOfSavedTargets(track) : null;
            RideDynamics.Step step = profile == null
                    ? RideDynamics.advance(track, distance, speed, true, maxSpeed, CoasterConfig.MAX_ACCELERATION.get())
                    : RideDynamics.advanceProfiled(track, distance, speed, true, maxSpeed,
                            CoasterConfig.MAX_ACCELERATION.get(), profile);
            // Check the entire travelled arc, including the wrap to the station. A
            // fast cart cannot skip an unloaded chunk between its two tick poses.
            double travel = step.crossedFinish() && track.closed()
                    ? track.length() - distance + step.distance() : step.distance() - distance;
            if (!Double.isFinite(travel) || travel < -1.0E-7 || travel > maxSpeed + 0.1) {
                emergencyStop();
                return;
            }
            int checks = Math.max(1, (int) Math.ceil(travel / PATH_CHECK_SPACING));
            for (int i = 0; i <= checks; i++) {
                if (!formationIsSafe(server, cars, track, distance + travel * i / checks)) {
                    emergencyStop();
                    return;
                }
            }
            double nextDistance = step.crossedFinish() && track.closed() ? 0.0 : step.distance();
            if (!formationIsSafe(server, cars, track, nextDistance)) {
                emergencyStop();
                return;
            }
            if (step.crossedFinish()) {
                entityData.set(LAPS, (int) Math.min(Integer.MAX_VALUE, (long) getLaps() + 1L));
            }
            boolean running = !step.crossedFinish() && !step.stopped();
            applyFormation(cars, track, nextDistance, running ? step.speed() : 0.0, running);
        } catch (IllegalArgumentException | IllegalStateException invalidTrack) {
            // Corrupt persisted geometry or invalid physics cannot move a rider.
            emergencyStop();
        }
    }

    private Course resolveCourse(ServerLevel server) {
        UUID id = courseId();
        return id == null ? null : CoasterSavedData.get(server).getCourse(id);
    }

    private boolean formationIsSafe(ServerLevel server, List<CoasterEntity> cars, SplineTrack track,
                                    double leaderDistance) {
        for (int i = 0; i < cars.size(); i++) {
            double carDistance = TrainSpacing.distance(track, leaderDistance, i, TrainSpacing.DEFAULT_SPACING);
            if (!cars.get(i).sampleIsLoadedAndSafe(server, track.sample(carDistance))) return false;
        }
        return true;
    }

    /** Read-only geometry check for editor previews and build planning. */
    public boolean canUseTrackSample(TrackSample sample) {
        return sample != null && level() instanceof ServerLevel server
                && sampleIsLoadedAndSafe(server, sample);
    }

    /** Checks proposed geometry without replacing SavedData or moving any entity. */
    public boolean canPlaceFormationOnTrack(SplineTrack track, double leaderDistance) {
        if (track == null || !Double.isFinite(leaderDistance)) return false;
        CoasterEntity leader = resolveLeader();
        if (leader == null || !(leader.level() instanceof ServerLevel server)) return false;
        List<CoasterEntity> cars = leader.getLoadedFormation();
        return !cars.isEmpty() && formationFitsTrack(cars, track)
                && leader.formationIsSafe(server, cars, track, leaderDistance);
    }

    private static boolean formationFitsTrack(List<CoasterEntity> cars, SplineTrack track) {
        return cars.size() <= 1 || (track.closed()
                && track.length() > (cars.size() - 1) * TrainSpacing.DEFAULT_SPACING + 3.0);
    }

    /** Server tick order cannot alter spacing: followers are committed here together. */
    private void applyFormation(List<CoasterEntity> cars, SplineTrack track, double leaderDistance,
                                double nextSpeed, boolean running) {
        int laps = getLaps();
        for (int i = 0; i < cars.size(); i++) {
            CoasterEntity car = cars.get(i);
            car.distance = TrainSpacing.distance(track, leaderDistance, i, TrainSpacing.DEFAULT_SPACING);
            car.speed = nextSpeed;
            car.applyPose(track.sample(car.distance));
            car.entityData.set(DISTANCE, (float) car.distance);
            car.entityData.set(SPEED, (float) nextSpeed);
            car.entityData.set(RUNNING, running);
            car.entityData.set(LAPS, laps);
            car.entityData.set(CAR_COUNT, cars.size());
            car.entityData.set(SPACING, (float) TrainSpacing.DEFAULT_SPACING);
            for (Entity passenger : car.getPassengers()) car.positionRider(passenger);
        }
    }

    private boolean sampleIsLoadedAndSafe(ServerLevel server, TrackSample sample) {
        TrackVec3 p = sample.position();
        TrackVec3 tangent = sample.tangent();
        if (!Double.isFinite(p.x()) || !Double.isFinite(p.y()) || !Double.isFinite(p.z())
                || !Double.isFinite(tangent.x()) || !Double.isFinite(tangent.y())
                || !Double.isFinite(tangent.z()) || !Double.isFinite(sample.bankDegrees())) return false;
        double yaw = Math.atan2(-tangent.x(), tangent.z());
        double pitch = -Math.atan2(tangent.y(), Math.hypot(tangent.x(), tangent.z()));
        Vec3[] basis = orientationBasis(yaw, pitch, Math.toRadians(sample.bankDegrees()));
        return poseIsLoadedAndClear(server, new Vec3(p.x(), p.y(), p.z()), basis, null);
    }

    private boolean poseIsLoadedAndClear(ServerLevel server, Vec3 anchor, Vec3[] basis, Entity boarding) {
        if (!boxIsLoadedAndClear(server, cartBounds(anchor, basis))) return false;
        for (int seat = 0; seat < SEATS; seat++) {
            Vec3 feet = seatPosition(anchor, basis, seat);
            // Preserve player headroom even before anybody boards the cart.
            AABB riderSpace = new AABB(feet.x - 0.30, feet.y, feet.z - 0.30,
                    feet.x + 0.30, feet.y + 1.80, feet.z + 0.30);
            if (!boxIsLoadedAndClear(server, riderSpace)) return false;
            if (seat < getPassengers().size()) {
                Entity passenger = getPassengers().get(seat);
                AABB actualBody = passenger.getBoundingBox().move(feet.subtract(passenger.position()));
                if (!boxIsLoadedAndClear(server, actualBody)) return false;
            } else if (boarding != null && seat == getPassengers().size()) {
                AABB boardingBody = boarding.getBoundingBox().move(feet.subtract(boarding.position()));
                if (!boxIsLoadedAndClear(server, boardingBody)) return false;
            }
        }
        return true;
    }

    private boolean boxIsLoadedAndClear(ServerLevel server, AABB box) {
        if (box.minY < server.getMinBuildHeight() || box.maxY > server.getMaxBuildHeight()) return false;
        int minX = Mth.floor(box.minX), minY = Mth.floor(box.minY), minZ = Mth.floor(box.minZ);
        int maxX = Mth.floor(box.maxX - 1.0E-7), maxY = Mth.floor(box.maxY - 1.0E-7);
        int maxZ = Mth.floor(box.maxZ - 1.0E-7);
        if (!server.getWorldBorder().isWithinBounds(new BlockPos(minX, minY, minZ))
                || !server.getWorldBorder().isWithinBounds(new BlockPos(maxX, maxY, maxZ))) return false;
        for (int chunkX = minX >> 4; chunkX <= (maxX >> 4); chunkX++) {
            for (int chunkZ = minZ >> 4; chunkZ <= (maxZ >> 4); chunkZ++) {
                if (!server.hasChunkAt(new BlockPos(chunkX << 4, minY, chunkZ << 4))) return false;
            }
        }
        // Block-only collision ignores this cart and its passengers, but keeps
        // normal voxel shapes and suffocation hazards fully authoritative.
        for (var shape : server.getBlockCollisions(this, box)) {
            if (!shape.isEmpty()) return false;
        }
        for (BlockPos block : BlockPos.betweenClosed(minX, minY, minZ, maxX, maxY, maxZ)) {
            if (!server.getFluidState(block).isEmpty()) return false;
            BlockState state = server.getBlockState(block);
            if (state.is(Blocks.FIRE) || state.is(Blocks.SOUL_FIRE)
                    || state.is(Blocks.SWEET_BERRY_BUSH)) return false;
        }
        return true;
    }

    private void applyPose(TrackSample sample) {
        TrackVec3 p = sample.position();
        TrackVec3 tangent = sample.tangent();
        setPos(p.x(), p.y(), p.z());
        setYRot((float) Math.toDegrees(Math.atan2(-tangent.x(), tangent.z())));
        setXRot((float) -Math.toDegrees(Math.atan2(tangent.y(), Math.hypot(tangent.x(), tangent.z()))));
        entityData.set(BANK, Mth.wrapDegrees((float) sample.bankDegrees()));
        updateCartBounds();
    }

    @Override
    public void lerpTo(double x, double y, double z, float yaw, float pitch, int steps, boolean teleport) {
        if (teleport || distanceToSqr(x, y, z) > 256.0) {
            setPos(x, y, z);
            setYRot(yaw);
            setXRot(pitch);
            xo = x;
            yo = y;
            zo = z;
            yRotO = yaw;
            xRotO = pitch;
            lerpSteps = 0;
            updateCartBounds();
            return;
        }
        lerpX = x;
        lerpY = y;
        lerpZ = z;
        lerpYaw = yaw;
        lerpPitch = pitch;
        lerpSteps = Math.max(2, Math.min(8, steps));
    }

    private void interpolateClient() {
        if (lerpSteps <= 0) return;
        double fraction = 1.0 / lerpSteps;
        setPos(Mth.lerp(fraction, getX(), lerpX), Mth.lerp(fraction, getY(), lerpY),
                Mth.lerp(fraction, getZ(), lerpZ));
        setYRot(getYRot() + Mth.wrapDegrees(lerpYaw - getYRot()) / lerpSteps);
        setXRot(getXRot() + (lerpPitch - getXRot()) / lerpSteps);
        lerpSteps--;
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (player.isShiftKeyDown() || isRunning() || !hasFreeSeat()) return InteractionResult.PASS;
        if (level().isClientSide) return InteractionResult.SUCCESS;
        return player.startRiding(this) ? InteractionResult.CONSUME : InteractionResult.PASS;
    }

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        if (!(passenger instanceof LivingEntity) || isRunning() || !hasFreeSeat()) return false;
        if (level() instanceof ServerLevel server && WorldQualityUpgradeService.isActive(server, courseId())) return false;
        if (!isTrainLeader() && level() instanceof ServerLevel server
                && (!java.util.Objects.equals(CoasterSavedData.get(server).vehicleId(courseId()), leaderId())
                    || resolveLeader() == null)) return false;
        return !(level() instanceof ServerLevel server)
                || poseIsLoadedAndClear(server, position(), orientationBasis(), passenger);
    }

    @Override
    protected void positionRider(Entity passenger, Entity.MoveFunction move) {
        if (!hasPassenger(passenger)) return;
        int seat = getPassengers().indexOf(passenger);
        Vec3[] basis = orientationBasis();
        Vec3 seatPosition = seatPosition(position(), basis, seat);
        move.accept(passenger, seatPosition.x, seatPosition.y, seatPosition.z);
        passenger.fallDistance = 0;
        passenger.setDeltaMovement(Vec3.ZERO);
    }

    @Override
    public double getPassengersRidingOffset() { return 0.45; }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        if (level() instanceof ServerLevel server) {
            if (isRunning()) emergencyStop();
            Course course = resolveCourse(server);
            // Emergency dismounts use the station, even while far from it. Never
            // leave a player suspended over the lava beneath an elevated track.
            if (course != null) {
                // Loading the landing chunk is confined to a player's explicit
                // dismount. Normal rail traversal never loads missing chunks.
                if (!server.hasChunkAt(course.station())) server.getChunkAt(course.station());
                Vec3 stationExit = findExitNear(course.station(), passenger, 5, 8);
                if (stationExit != null) return stationExit;
            }
            if (lastSafeExit != null) {
                Vec3 savedExit = findExitNear(lastSafeExit, passenger, 2, 3);
                if (savedExit != null) return savedExit;
            }
            Vec3 nearby = findExitNear(blockPosition(), passenger, 5, 24);
            if (nearby != null) return nearby;
            Vec3 spawn = findExitNear(server.getSharedSpawnPos(), passenger, 6, 16);
            if (spawn != null) return spawn;
        }
        // Missing geometry or a completely unloaded world still cannot impart
        // the coaster's speed or a fall-damage accumulator to the passenger.
        passenger.fallDistance = 0;
        passenger.setDeltaMovement(Vec3.ZERO);
        return position().add(0.0, 1.25, 0.0);
    }

    private Vec3 findExitNear(BlockPos origin, LivingEntity passenger, int radius, int vertical) {
        for (int ring = 0; ring <= radius; ring++) {
            for (int dy = 0; dy <= vertical; dy++) {
                int[] offsetsY = dy == 0 ? new int[] {0} : new int[] {dy, -dy};
                for (int offsetY : offsetsY) {
                    for (int dx = -ring; dx <= ring; dx++) {
                        for (int dz = -ring; dz <= ring; dz++) {
                            if (Math.max(Math.abs(dx), Math.abs(dz)) != ring) continue;
                            BlockPos feet = origin.offset(dx, offsetY, dz);
                            if (!level().hasChunkAt(feet) || feet.getY() <= level().getMinBuildHeight()
                                    || feet.getY() + 2 >= level().getMaxBuildHeight()) continue;
                            BlockState floor = level().getBlockState(feet.below());
                            if (!floor.isFaceSturdy(level(), feet.below(), Direction.UP)
                                    || floor.is(Blocks.MAGMA_BLOCK) || floor.is(Blocks.CAMPFIRE)
                                    || floor.is(Blocks.SOUL_CAMPFIRE)
                                    || !level().getFluidState(feet).isEmpty()
                                    || !level().getFluidState(feet.above()).isEmpty()
                                    || !level().getFluidState(feet.below()).isEmpty()) continue;
                            Vec3 candidate = new Vec3(feet.getX() + 0.5, feet.getY(), feet.getZ() + 0.5);
                            AABB body = passenger == null
                                    ? new AABB(candidate.x - 0.35, candidate.y, candidate.z - 0.35,
                                        candidate.x + 0.35, candidate.y + 1.9, candidate.z + 0.35)
                                    : passenger.getBoundingBox().move(candidate.subtract(passenger.position()));
                            if (level().noCollision(passenger, body)) return candidate;
                        }
                    }
                }
            }
        }
        return null;
    }

    /** right, up and forward match the original model's local axes. */
    private Vec3[] orientationBasis() {
        double yaw = Math.toRadians(getYRot());
        double pitch = Math.toRadians(getXRot());
        double bank = Math.toRadians(level().isClientSide ? renderBank : getBank());
        return orientationBasis(yaw, pitch, bank);
    }

    private static Vec3[] orientationBasis(double yaw, double pitch, double bank) {
        Vec3 forward = new Vec3(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch),
                Math.cos(yaw) * Math.cos(pitch));
        Vec3 right = new Vec3(Math.cos(yaw), 0.0, Math.sin(yaw));
        Vec3 up = forward.cross(right);
        return new Vec3[] {right.scale(Math.cos(bank)).add(up.scale(Math.sin(bank))),
                up.scale(Math.cos(bank)).subtract(right.scale(Math.sin(bank))), forward};
    }

    private void updateCartBounds() {
        Vec3[] basis = orientationBasis();
        setBoundingBox(cartBounds(position(), basis));
    }

    private static Vec3 seatPosition(Vec3 anchor, Vec3[] basis, int seat) {
        return anchor.add(basis[0].scale(seat == 0 ? -0.45 : 0.45)).add(basis[1].scale(0.45));
    }

    private static AABB cartBounds(Vec3 anchor, Vec3[] basis) {
        double minX = Double.POSITIVE_INFINITY, minY = Double.POSITIVE_INFINITY, minZ = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY, maxY = Double.NEGATIVE_INFINITY, maxZ = Double.NEGATIVE_INFINITY;
        for (double x : new double[] {-0.9, 0.9}) {
            for (double y : new double[] {-0.05, 1.2}) {
                for (double z : new double[] {-1.5, 1.5}) {
                    Vec3 corner = anchor.add(basis[0].scale(x)).add(basis[1].scale(y)).add(basis[2].scale(z));
                    minX = Math.min(minX, corner.x); minY = Math.min(minY, corner.y); minZ = Math.min(minZ, corner.z);
                    maxX = Math.max(maxX, corner.x); maxY = Math.max(maxY, corner.y); maxZ = Math.max(maxZ, corner.z);
                }
            }
        }
        return new AABB(minX, minY, minZ, maxX, maxY, maxZ);
    }

    @Override
    public boolean isPickable() { return !isRemoved(); }

    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean canChangeDimensions() { return false; }

    @Override
    public Entity changeDimension(ServerLevel destination) {
        return destination == level() ? this : null;
    }

    @Override
    public Entity changeDimension(ServerLevel destination, ITeleporter teleporter) {
        return destination == level() ? this : null;
    }

    @Override
    public boolean teleportTo(ServerLevel destination, double x, double y, double z,
                              Set<RelativeMovement> relative, float yaw, float pitch) {
        if (destination != level()) return false;
        emergencyStop();
        return super.teleportTo(destination, x, y, z, relative, yaw, pitch);
    }

    @Override
    public boolean canBeCollidedWith() { return !isRemoved(); }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRunning() || !(source.getEntity() instanceof Player player)
                || !player.isCreative()) return false;
        emergencyStop();
        ejectPassengers();
        discard();
        return true;
    }

    @Override
    public void remove(RemovalReason reason) {
        if (reason.shouldDestroy() && level() instanceof ServerLevel server
                && (server.getEntity(getUUID()) == null || server.getEntity(getUUID()) == this)) {
            if (isTrainLeader()) {
                emergencyStop();
                for (UUID id : List.copyOf(followers)) {
                    Entity entity = server.getEntity(id);
                    if (entity instanceof CoasterEntity car && getUUID().equals(car.leaderId())) {
                        car.ejectPassengers();
                        car.discard();
                    }
                }
                if (courseId() != null) CoasterSavedData.get(server).releaseVehicle(courseId(), getUUID());
            } else {
                CoasterEntity leader = resolveLeader();
                if (leader != null && leader.followers.contains(getUUID())) leader.emergencyStop();
            }
        }
        super.remove(reason);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        UUID id = courseId();
        if (id != null) tag.putUUID("CoasterCourse", id);
        tag.putDouble("CoasterDistance", distance);
        tag.putDouble("CoasterSpeed", speed);
        tag.putFloat("CoasterBank", getBank());
        tag.putInt("CoasterLaps", getLaps());
        tag.putBoolean("CoasterRunning", isRunning());
        if (leaderId() != null) tag.putUUID("CoasterLeader", leaderId());
        tag.putInt("CoasterCarIndex", carIndex());
        tag.putInt("CoasterCarCount", carCount());
        tag.putDouble("CoasterCarSpacing", carSpacing());
        ListTag childTags = new ListTag();
        for (UUID child : followers) {
            CompoundTag childTag = new CompoundTag();
            childTag.putUUID("Id", child);
            childTags.add(childTag);
        }
        tag.put("CoasterFollowers", childTags);
        if (lastSafeExit != null) tag.putLong("CoasterSafeExit", lastSafeExit.asLong());
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(COURSE, tag.hasUUID("CoasterCourse")
                ? Optional.of(tag.getUUID("CoasterCourse")) : Optional.empty());
        double savedDistance = tag.getDouble("CoasterDistance");
        distance = Double.isFinite(savedDistance) && savedDistance >= 0.0 ? savedDistance : 0.0;
        entityData.set(DISTANCE, (float) Math.min(Float.MAX_VALUE, distance));
        entityData.set(LAPS, Math.max(0, tag.getInt("CoasterLaps")));
        entityData.set(LEADER, tag.hasUUID("CoasterLeader")
                ? Optional.of(tag.getUUID("CoasterLeader")) : Optional.empty());
        entityData.set(CAR_INDEX, isTrainLeader() ? 0
                : Math.max(1, Math.min(TrainSpacing.MAX_CARS - 1, tag.getInt("CoasterCarIndex"))));
        entityData.set(SPACING, (float) TrainSpacing.DEFAULT_SPACING);
        followers.clear();
        if (isTrainLeader()) {
            ListTag children = tag.getList("CoasterFollowers", Tag.TAG_COMPOUND);
            for (int i = 0; i < Math.min(children.size(), TrainSpacing.MAX_CARS - 1); i++) {
                CompoundTag child = children.getCompound(i);
                if (child.hasUUID("Id")) {
                    UUID id = child.getUUID("Id");
                    if (!id.equals(getUUID()) && !followers.contains(id)) followers.add(id);
                }
            }
        }
        entityData.set(CAR_COUNT, isTrainLeader() ? 1 + followers.size()
                : Math.max(carIndex() + 1, Math.min(TrainSpacing.MAX_CARS, tag.getInt("CoasterCarCount"))));
        float savedBank = tag.getFloat("CoasterBank");
        entityData.set(BANK, Float.isFinite(savedBank) ? Mth.wrapDegrees(savedBank) : 0.0F);
        lastSafeExit = tag.contains("CoasterSafeExit") ? BlockPos.of(tag.getLong("CoasterSafeExit")) : null;
        // A saved running train deliberately reloads paused, so player/chunk
        // initialization cannot make it continue into an unavailable section.
        stopLocal();
        setNoGravity(true);
        noPhysics = true;
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }
}
