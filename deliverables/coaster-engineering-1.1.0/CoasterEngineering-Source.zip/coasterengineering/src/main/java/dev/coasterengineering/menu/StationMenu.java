package dev.coasterengineering.menu;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.station.StationControllerBlockEntity;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.item.ItemStack;

/** Slotless server-owned station console; clients receive only status values. */
public final class StationMenu extends AbstractContainerMenu {
    private static final int DATA_COUNT = 9;
    private final BlockPos position;
    private final UUID courseId;
    private final Player player;
    private final ContainerData data;

    public StationMenu(int windowId, Inventory inventory, FriendlyByteBuf buffer) {
        this(windowId, inventory, buffer.readBlockPos(), buffer.readUUID(), new SimpleContainerData(DATA_COUNT));
    }

    public StationMenu(int windowId, Inventory inventory, StationControllerBlockEntity controller) {
        this(windowId, inventory, controller.getBlockPos(), controller.courseId(), new ContainerData() {
            @Override public int get(int index) {
                CoasterEntity leader = controller.leader();
                return switch (index) {
                    case 0 -> leader == null ? 0 : (int) Math.round(leader.getSpeed() * 720);
                    case 1 -> leader == null ? 0 : leader.getLaps();
                    case 2 -> leader != null && leader.isRunning() ? 1 : 0;
                    case 3 -> leader == null ? 0 : leader.carCount();
                    case 4 -> leader == null ? 0 : leader.getLoadedFormation().stream().mapToInt(car -> car.getPassengers().size()).sum();
                    case 5 -> controller.autoDeparture() ? 1 : 0;
                    case 6 -> controller.emergencyLatched() ? 1 : 0;
                    case 7 -> controller.countdownTicks();
                    case 8 -> controller.dwellTicks();
                    default -> 0;
                };
            }
            @Override public void set(int index, int value) { }
            @Override public int getCount() { return DATA_COUNT; }
        });
    }

    private StationMenu(int windowId, Inventory inventory, BlockPos position, UUID courseId, ContainerData data) {
        super(CoasterRegistries.STATION_MENU.get(), windowId);
        this.position = position.immutable();
        this.courseId = courseId;
        this.player = inventory.player;
        this.data = data;
        addDataSlots(data);
    }

    public BlockPos controllerPos() { return position; }
    public UUID courseId() { return courseId; }
    public double speedKmh() { return data.get(0) / 10.0; }
    public int laps() { return data.get(1); }
    public boolean running() { return data.get(2) != 0; }
    public int carCount() { return data.get(3); }
    public int riderCount() { return data.get(4); }
    public boolean autoDeparture() { return data.get(5) != 0; }
    public boolean emergencyLatched() { return data.get(6) != 0; }
    public int countdownTicks() { return data.get(7); }
    public int dwellTicks() { return data.get(8); }
    public boolean mayManage() { return player.hasPermissions(2); }
    public boolean mayOperate() {
        return mayManage() || player.getVehicle() instanceof CoasterEntity car && courseId.equals(car.courseId());
    }

    public StationControllerBlockEntity controller() {
        return player.level().getBlockEntity(position) instanceof StationControllerBlockEntity station ? station : null;
    }

    @Override public boolean stillValid(Player player) {
        StationControllerBlockEntity controller = controller();
        return controller != null && !controller.isRemoved() && courseId.equals(controller.courseId())
                && player.distanceToSqr(position.getX() + .5, position.getY() + .5, position.getZ() + .5) <= 64;
    }

    @Override public ItemStack quickMoveStack(Player player, int index) { return ItemStack.EMPTY; }
}
