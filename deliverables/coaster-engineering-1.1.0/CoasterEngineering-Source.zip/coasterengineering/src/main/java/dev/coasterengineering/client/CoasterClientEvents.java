package dev.coasterengineering.client;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.CoasterConfig;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityMountEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "coasterengineering", value = Dist.CLIENT)
public final class CoasterClientEvents {
    private static UUID cameraVehicle;
    private static float initialLookYaw;
    private static float initialLookPitch;
    private static final RideCameraMotion CAMERA_MOTION = new RideCameraMotion();

    private CoasterClientEvents() { }

    @SubscribeEvent
    public static void logout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientCourses.clear();
        resetCamera();
    }

    @SubscribeEvent
    public static void camera(ViewportEvent.ComputeCameraAngles event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null
                || !(minecraft.player.getVehicle() instanceof CoasterEntity coaster)) {
            resetCamera();
            return;
        }
        rememberCameraMount(minecraft, coaster);
        float partialTick = (float) event.getPartialTick();
        boolean mirrored = minecraft.options.getCameraType().isMirrored();
        RideCameraMotion.Sample motion = cameraMotion(coaster, partialTick);
        if (CoasterConfig.FOLLOW_TRACK_CAMERA.get()) {
            float heading = Mth.rotLerp(partialTick, coaster.yRotO, coaster.getYRot());
            float pitch = Mth.lerp(partialTick, coaster.xRotO, coaster.getXRot());
            // The event already includes the 180-degree front-view camera offset.
            // Mouse look remains relative to the orientation at boarding, without
            // modifying the player's server-facing yaw/pitch or train movement.
            event.setYaw(heading + Mth.wrapDegrees(event.getYaw() - initialLookYaw));
            float baselinePitch = mirrored ? -initialLookPitch : initialLookPitch;
            event.setPitch(Mth.clamp((mirrored ? -pitch : pitch)
                    + event.getPitch() - baselinePitch
                    + (float) (mirrored ? -motion.pitchDegrees() : motion.pitchDegrees()), -85, 85));
        }
        if (CoasterConfig.BANK_CAMERA.get()) {
            // Preserve free look while keeping camera roll within a comfortable range.
            float bank = coaster.interpolatedBank(partialTick);
            float limit = CoasterConfig.CAMERA_ROLL_LIMIT.get().floatValue();
            float extraRoll = (float) motion.rollDegrees();
            event.setRoll(event.getRoll() + Mth.clamp(mirrored ? -bank - extraRoll : bank + extraRoll, -limit, limit));
        }
    }

    @SubscribeEvent
    public static void fov(ViewportEvent.ComputeFov event) {
        // The hand-rendering projection also computes FOV. Keep that projection
        // unchanged and widen only the normal configured world-camera FOV.
        if (!event.usedConfiguredFov() || CoasterConfig.CAMERA_FOV_PERCENT.get() <= 0) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || minecraft.player == null
                || !(minecraft.player.getVehicle() instanceof CoasterEntity coaster)) {
            resetCamera();
            return;
        }
        rememberCameraMount(minecraft, coaster);
        RideCameraMotion.Sample motion = cameraMotion(coaster, event.getPartialTick());
        event.setFOV(event.getFOV() * motion.fovScale());
    }

    @SubscribeEvent
    public static void mounted(EntityMountEvent event) {
        if (!event.getLevel().isClientSide || !event.isMounting()) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (event.getEntityMounting() == minecraft.player
                && event.getEntityBeingMounted() instanceof CoasterEntity coaster) {
            rememberCameraMount(minecraft, coaster);
        }
    }

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft minecraft = Minecraft.getInstance();
        // Passenger-list updates temporarily detach/re-attach existing riders in
        // the same tick. Delay clearing until the final state to preserve free look.
        if (minecraft.level == null || minecraft.player == null
                || !(minecraft.player.getVehicle() instanceof CoasterEntity coaster)) {
            resetCamera();
            return;
        }
        rememberCameraMount(minecraft, coaster);
        if (!minecraft.isPaused()) CAMERA_MOTION.tick(coaster.getSpeed(), coaster.isRunning(),
                CoasterConfig.CAMERA_VIBRATION_DEGREES.get(), CoasterConfig.CAMERA_FOV_PERCENT.get());
    }

    private static void rememberCameraMount(Minecraft minecraft, CoasterEntity coaster) {
        if (minecraft.level == null || minecraft.player == null) {
            resetCamera();
            return;
        }
        if (coaster.getUUID().equals(cameraVehicle)) return;
        cameraVehicle = coaster.getUUID();
        initialLookYaw = minecraft.player.getYRot();
        initialLookPitch = minecraft.player.getXRot();
        CAMERA_MOTION.reset();
    }

    private static void resetCamera() {
        cameraVehicle = null;
        initialLookYaw = 0;
        initialLookPitch = 0;
        CAMERA_MOTION.reset();
    }

    private static RideCameraMotion.Sample cameraMotion(CoasterEntity coaster, double partialTick) {
        if (!coaster.isRunning() || coaster.getSpeed() <= 0) {
            CAMERA_MOTION.reset();
            return new RideCameraMotion.Sample(0, 0, 1);
        }
        RideCameraMotion.Sample sample = CAMERA_MOTION.sample(partialTick, coaster.tickCount + partialTick);
        double vibrationLimit = CoasterConfig.CAMERA_VIBRATION_DEGREES.get();
        double fovLimit = CoasterConfig.CAMERA_FOV_PERCENT.get() / 100;
        // Config changes can arrive between two ticks; disabled options take
        // effect in this frame, even while the game is paused.
        return new RideCameraMotion.Sample(
                vibrationLimit > 0 ? Mth.clamp(sample.rollDegrees(), -vibrationLimit, vibrationLimit) : 0,
                vibrationLimit > 0 ? Mth.clamp(sample.pitchDegrees(), -vibrationLimit, vibrationLimit) : 0,
                fovLimit > 0 ? Math.min(sample.fovScale(), 1 + fovLimit) : 1);
    }

    @SubscribeEvent
    public static void hud(RenderGuiEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.options.hideGui || minecraft.level == null || minecraft.player == null
                || !(minecraft.player.getVehicle() instanceof CoasterEntity coaster)) return;
        Component state = Component.translatable(coaster.isRunning()
                ? "hud.coasterengineering.running" : "hud.coasterengineering.stopped");
        Component speed = Component.translatable("hud.coasterengineering.status",
                Math.round(coaster.getSpeed() * 72), coaster.getLaps(), state);
        // Chat/status messages occupy the lower left and can hide a ride overlay.
        // Keep the instruments at the top left with a readable dark background.
        int width = minecraft.font.width(speed);
        event.getGuiGraphics().fill(6, 6, width + 14, 21, 0xB0081019);
        event.getGuiGraphics().drawString(minecraft.font, speed, 10, 10, 0x66E4FF, true);
    }
}
