package dev.coasterengineering.station;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.menu.StationMenu;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Persistent station policy is separate from vehicle physics and formation state. */
public final class StationControllerBlockEntity extends BlockEntity implements MenuProvider {
    public static final int MIN_DWELL_TICKS = 140;
    public static final int MAX_DWELL_TICKS = 1200;
    private UUID boundCourse;
    private boolean automatic;
    private boolean emergency;
    private boolean modernAlarm = true;
    private int dwell = MIN_DWELL_TICKS;
    private int waited;
    private int countdown;
    private boolean powerInitialized;
    private boolean previousPower;

    public StationControllerBlockEntity(BlockPos pos, BlockState state) {
        super(CoasterRegistries.STATION_CONTROLLER_ENTITY.get(), pos, state);
    }

    public UUID courseId() { return boundCourse; }
    public boolean autoDeparture() { return automatic; }
    public boolean emergencyLatched() {
        if (boundCourse != null && level instanceof ServerLevel server) {
            boolean global = CoasterSavedData.get(server).isEmergency(boundCourse);
            return modernAlarm ? global : emergency || global;
        }
        return emergency;
    }
    public int dwellTicks() { return dwell; }
    public int countdownTicks() { return countdown; }

    public boolean bind(UUID id) {
        if (id == null || !(level instanceof ServerLevel server)) return false;
        CoasterSavedData data = CoasterSavedData.get(server);
        Course proposed = data.getCourse(id);
        if (proposed == null || worldPosition.distSqr(proposed.station()) > 64.0
                || !data.claimController(id, worldPosition)) return false;
        if (boundCourse != null && !boundCourse.equals(id)) data.releaseController(boundCourse, worldPosition);
        boundCourse = id;
        if (!modernAlarm && emergency) data.setEmergency(id, true);
        modernAlarm = true;
        emergency = data.isEmergency(id);
        resetCountdown();
        previousPower = server.hasNeighborSignal(worldPosition);
        powerInitialized = true;
        changedAndSync();
        return true;
    }

    /** Cross-check the persistent claim on every use; a copied console cannot operate a course. */
    public Course course() {
        if (boundCourse == null || !(level instanceof ServerLevel server)) return null;
        CoasterSavedData data = CoasterSavedData.get(server);
        Course course = data.getCourse(boundCourse);
        BlockPos claimed = data.controllerPos(boundCourse);
        return course != null && worldPosition.equals(claimed)
                && worldPosition.distSqr(course.station()) <= 64.0 ? course : null;
    }

    public CoasterEntity leader() {
        if (!(level instanceof ServerLevel server) || course() == null) return null;
        UUID vehicle = CoasterSavedData.get(server).vehicleId(boundCourse);
        Entity entity = vehicle == null ? null : server.getEntity(vehicle);
        return entity instanceof CoasterEntity car && !car.isRemoved() && car.isTrainLeader()
                && boundCourse.equals(car.courseId()) ? car : null;
    }

    public boolean dispatch() {
        CoasterEntity leader = leader();
        if (emergencyLatched() || leader == null || leader.isRunning() || leader.getLoadedFormation().isEmpty()) return false;
        if (!leader.startRide()) return false;
        resetCountdown();
        changedAndSync();
        return true;
    }

    public void stopEmergency() {
        modernAlarm = true;
        emergency = true;
        if (level instanceof ServerLevel server && course() != null)
            CoasterSavedData.get(server).setEmergency(boundCourse, true);
        CoasterEntity leader = leader();
        if (leader != null) leader.emergencyStop();
        resetCountdown();
        changedAndSync();
    }

    /** Clearing the alarm alone never moves a train. */
    public void clearEmergency() {
        modernAlarm = true;
        emergency = false;
        if (level instanceof ServerLevel server && course() != null)
            CoasterSavedData.get(server).setEmergency(boundCourse, false);
        resetCountdown();
        changedAndSync();
    }

    public boolean returnToStation() {
        CoasterEntity leader = leader();
        if (leader == null || leader.isRunning()) return false;
        List<CoasterEntity> cars = leader.getLoadedFormation();
        if (cars.isEmpty() || cars.stream().anyMatch(Entity::isVehicle) || !leader.resetToStation()) return false;
        resetCountdown();
        changedAndSync();
        return true;
    }

    public void setAutoDeparture(boolean enabled) {
        automatic = enabled;
        resetCountdown();
        changedAndSync();
    }

    public void setDwellTicks(int ticks) {
        if (ticks < MIN_DWELL_TICKS || ticks > MAX_DWELL_TICKS)
            throw new IllegalArgumentException("Station dwell must be 140..1200 ticks");
        dwell = ticks;
        resetCountdown();
        changedAndSync();
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state,
                                  StationControllerBlockEntity controller) {
        if (!(level instanceof ServerLevel server)) return;
        controller.restoreUnclaimedBinding(server);
        boolean powered = server.hasNeighborSignal(pos);
        boolean rising = controller.powerInitialized && powered && !controller.previousPower;
        controller.previousPower = powered;
        controller.powerInitialized = true;
        if (rising && !controller.emergencyLatched()) controller.dispatch();

        CoasterEntity leader = controller.leader();
        List<CoasterEntity> cars = leader == null ? List.of() : leader.getLoadedFormation();
        Course course = controller.course();
        boolean eligible = controller.automatic && !controller.emergencyLatched() && leader != null
                && course != null && course.enabled()
                && !leader.isRunning() && Math.abs(leader.getDistance()) < 1.0E-6
                && leader.getSpeed() == 0.0 && !cars.isEmpty() && cars.stream().anyMatch(Entity::isVehicle);
        if (!eligible) {
            controller.resetCountdown();
            return;
        }
        controller.waited++;
        controller.countdown = Math.max(0, controller.dwell - controller.waited);
        if (controller.waited >= controller.dwell) {
            controller.dispatch();
            controller.resetCountdown();
        }
    }

    private void restoreUnclaimedBinding(ServerLevel server) {
        if (boundCourse == null) return;
        CoasterSavedData data = CoasterSavedData.get(server);
        Course course = data.getCourse(boundCourse);
        if (course != null && worldPosition.distSqr(course.station()) <= 64.0
                && data.controllerPos(boundCourse) == null) data.claimController(boundCourse, worldPosition);
        if (course != null && worldPosition.equals(data.controllerPos(boundCourse))) {
            boolean migrated = !modernAlarm;
            if (!modernAlarm && emergency) data.setEmergency(boundCourse, true);
            modernAlarm = true;
            emergency = data.isEmergency(boundCourse);
            if (migrated) changedAndSync();
        }
    }

    private void resetCountdown() { waited = 0; countdown = 0; }

    private void changedAndSync() {
        setChanged();
        if (level != null && !level.isClientSide) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_CLIENTS);
        }
    }

    @Override
    public Component getDisplayName() { return Component.translatable("gui.coasterengineering.station"); }

    @Override
    public AbstractContainerMenu createMenu(int windowId, Inventory inventory, Player player) {
        return new StationMenu(windowId, inventory, this);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (boundCourse != null) tag.putUUID("Course", boundCourse);
        tag.putBoolean("AutoDeparture", automatic);
        tag.putInt("AlarmFormatVersion", 2);
        tag.putBoolean("EmergencyLatched", emergencyLatched());
        tag.putInt("DwellTicks", dwell);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        boundCourse = tag.hasUUID("Course") ? tag.getUUID("Course") : null;
        automatic = tag.getBoolean("AutoDeparture");
        emergency = tag.getBoolean("EmergencyLatched");
        modernAlarm = tag.getInt("AlarmFormatVersion") >= 2;
        dwell = Math.max(MIN_DWELL_TICKS, Math.min(MAX_DWELL_TICKS, tag.getInt("DwellTicks")));
        resetCountdown();
        powerInitialized = false;
    }

    @Override
    public CompoundTag getUpdateTag() { return saveWithoutMetadata(); }

    @Override
    public ClientboundBlockEntityDataPacket getUpdatePacket() { return ClientboundBlockEntityDataPacket.create(this); }
}
