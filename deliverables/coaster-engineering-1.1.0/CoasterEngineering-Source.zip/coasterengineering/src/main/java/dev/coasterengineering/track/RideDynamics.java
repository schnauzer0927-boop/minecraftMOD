package dev.coasterengineering.track;

import java.util.Objects;

/** Deterministic forward-only tick integration. World/chunk safety is checked by the entity. */
public final class RideDynamics {
    /** 120 km/h when one block is treated as one metre and the server ticks at 20 Hz. */
    public static final double MAX_SUPPORTED_SPEED = 120.0 / 72.0;
    private static final double GRAVITY = 9.81 / 400.0;
    private static final double MOTOR_ACCELERATION = 0.025;
    private static final double BRAKE_DECELERATION = 0.035;
    private static final double STOP_EPSILON = 1e-8;

    private RideDynamics() { }

    public record Step(double distance, double speed, boolean crossedFinish, boolean stopped) { }

    /** Optional explicit ride program; ordinary courses keep their existing rail physics. */
    public interface SpeedProfile {
        double targetSpeed(double distance);
        default double maximumAcceleration() { return .012; }
        default double maximumBraking() { return .020; }
    }

    public static Step advance(SplineTrack track, double distance, double speed,
                               boolean running, double maxSpeed) {
        return advance(track, distance, speed, running, maxSpeed, MOTOR_ACCELERATION);
    }

    /** Limit positive acceleration for ride comfort while preserving brake authority. */
    public static Step advance(SplineTrack track, double distance, double speed,
                               boolean running, double maxSpeed, double maximumAcceleration) {
        return integrate(track, distance, speed, running, maxSpeed, maximumAcceleration, null);
    }

    public static Step advanceProfiled(SplineTrack track, double distance, double speed,
                                      boolean running, double maxSpeed, double maximumAcceleration,
                                      SpeedProfile profile) {
        return integrate(track, distance, speed, running, maxSpeed, maximumAcceleration,
                Objects.requireNonNull(profile, "profile"));
    }

    private static Step integrate(SplineTrack track, double distance, double speed,
                                  boolean running, double maxSpeed, double maximumAcceleration,
                                  SpeedProfile profile) {
        Objects.requireNonNull(track, "track");
        if (!Double.isFinite(distance) || !Double.isFinite(speed) || speed < 0
                || !Double.isFinite(maxSpeed) || maxSpeed < 0) {
            throw new IllegalArgumentException("Ride state must be finite and speeds nonnegative");
        }
        if (!Double.isFinite(maximumAcceleration) || maximumAcceleration <= 0
                || maximumAcceleration > MOTOR_ACCELERATION) {
            throw new IllegalArgumentException("Maximum acceleration must be finite, positive and at most 0.025");
        }
        double currentDistance = track.normalizeDistance(distance);
        if (!running || maxSpeed == 0 || (!track.closed() && currentDistance >= track.length())) {
            return new Step(currentDistance, 0, false, true);
        }
        double limit = Math.min(maxSpeed, MAX_SUPPORTED_SPEED);
        double previousSpeed = Math.min(speed, limit);
        TrackSample sample = track.sample(currentDistance);
        double target = Math.min(sample.targetSpeed(), limit);
        double natural = -GRAVITY * sample.tangent().y() - (0.0003 + 0.0006 * previousSpeed * previousSpeed);
        double braking = BRAKE_DECELERATION;
        if (profile != null) {
            double requestedTarget = profile.targetSpeed(currentDistance);
            if (!Double.isFinite(requestedTarget) || requestedTarget < 0
                    || !Double.isFinite(profile.maximumAcceleration()) || profile.maximumAcceleration() <= 0
                    || profile.maximumAcceleration() > MOTOR_ACCELERATION
                    || !Double.isFinite(profile.maximumBraking()) || profile.maximumBraking() <= 0
                    || profile.maximumBraking() > BRAKE_DECELERATION) {
                throw new IllegalArgumentException("Ride profile contains invalid speed or acceleration limits");
            }
            target = Math.min(requestedTarget, limit);
            maximumAcceleration = Math.min(maximumAcceleration, profile.maximumAcceleration());
            braking = profile.maximumBraking();
        }
        double acceleration = profile == null ? switch (sample.kind()) {
            case NORMAL -> natural;
            case BOOST -> natural + Math.max(0, Math.min(MOTOR_ACCELERATION, target - previousSpeed));
            case LIFT, STATION -> clamp(target - previousSpeed, -BRAKE_DECELERATION, MOTOR_ACCELERATION);
            case BRAKE -> previousSpeed > target
                    ? Math.min(natural, -Math.min(BRAKE_DECELERATION, previousSpeed - target)) : natural;
        } : switch (sample.kind()) {
            // Gravity still drives free-rolling sections, with the speed governor
            // applying trim brakes if the programmed ceiling is reached.
            case NORMAL -> Math.min(natural, target - previousSpeed);
            // LSM drive compensates grade/drag. The final acceleration, rather
            // than the motor force, is limited for passenger comfort.
            case BOOST -> target - previousSpeed;
            // Low-speed return sections include station motor creep; friction
            // must not strand a train just before its one-lap parking boundary.
            case LIFT, STATION, BRAKE -> target - previousSpeed;
        };
        acceleration = clamp(acceleration, -braking, maximumAcceleration);
        double nextSpeed = clamp(previousSpeed + acceleration, 0, limit);
        if (profile == null && sample.kind() == RailKind.BRAKE && previousSpeed <= target) nextSpeed = Math.min(nextSpeed, target);
        if (nextSpeed < STOP_EPSILON) nextSpeed = 0;
        // Trapezoidal integration keeps distance continuous while speeding up and slowing down.
        double unboundedDistance = currentDistance + (previousSpeed + nextSpeed) * 0.5;
        boolean crossedFinish = unboundedDistance >= track.length() && unboundedDistance > currentDistance;
        if (!track.closed() && crossedFinish) return new Step(track.length(), 0, true, true);
        return new Step(track.normalizeDistance(unboundedDistance), nextSpeed, crossedFinish, nextSpeed == 0);
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
