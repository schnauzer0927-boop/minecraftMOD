package dev.coasterengineering.world;

import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.network.CoasterNetwork;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackVec3;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Phase 1 driving fixture. Does not pretend to be the final volcanic attraction. */
public final class DemoCourseBuilder {
    public static Course build(ServerLevel level, BlockPos origin) {
        double x = origin.getX() + .5, y = origin.getY() + .25, z = origin.getZ() + .5;
        List<ControlPoint> points = List.of(
                point(x+2, y, z+12, 0, RailKind.STATION, .32),
                point(x+2, y, z+2, 0, RailKind.LIFT, .32),
                point(x+12, y+4, z-4, -10, RailKind.LIFT, .32),
                point(x+26, y+8, z+2, -15, RailKind.NORMAL, .65),
                point(x+32, y+2, z+16, -15, RailKind.BOOST, .65),
                point(x+26, y, z+30, -10, RailKind.NORMAL, .65),
                point(x+12, y, z+34, -10, RailKind.BRAKE, .25),
                point(x+2, y, z+26, 0, RailKind.BRAKE, .25));
        SplineTrack track = new SplineTrack(points, true);
        BlockPos landing = BlockPos.containing(x-1, y+.5, z+12);
        Course course = new Course(UUID.randomUUID(), "Engineering Test Loop", track, landing, true);
        CoasterSavedData data = CoasterSavedData.get(level);
        if (data.courses().size() >= CoasterSavedData.MAX_COURSES) throw new IllegalArgumentException("Course limit reached");
        Map<BlockPos, BlockState> plan = new LinkedHashMap<>();

        // Adjacent, solid station landing, rail anchors, and narrow support columns.
        // Keep the deck outside the cart's swept body on the first left-bending segment.
        for (int dx = -4; dx <= -1; dx++) for (int dz = 8; dz <= 17; dz++) {
            plan.put(origin.offset(dx, -1, dz), Blocks.POLISHED_DEEPSLATE.defaultBlockState());
            if (dx == -4 || dz == 8 || dz == 17)
                plan.put(origin.offset(dx, 0, dz), Blocks.IRON_BARS.defaultBlockState());
        }
        for (int dz = 9; dz <= 16; dz += 7) {
            plan.put(origin.offset(-3, 2, dz), Blocks.SEA_LANTERN.defaultBlockState());
            plan.put(origin.offset(-3, 1, dz), Blocks.IRON_BARS.defaultBlockState());
        }
        for (double s = 0; s < track.length(); s += 4) {
            var sample = track.sample(s);
            BlockPos p = BlockPos.containing(sample.position().x(), sample.position().y(), sample.position().z());
            for (int supportY = origin.getY()-6; supportY < p.getY()-4; supportY++)
                plan.put(new BlockPos(p.getX(), supportY, p.getZ()), Blocks.IRON_BARS.defaultBlockState());
            // Bank and pitch enlarge the swept underside beyond a flat cart's bounds.
            plan.put(p.below(4), Blocks.POLISHED_DEEPSLATE.defaultBlockState());
        }
        for (ControlPoint point : points) {
            BlockPos p = BlockPos.containing(point.position().x(), point.position().y(), point.position().z());
            plan.put(p, block(point.kind()).defaultBlockState());
        }

        // No chunk generation, terrain clearing, or partial construction on obstruction.
        for (BlockPos p : plan.keySet()) {
            if (level.isOutsideBuildHeight(p) || !level.hasChunkAt(p) || !level.getWorldBorder().isWithinBounds(p))
                throw new IllegalArgumentException("Demo footprint must be inside the world and loaded chunks");
            if (!level.getBlockState(p).isAir())
                throw new IllegalArgumentException("Demo footprint obstructed at " + p.toShortString() + "; use a clear area higher above terrain");
        }
        for (double s = 0; s < track.length(); s += .5) {
            var v = track.sample(s).position();
            BlockPos p = BlockPos.containing(v.x(), v.y(), v.z());
            if (level.isOutsideBuildHeight(p) || !level.hasChunkAt(p) || !level.getWorldBorder().isWithinBounds(p)
                    || !level.getBlockState(p).isAir() || !level.getBlockState(p.above()).isAir())
                throw new IllegalArgumentException("Track path needs loaded empty space inside world limits");
        }
        CoasterEntity cart = CoasterRegistries.COASTER.get().create(level);
        if (cart == null) throw new IllegalStateException("Could not create coaster entity");
        data.putCourse(course);
        data.claimVehicle(course.id(), cart.getUUID());
        cart.setCourse(course.id());
        if (!cart.resetToStation()) {
            data.removeCourse(course.id());
            throw new IllegalArgumentException("Vehicle footprint crosses unloaded chunks or world limits");
        }
        if (!level.addFreshEntity(cart)) {
            data.removeCourse(course.id());
            throw new IllegalStateException("Could not add coaster entity");
        }
        for (var entry : plan.entrySet()) level.setBlock(entry.getKey(), entry.getValue(), 3);
        CoasterNetwork.broadcastCourse(level, course);
        return course;
    }

    private static ControlPoint point(double x, double y, double z, double bank, RailKind kind, double target) {
        return new ControlPoint(new TrackVec3(x, y, z), bank, kind, target);
    }

    private static Block block(RailKind kind) {
        return switch (kind) {
            case NORMAL -> CoasterRegistries.RAIL.get();
            case BOOST -> CoasterRegistries.BOOST_RAIL.get();
            case BRAKE -> CoasterRegistries.BRAKE_RAIL.get();
            case LIFT -> CoasterRegistries.LIFT_RAIL.get();
            case STATION -> CoasterRegistries.STATION_RAIL.get();
        };
    }

    private DemoCourseBuilder() { }
}
