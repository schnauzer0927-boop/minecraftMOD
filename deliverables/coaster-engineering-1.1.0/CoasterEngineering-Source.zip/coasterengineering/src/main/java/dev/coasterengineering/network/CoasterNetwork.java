package dev.coasterengineering.network;

import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import java.util.UUID;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

@Mod.EventBusSubscriber(modid = CoasterEngineering.MOD_ID)
public final class CoasterNetwork {
    private static final String VERSION = "1.1.0-1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(CoasterEngineering.MOD_ID, "courses"), () -> VERSION, VERSION::equals, VERSION::equals);

    public static void register() {
        CHANNEL.messageBuilder(CoursePacket.class, 0, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(CoursePacket::encode).decoder(CoursePacket::decode)
                .consumerMainThread(CoursePacket::handle).add();
        CHANNEL.messageBuilder(StationActionPacket.class, 1, NetworkDirection.PLAY_TO_SERVER)
                .encoder(StationActionPacket::encode).decoder(StationActionPacket::decode)
                .consumerMainThread(StationActionPacket::handle).add();
    }

    public static void broadcastCourse(ServerLevel level, Course course) {
        CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension), CoursePacket.update(course));
    }

    public static void removeCourse(ServerLevel level, UUID id) {
        CHANNEL.send(PacketDistributor.DIMENSION.with(level::dimension), CoursePacket.remove(id));
    }

    private static void sync(ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), CoursePacket.clear());
        for (Course course : CoasterSavedData.get(player.serverLevel()).courses())
            CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), CoursePacket.update(course));
    }

    @SubscribeEvent
    public static void loggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) sync(player);
    }

    @SubscribeEvent
    public static void changedDimension(PlayerEvent.PlayerChangedDimensionEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) sync(player);
    }

    @SubscribeEvent
    public static void respawned(PlayerEvent.PlayerRespawnEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) sync(player);
    }

    private CoasterNetwork() { }
}
