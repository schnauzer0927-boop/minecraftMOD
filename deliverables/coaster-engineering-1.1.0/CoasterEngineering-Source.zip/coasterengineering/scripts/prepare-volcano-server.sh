#!/usr/bin/env bash
set -euo pipefail
COASTER_PROJECT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COASTER_SERVER_DIR="${1:-$COASTER_PROJECT/run-volcano}"
mkdir -p "$COASTER_SERVER_DIR"
if [[ -f "$COASTER_SERVER_DIR/server.properties" || -f "$COASTER_SERVER_DIR/Coaster World - Volcanic Abyss/level.dat" ]]; then
    printf 'Server directory is already configured: %s\n' "$COASTER_SERVER_DIR"
    exit 0
fi
cat >"$COASTER_SERVER_DIR/server.properties" <<'PROPERTIES'
level-name=Coaster World - Volcanic Abyss
level-seed=20261011
level-type=minecraft:flat
generator-settings={"layers":[{"block":"minecraft:bedrock","height":1},{"block":"minecraft:stone","height":124},{"block":"minecraft:dirt","height":2},{"block":"minecraft:grass_block","height":1}],"biome":"minecraft:plains","structures":{}}
generate-structures=false
gamemode=adventure
difficulty=peaceful
spawn-protection=0
online-mode=false
server-ip=127.0.0.1
server-port=25565
view-distance=12
simulation-distance=8
max-players=1
allow-flight=true
enable-command-block=false
enable-rcon=false
enable-query=false
max-tick-time=60000
PROPERTIES
printf 'eula=true\n' >"$COASTER_SERVER_DIR/eula.txt"
printf 'Prepared fixed-seed local world server: %s\n' "$COASTER_SERVER_DIR"
printf 'Run ./gradlew runServer -PcoasterServerDir=%s, then enter coaster volcano.\n' "$COASTER_SERVER_DIR"
