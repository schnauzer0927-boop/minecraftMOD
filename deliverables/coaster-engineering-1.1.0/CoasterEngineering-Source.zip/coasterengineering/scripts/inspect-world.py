#!/usr/bin/env python3
"""Read a stopped Minecraft1.20.1 save and report the real coaster NBT as JSON."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import gzip
import io
import json
import math
from pathlib import Path
import struct
import sys
import uuid
import zlib

COURSE_ID = "61da851c-7705-3a82-b7b3-2e2e8ee296b4"
WORLD_NAME = "Coaster World - Volcanic Abyss"


def read_nbt(data: bytes) -> dict:
    stream = io.BytesIO(data)

    def take(size: int) -> bytes:
        if size < 0:
            raise ValueError("Negative NBT payload size")
        value = stream.read(size)
        if len(value) != size:
            raise ValueError("Truncated NBT payload")
        return value

    def number(fmt: str):
        return struct.unpack(fmt, take(struct.calcsize(fmt)))[0]

    def string() -> str:
        return take(number(">H")).decode("utf-8")

    def payload(kind: int, depth: int = 0):
        if depth > 128:
            raise ValueError("NBT nesting limit exceeded")
        if kind in (1, 2, 3, 4, 5, 6):
            return number({1: ">b", 2: ">h", 3: ">i", 4: ">q", 5: ">f", 6: ">d"}[kind])
        if kind == 7:
            return take(number(">i"))
        if kind == 8:
            return string()
        if kind in (9, 11, 12):
            element = number(">B") if kind == 9 else 3 if kind == 11 else 4
            count = number(">i")
            if count < 0 or count > len(data):
                raise ValueError("Invalid NBT array length")
            return [payload(element, depth + 1) for _ in range(count)]
        if kind == 10:
            result = {}
            while (child := number(">B")) != 0:
                name = string()
                result[name] = payload(child, depth + 1)
            return result
        raise ValueError(f"Unsupported NBT tag {kind}")

    kind = number(">B")
    string()
    if kind != 10:
        raise ValueError("NBT root must be a compound")
    root = payload(kind)
    if stream.tell() != len(data):
        raise ValueError("Unexpected bytes after NBT root")
    return root


def read_dat(path: Path) -> dict:
    return read_nbt(gzip.decompress(path.read_bytes()))


def region_chunks(directory: Path):
    for path in sorted(directory.glob("r.*.*.mca")):
        raw = path.read_bytes()
        if not raw:
            continue  # Minecraft opens empty entity regions before the first write.
        if len(raw) < 8192:
            raise ValueError(f"Truncated Anvil region: {path}")
        region_x, region_z = map(int, path.stem.split(".")[1:])
        for index in range(1024):
            entry = raw[index * 4:index * 4 + 4]
            sector, sectors = int.from_bytes(entry[:3], "big"), entry[3]
            if sector == 0:
                continue
            offset = sector * 4096
            if offset + 5 > len(raw) or sectors == 0:
                raise ValueError(f"Invalid region location: {path}, entry{index}")
            length = int.from_bytes(raw[offset:offset + 4], "big")
            compression = raw[offset + 4]
            if compression & 128:
                x, z = region_x * 32 + index % 32, region_z * 32 + index // 32
                compressed = path.with_name(f"c.{x}.{z}.mcc").read_bytes()
            else:
                if length < 1 or length > sectors * 4096 - 4 or offset + length + 4 > len(raw):
                    raise ValueError(f"Invalid region payload: {path}, entry{index}")
                compressed = raw[offset + 5:offset + 4 + length]
            mode = compression & 127
            if mode not in (1, 2, 3):
                raise ValueError(f"Unsupported Minecraft1.20.1 region compression {mode}")
            decoded = gzip.decompress(compressed) if mode == 1 else zlib.decompress(compressed) if mode == 2 else compressed
            yield read_nbt(decoded)


def uuid_string(value) -> str | None:
    if value is None:
        return None
    if not isinstance(value, list) or len(value) != 4:
        raise ValueError("Malformed saved UUID")
    return str(uuid.UUID(bytes=b"".join(struct.pack(">I", part & 0xffffffff) for part in value)))


def block_position(packed: int | None) -> list[int] | None:
    if packed is None:
        return None
    x, y, z = packed >> 38, packed & 4095, (packed >> 12) & 67108863
    return [x, y - 4096 if y >= 2048 else y, z - 67108864 if z >= 33554432 else z]


@contextmanager
def stable_save(world: Path):
    """A shared read lock detects Minecraft's exclusive running-world lock."""
    lock = world / "session.lock"
    if not lock.exists():
        yield  # Distributable ZIPs intentionally omit this transient file.
        return
    import fcntl
    with lock.open("rb") as handle:
        try:
            fcntl.lockf(handle, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError("World is running; save and stop Minecraft before inspecting the snapshot") from None
        try:
            yield
        finally:
            fcntl.lockf(handle, fcntl.LOCK_UN)


def inspect_world(world: Path) -> dict:
    level = read_dat(world / "level.dat")["Data"]
    data = read_dat(world / "data/coasterengineering_courses.dat")["data"]
    courses = [{"id": uuid_string(c.get("Id")), "name": c.get("Name"), "enabled": c.get("Enabled"),
                "closed": c.get("Closed"), "node_count": len(c.get("Points", [])), "vehicle_id": uuid_string(c.get("Vehicle")),
                "controller_position": block_position(c.get("Controller")), "station": block_position(c.get("Station")),
                "emergency": c.get("Emergency"), "points": c.get("Points", [])} for c in data.get("Courses", [])]
    vehicles = []
    for chunk in region_chunks(world / "entities"):
        for entity in chunk.get("Entities", []):
            if entity.get("id") != "coasterengineering:coaster":
                continue
            vehicles.append({"id": uuid_string(entity.get("UUID")), "course_id": uuid_string(entity.get("CoasterCourse")),
                             "leader_id": uuid_string(entity.get("CoasterLeader")), "car_index": entity.get("CoasterCarIndex"),
                             "car_count": entity.get("CoasterCarCount"), "distance": entity.get("CoasterDistance"),
                             "speed": entity.get("CoasterSpeed"), "running": entity.get("CoasterRunning"),
                             "laps": entity.get("CoasterLaps"), "spacing": entity.get("CoasterCarSpacing"),
                             "position": entity.get("Pos"), "passenger_count": len(entity.get("Passengers", [])),
                             "follower_ids": [uuid_string(f.get("Id")) for f in entity.get("CoasterFollowers", [])]})
    vehicles.sort(key=lambda car: (car["car_index"] if isinstance(car["car_index"], int) else -1, car["id"] or ""))
    controllers = []
    region_count = 0
    for chunk in region_chunks(world / "region"):
        region_count += 1
        for entity in chunk.get("block_entities", []):
            if entity.get("id") == "coasterengineering:station_controller":
                controllers.append({"position": [entity.get("x"), entity.get("y"), entity.get("z")],
                                    "course_id": uuid_string(entity.get("Course")), "automatic": entity.get("AutoDeparture"),
                                    "dwell_ticks": entity.get("DwellTicks"), "emergency": entity.get("EmergencyLatched"),
                                    "alarm_format": entity.get("AlarmFormatVersion")})
    forced_file = world / "data/chunks.dat"
    forced = read_dat(forced_file).get("data", {}) if forced_file.exists() else {}
    generator = level.get("WorldGenSettings", {}).get("dimensions", {}).get("minecraft:overworld", {}).get("generator", {}).get("type")
    quality_file = world / "data/coasterengineering_world_quality.dat"
    quality = read_dat(quality_file).get("data", {}) if quality_file.exists() else {}
    result = {"world": {"path": str(world), "name": level.get("LevelName"), "seed": level.get("WorldGenSettings", {}).get("seed"),
                        "data_version": level.get("DataVersion"), "game_type": level.get("GameType"),
                        "spawn": [level.get("SpawnX"), level.get("SpawnY"), level.get("SpawnZ")], "generator": generator,
                        "embedded_player": "Player" in level, "saved_overworld_chunks": region_count,
                        "persistent_forced_chunks": len(forced.get("Forced", [])) + len(forced.get("ForgeForced", []))},
              "courses": courses, "vehicles": vehicles, "controllers": controllers,
              "quality_upgrade": {"version": quality.get("qualityVersion", 0), "report": quality.get("report")}}
    failures = []

    def require(condition, message):
        if not condition:
            failures.append(message)

    metadata = result["world"]
    require(metadata["name"] == WORLD_NAME and metadata["seed"] == 20261011, "Original world name and fixed seed must match")
    require(metadata["game_type"] == 2 and metadata["spawn"] == [-3, 94, -96], "Default adventure spawn must be the safe station landing")
    require(metadata["data_version"] == 3465 and generator == "minecraft:flat", "World must retain the Minecraft1.20.1 dedicated flat generator")
    require(not metadata["embedded_player"], "Embedded client Player would override the distributable world's default spawn")
    require(metadata["persistent_forced_chunks"] == 0, "Commissioning must leave no persistent forced chunks")
    require(region_count > 0, "Actual saved Overworld regions must exist")
    require(len(courses) == 1 and courses[0]["id"] == COURSE_ID and courses[0]["node_count"] == 45
            and courses[0]["enabled"] == 1 and courses[0]["closed"] == 1 and courses[0]["emergency"] == 0,
            "Exactly one enabled, closed, nonalarmed original45node course must be saved")
    require(len(vehicles) == 3 and {car["car_index"] for car in vehicles} == {0, 1, 2}
            and len({car["id"] for car in vehicles}) == 3 and all(car["id"] and car["course_id"] == COURSE_ID for car in vehicles),
            "Exactly three distinct saved cars must belong to the original course")
    require(all(car["car_count"] == 3 and car["spacing"] == 4 and car["running"] == 0 and car["speed"] == 0 and car["passenger_count"] == 0
                and isinstance(car["distance"], (float, int)) and math.isfinite(car["distance"]) for car in vehicles),
            "All three cars must retain four-block spacing and be paused, empty and finite")
    leaders = [car for car in vehicles if car["car_index"] == 0]
    if len(courses) == 1 and len(leaders) == 1:
        leader = leaders[0]
        followers = [car for car in vehicles if car["car_index"] in (1, 2)]
        require(leader["leader_id"] is None and leader["id"] == courses[0]["vehicle_id"] and leader["distance"] == 0
                and leader["follower_ids"] == [car["id"] for car in followers]
                and all(car["leader_id"] == leader["id"] and car["laps"] == leader["laps"] for car in followers),
                "The reserved original leader, follower UUID order, paused station and lap counters must match")
    require(len(controllers) == 1 and controllers[0]["course_id"] == COURSE_ID and controllers[0]["automatic"] == 1
            and controllers[0]["dwell_ticks"] == 140 and controllers[0]["emergency"] == 0
            and len(courses) == 1 and controllers[0]["position"] == courses[0]["controller_position"],
            "Exactly one uniquely bound automatic140tick station console must be saved without an alarm")
    result["ready"] = not failures
    result["readiness_failures"] = failures
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world", type=Path, required=True, help="Stopped save directory, including level.dat")
    parser.add_argument("--require-ready", action="store_true", help="Exit1 unless the distributable original attraction is ready")
    parser.add_argument("--require-quality", action="store_true", help="Exit1 unless the completed quality-upgrade marker was saved")
    parser.add_argument("--output", type=Path, help="Optionally write the JSON report to this explicit path")
    args = parser.parse_args()
    try:
        if args.output and args.output.resolve().is_relative_to(args.world.resolve()):
            raise ValueError("Write inspection reports outside the world; the saved world is read-only")
        with stable_save(args.world):
            report = inspect_world(args.world.resolve())
        output = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
        if args.output:
            args.output.write_text(output, encoding="utf-8")
        print(output, end="")
        return 1 if (args.require_ready and not report["ready"]
                     or args.require_quality and report["quality_upgrade"]["version"] < 1) else 0
    except (OSError, ValueError, KeyError, ImportError) as error:
        print(json.dumps({"error": str(error), "ready": False}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
