#!/usr/bin/env python3
"""Verify the original car model and appearance were preserved byte for byte."""
import hashlib
import json
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
manifest = json.loads((PROJECT / "scripts/preserved-design.json").read_text())
failures = []
for name, expected in manifest["protected_files"].items():
    path = PROJECT / name
    actual = hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None
    if actual != expected:
        failures.append(name)
if failures:
    raise SystemExit("Protected original appearance changed: " + ", ".join(failures))
print(f"Original vehicle appearance preserved: {len(manifest['protected_files'])} exact SHA-256 matches")
