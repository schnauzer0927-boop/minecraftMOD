#!/usr/bin/env python3
"""Read-only seat-light, saved geometry and tunnel-shell audit of a stopped save.

Saved block states are not Minecraft voxel shapes. Clearance candidates and shell
gaps are diagnostics; the actual Forge ride validator remains authoritative.
"""
from __future__ import annotations

import argparse
import bisect
from collections import Counter
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import sys

SPEC = importlib.util.spec_from_file_location("coaster_save_reader", Path(__file__).with_name("inspect-world.py"))
SAVE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SAVE)
AIR = {"minecraft:air", "minecraft:cave_air", "minecraft:void_air"}
PASSABLE = AIR | {"minecraft:light"} | {"coasterengineering:" + name for name in
                  ("rail", "boost_rail", "brake_rail", "lift_rail", "station_rail", "support_beam")}
ROOMS = ((-72, 80, 15, 24, 16, 24), (45, 83, 40, 24, 19, 24), (-29, 83, 10, 22, 22, 22))
STAGES = ((0, "EXPLORE"), (6, "ANOMALY"), (8, "DROP"), (11, "MONSTER"),
          (14, "CAVERN"), (22, "CLIMAX"), (37, "RETURN"))


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def scale(a, k):
    return tuple(x * k for x in a)


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def normalize(a):
    length = math.sqrt(sum(x * x for x in a))
    if not math.isfinite(length) or length < 1e-8:
        raise ValueError("Saved track has a degenerate tangent")
    return scale(a, 1 / length)


def angular(a):
    return (a + 180) % 360 - 180


class SavedSpline:
    """The shipping 128-subdivision Catmull-Rom arc lookup, from actual NBT."""
    def __init__(self, points):
        if len(points) < 4:
            raise ValueError("Audit requires a complete closed track")
        self.points = points
        self.distances = [0.0]
        previous = self.position(0, 0)
        for i in range(1, len(points) * 128 + 1):
            segment = min(i // 128, len(points) - 1)
            t = i / 128 - segment
            position = self.position(segment, t)
            self.distances.append(self.distances[-1] + math.dist(previous, position))
            previous = position
        self.length = self.distances[-1]

    def components(self, segment, key):
        return [self.points[(segment + offset) % len(self.points)][key] for offset in (-1, 0, 1, 2)]

    def position(self, segment, t):
        result = []
        for key in ("X", "Y", "Z"):
            p0, p1, p2, p3 = self.components(segment, key)
            a, b, c = -p0 + 3*p1 - 3*p2 + p3, 2*p0 - 5*p1 + 4*p2 - p3, -p0 + p2
            result.append(.5 * (((a * t + b) * t + c) * t + 2*p1))
        return tuple(result)

    def sample(self, distance):
        bounded = distance % self.length
        upper = bisect.bisect_left(self.distances, bounded)
        if upper < len(self.distances) and self.distances[upper] == bounded:
            parameter = upper / 128
        else:
            lower = max(0, upper - 1)
            upper = min(upper, len(self.distances) - 1)
            parameter = (lower + (bounded - self.distances[lower]) /
                         (self.distances[upper] - self.distances[lower])) / 128
        segment = min(int(parameter), len(self.points) - 1)
        t = parameter - segment
        tangent = []
        for key in ("X", "Y", "Z"):
            p0, p1, p2, p3 = self.components(segment, key)
            a, b = -p0 + 3*p1 - 3*p2 + p3, 2*p0 - 5*p1 + 4*p2 - p3
            tangent.append(.5 * ((3*a*t + 2*b)*t - p0 + p2))
        forward = normalize(tangent)
        horizontal = (forward[2], 0, -forward[0])
        right = normalize(horizontal) if math.hypot(forward[0], forward[2]) >= 1e-6 else normalize(add((1, 0, 0), scale(forward, -forward[0])))
        up = normalize(cross(forward, right))
        start, end = self.points[segment]["Bank"], self.points[(segment + 1) % len(self.points)]["Bank"]
        bank = math.radians(angular(angular(start) + angular(angular(end) - angular(start)) * t))
        return self.position(segment, t), add(scale(right, math.cos(bank)), scale(up, math.sin(bank))), \
            add(scale(up, math.cos(bank)), scale(right, -math.sin(bank))), forward, segment


class SavedBlocks:
    def __init__(self, world, track):
        xs, zs = [p["X"] for p in track.points], [p["Z"] for p in track.points]
        min_x, max_x = math.floor(min(xs) - 40) >> 4, math.floor(max(xs) + 40) >> 4
        min_z, max_z = math.floor(min(zs) - 40) >> 4, math.floor(max(zs) + 40) >> 4
        self.chunks = {}
        for chunk in SAVE.region_chunks(world / "region"):
            x, z = chunk["xPos"], chunk["zPos"]
            if min_x <= x <= max_x and min_z <= z <= max_z:
                self.chunks[x, z] = (bool(chunk.get("isLightOn")), {s["Y"]: s for s in chunk.get("sections", [])})
        self.missing = set()

    def section(self, pos):
        x, y, z = pos
        chunk = self.chunks.get((x >> 4, z >> 4))
        if chunk is None:
            self.missing.add((x >> 4, z >> 4))
            return False, None
        return chunk[0], chunk[1].get(y >> 4)

    def state(self, pos):
        _, section = self.section(pos)
        if section is None:
            return None
        states = section.get("block_states", {})
        palette = states.get("palette", [{"Name": "minecraft:air"}])
        if len(palette) == 1:
            return palette[0]
        bits = max(4, (len(palette) - 1).bit_length())
        per_long = 64 // bits
        index = ((pos[1] & 15) << 8) | ((pos[2] & 15) << 4) | (pos[0] & 15)
        word = states["data"][index // per_long] & ((1 << 64) - 1)
        return palette[(word >> ((index % per_long) * bits)) & ((1 << bits) - 1)]

    def light(self, pos, layer):
        lit, section = self.section(pos)
        if not lit or section is None:
            return None
        data = section.get(layer)
        # Omitted block-light storage denotes all-zero. Skylight omission may
        # require runtime section inheritance, so report unknown, never invent15.
        if data is None:
            return 0 if layer == "BlockLight" else None
        if len(data) != 2048:
            raise ValueError("Malformed saved light nibble array")
        index = ((pos[1] & 15) << 8) | ((pos[2] & 15) << 4) | (pos[0] & 15)
        return (data[index // 2] >> (4 * (index & 1))) & 15


def light_distribution(values):
    known = sorted(v for v in values if v is not None)
    histogram = Counter(known)
    return {"count": len(values), "known": len(known), "unknown": len(values) - len(known),
            "histogram_0_to_15": [histogram[i] for i in range(16)],
            "mean": sum(known) / len(known) if known else None,
            "p50": known[(len(known) - 1) // 2] if known else None,
            "p90": known[math.floor((len(known) - 1) * .9)] if known else None,
            "fraction_0_to_3": sum(v <= 3 for v in known) / len(known) if known else None,
            "fraction_at_least_8": sum(v >= 8 for v in known) / len(known) if known else None}


def underground_tunnel(anchor):
    x, y, z = anchor
    for rx, ry, rz, hx, hy, hz in ROOMS:
        # Keep chamber joints in the audit. The original expanded-room cutoff
        # skipped exactly those transition areas; only deep room interiors are
        # intentional broad chambers exempt from the tunnel enclosure probe.
        if ((x-rx)/max(1, hx-5))**2 + ((y-ry)/max(1, hy-5))**2 + ((z-rz)/max(1, hz-5))**2 <= 1:
            return False
    radius = math.hypot(x - .5, z - .5)
    surface = math.floor(max(64, min(174, 174 - 110 * radius**2 / 140**2 + 5 * math.exp(-((radius-28)/7)**2))))
    return y < surface - 6


def body_boxes(anchor, right, up, forward):
    corners = [add(add(add(anchor, scale(right, x)), scale(up, y)), scale(forward, z))
               for x, y, z in itertools.product((-.9, .9), (-.05, 1.2), (-1.5, 1.5))]
    yield tuple(min(p[i] for p in corners) for i in range(3)), tuple(max(p[i] for p in corners) for i in range(3))
    for seat in (-.45, .45):
        feet = add(add(anchor, scale(right, seat)), scale(up, .45))
        yield (feet[0] - .3, feet[1], feet[2] - .3), (feet[0] + .3, feet[1] + 1.8, feet[2] + .3)


def identity(inventory):
    return {"courses": [{"id": c["id"], "station": c["station"], "closed": c["closed"],
                         "vehicle_id": c["vehicle_id"], "controller_position": c["controller_position"],
                         "geometry": [{k: p[k] for k in ("X", "Y", "Z", "Bank")} for p in c["points"]]}
                        for c in inventory["courses"]],
            "vehicles": [{k: v[k] for k in ("id", "course_id", "leader_id", "car_index", "car_count", "spacing",
                                           "position", "distance", "speed", "running", "passenger_count", "follower_ids")}
                         for v in inventory["vehicles"]]}


def audit(world, step):
    inventory = SAVE.inspect_world(world)
    if len(inventory["courses"]) != 1 or not inventory["courses"][0]["closed"]:
        raise ValueError("Expected one closed saved attraction")
    track = SavedSpline(inventory["courses"][0]["points"])
    blocks = SavedBlocks(world, track)
    lights = {name: {"BlockLight": [], "SkyLight": []} for _, name in STAGES}
    candidates = {}
    gaps = {name: [] for name in ("left", "right", "ceiling")}
    samples = []
    sample_count = math.ceil(track.length / step)
    for i in range(sample_count):
        distance = i * step
        anchor, right, up, forward, segment = track.sample(distance)
        stage = next(name for index, name in reversed(STAGES) if segment >= index)
        eyes = [add(add(add(anchor, scale(right, seat)), scale(up, .45)), (0, 1.62, 0)) for seat in (-.45, .45)]
        eye_light = []
        for eye in eyes:
            pos = tuple(math.floor(v) for v in eye)
            row = {layer: blocks.light(pos, layer) for layer in ("BlockLight", "SkyLight")}
            eye_light.append({"block_position": pos, **row})
            for layer, value in row.items():
                lights[stage][layer].append(value)
        for low, high in body_boxes(anchor, right, up, forward):
            for pos in itertools.product(*(range(math.floor(a), math.floor(b - 1e-7) + 1) for a, b in zip(low, high))):
                state = blocks.state(pos)
                if state is not None and state["Name"] not in PASSABLE:
                    candidates.setdefault(pos, {"position": pos, "state": state, "first_distance": distance})
        tunnel = underground_tunnel(anchor)
        shell = {}
        if tunnel:
            for name, direction in (("left", scale(right, -1)), ("right", right), ("ceiling", up)):
                found = None
                for ray_step in range(3, 33):
                    pos = tuple(math.floor(v) for v in add(eyes[0], scale(direction, ray_step)))
                    state = blocks.state(pos)
                    if state is not None and state["Name"] not in PASSABLE:
                        found = ray_step
                        break
                shell[name] = found
                if found is None:
                    gaps[name].append(distance)
        samples.append({"distance": distance, "segment": segment, "stage": stage, "anchor": anchor,
                        "seat_eyes": eye_light, "planned_underground_tunnel": tunnel, "first_non_air_shell_distance": shell})
    runs = {}
    for name, distances in gaps.items():
        ranges = []
        for distance in distances:
            if ranges and distance - ranges[-1]["end"] <= step * 1.01:
                ranges[-1]["end"] = distance
                ranges[-1]["length"] += step
            else:
                ranges.append({"start": distance, "end": distance, "length": step})
        runs[name] = {"sample_count": len(distances), "total_length": len(distances) * step,
                      "longest_run": max((r["length"] for r in ranges), default=0), "runs": ranges}
    fixed = identity(inventory)
    return {"audit_format": 1, "world": str(world), "course_id": inventory["courses"][0]["id"], "length": track.length,
            "sample_spacing": step, "samples": sample_count,
            "geometry_and_train_identity": fixed,
            "identity_sha256": hashlib.sha256(json.dumps(fixed, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
            "point_distances": [track.distances[i * 128] for i in range(len(track.points))],
            "speed_profile": [{"segment": i, "kind": p["Kind"], "target_speed": p["TargetSpeed"]} for i, p in enumerate(track.points)],
            "seat_eye_saved_lighting": {name: {layer: light_distribution(values) for layer, values in rows.items()} for name, rows in lights.items()},
            "clearance_nbt_candidates": {"count": len(candidates), "blocks": list(candidates.values())},
            "planned_tunnel_shell_gap_candidates": runs,
            "missing_chunks": sorted(blocks.missing), "inventory_ready": inventory["ready"],
            "limitations": ["NBT blocks cannot reproduce Forge collision voxel shapes: candidates require live canUseTrackSample/full-lap validation.",
                            "Shell rays include chamber joints but exclude deep room interiors/outdoor track. A missing block within32 may be an intentional view; candidates do not prove an unintended hole.",
                            "Saved SKY arrays can be absent and need runtime section inheritance; those samples remain unknown.",
                            "Light15 or improved brightness does not prove that the rider can see a particular cave landmark; human scene inspection remains necessary.",
                            "This spatially uniform sample is not time weighted; live validator lighting uses normal tick exposure."],
            "route_samples": samples}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--compare", type=Path, help="Earlier JSON audit; require unchanged geometry and parked train identity")
    parser.add_argument("--step", type=float, default=.5)
    args = parser.parse_args()
    try:
        if not .1 <= args.step <= 4 or not math.isfinite(args.step):
            raise ValueError("Sample step must be .1..4 blocks")
        world = args.world.resolve()
        if args.output.resolve().is_relative_to(world):
            raise ValueError("Audit output must stay outside the read-only saved world")
        with SAVE.stable_save(world):
            report = audit(world, args.step)
        if args.compare:
            before = json.loads(args.compare.read_text())
            report["comparison"] = {"same_geometry_and_train_identity": before["geometry_and_train_identity"] == report["geometry_and_train_identity"],
                                    "length_difference": report["length"] - before["length"],
                                    "clearance_candidates_before": before["clearance_nbt_candidates"]["count"],
                                    "clearance_candidates_after": report["clearance_nbt_candidates"]["count"],
                                    "shell_gaps_before": before["planned_tunnel_shell_gap_candidates"]}
        args.output.parent.mkdir(parents=True, exist_ok=True)
        temporary = args.output.with_suffix(args.output.suffix + ".tmp")
        temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
        temporary.replace(args.output)
        summary = {k: v for k, v in report.items() if k not in ("route_samples", "geometry_and_train_identity", "point_distances", "speed_profile")}
        print(json.dumps(summary, ensure_ascii=False, indent=2))
        return 1 if args.compare and not report["comparison"]["same_geometry_and_train_identity"] else 0
    except (OSError, ValueError, KeyError, IndexError) as error:
        print(json.dumps({"error": str(error)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
