#!/usr/bin/env bash
set -euo pipefail
COASTER_PROJECT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$COASTER_PROJECT"
if [[ -n "${JAVA_HOME:-}" ]]; then
    COASTER_JAVA="$JAVA_HOME/bin/java"
    COASTER_JAVAC="$JAVA_HOME/bin/javac"
else
    COASTER_JAVA="$(command -v java)"
    COASTER_JAVAC="$(command -v javac)"
fi
if ! "$COASTER_JAVA" -version 2>&1 | head -n 1 | grep -Eq 'version "17\.'; then
    printf '%s\n' 'Use Java 17: set JAVA_HOME to a verified JDK 17 installation.' >&2
    exit 1
fi
COASTER_TOOLS="$COASTER_PROJECT/build/standalone-tools"
mkdir -p "$COASTER_TOOLS"
COASTER_JUNIT="$COASTER_TOOLS/junit-platform-console-standalone-1.10.3.jar"
# Published Maven Central SHA-512, independently verified during onboarding.
COASTER_SHA512=8d6c2c2ab55a637606db8f5bcb5a3086fe7075cb9afe7407a38cd78d5c0ca14ee1526ded000e9516a069766f88ac71deb33c0e9df7e6746e4a92004310d49592
if [[ ! -f "$COASTER_JUNIT" ]]; then
    curl --fail --location --retry 2 --output "$COASTER_JUNIT.download" \
        https://repo.maven.apache.org/maven2/org/junit/platform/junit-platform-console-standalone/1.10.3/junit-platform-console-standalone-1.10.3.jar
    printf '%s  %s\n' "$COASTER_SHA512" "$COASTER_JUNIT.download" | sha512sum --check --strict
    mv "$COASTER_JUNIT.download" "$COASTER_JUNIT"
fi
printf '%s  %s\n' "$COASTER_SHA512" "$COASTER_JUNIT" | sha512sum --check --strict
COASTER_RUN="$(mktemp -d "$COASTER_PROJECT/build/track-validation.XXXXXX")"
mkdir -p "$COASTER_RUN/classes" "$COASTER_RUN/reports"
"$COASTER_JAVAC" --release 17 -encoding UTF-8 -cp "$COASTER_JUNIT" -d "$COASTER_RUN/classes" \
    src/main/java/dev/coasterengineering/track/*.java \
    src/test/java/dev/coasterengineering/track/*.java
"$COASTER_JAVA" -jar "$COASTER_JUNIT" execute \
    --class-path "$COASTER_RUN/classes" --select-package dev.coasterengineering.track \
    --fail-if-no-tests --disable-ansi-colors --reports-dir "$COASTER_RUN/reports"
printf 'Current run reports: %s/reports\n' "$COASTER_RUN"
