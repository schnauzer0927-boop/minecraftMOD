#!/usr/bin/env python3
"""Generate wholly original Coaster Engineering music/effects without audio samples.

Requires Python 3.12+ standard library and FFmpeg with libvorbis (validated with
FFmpeg 7.1.5). All oscillators, arrangements and seeded noise are defined here.
PCM is deterministic; bitexact Ogg/Vorbis output is checked within the installed
encoder version. Run --verify-only to validate the committed assets independently.
"""

from __future__ import annotations

import argparse
import array
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
import random
import shutil
import struct
import subprocess
import sys
import tempfile
import wave

RATE = 32_000
TAU = math.tau
REPO = Path(__file__).resolve().parent.parent


@dataclass(frozen=True)
class Clip:
    event: str
    path: str
    duration: float
    seed: int
    peak: float
    music: bool = False
    loop: bool = False
    target_rms_dbfs: float | None = None


CLIPS = (
    Clip("music.research", "music/research", 24.0, 1701201, .60, True, True, -18),
    Clip("music.abyss", "music/abyss", 24.0, 1701202, .60, True, True, -18),
    Clip("music.escape", "music/escape", 24.0, 1701203, .60, True, True, -18),
    Clip("coaster.launch", "coaster/launch", 2.0, 1701204, .16),
    Clip("coaster.brake", "coaster/brake", 1.2, 1701205, .14),
    Clip("coaster.alarm", "coaster/alarm", 2.4, 1701206, .12),
    Clip("abyss.monster", "abyss/monster", 2.8, 1701207, .16),
    Clip("coaster.wind", "coaster/wind", 4.0, 1701208, .28, False, True, -24),
    Clip("coaster.wheels", "coaster/wheels", 4.0, 1701209, .28, False, True, -24),
)


def envelope(t: float, duration: float, attack: float, release: float) -> float:
    if t < 0 or t >= duration:
        return 0.0
    attack_gain = math.sin(min(1.0, t / attack) * math.pi / 2) ** 2
    release_gain = math.sin(min(1.0, (duration - t) / release) * math.pi / 2) ** 2
    return attack_gain * release_gain


def frequency(note: int) -> float:
    # Align pad oscillators to the 24-second loop; tuning change is under .021 Hz.
    return round((440 * 2 ** ((note - 69) / 12)) * 24) / 24


ARRANGEMENTS = {
    "music.research": {
        "chords": ((50, 53, 57), (46, 50, 53), (53, 57, 60), (48, 52, 55)),
        "motif": (74, 77, 81, 77, 72, 76, 79, 76, 77, 81, 84, 81, 72, 76, 79, 76),
        "pad": .55, "lead": .34, "drum": .2,
    },
    "music.abyss": {
        "chords": ((45, 48, 52), (41, 45, 48), (43, 47, 50), (40, 44, 47)),
        "motif": (69, 72, 76, 72, 65, 69, 72, 69, 67, 71, 74, 71, 64, 68, 71, 68),
        "pad": .72, "lead": .19, "drum": .08,
    },
    "music.escape": {
        "chords": ((50, 54, 57), (55, 59, 62), (57, 61, 64), (52, 55, 59)),
        "motif": (74, 78, 81, 86, 79, 83, 86, 83, 81, 85, 88, 85, 76, 79, 83, 79),
        "pad": .5, "lead": .32, "drum": .26,
    },
}


def render_music(clip: Clip) -> tuple[list[float], list[float]]:
    arrangement = ARRANGEMENTS[clip.event]
    rng = random.Random(clip.seed)
    left, right = [], []
    beat = .75  # 80 BPM, eight bars, exactly 24 seconds.
    frames = round(clip.duration * RATE)
    # Render one circular motif first: delayed notes at the beginning come from
    # the end of the same loop rather than from an initially empty delay buffer.
    lead_history = []
    for i in range(frames):
        t = i / RATE
        step, local = int(t / beat), t % beat
        note = arrangement["motif"][(step // 2) % 16]
        gain = envelope(local, beat, .045, .3) * math.exp(-2.4 * local)
        phase = TAU * frequency(note) * local
        lead_history.append((math.sin(phase) + .1 * math.sin(phase * 3)) * gain * .08 * arrangement["lead"])
    filtered_noise = 0.0
    for i in range(frames):
        t = i / RATE
        chord_index = min(3, int(t // 6))
        chord_t = t % 6
        chord = arrangement["chords"][chord_index]
        previous_chord = arrangement["chords"][(chord_index - 1) % 4]
        # Sustain through the loop boundary and overlap adjacent chords with a
        # smooth crossfade. Quantized oscillator periods join exactly at 24 s.
        blend = .5 - .5 * math.cos(math.pi * min(1.0, chord_t / .7))
        pad_l = pad_r = 0.0
        for notes, weight in ((previous_chord, 1 - blend), (chord, blend)):
            for note in notes:
                phase = TAU * frequency(note) * t
                pad_l += (math.sin(phase) + .16 * math.sin(phase * 2)) * weight
                pad_r += (math.sin(phase + .12) + .16 * math.sin(phase * 2 + .2)) * weight
        pad_l *= .027 * arrangement["pad"]
        pad_r *= .027 * arrangement["pad"]

        step = int(t / beat)
        local = t % beat
        lead = lead_history[i]
        echo_left = lead_history[(i - 12_000) % frames] * .23
        echo_right = lead_history[(i - 18_000) % frames] * .2
        pan = .5 + .22 * math.sin(TAU * step / 16)

        bass = math.sin(TAU * frequency(chord[0] - 12) * t) * .045 * envelope(local, beat, .035, .25)
        kick_t = t % 1.5
        kick_phase = TAU * (48 * kick_t + 18 * (1 - math.exp(-14 * kick_t)) / 14)
        kick = math.sin(kick_phase) * math.exp(-15 * kick_t) * min(1.0, kick_t / .008)
        filtered_noise = .85 * filtered_noise + .15 * rng.uniform(-1, 1)
        shaker_t = t % .375
        shaker = filtered_noise * envelope(shaker_t, .12, .006, .03) * .04
        rhythm = (kick * .028 + shaker) * arrangement["drum"]
        left.append(pad_l + bass + rhythm + lead * (1 - pan) + echo_left)
        right.append(pad_r + bass + rhythm + lead * pan + echo_right)
    return left, right


def render_motion(clip: Clip) -> tuple[list[float], None]:
    """Quiet circular noise/rumble textures, without recordings or sharp clicks."""
    rng = random.Random(clip.seed)
    frames = round(clip.duration * RATE)
    noise = [rng.uniform(-1, 1) for _ in range(frames)]
    low = 0.0
    # Repeating the input settles the low-pass filter into its periodic state.
    filtered = []
    smoothing = .985 if clip.event == "coaster.wheels" else .88
    for cycle in range(2):
        for value in noise:
            low = smoothing * low + (1 - smoothing) * value
            if cycle: filtered.append(low)
    values = []
    for i, low in enumerate(filtered):
        t = i / RATE
        if clip.event == "coaster.wind":
            # Slow periodic air pressure, a soft band of air and no harsh hiss.
            flutter = .8 + .1 * math.sin(TAU * .5 * t) + .1 * math.sin(TAU * 1.25 * t)
            value = low * flutter + .03 * math.sin(TAU * 43 * t)
        else:
            rotation = .75 + .25 * math.cos(TAU * 8 * t)
            value = .035 * math.sin(TAU * 57 * t) + .012 * math.sin(TAU * 114 * t)
            value += low * .48 * rotation
        values.append(value)
    dc = sum(values) / len(values)
    return [value - dc for value in values], None


def render_effect(clip: Clip) -> tuple[list[float], None]:
    rng = random.Random(clip.seed)
    values = []
    low_noise = 0.0
    for i in range(round(clip.duration * RATE)):
        t = i / RATE
        low_noise = .96 * low_noise + .04 * rng.uniform(-1, 1)
        if clip.event == "coaster.launch":
            phase = TAU * (85 * t + 75 * t * t)
            value = .055 * math.sin(phase) + .07 * low_noise * (t / clip.duration)
            tone_t = t % .25
            note = (50, 53, 57, 62, 65, 69, 74, 77)[min(7, int(t / .25))]
            value += .03 * math.sin(TAU * frequency(note) * tone_t) * envelope(tone_t, .25, .015, .08)
            value *= envelope(t, clip.duration, .1, .35)
        elif clip.event == "coaster.brake":
            phase = TAU * (200 * t - 55 * t * t)
            value = (.025 * math.sin(phase) + .09 * low_noise) * envelope(t, clip.duration, .06, .45)
        elif clip.event == "coaster.alarm":
            pulse_t = t % .8
            pitch = 660 if int(t / .8) % 2 == 0 else 792
            value = (.065 * math.sin(TAU * pitch * pulse_t)
                     + .007 * math.sin(TAU * pitch * 2 * pulse_t)) * envelope(pulse_t, .38, .035, .08)
        else:
            phase = TAU * (46 * t + 4 * t * t)
            growl = math.sin(phase) + .3 * math.sin(phase * 2.03) + .15 * math.sin(phase * 3.01)
            value = (.045 * growl * (.8 + .2 * math.sin(TAU * 3 * t))
                     + .08 * low_noise) * envelope(t, clip.duration, .3, .65)
        values.append(value)
    return values, None


def write_wav(path: Path, clip: Clip) -> str:
    left, right = render_music(clip) if clip.music else render_motion(clip) if clip.loop else render_effect(clip)
    peak = max(max(map(abs, left)), max(map(abs, right)) if right is not None else 0)
    gain = clip.peak / peak
    if clip.target_rms_dbfs is not None:
        square_sum = sum(x * x for x in left) + (sum(x * x for x in right) if right is not None else 0)
        count = len(left) * (2 if right is not None else 1)
        rms = math.sqrt(square_sum / count)
        # RMS normalization with a conservative peak ceiling; no clipping or
        # compression is needed and every user's Minecraft sliders still apply.
        gain = min(gain, 10 ** (clip.target_rms_dbfs / 20) / rms)
    pcm = bytearray()
    if right is None:
        for sample in left:
            pcm.extend(struct.pack("<h", round(max(-1, min(1, sample * gain)) * 32767)))
    else:
        for a, b in zip(left, right):
            pcm.extend(struct.pack("<hh", round(a * gain * 32767), round(b * gain * 32767)))
    with wave.open(str(path), "wb") as wav:
        wav.setnchannels(2 if clip.music else 1)
        wav.setsampwidth(2)
        wav.setframerate(RATE)
        wav.writeframes(pcm)
    return hashlib.sha256(pcm).hexdigest()


def encode(ffmpeg: str, wav: Path, destination: Path) -> None:
    subprocess.run((ffmpeg, "-hide_banner", "-loglevel", "error", "-y", "-i", str(wav),
                    "-map_metadata", "-1", "-c:a", "libvorbis", "-q:a", "4",
                    "-fflags", "+bitexact", "-flags:a", "+bitexact", "-serial_offset", "0", str(destination)), check=True)


def verify(ffmpeg: str, ffprobe: str, path: Path, clip: Clip) -> dict:
    metadata = json.loads(subprocess.check_output((ffprobe, "-v", "error", "-show_streams", "-show_format",
                                                  "-of", "json", str(path)), text=True))
    stream = metadata["streams"][0]
    duration = float(metadata["format"]["duration"])
    channels = int(stream["channels"])
    assert stream["codec_name"] == "vorbis" and int(stream["sample_rate"]) == RATE, path
    assert channels == (2 if clip.music else 1) and abs(duration - clip.duration) < .002, path
    raw = subprocess.check_output((ffmpeg, "-hide_banner", "-loglevel", "error", "-i", str(path),
                                   "-f", "s16le", "-acodec", "pcm_s16le", "pipe:1"))
    decoded = array.array("h", raw)
    if sys.byteorder != "little":
        decoded.byteswap()
    peak = max(abs(x) for x in decoded) / 32768
    rms = math.sqrt(sum((x / 32768) ** 2 for x in decoded) / len(decoded))
    rms_dbfs = 20 * math.log10(rms)
    edge_count = round(.04 * RATE) * channels
    boundary = list(decoded[:edge_count]) + list(decoded[-edge_count:])
    boundary_rms = math.sqrt(sum((x / 32768) ** 2 for x in boundary) / len(boundary))
    seam = max(abs(decoded[c] - decoded[-channels + c]) / 32768 for c in range(channels))
    derivative_error = max(abs((decoded[c] - decoded[-channels + c])
                               - (decoded[channels + c] - decoded[c])) / 32768 for c in range(channels))
    assert peak < clip.peak * 1.2 + .01, f"Unexpected loud/clipped asset: {path}: {peak}"
    if clip.target_rms_dbfs is not None:
        assert abs(rms_dbfs - clip.target_rms_dbfs) < 1, f"RMS normalization drift: {path}: {rms_dbfs}"
    if clip.loop:
        # Continuous music is allowed its ordinary adjacent-sample slope. A
        # quiet boundary is not forced: check the join and derivative separately.
        assert seam < (.03 if clip.music else .12), f"Loop boundary jump too large: {path}: {seam}"
        assert derivative_error < (.02 if clip.music else .18), f"Loop slope discontinuity: {path}: {derivative_error}"
    return {"event": clip.event, "file": str(path.relative_to(REPO)) if path.is_relative_to(REPO) else str(path),
            "seconds": duration, "channels": channels, "sample_rate": RATE, "codec": "vorbis",
            "bytes": path.stat().st_size, "peak": round(peak, 6), "rms_dbfs": round(rms_dbfs, 2),
            "loop_boundary_jump": round(seam, 8), "loop_derivative_error": round(derivative_error, 8),
            "boundary_40ms_rms_dbfs": round(20 * math.log10(boundary_rms), 2),
            "loop": clip.loop, "target_rms_dbfs": clip.target_rms_dbfs,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--output", type=Path, default=REPO / "src/main/resources/assets/coasterengineering/sounds")
    parser.add_argument("--report", type=Path, default=REPO / "build/audio-generation.txt")
    args = parser.parse_args()
    ffmpeg, ffprobe = shutil.which("ffmpeg"), shutil.which("ffprobe")
    if not ffmpeg or not ffprobe:
        raise SystemExit("FFmpeg and ffprobe with libvorbis are required; no Python packages are needed.")
    records = []
    with tempfile.TemporaryDirectory(prefix="coaster-original-audio-") as temporary:
        temporary = Path(temporary)
        for clip in CLIPS:
            destination = args.output / (clip.path + ".ogg")
            pcm_hash = None
            if not args.verify_only:
                destination.parent.mkdir(parents=True, exist_ok=True)
                wav = temporary / "source.wav"
                pcm_hash = write_wav(wav, clip)
                encode(ffmpeg, wav, destination)
                # Check container serial numbers and encoder output are reproducible.
                second = temporary / "repeat.ogg"
                encode(ffmpeg, wav, second)
                assert destination.read_bytes() == second.read_bytes(), "Encoder output was not reproducible"
            record = verify(ffmpeg, ffprobe, destination, clip)
            if pcm_hash:
                record["source_pcm_sha256"] = pcm_hash
                record["repeat_encode_identical"] = True
            records.append(record)
            print(f"{clip.event}: {record['seconds']:.1f}s, {record['bytes']} bytes, RMS {record['rms_dbfs']} dBFS", flush=True)
    if not args.verify_only:
        definitions = {clip.event: {"sounds": [{"name": "coasterengineering:" + clip.path,
                                                "stream": clip.music}]} for clip in CLIPS}
        (args.output.parent / "sounds.json").write_text(json.dumps(definitions, indent=2) + "\n")
    args.report.parent.mkdir(parents=True, exist_ok=True)
    report = {"provenance": "Wholly original mathematical synthesis and seeded noise; no recordings or sample libraries.",
              "python": sys.version.split()[0],
              "ffmpeg": subprocess.check_output((ffmpeg, "-version"), text=True).splitlines()[0],
              "verification": "Vorbis codec, duration, sample rate, channels, decoded peak and loop boundary checked.",
              "loop_note": "Music uses circular delayed melodies and sustained crossfading chords: no forced silent loop boundary. Wind/wheels are periodic filtered synthesis. Runtime playback requires a Minecraft client.",
              "total_bytes": sum(record["bytes"] for record in records), "clips": records}
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(f"Validated {len(records)} original assets; total {report['total_bytes']} bytes. Report: {args.report}")


if __name__ == "__main__":
    main()
