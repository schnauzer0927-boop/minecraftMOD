#!/usr/bin/env python3
"""Run the real installed Forge server, optionally upgrade, then commission and save.

This observes actual server log events and normal entity ticks. It does not edit
NBT, substitute simulated motion, or manufacture a successful test result.
"""
import argparse
import json
from pathlib import Path
import queue
import subprocess
import threading
import time

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--server", required=True, type=Path)
parser.add_argument("--log", required=True, type=Path)
parser.add_argument("--result", required=True, type=Path)
parser.add_argument("--upgrade", action="store_true")
args = parser.parse_args()
runtime = args.server.resolve()
args.log.parent.mkdir(parents=True, exist_ok=True)
process = subprocess.Popen(["./run.sh", "nogui"], cwd=runtime, stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
pending_lines = queue.Queue()

def read_output():
    for line in process.stdout:
        pending_lines.put(line)

reader = threading.Thread(target=read_output, daemon=True)
reader.start()
started = time.monotonic()
result = {"ready": False, "quality_completed": False, "ride_passed": False, "normal_shutdown": False}
stopping = False

def send(command):
    process.stdin.write(command + "\n")
    process.stdin.flush()

def stop():
    global stopping
    if not stopping:
        stopping = True
        send("save-all flush")
        send("stop")

with args.log.open("w") as log:
    while process.poll() is None:
        if time.monotonic() - started > 360:
            result["failure"] = "Timed out after 360 real seconds"
            stop()
        try:
            line = pending_lines.get(timeout=.25)
        except queue.Empty:
            continue
        if line:
            log.write(line)
            log.flush()
            if "Done (" in line and not result["ready"]:
                result["ready"] = True
                send("coaster upgrade volcano" if args.upgrade else "coaster validate 61da851c-7705-3a82-b7b3-2e2e8ee296b4")
            if "VOLCANIC_QUALITY_COMPLETED" in line:
                result["quality_completed"] = True
                result["quality_report"] = line.strip()
                send("coaster validate 61da851c-7705-3a82-b7b3-2e2e8ee296b4")
            if "COASTER_RIDE_LIGHTING " in line:
                result["live_seat_lighting"] = json.loads(line.split("COASTER_RIDE_LIGHTING ", 1)[1])
            if "VOLCANIC_RIDE_VALIDATED PASSED" in line:
                result["ride_passed"] = True
                result["ride_report"] = line.strip()
                stop()
            if "VOLCANIC_QUALITY_FAILED" in line or "VOLCANIC_RIDE_VALIDATION_FAILED" in line:
                result["failure"] = line.strip()
                stop()
    reader.join(timeout=2)
    while not pending_lines.empty():
        log.write(pending_lines.get_nowait())
result["exit_code"] = process.wait()
result["normal_shutdown"] = result["exit_code"] == 0 and stopping
result["elapsed_wall_seconds"] = round(time.monotonic() - started, 2)
result["passed"] = "failure" not in result and result["ready"] and result["ride_passed"] and result["normal_shutdown"] and (not args.upgrade or result["quality_completed"])
args.result.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k != "live_seat_lighting"}, ensure_ascii=False, indent=2))
raise SystemExit(0 if result["passed"] else 1)
