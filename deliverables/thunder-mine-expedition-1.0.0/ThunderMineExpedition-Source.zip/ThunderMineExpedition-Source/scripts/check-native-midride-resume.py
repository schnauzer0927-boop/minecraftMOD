#!/usr/bin/env python3
"""Commission an already-made SEPARATE world copy through normal server save/reboot/resume."""
import argparse, hashlib, importlib.util, json, os, queue, re, subprocess, threading, time
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
JAVA_BIN = Path('/workspace/.tools/thunder-mine-java21/extracted/usr/lib/jvm/java-21-openjdk-amd64/bin')
spec = importlib.util.spec_from_file_location('native_evidence', BASE/'scripts/extract-native-ride-evidence.py')
evidence = importlib.util.module_from_spec(spec); spec.loader.exec_module(evidence)


def stage(server, path, mode, run_id=None):
    env = dict(os.environ); env['PATH'] = str(JAVA_BIN) + os.pathsep + env.get('PATH', '')
    process = subprocess.Popen(['sh', 'run.sh', 'nogui'], cwd=server, env=env, stdin=subprocess.PIPE,
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    output = queue.Queue()
    def reader():
        for line in process.stdout: output.put(line)
        output.put(None)
    threading.Thread(target=reader, daemon=True).start()
    result = {'mode':mode, 'commands':[], 'samples':[], 'reload':None, 'resume':None, 'pass':None, 'failure':None, 'normal_stop':False}
    started = time.monotonic(); ready=False; saved=False; stop_sent=False; hold_started=None; hold_queries=0; cart=None
    def send(command):
        if process.poll() is not None: return
        process.stdin.write(command+'\n'); process.stdin.flush()
        result['commands'].append({'command':command,'seconds_after_launch':time.monotonic()-started})
        log.write('COMMAND_SENT '+command+'\n'); log.flush()
        print(mode+' command: '+command, flush=True)
    with path.open('w') as log:
        while time.monotonic()-started < 600:
            try: line=output.get(timeout=0.2)
            except queue.Empty:
                if process.poll() is not None: break
                line=''
            if line is None: break
            if line:
                log.write(line); log.flush()
                if 'Done (' in line and 'For help, type' in line:
                    ready=True; send('mine_world status')
                    if mode=='save-midride': send('mine_world start')
                match=evidence.MARKER.search(line)
                if match:
                    marker=match.group(1); fields=evidence.fields_of(line[match.end():])
                    if marker=='MINE_MAIN_RIDE_STARTED' and mode=='save-midride':
                        run_id=fields['run'];cart=fields['cart'];result['run_id']=run_id;result['cart_id']=cart
                    if marker=='MINE_MAIN_RELOAD':
                        result['reload']=fields;cart=fields.get('cart',cart)
                        if mode=='resume-midride':
                            hold_started=time.monotonic();send('mine_world status')
                            if cart:send('data get sub_level '+cart+' thunder_mine_expedition')
                    if marker=='MINE_MAIN_SAMPLE' and fields.get('run')==run_id:
                        result['samples'].append(fields)
                        if len(result['samples'])%10==0:print(mode+' elapsed='+str(fields.get('elapsed'))+' s='+str(fields.get('s'))+' phase='+str(fields.get('phase')),flush=True)
                        if mode=='save-midride' and fields.get('elapsed',0)>=50 and not saved:
                            saved=True;result['last_sample_before_save']=fields;send('mine_world status');send('save-all flush')
                    if marker=='MINE_MAIN_RIDE_RESUMED':
                        result['resume']=fields;run_id=fields['run'];result['run_id']=run_id;cart=fields['cart'];result['cart_id']=cart
                    if marker=='MINE_MAIN_RIDE_PASSED' and fields.get('run')==run_id:
                        result['pass']=fields;send('mine_world status');send('sable info '+fields['cart']);send('save-all flush');saved=True
                    if marker in evidence.FAILURE_MARKERS:
                        result['failure']={'marker':marker,'fields':fields};send('stop');stop_sent=True
                if 'Saved the game' in line and saved and not stop_sent:
                    send('stop');stop_sent=True
                if 'All dimensions are saved' in line: result['normal_stop']=True
                if 'Encountered an unexpected exception' in line:
                    result['failure']={'server_crash':line.strip()}
                if mode=='resume-midride' and ('has the following' in line or 'phase=INTERRUPTED' in line or 'Position:' in line or 'Velocity:' in line):
                    result.setdefault('hold_readbacks',[]).append({'seconds':time.monotonic()-started,'line':line.strip()})
            if mode=='resume-midride' and ready and hold_started is not None and result['resume'] is None and not stop_sent:
                held=time.monotonic()-hold_started
                if hold_queries==0 and held>=1:
                    send('sable info '+cart);hold_queries=1
                if hold_queries==1 and held>=11:
                    send('mine_world status');send('data get sub_level '+cart+' thunder_mine_expedition');send('sable info '+cart)
                    result['hold_wall_seconds_before_resume']=held;send('mine_world resume');hold_queries=2
        if process.poll() is None and not stop_sent: send('stop');stop_sent=True
        try:process.wait(timeout=50)
        except subprocess.TimeoutExpired: result['failure']={'stop_timeout':True};process.terminate();process.wait(timeout=10)
        # Drain all final output after normal server shutdown.
        while True:
            try:line=output.get_nowait()
            except queue.Empty:break
            if line is None:continue
            log.write(line)
            if 'All dimensions are saved' in line:result['normal_stop']=True
        result['exit_code']=process.returncode
        result['wall_seconds']=time.monotonic()-started
        if not ready:result['failure']={'server_never_ready':True}
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--server',required=True,type=Path);parser.add_argument('--evidence-dir',required=True,type=Path);args=parser.parse_args()
    server=args.server.resolve();args.evidence_dir.mkdir(parents=True,exist_ok=True)
    assert server.name=='run-mine-resume-check','Only the dedicated check copy may be run'
    jar=server/'mods/thunder-mine-tools-1.0.0.jar'
    assert hashlib.sha256(jar.read_bytes()).hexdigest()=='ed9c8555821b1a63a417506c82668d448837395f34c39e8b2e56fc708bc6ad6e','Expected immutable commissioned helper'
    first=stage(server,args.evidence_dir/'midride-before-save.log','save-midride')
    (args.evidence_dir/'midride-before-save.json').write_text(json.dumps(first,indent=2)+'\n')
    if first['failure'] or not first['normal_stop'] or not first.get('last_sample_before_save'):raise SystemExit('Initial ordinary midride save failed; restart test not performed')
    second=stage(server,args.evidence_dir/'midride-after-reload.log','resume-midride',first['run_id'])
    (args.evidence_dir/'midride-after-reload.json').write_text(json.dumps(second,indent=2)+'\n')
    report=evidence.extract([args.evidence_dir/'midride-before-save.log',args.evidence_dir/'midride-after-reload.log'],'main')
    report['resume_test_conditions']={'separate_world_copy':True,'ordinary_save_and_normal_stop':first['normal_stop'],'same_cart_uuid':first.get('cart_id')==second.get('cart_id'),'same_run_uuid':first.get('run_id')==second.get('run_id'),'held_before_resume_wall_seconds':second.get('hold_wall_seconds_before_resume'),'normal_stop_after_finish':second['normal_stop'],'gui_or_fake_player_used':False,'automatic_remount_resume_verified':False}
    (args.evidence_dir/'midride-resume-evidence.json').write_text(json.dumps(report,indent=2)+'\n')
    passed=report['evidence_accepted'] and second['normal_stop'] and first['cart_id']==second.get('cart_id') and first['run_id']==second.get('run_id')
    print('MIDRIDE RESUME '+('PASSED' if passed else 'FAILED/INCOMPLETE'),flush=True)
    raise SystemExit(0 if passed else 1)

if __name__=='__main__':main()
