#!/usr/bin/env python3
"""Read existing native-test logs and summarize explicit evidence; never fabricate a pass."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import re
import sys
from collections import Counter

MARKER = re.compile(r"\b(MINE_(?:MAIN|NATIVE|EFFECT|WORLD)_[A-Z_]+)\b")
KEY = re.compile(r"(?:^|\s)([A-Za-z][A-Za-z0-9_]*)=")
NUMBER = re.compile(r"^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$")
FLOAT_IN_VECTOR = re.compile(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?")
PASS_MARKERS = {"MINE_MAIN_RIDE_PASSED", "MINE_NATIVE_TEST_PASSED"}
FAILURE_MARKERS = {
    "MINE_MAIN_RIDE_FAILED", "MINE_MAIN_RESTORE_REFUSED", "MINE_MAIN_NATIVE_HOLD_FAILED",
    "MINE_NATIVE_TEST_FAILED", "MINE_NATIVE_RESTORE_REFUSED",
}


def atom(raw: str):
    raw = raw.strip()
    if raw in ("true", "false"):
        return raw == "true"
    if NUMBER.fullmatch(raw):
        value = float(raw)
        if not math.isfinite(value):
            return raw
        return int(value) if re.fullmatch(r"[+-]?\d+", raw) else value
    if raw.startswith("(") and raw.endswith(")"):
        values = FLOAT_IN_VECTOR.findall(raw)
        if len(values) in (3, 4):
            return [float(value) for value in values]
    return raw


def fields_of(message: str) -> dict:
    matches = list(KEY.finditer(message))
    result = {}
    for i, match in enumerate(matches):
        end = matches[i + 1].start() if i + 1 < len(matches) else len(message)
        result[match.group(1)] = atom(message[match.end():end])
    return result


def finite_number(value) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def pass_checks(marker: str, fields: dict) -> dict:
    distance = fields.get("measuredDistance" if marker.startswith("MINE_MAIN") else "measuredDistance3d")
    elapsed = fields.get("elapsedSeconds")
    laps = fields.get("laps")
    station = fields.get("stationDistance")
    held = fields.get("stationarySeconds")
    speed = fields.get("maxNativeSpeed")
    measured_speed = fields.get("maxMeasuredSpeed")
    checks = {
        "explicit_native_pass_marker": marker in PASS_MARKERS,
        "nonzero_actual_displacement": finite_number(distance) and distance > 0,
        "nonzero_simulated_elapsed_time": finite_number(elapsed) and elapsed > 0,
        "one_or_more_reported_laps": finite_number(laps) and laps >= 1,
        "station_distance_within_0_65_blocks": finite_number(station) and 0 <= station <= 0.65,
        "at_least_three_stationary_simulated_seconds": finite_number(held) and held >= 3.0,
        "nonzero_measured_and_native_max_speeds": finite_number(speed) and speed > 0 and finite_number(measured_speed) and measured_speed > 0,
        "zero_helper_pose_assignments_reported": fields.get("nativePoseAssignments") == 0,
        "average_measured_speed_not_above_reported_measured_max": (
            finite_number(distance) and finite_number(elapsed) and elapsed > 0
            and finite_number(measured_speed) and distance / elapsed <= measured_speed * 1.02
        ),
    }
    if marker.startswith("MINE_MAIN"):
        length = fields.get("nativeArcLength")
        checks["actual_distance_consistent_with_native_arc_laps"] = (
            finite_number(length) and length > 0 and finite_number(laps) and laps >= 1
            and finite_number(distance) and length * laps * 0.95 <= distance <= length * laps * 1.10 + 0.65
        )
    return checks


def extract(paths: list[Path], scope: str = "main") -> dict:
    events = []
    sources = []
    duplicates = 0
    seen = set()
    for path in paths:
        content = path.read_bytes()
        sources.append({"path": str(path.resolve()), "bytes_read": len(content), "sha256": hashlib.sha256(content).hexdigest()})
        for line_number, line in enumerate(content.decode("utf-8", errors="replace").splitlines(), 1):
            match = MARKER.search(line)
            if not match:
                continue
            marker = match.group(1)
            fields = fields_of(line[match.end():])
            signature = (marker, json.dumps(fields, sort_keys=True, ensure_ascii=False))
            if signature in seen:
                duplicates += 1
                continue
            seen.add(signature)
            events.append({"marker": marker, "fields": fields, "source": str(path.resolve()), "line": line_number})

    runs = {}
    active_by_cart = {}
    current_main = None
    cues = Counter()
    cue_executions = Counter()
    for event in events:
        marker, fields = event["marker"], event["fields"]
        run_id = fields.get("run")
        cart = fields.get("cart")
        if run_id:
            record = runs.setdefault(str(run_id), {
                "run_id": str(run_id), "cart_id": cart, "markers": Counter(), "samples": [],
                "passes": [], "failures": [], "resumes": [], "cue_triggers": Counter(), "cue_executions": Counter(),
            })
            record["markers"][marker] += 1
            if marker.startswith("MINE_MAIN") and cart:
                active_by_cart[str(cart)] = str(run_id)
                current_main = str(run_id)
            if marker in ("MINE_MAIN_SAMPLE", "MINE_NATIVE_SAMPLE"):
                record["samples"].append(event)
            if marker in PASS_MARKERS:
                checked = dict(event)
                checked["checks"] = pass_checks(marker, fields)
                checked["valid_reported_pass"] = all(checked["checks"].values())
                record["passes"].append(checked)
            if marker in FAILURE_MARKERS:
                record["failures"].append(event)
            if marker == "MINE_MAIN_RIDE_RESUMED":
                record["resumes"].append(event)
        if marker == "MINE_EFFECT_RUN_START" and cart:
            current_main = active_by_cart.get(str(cart), current_main)
        if marker == "MINE_EFFECT_TRIGGER":
            cue_id = str(fields.get("id", "unknown"))
            cues[cue_id] += 1
            if current_main in runs:
                runs[current_main]["cue_triggers"][cue_id] += 1
        if marker == "MINE_EFFECT_EXECUTE":
            cue_id = str(fields.get("id", "unknown"))
            cue_executions[cue_id] += 1
            if current_main in runs:
                runs[current_main]["cue_executions"][cue_id] += 1

    selected_runs = []
    valid_passes = []
    for record in runs.values():
        is_main = any(marker.startswith("MINE_MAIN") for marker in record["markers"])
        if scope == "main" and not is_main or scope == "test" and is_main:
            continue
        samples = record.pop("samples")
        record["sample_count"] = len(samples)
        record["seated_sample_count"] = sum(1 for event in samples if finite_number(event["fields"].get("seated")) and event["fields"]["seated"] > 0)
        record["engaged_sample_count"] = sum(1 for event in samples if event["fields"].get("engaged") is True)
        record["disengaged_sample_count"] = sum(1 for event in samples if event["fields"].get("engaged") is False)
        record["loaded_ahead_true_sample_count"] = sum(1 for event in samples if event["fields"].get("loadedAhead") is True)
        record["loaded_ahead_false_sample_count"] = sum(1 for event in samples if event["fields"].get("loadedAhead") is False)
        record["first_sample"] = samples[0] if samples else None
        record["last_sample"] = samples[-1] if samples else None
        record["observed_areas"] = sorted({str(event["fields"]["area"]) for event in samples if "area" in event["fields"]})
        for event in record["passes"]:
            if event["valid_reported_pass"]:
                valid_passes.append(event)
        selected_runs.append(record)

    def relevant(marker):
        return scope == "all" or scope == "main" and marker.startswith("MINE_MAIN") or scope == "test" and marker.startswith("MINE_NATIVE")

    failures = [event for event in events if event["marker"] in FAILURE_MARKERS and relevant(event["marker"])]
    reloads = [event for event in events if event["marker"] in ("MINE_MAIN_RELOAD", "MINE_NATIVE_RELOAD") and relevant(event["marker"])]
    resumes = [event for event in events if event["marker"] == "MINE_MAIN_RIDE_RESUMED" and relevant(event["marker"])]
    boarding = [event for event in events if event["marker"] in ("MINE_MAIN_BOARDING", "MINE_NATIVE_BOARDING") and relevant(event["marker"])]
    effect_failures = [event for event in events if event["marker"].startswith("MINE_EFFECT") and any(word in event["marker"] for word in ("FAILED", "REJECTED", "DISABLED"))]
    invalid_passes = [event for record in selected_runs for event in record["passes"] if not event["valid_reported_pass"]]
    problems = []
    if not valid_passes:
        problems.append("No explicit native PASS marker with complete, valid physical metrics was found for the requested scope.")
    if failures:
        problems.append("Native ride/restore/hold failure markers were present; review the attached records.")
    if invalid_passes:
        problems.append("One or more PASS markers had missing or inconsistent physical metrics.")
    return {
        "schema": 1, "scope": scope, "source_files": sources, "input_file_order": "as supplied; pass logs in chronological server-session order",
        "duplicate_records_ignored": duplicates, "evidence_accepted": not problems,
        "problems": problems, "explicit_valid_pass_count": len(valid_passes), "runs": selected_runs,
        "native_failure_records": failures, "reload_records": reloads, "resume_records": resumes,
        "boarding_records": boarding, "cue_trigger_counts": dict(cues), "cue_execution_counts": dict(cue_executions),
        "effect_failure_records": effect_failures,
        "verification_boundary": "Read-only extraction of existing log statements and measured values; it does not launch Minecraft or independently prove visuals, audio, player comfort, or missing tests.",
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("logs", nargs="+", type=Path)
    parser.add_argument("--scope", choices=("main", "test", "all"), default="main")
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        result = extract(args.logs, args.scope)
    except (OSError, ValueError) as error:
        print(f"Evidence extraction refused: {error}", file=sys.stderr)
        return 2
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"{'ACCEPTED' if result['evidence_accepted'] else 'INCOMPLETE/FAILED'}: {result['explicit_valid_pass_count']} explicit valid {args.scope} pass record(s); output={args.output}")
    return 0 if result["evidence_accepted"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
