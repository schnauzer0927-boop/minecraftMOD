#!/usr/bin/env bash
set -euo pipefail
COASTER_PROJECT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
COASTER_V2_SERVER="${1:-$COASTER_PROJECT/run-v2}"
mkdir -p "$COASTER_V2_SERVER"
if [[ -f "$COASTER_V2_SERVER/server.properties" || -e "$COASTER_V2_SERVER/Coaster World - Volcanic Abyss 2.0" ]]; then
    printf 'Existing directory retained: %s\n' "$COASTER_V2_SERVER"
    exit 0
fi
cat >"$COASTER_V2_SERVER/server.properties" <<'PROPERTIES'
level-name=Coaster World - Volcanic Abyss 2.0
level-seed=20261012
level-type=minecraft:flat
generator-settings={"layers":[{"block":"minecraft:bedrock","height":1},{"block":"minecraft:stone","height":124},{"block":"minecraft:dirt","height":2},{"block":"minecraft:grass_block","height":1}],"biome":"minecraft:plains","structures":{}}
generate-structures=false
gamemode=adventure
difficulty=peaceful
spawn-protection=0
online-mode=false
server-ip=127.0.0.1
server-port=25565
view-distance=14
simulation-distance=10
max-players=1
allow-flight=true
enable-command-block=false
enable-rcon=false
enable-query=false
max-tick-time=60000
PROPERTIES
printf 'eula=true\n' >"$COASTER_V2_SERVER/eula.txt"
printf 'Prepared new fixed-seed 2.0 local test world: %s\n' "$COASTER_V2_SERVER"
printf 'Run ./gradlew runServer -PcoasterServerDir=%s, then enter coaster volcano2.\n' "$COASTER_V2_SERVER"
