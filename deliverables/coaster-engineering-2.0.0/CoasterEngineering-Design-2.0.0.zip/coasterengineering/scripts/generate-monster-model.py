#!/usr/bin/env python3
"""Create the original VOLCANIC ABYSS puppet and editable Blockbench model.

The runtime geometry is the same world-up mesh as the .bbmodel. After editing
only cube bounds and group pivots in Blockbench, --from-bbmodel exports them
back to the runtime asset. Keep the named animation groups and box UVs.
"""
import argparse
import base64
import hashlib
import json
from pathlib import Path
import random
import struct
import uuid
import zlib

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / "src/main/resources/assets/coasterengineering"
MODEL = ASSETS / "models/entity/show_monster.json"
EDITABLE = ROOT / "models/volcanic_abyss_sentinel.bbmodel"
TEXTURE = ASSETS / "textures/entity/show_monster.png"
EYES = ASSETS / "textures/entity/show_monster_eyes.png"
COLORS = {
    "body": [0.55, 0.59, 0.65], "shell": [0.78, 0.8, 0.84],
    "bone": [0.89, 0.8, 0.65], "claw": [0.65, 0.59, 0.5],
    "eye": [1.0, 0.42, 0.075], "fissure": [1.0, 0.17, 0.025],
}


def png(path, emissive=False):
    randomizer = random.Random(20261012)
    rows = bytearray()
    for y in range(256):
        rows.append(0)
        for x in range(256):
            if emissive:
                rows.extend((255, 255, 255, 255))
            else:
                grain = randomizer.randint(-5, 5)
                ridges = 7 if (x + y * 3) % 23 < 2 else 0
                value = max(0, min(255, 76 + grain + ridges))
                rows.extend((value, value + 3, value + 7, 255))
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))
    data = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", 256, 256, 8, 6, 0, 0, 0))
    data += chunk(b"IDAT", zlib.compress(bytes(rows), 9)) + chunk(b"IEND", b"")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def canonical():
    bones = []
    def bone(name, parent, pivot, color, cubes):
        bones.append({"name": name, "parent": parent, "pivot": pivot, "color": COLORS[color],
                      "emissive": color in ("eye", "fissure"),
                      "cubes": [{"from": box[:3], "size": box[3:], "uv": [0, 0]} for box in cubes]})
    bone("body", "root", [0, 0, 0], "body", [
        [-16, 5, -22, 32, 16, 44], [-12, 21, -17, 24, 5, 34], [-11, 1, -15, 22, 5, 28]])
    bone("armor", "body", [0, 0, 0], "shell", [
        [-17, 13, -18, 34, 11, 9], [-18, 15, -6, 36, 11, 9], [-17, 13, 7, 34, 11, 9],
        [-20, 9, -13, 5, 10, 19], [15, 9, -13, 5, 10, 19]])
    bone("spines", "body", [0, 0, 0], "bone", [
        [-3, 25, -16, 6, 8, 5], [-3, 26, -5, 6, 11, 5], [-3, 25, 7, 6, 8, 5]])
    bone("fissures", "body", [0, 0, 0], "fissure", [
        [-17.2, 12, -16, 0.3, 1.1, 25], [16.9, 12, -16, 0.3, 1.1, 25],
        [-12, 24, -8, 24, 0.3, 1], [-11, 24, 5, 22, 0.3, 1]])
    bone("neck", "body", [0, 20, 15], "body", [
        [-8, -1, -1, 16, 12, 12], [-7, 9, 2, 14, 8, 9]])
    bone("head", "neck", [0, 12, 7], "shell", [
        [-11, -3, -4, 22, 11, 18], [-9, 0, 14, 18, 6, 4], [-12, 4, -1, 24, 5, 10]])
    bone("horns", "head", [0, 0, 0], "bone", [
        [-11, 8, -1, 4, 9, 5], [-12, 15, 0, 3, 8, 3],
        [7, 8, -1, 4, 9, 5], [9, 15, 0, 3, 8, 3]])
    bone("eyes", "head", [0, 0, 0], "eye", [
        [-10.5, 3, 13.8, 7, 3.6, 0.6], [3.5, 3, 13.8, 7, 3.6, 0.6],
        [-11.7, 3.4, 7, 0.5, 2.6, 4.5], [11.2, 3.4, 7, 0.5, 2.6, 4.5]])
    bone("jaw", "head", [0, -1, 1], "body", [[-10, -6, -1, 20, 4, 18]])
    bone("fangs", "jaw", [0, 0, 0], "bone", [
        [-8, -2, 12, 2, 5, 2], [-3, -2, 14, 2, 4, 2], [1, -2, 14, 2, 4, 2], [6, -2, 12, 2, 5, 2]])
    for name, x, z in [("left_front_leg", -13, 14), ("right_front_leg", 13, 14),
                       ("left_rear_leg", -13, -12), ("right_rear_leg", 13, -12)]:
        direction = -1 if x < 0 else 1
        bx = -8 if direction < 0 else 0
        bone(name, "root", [x, 12, z], "body", [[bx, -11, -4, 8, 13, 9], [bx, -12, 3, 8, 4, 10]])
        bone(name + "_claws", name, [0, 0, 0], "claw", [
            [bx, -12, 11, 2, 3, 5], [bx + 3, -12, 11, 2, 3, 6], [bx + 6, -12, 11, 2, 3, 5]])
    bone("tail", "body", [0, 11, -20], "body", [[-9, -2, -18, 18, 10, 20]])
    bone("tail_tip", "tail", [0, 2, -16], "shell", [[-5, -1, -14, 10, 7, 16], [-2, 0, -23, 4, 5, 10]])
    return {"format": "coasterengineering:world_up_puppet_v1", "scale": 2.8,
            "texture_width": 256, "texture_height": 256, "bones": bones}


def stable_id(name):
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "coasterengineering/volcanic-sentinel/" + name))


def blockbench(geometry):
    elements = []
    groups = {"root": {"name": "root", "origin": [0, 0, 0], "uuid": stable_id("root"), "children": []}}
    absolute = {"root": [0, 0, 0]}
    for bone in geometry["bones"]:
        parent = bone["parent"]
        pivot = [a + b for a, b in zip(absolute[parent], bone["pivot"])]
        absolute[bone["name"]] = pivot
        group = {"name": bone["name"], "origin": pivot, "rotation": [0, 0, 0],
                 "uuid": stable_id(bone["name"]), "export": True, "isOpen": True, "children": []}
        groups[parent]["children"].append(group)
        groups[bone["name"]] = group
        for index, cube in enumerate(bone["cubes"]):
            start = [a + b for a, b in zip(pivot, cube["from"])]
            end = [a + b for a, b in zip(start, cube["size"])]
            name = f"{bone['name']}_{index}"
            element = {"name": name, "uuid": stable_id(name), "type": "cube", "box_uv": True,
                       "from": start, "to": end, "origin": pivot, "rotation": [0, 0, 0],
                       "uv_offset": cube["uv"], "color": 3 if bone["emissive"] else 7,
                       "faces": {face: {"uv": [0, 0, 16, 16], "texture": 0}
                                 for face in ("north", "east", "south", "west", "up", "down")}}
            elements.append(element)
            group["children"].append(element["uuid"])
    texture = {"name": TEXTURE.name, "path": "../src/main/resources/assets/coasterengineering/textures/entity/show_monster.png",
               "uuid": stable_id("texture"), "id": "0", "mode": "bitmap", "saved": False,
               "width": 256, "height": 256, "uv_width": 256, "uv_height": 256,
               "source": "data:image/png;base64," + base64.b64encode(TEXTURE.read_bytes()).decode()}
    return {"meta": {"format_version": "4.10", "model_format": "free", "box_uv": True},
            "name": "Volcanic Abyss Sentinel", "model_identifier": "coasterengineering:show_monster",
            "resolution": {"width": 256, "height": 256}, "elements": elements,
            "outliner": [groups["root"]], "textures": [texture], "animations": [],
            "credit": "Original Coaster Engineering VOLCANIC ABYSS 2.0 stage creature"}


def import_blockbench(path):
    editable = json.loads(path.read_text())
    elements = {cube["uuid"]: cube for cube in editable["elements"]}
    original = canonical()
    metadata = {bone["name"]: bone for bone in original["bones"]}
    imported = []
    def visit(group, parent_name, parent_origin):
        name = group["name"]
        if name == "root":
            for child in group["children"]:
                if isinstance(child, dict): visit(child, "root", group.get("origin", [0, 0, 0]))
            return
        if name not in metadata:
            raise SystemExit(f"Unknown animation group {name}; keep the original group names")
        if any(abs(v) > 1e-6 for v in group.get("rotation", [0, 0, 0])):
            raise SystemExit("Bake group rotations into cube geometry before export; runtime uses animation rotations")
        origin = group.get("origin", [0, 0, 0])
        bone = dict(metadata[name])
        bone["parent"] = parent_name
        bone["pivot"] = [round(a - b, 7) for a, b in zip(origin, parent_origin)]
        bone["cubes"] = []
        for child in group["children"]:
            if isinstance(child, dict): continue
            cube = elements[child]
            if any(abs(v) > 1e-6 for v in cube.get("rotation", [0, 0, 0])):
                raise SystemExit("Runtime cuboids require axis aligned cubes; bake rotations before export")
            bone["cubes"].append({"from": [round(a - b, 7) for a, b in zip(cube["from"], origin)],
                                  "size": [round(b - a, 7) for a, b in zip(cube["from"], cube["to"])],
                                  "uv": cube.get("uv_offset", [0, 0])})
        imported.append(bone)
        for child in group["children"]:
            if isinstance(child, dict): visit(child, name, origin)
    for group in editable["outliner"]: visit(group, "root", [0, 0, 0])
    if set(metadata) != {bone["name"] for bone in imported}:
        raise SystemExit("Missing animation groups: keep all named groups")
    original["bones"] = imported
    return original


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--from-bbmodel", type=Path)
    parser.add_argument("--check", action="store_true", help="verify current model matches editable cube geometry without writing")
    arguments = parser.parse_args()
    if arguments.check:
        actual = json.loads(MODEL.read_text())
        converted = import_blockbench(EDITABLE)
        actual_bones = {b["name"]: b for b in actual["bones"]}
        converted_bones = {b["name"]: b for b in converted["bones"]}
        if actual_bones != converted_bones: raise SystemExit("Runtime and Blockbench geometry differ")
        print(json.dumps({"model": str(MODEL), "bones": len(actual["bones"]),
                          "cubes": sum(len(b["cubes"]) for b in actual["bones"]),
                          "blockbench_geometry_equal": True,
                          "texture_sha256": hashlib.sha256(TEXTURE.read_bytes()).hexdigest()}, indent=2))
        return
    if arguments.from_bbmodel:
        geometry = import_blockbench(arguments.from_bbmodel)
    else:
        geometry = canonical()
        png(TEXTURE)
        png(EYES, emissive=True)
        EDITABLE.parent.mkdir(parents=True, exist_ok=True)
        EDITABLE.write_text(json.dumps(blockbench(geometry), indent=2) + "\n")
    MODEL.parent.mkdir(parents=True, exist_ok=True)
    MODEL.write_text(json.dumps(geometry, indent=2) + "\n")
    print(f"Generated {len(geometry['bones'])} animation groups and {sum(len(b['cubes']) for b in geometry['bones'])} cubes")


if __name__ == "__main__": main()
