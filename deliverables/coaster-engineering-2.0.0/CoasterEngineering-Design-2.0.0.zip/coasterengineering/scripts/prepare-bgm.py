#!/usr/bin/env python3
"""Create a Minecraft 1.20.1 music resource pack from authored regions of one song."""
import argparse
import json
import math
from pathlib import Path
import shutil
import subprocess
import zipfile

NAMES = ("exploration", "ruins_chase", "monster_encounter", "eruption_escape", "finale")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="Music audio file owned/provided by the user")
    parser.add_argument("--cues", type=Path, required=True, help="JSON tracks/name/startSeconds/durationSeconds")
    parser.add_argument("--output", type=Path, required=True, help="Output pack directory; its ZIP is created beside it")
    args = parser.parse_args()
    if not args.input.is_file() or not args.input.stat().st_size:
        parser.error("Input audio file is missing or empty")
    ffmpeg = shutil.which("ffmpeg")
    ffprobe = shutil.which("ffprobe")
    if not ffmpeg or not ffprobe:
        parser.error("ffmpeg and ffprobe are required only when preparing custom music")
    tracks = json.loads(args.cues.read_text(encoding="utf-8"))["tracks"]
    regions = {}
    for name in NAMES:
        cue = tracks[name]
        start, duration = float(cue["startSeconds"]), float(cue["durationSeconds"])
        if not math.isfinite(start) or not math.isfinite(duration) or start < 0 or duration < 2:
            parser.error(f"Invalid region for {name}: start >= 0 and duration >= 2 seconds required")
        regions[name] = (start, duration)
    probe = subprocess.run([ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "json",
                            str(args.input)], check=True, text=True, capture_output=True)
    input_duration = float(json.loads(probe.stdout)["format"]["duration"])
    for name, (start, duration) in regions.items():
        if start + duration > input_duration + .05:
            parser.error(f"{name} region exceeds input duration {input_duration:.3f}s")
    directory = args.output / "assets/coasterengineering/sounds/music"
    directory.mkdir(parents=True, exist_ok=True)
    manifest = {"pack": {"pack_format": 15, "description": "Coaster Engineering 2.0 custom attraction music"}}
    (args.output / "pack.mcmeta").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    sounds = {}
    for name, (start, duration) in regions.items():
        # Region offsets are an authoring operation. Runtime chooses these cues
        # by actual course distance; it does not pretend OpenAL can seek a stream.
        output = directory / f"{name}.ogg"
        subprocess.run([ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error", "-y",
                        "-ss", str(start), "-i", str(args.input), "-t", str(duration),
                        "-vn", "-ac", "2", "-ar", "44100", "-c:a", "libvorbis", "-q:a", "5",
                        "-af", f"afade=t=in:st=0:d=0.08,afade=t=out:st={duration-.08}:d=0.08", str(output)], check=True)
        if not output.is_file() or output.stat().st_size == 0:
            raise RuntimeError(f"Music conversion produced no audio: {name}")
        converted = subprocess.run([ffprobe, "-v", "error", "-show_entries", "stream=codec_name,channels",
                                    "-of", "json", str(output)], check=True, text=True, capture_output=True)
        streams = json.loads(converted.stdout).get("streams", [])
        if not streams or streams[0].get("codec_name") != "vorbis" or streams[0].get("channels") != 2:
            raise RuntimeError(f"Expected stereo Vorbis output: {name}")
        sounds[f"music.{name}"] = {"replace": True, "sounds": [{"name": f"coasterengineering:music/{name}", "stream": True}]}
    (args.output / "assets/coasterengineering/sounds.json").write_text(json.dumps(sounds, indent=2) + "\n", encoding="utf-8")
    (args.output / "authoring-cues.json").write_text(args.cues.read_text(encoding="utf-8"), encoding="utf-8")
    archive = args.output.with_name(args.output.name + ".zip")
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as target:
        for path in sorted(args.output.rglob("*")):
            if path.is_file():
                target.write(path, path.relative_to(args.output).as_posix())
    print(json.dumps({"resource_pack": str(archive.resolve()), "bytes": archive.stat().st_size,
                      "regions": regions}, indent=2))


if __name__ == "__main__":
    main()
