# VOLCANIC ABYSS 2.0 — 巨大生命体モデル

オリジナルの「地底センチネル」は戦闘MOBではなく、演出専用の `coasterengineering:show_monster` Entityです。玄武岩の甲殻、角、4本の脚、長い尾、発光する目と亀裂で構成します。20個のアニメーション用グループ、56個のcuboidを使用しています。Javaのモデル座標16単位を1ブロックとし、描画時に2.8倍に拡大します。最大幅約7.4ブロック、高さ約9.6ブロック、尾を含む全長約17ブロックです。

衝突、ダメージ、戦闘AI、重力、ブロック破壊はありません。Entityの位置は巣のアンカーに固定し、出現・退場はモデルの上下移動で表現します。目と甲殻の亀裂はMinecraft標準のeyes描画パスで発光するため、追加シェーダーは不要です。

## Blockbenchで編集

1. `models/volcanic_abyss_sentinel.bbmodel` をBlockbenchで開きます。独自のworld-up座標を使うため、プロジェクト形式は「Generic Model」です。テクスチャをファイル内に埋め込んであり、追加ダウンロードは不要です。
2. cubeのサイズ・位置、グループのpivotを編集します。`body`、`neck`、`head`、`jaw`、`eyes`、`fissures`、`left_front_leg`、`right_front_leg`、`tail` を含む既存グループ名は維持してください。
3. cubeは軸に平行なまま、Box UVを使用します。独立したcubeの回転・グループの初期回転は変換対象外です。必要な場合は回転をジオメトリに焼き込んだ軸平行cubeへ分割します。
4. 編集した `.bbmodel` を保存し、プロジェクト直下で次を実行します。

```bash
python3 scripts/generate-monster-model.py --from-bbmodel models/volcanic_abyss_sentinel.bbmodel
python3 scripts/generate-monster-model.py --check
./gradlew build
```

`--from-bbmodel` はアニメーション用グループとcubeをランタイムJSONへ変換します。モデルは `src/main/resources/assets/coasterengineering/models/entity/show_monster.json` から読み込まれるため、Javaのcube定義を書き換える必要はありません。Blockbench標準のMinecraft Java Exportは座標規約が異なるため、付属スクリプトで変換してください。

テクスチャをBlockbenchで塗り替えた場合はPNGも書き出し、 `src/main/resources/assets/coasterengineering/textures/entity/show_monster.png` を更新してください。`show_monster_eyes.png` は発光パス用の白いテクスチャで、目と亀裂の色はモデルJSONのグループごとの `color` に設定します。UVサイズは256×256です。

## 演出APIと保存

`ShowMonsterEntity.ensure(level, courseId, anchor)` はロード済みアンカーチャンクで既存の同コースEntityを再利用します。初期状態は潜伏しています。`setShowActive(true)` で約1.5秒かけて出現し、`roar()` で60tickの首・顎アニメーションと咆哮音、`threaten()` で80tickの前脚威嚇を開始します。頭は同コースの列車をゆっくり追います。これらの関数が列車の移動や駅制御を直接変えることはありません。退場は `setShowActive(false)`、チャンク復帰時に演出の再表示を避ける即時初期化は `resetHiddenImmediately()` を使用します。

NBTには `ShowCourse`、`ShowActive`、`ShowExposure`、`ShowHeadYaw`、`ShowHeadPitch`、`ShowRoarTicks`、`ShowThreatTicks` を保存します。コース側のイベント管理が周回・途中退出・再ロード時の演出状態を決めます。

モデルとBlockbenchデータの同一性は `--check` で確認できます。顎・前脚の動きと発光範囲はpure Javaの `MonsterPoseTest` で検査します。実ゲームでの見え方とイベント同期は、別途ゲーム画面・GameTestで検証します。
