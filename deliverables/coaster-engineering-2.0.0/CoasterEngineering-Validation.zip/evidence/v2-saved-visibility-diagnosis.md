# V2 saved-geometry visibility diagnosis

The inspected completed save encloses all three actual riding checkpoints. The blue sky occupying the original photographs is not supported by the saved geometry at those recorded seat positions. Client chunk receipt, mesh generation, or rendering delay is the likely remaining cause; the exact graphics-pipeline stage has not been measured.

The source is the stopped production save, its committed 62-point spline, and the actual capture log distances. The world and production source were not modified.

| Checkpoint | Recorded FPS | Block/sky light | Direct roof distance | Actual saved opaque roof | Forward-frustum rays closed | Full upper-hemisphere rays closed |
|---|---:|---:|---:|---|---:|---:|
| 7 | 3 | 12/0 | 33.0b | `(-127, 117, -24)` minecraft:deepslate | 1025/1025 | 1296/1296 |
| 15 | 8 | 11/0 | 24.0b | `(66, 146, -62)` minecraft:blackstone | 1025/1025 | 1296/1296 |
| 19 | 5 | 9/0 | 32.0b | `(44, 145, 21)` minecraft:tuff | 1025/1025 | 1296/1296 |

3075 forward-frustum rays and 3888 upper-hemisphere rays reached actual opaque saved blocks. None exited the construction footprint or encountered a missing saved chunk. Glass, panes, iron bars, fluids, and partial decorative blocks were conservatively passed through. Upper-hemisphere rays cover every five degrees of azimuth and elevations5..90 degrees, independently of the camera's free-look/roll assumptions.

The first screenshots visibly show sharp rectangular missing regions while the custom spline rails remain drawn. The measured3/8/5FPS explains why dynamic views need a second comparison after terrain render queues settle. This diagnostic establishes saved enclosure, not finished on-screen scenery quality. Repeat a stationary view at the same coordinates, wait for geometry to render, and compare before accepting landscape visibility.

Machine-readable ray coordinates, materials, reconstructed seat-eye positions, and limits: `v2-saved-visibility-diagnosis.json`. The default-FOV forward scan assumes70-degree vertical FOV,854x480 aspect, follow-track orientation, and no free-look offset. Voxel material checks approximate visible block surfaces rather than invoking the Minecraft renderer.
