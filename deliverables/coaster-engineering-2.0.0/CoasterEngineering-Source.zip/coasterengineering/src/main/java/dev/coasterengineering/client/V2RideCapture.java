package dev.coasterengineering.client;

import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.track.TrainSpacing;
import dev.coasterengineering.track.VolcanicAbyssV2;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Screenshot;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Opt-in screenshot inspection of real rendered riding frames; never controls the train. */
@Mod.EventBusSubscriber(modid = CoasterEngineering.MOD_ID, value = Dist.CLIENT)
public final class V2RideCapture {
    private static final int[] POINTS = {7, 9, 15, 19, 25, 29, 33, 42, 43, 45, 49, 55};
    private static final Set<Integer> CAPTURED = new HashSet<>();
    private static boolean armed, boarded, departed;
    private static int initialLap, stillTicks, frames;
    private static long lastStillGameTime = Long.MIN_VALUE;
    private static long stillSinceGameTime = Long.MIN_VALUE;
    private static boolean hasPreviousDistance;
    private static double previousDistance;
    private static int previousLap;
    private static UUID previousVehicle;
    private static String session = "";
    private V2RideCapture() { }

    public static String start() {
        CAPTURED.clear(); armed = true; boarded = departed = false;
        frames = stillTicks = 0; lastStillGameTime = Long.MIN_VALUE;
        stillSinceGameTime = Long.MIN_VALUE; hasPreviousDistance = false; previousVehicle = null;
        session = Long.toString(System.currentTimeMillis());
        return "V2 capture armed: board the 2.0 train. Real images will be saved in screenshots/.";
    }
    public static String stop() { armed = false; return status(); }
    public static String status() { return "V2 capture armed=" + armed + ", frames=" + frames + ", checkpoints=" + CAPTURED.size(); }

    @SubscribeEvent
    public static void render(RenderGuiEvent.Post event) {
        Minecraft minecraft = Minecraft.getInstance();
        if (!armed || minecraft.level == null || minecraft.player == null || minecraft.isPaused()
                || !(minecraft.player.getVehicle() instanceof CoasterEntity car)
                || !VolcanicAbyssV2.COURSE_ID.equals(car.courseId())) {
            // Boarding halfway through, or returning after dismount, cannot
            // claim checkpoints which passed while no riding frame was shown.
            hasPreviousDistance = false;
            stillSinceGameTime = lastStillGameTime = Long.MIN_VALUE;
            return;
        }
        var track = ClientCourses.all().get(car.courseId());
        if (track == null || track.points().size() != 62) { hasPreviousDistance = false; return; }
        double distance = car.getDistance();
        boolean continuousFrame = hasPreviousDistance && car.getUUID().equals(previousVehicle)
                && car.getLaps() == previousLap && distance >= previousDistance;
        double lastDistance = continuousFrame ? previousDistance : distance;
        if (!continuousFrame) stillSinceGameTime = lastStillGameTime = Long.MIN_VALUE;
        previousDistance = distance;
        previousLap = car.getLaps();
        previousVehicle = car.getUUID();
        hasPreviousDistance = true;
        if (!boarded) { boarded = true; initialLap = car.getLaps(); capture(minecraft, car, "boarded"); }
        if (car.isRunning()) departed = true;
        if (departed && !car.isRunning() && car.getLaps() > initialLap) {
            capture(minecraft, car, "station-return"); armed = false; return;
        }
        if (!car.isRunning()) return;
        long tick = minecraft.level.getGameTime();
        if (tick != lastStillGameTime) {
            if (car.getSpeed() <= .001) {
                if (stillSinceGameTime == Long.MIN_VALUE) stillSinceGameTime = tick;
                // Count observed world time, not rendered frames. At 2 FPS a
                // 60-tick reveal still contains enough time for a stable view.
                stillTicks = (int) Math.min(Integer.MAX_VALUE, Math.max(0, tick - stillSinceGameTime));
            } else {
                stillTicks = 0;
                stillSinceGameTime = Long.MIN_VALUE;
            }
            lastStillGameTime = tick;
        }
        for (int point : POINTS) {
            if (CAPTURED.contains(point)) continue;
            double target = TrainSpacing.distance(track, track.controlPointDistance(point),
                    car.carIndex(), car.carSpacing());
            if (point == 25 || point == 42) {
                // Wait for the stable show-stop frame, after the reveal/camera blend starts.
                int revealTicks = point == 25 ? 30 : 12;
                if (stillTicks < revealTicks || Math.abs(distance - target) > .25) continue;
            } else if (!continuousFrame || lastDistance >= target || distance < target) continue;
            CAPTURED.add(point);
            CoasterEngineering.LOGGER.info("V2_CAPTURE_CHECKPOINT point={} targetDistance={} actualDistance={} renderAdvance={} lagBlocks={}",
                    point, target, distance, distance - lastDistance, distance - target);
            capture(minecraft, car, String.format(Locale.ROOT, "point-%02d-%s", point,
                    VolcanicAbyssV2.stageAt(track, distance).name().toLowerCase(Locale.ROOT)));
        }
    }

    private static void capture(Minecraft minecraft, CoasterEntity car, String label) {
        String name = "volcanic-v2-" + session + "-" + label + ".png";
        try {
            Screenshot.grab(minecraft.gameDirectory, name, minecraft.getMainRenderTarget(),
                    message -> CoasterEngineering.LOGGER.info("V2_CAPTURE_FILE {} {}", name, message.getString()));
            frames++;
            CoasterEngineering.LOGGER.info("V2_CAPTURE_FRAME file={} distance={} speedKmh={} lap={} car={} bank={} running={} fps={} {}",
                    name, car.getDistance(), car.getSpeed() * 72, car.getLaps(), car.carIndex(), car.getBank(),
                    car.isRunning(), minecraft.getFps(), CoasterEffects.diagnostics());
        } catch (RuntimeException failed) {
            CoasterEngineering.LOGGER.warn("V2_CAPTURE_FAILED {} {}", name, failed.toString());
        }
    }
}
