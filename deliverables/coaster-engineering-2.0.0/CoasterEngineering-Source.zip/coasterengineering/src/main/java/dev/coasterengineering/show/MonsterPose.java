package dev.coasterengineering.show;

/** Deterministic animation math, separated from entity ticking and render code. Angles are radians. */
public final class MonsterPose {
    public record Pose(double bodyBob, double neckPitch, double headPitch,
                       double jawAngle, double leftLegAngle, double rightLegAngle, double eyeBrightness) { }
    private MonsterPose() { }

    public static Pose sample(double exposure, double roarProgress, double threatProgress, double ageTicks) {
        double shown = Math.max(0, Math.min(1, exposure));
        double breath = Math.sin(ageTicks * .055) * shown;
        double roar = pulse(roarProgress);
        double threat = threatProgress < 0 ? 0 : Math.sin(Math.PI * Math.max(0, Math.min(1, threatProgress)));
        double strike = threatProgress < 0 ? 0 : Math.sin(Math.PI * Math.max(0,
                Math.min(1, (threatProgress - .38) / .42)));
        return new Pose(breath * .4, -.06 * breath - .16 * roar - .18 * strike,
                -.1 * roar + .22 * strike, .12 + .58 * roar + .14 * threat,
                -.95 * threat + .3 * strike, -.38 * threat,
                shown * (.88 + .12 * Math.sin(ageTicks * .07)));
    }

    private static double pulse(double progress) {
        if (progress < 0 || progress > 1) return 0;
        double value = Math.sin(Math.PI * progress);
        return value * value;
    }
}
