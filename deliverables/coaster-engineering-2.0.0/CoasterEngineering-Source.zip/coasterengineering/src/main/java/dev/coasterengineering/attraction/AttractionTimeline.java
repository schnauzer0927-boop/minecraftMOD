package dev.coasterengineering.attraction;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;

/** Pure deterministic crossing/delay/hold state machine. Cosmetic failures cannot block motion. */
public final class AttractionTimeline {
    public enum Status { WAITING, PENDING, EXECUTED, FAILED, SKIPPED }
    public record Execution(String id, Status status, long dueTick, int count) { }
    public record Snapshot(long runNumber, boolean active, boolean interrupted, long elapsedTicks, int lap,
                           double distance, String holdId, int holdRemaining, Set<String> completedStops,
                           List<Execution> executions) { }
    private record Positioned(AttractionDefinition.EventSpec event, double distance) { }
    private final List<Positioned> events;
    private final Map<String, Execution> executions = new LinkedHashMap<>();
    private final Set<String> completedStops = new LinkedHashSet<>();
    private long runNumber, elapsedTicks;
    private boolean active, interrupted;
    private int lap, holdRemaining;
    private double distance;
    private String holdId = "";

    public AttractionTimeline(AttractionDefinition definition, ToDoubleFunction<AttractionDefinition.Trigger> resolver) {
        ArrayList<Positioned> positioned = new ArrayList<>();
        for (var event : definition.events()) {
            double resolved = resolver.applyAsDouble(event.trigger());
            if (!Double.isFinite(resolved) || resolved < 0 || resolved > 16000) throw new IllegalArgumentException("Invalid resolved event position");
            positioned.add(new Positioned(event, resolved));
            executions.put(event.id(), new Execution(event.id(), Status.WAITING, -1, 0));
        }
        positioned.sort(Comparator.comparingDouble(Positioned::distance)); events = List.copyOf(positioned);
    }
    public void dispatch(int lap, double startDistance, Predicate<AttractionDefinition.EventSpec> condition,
                         Consumer<AttractionDefinition.EventSpec> execute) {
        if (!Double.isFinite(startDistance) || startDistance < 0) throw new IllegalArgumentException("Invalid dispatch distance");
        runNumber++; active = true; interrupted = false; elapsedTicks = 0; this.lap = lap; distance = startDistance;
        holdId = ""; holdRemaining = 0; completedStops.clear();
        for (Positioned positioned : events) {
            var event = positioned.event(); Execution old = executions.get(event.id());
            boolean onceEver = !event.retrigger() && old.count() > 0;
            boolean behind = positioned.distance() < startDistance - 0.001;
            executions.put(event.id(), new Execution(event.id(), onceEver || behind ? Status.SKIPPED : Status.WAITING, -1, old.count()));
            // Resume is a new show run at the persisted safe distance; past stops must not trap the train.
            if (event.type() == AttractionDefinition.EventType.STOP && positioned.distance() <= startDistance + .35)
                completedStops.add(event.id());
            if (positioned.distance() == 0 && startDistance < .001) trigger(positioned, condition);
        }
        drain(execute);
    }
    public void cross(double oldDistance, double newDistance, int oldLap, int newLap, double length,
                      Predicate<AttractionDefinition.EventSpec> condition, Consumer<AttractionDefinition.EventSpec> execute) {
        if (!active) return;
        if (!Double.isFinite(oldDistance) || !Double.isFinite(newDistance) || !Double.isFinite(length) || length <= 0)
            throw new IllegalArgumentException("Invalid travelled interval");
        if (newLap < oldLap || (newLap == oldLap && newDistance + .001 < oldDistance)) {
            interrupt(); return; // Teleports/reversed progress never replay an attraction.
        }
        double endpoint = newLap > oldLap ? length : newDistance;
        for (Positioned positioned : events)
            if (oldDistance < positioned.distance() && endpoint + 1e-7 >= positioned.distance()) trigger(positioned, condition);
        distance = newDistance; lap = newLap; drain(execute);
    }
    public void tick(Consumer<AttractionDefinition.EventSpec> execute) {
        if (!active) return;
        elapsedTicks++; drain(execute);
    }
    private void trigger(Positioned positioned, Predicate<AttractionDefinition.EventSpec> condition) {
        var event = positioned.event(); Execution old = executions.get(event.id());
        if (old.status() != Status.WAITING) return;
        executions.put(event.id(), new Execution(event.id(), condition.test(event) ? Status.PENDING : Status.SKIPPED,
                elapsedTicks + event.delayTicks(), old.count()));
    }
    private void drain(Consumer<AttractionDefinition.EventSpec> execute) {
        for (Positioned positioned : events) {
            var event = positioned.event(); Execution old = executions.get(event.id());
            if (old.status() != Status.PENDING || old.dueTick() > elapsedTicks) continue;
            // Mark before invoking: a recursively called tick cannot execute the same event twice.
            executions.put(event.id(), new Execution(event.id(), Status.EXECUTED, old.dueTick(), old.count() + 1));
            try { execute.accept(event); }
            catch (RuntimeException failedCosmetic) {
                executions.put(event.id(), new Execution(event.id(), Status.FAILED, old.dueTick(), old.count() + 1));
            }
        }
    }
    public void beginHold(String id, int ticks) {
        if (!active || completedStops.contains(id)) return;
        if (id == null || !id.matches("[a-zA-Z0-9_.-]{1,64}") || ticks < 1 || ticks > 12000)
            throw new IllegalArgumentException("Invalid scheduled hold");
        if (holdRemaining > 0 && !holdId.equals(id)) throw new IllegalStateException("Overlapping holds");
        if (holdRemaining > 0) return;
        holdId = id; holdRemaining = ticks;
    }
    public boolean consumeHoldTick() {
        if (!active || holdRemaining <= 0) return false;
        holdRemaining--;
        if (holdRemaining == 0) { completedStops.add(holdId); holdId = ""; }
        return true;
    }
    public void interrupt() {
        active = false; interrupted = true; holdId = ""; holdRemaining = 0;
        executions.replaceAll((id, old) -> old.status() == Status.PENDING
                ? new Execution(id, Status.SKIPPED, old.dueTick(), old.count()) : old);
    }
    public void arrive() { interrupt(); interrupted = false; }
    public boolean active() { return active; }
    public long elapsedTicks() { return elapsedTicks; }
    public int holdRemaining() { return holdRemaining; }
    public String holdId() { return holdId; }
    public Set<String> completeStopIds() { return Set.copyOf(completedStops); }
    public void completeStop(String id) { completedStops.add(id); }
    public int executionCount(String id) { Execution value = executions.get(id); return value == null ? 0 : value.count(); }
    public Map<String, Integer> executionCounts() {
        Map<String, Integer> result = new LinkedHashMap<>(); executions.forEach((id, value) -> result.put(id, value.count())); return Map.copyOf(result);
    }
    public Snapshot snapshot() {
        return new Snapshot(runNumber, active, interrupted, elapsedTicks, lap, distance, holdId, holdRemaining,
                Set.copyOf(completedStops), List.copyOf(executions.values()));
    }
    public void restore(Snapshot snapshot) {
        runNumber = Math.max(0, snapshot.runNumber()); elapsedTicks = Math.max(0, snapshot.elapsedTicks());
        lap = Math.max(0, snapshot.lap()); distance = Double.isFinite(snapshot.distance()) ? Math.max(0, snapshot.distance()) : 0;
        completedStops.clear();
        for (String id : snapshot.completedStops()) if (executions.containsKey(id)) completedStops.add(id);
        for (Execution value : snapshot.executions()) if (executions.containsKey(value.id()))
            executions.put(value.id(), new Execution(value.id(), value.status(), value.dueTick(), Math.max(0, value.count())));
        // Server entity deserialization deliberately pauses trains. A reload never resumes timers/cosmetics by itself.
        active = snapshot.active(); interrupted = snapshot.interrupted(); interrupt();
    }
}
