package dev.coasterengineering.attraction;

import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.entity.ShowMonsterEntity;
import dev.coasterengineering.network.CoasterNetwork;
import dev.coasterengineering.registry.CoasterSounds;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.track.VolcanicAbyssV2;
import dev.coasterengineering.world.Course;
import dev.coasterengineering.world.CoasterSavedData;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

/** Server show conductor. Motion only consults explicit timed holds; cosmetic errors fail open. */
public final class AttractionDirector {
    public static final Vec3 MONSTER_ANCHOR = new Vec3(32, 78, 132);
    public static final Vec3 MONSTER_LOOK_TARGET = new Vec3(36.5, 85, 127.3);
    public static final float MONSTER_YAW = -136.273F;
    private static final Map<ServerLevel, Map<UUID, Runtime>> RUNTIMES = new WeakHashMap<>();
    private static final class Runtime {
        final AttractionDefinition definition;
        final AttractionTimeline timeline;
        final List<PositionedStage> stages;
        final Set<BlockPos> safeLights = new HashSet<>(), safeDoors = new HashSet<>();
        final Map<String, Boolean> lighting = new LinkedHashMap<>();
        String stage = "exploration", music = "exploration", effect = "";
        double gain = 1;
        int silenceRemaining, gazeRemaining;
        boolean doorOpen, monsterVisible;
        Runtime(AttractionDefinition definition, AttractionTimeline timeline, SplineTrack track) {
            this.definition = definition; this.timeline = timeline;
            ArrayList<PositionedStage> ordered = new ArrayList<>();
            for (var stage : definition.stages()) ordered.add(new PositionedStage(stage, resolve(stage.trigger(), track)));
            ordered.sort(java.util.Comparator.comparingDouble(PositionedStage::distance)); stages = List.copyOf(ordered);
            // These sparse fixtures can never change a swept rail/rider envelope. Safety is geometry-based, independent of JSON trust.
            List<TrackVec3> path = new ArrayList<>();
            for (double d = 0; d < track.length(); d += .75) path.add(track.sample(d).position());
            for (var rig : definition.lightRigs()) {
                lighting.put(rig.id(), false);
                for (TrackVec3 p : rig.positions()) if (farFromPath(p, path)) safeLights.add(block(p));
            }
            for (TrackVec3 p : definition.doorBlocks()) if (farFromPath(p, path)) safeDoors.add(block(p));
        }
    }
    private record PositionedStage(AttractionDefinition.Stage stage, double distance) { }

    private static boolean supported(Course course) { return course != null && VolcanicAbyssV2.COURSE_ID.equals(course.id()); }
    private static double resolve(AttractionDefinition.Trigger trigger, SplineTrack track) {
        double value;
        if (trigger.controlPoint() != null) {
            if (trigger.controlPoint() >= track.points().size()) throw new IllegalArgumentException("Show control point does not exist");
            value = track.controlPointDistance(trigger.controlPoint());
        } else value = trigger.distance();
        if (value > track.length() + .001) throw new IllegalArgumentException("Show trigger beyond course end");
        return value;
    }
    private static Runtime runtime(ServerLevel level, Course course) {
        Map<UUID, Runtime> map = RUNTIMES.computeIfAbsent(level, ignored -> new LinkedHashMap<>());
        return map.computeIfAbsent(course.id(), ignored -> {
            AttractionDefinition definition = AttractionDefinitions.load(level);
            try { validateGeometry(definition, course.track()); }
            catch (IllegalArgumentException invalidEditedScript) {
                CoasterEngineering.LOGGER.warn("Attraction script does not match course geometry; using bundled script: {}", invalidEditedScript.getMessage());
                definition = AttractionDefinitions.bundled(); validateGeometry(definition, course.track());
            }
            // Validate every trigger against the actual geometry before the runtime is cached.
            AttractionDefinition validatedDefinition = definition;
            AttractionTimeline timeline = AttractionSavedData.get(level).timeline(course.id(), validatedDefinition,
                    trigger -> resolve(trigger, course.track()));
            return new Runtime(validatedDefinition, timeline, course.track());
        });
    }
    private static void validateGeometry(AttractionDefinition definition, SplineTrack track) {
        for (var event : definition.events()) resolve(event.trigger(), track);
        for (var stage : definition.stages()) resolve(stage.trigger(), track);
    }
    /** Builder calls only after the new course, station and train have committed successfully. */
    public static void install(ServerLevel level, Course course) {
        if (!supported(course)) throw new IllegalArgumentException("Only the separately generated V2 attraction may install this show");
        AttractionDefinitions.installEditableCopy(level);
        Runtime runtime = runtime(level, course);
        resetPresentation(level, runtime);
        if (level.hasChunkAt(BlockPos.containing(MONSTER_ANCHOR))) {
            ShowMonsterEntity monster = ShowMonsterEntity.ensure(level, course.id(), MONSTER_ANCHOR);
            monster.setYRot(MONSTER_YAW); monster.setShowActive(false);
        }
        AttractionSavedData.get(level).setDirty();
        CoasterEngineering.LOGGER.info("V2_ATTRACTION_INSTALLED course={} events={} stages={} safeLights={} safeDoorBlocks={}",
                course.id(), runtime.definition.events().size(), runtime.stages.size(), runtime.safeLights.size(), runtime.safeDoors.size());
    }
    public static void onDispatch(ServerLevel level, CoasterEntity leader, Course course) {
        if (!supported(course)) return;
        try {
            Runtime runtime = runtime(level, course); resetPresentation(level, runtime);
            runtime.timeline.dispatch(leader.getLaps(), leader.getDistance(), event -> condition(event, leader), event -> execute(level, leader, course, runtime, event));
            updateStage(runtime, leader.getDistance());
            AttractionSavedData.get(level).setDirty(); send(level, leader, course, runtime, true);
            CoasterEngineering.LOGGER.info("V2_ATTRACTION_DISPATCH course={} run={} distance={} lap={}", course.id(),
                    runtime.timeline.snapshot().runNumber(), leader.getDistance(), leader.getLaps());
        } catch (RuntimeException exception) { failOpen("dispatch", exception); }
    }
    /** Exactly once per leader server tick. A true return means a deliberate show stop, with running=true. */
    public static boolean beforeMove(ServerLevel level, CoasterEntity leader, Course course) {
        if (!supported(course)) return false;
        try {
            Runtime runtime = runtime(level, course);
            if (!runtime.timeline.active()) onDispatch(level, leader, course);
            runtime.timeline.tick(event -> execute(level, leader, course, runtime, event));
            if (runtime.silenceRemaining > 0) runtime.silenceRemaining--;
            if (runtime.gazeRemaining > 0) runtime.gazeRemaining--;
            boolean hold = runtime.timeline.consumeHoldTick();
            if (runtime.timeline.elapsedTicks() % 20 == 0 || (hold && runtime.timeline.holdRemaining() == 0)) {
                updateStage(runtime, leader.getDistance()); applyLighting(level, runtime); applyDoor(level, runtime);
                AttractionSavedData.get(level).setDirty(); send(level, leader, course, runtime, true);
            }
            return hold;
        } catch (RuntimeException exception) { failOpen("tick", exception); return false; }
    }
    public static void afterMove(ServerLevel level, CoasterEntity leader, Course course,
                                 double oldDistance, double newDistance, int oldLaps, int newLaps) {
        if (!supported(course)) return;
        try {
            Runtime runtime = runtime(level, course);
            runtime.timeline.cross(oldDistance, newDistance, oldLaps, newLaps, course.track().length(),
                    event -> condition(event, leader), event -> execute(level, leader, course, runtime, event));
            // The authoritative entity performs arrival cleanup after applying its exact station pose.
            if (newLaps != oldLaps) return;
            String oldStage = runtime.stage; updateStage(runtime, newDistance);
            if (!oldStage.equals(runtime.stage)) send(level, leader, course, runtime, true);
        } catch (RuntimeException exception) { failOpen("crossing", exception); }
    }
    public static void beginHold(ServerLevel level, CoasterEntity leader, Course course, String stopId, int ticks) {
        if (!supported(course)) return;
        try {
            Runtime runtime = runtime(level, course);
            int configuredTicks = runtime.definition.events().stream()
                    .filter(event -> event.type() == AttractionDefinition.EventType.STOP && event.id().equals(stopId))
                    .findFirst().map(event -> event.ticks(ticks)).orElse(ticks);
            runtime.timeline.beginHold(stopId, configuredTicks);
            AttractionSavedData.get(level).setDirty(); send(level, leader, course, runtime, true);
            CoasterEngineering.LOGGER.info("V2_ATTRACTION_HOLD course={} id={} distance={} ticks={}", course.id(), stopId, leader.getDistance(), configuredTicks);
        } catch (RuntimeException failure) {
            AttractionTimeline timeline = AttractionSavedData.get(level).existing(course.id());
            if (timeline != null) timeline.completeStop(stopId);
            failOpen("hold", failure);
        }
    }
    public static Set<String> completedStopIds(ServerLevel level, Course course) {
        if (!supported(course)) return Set.of();
        try { return runtime(level, course).timeline.completeStopIds(); }
        catch (RuntimeException exception) {
            // Missing cosmetics must not strand a train at an unresolvable show timer.
            failOpen("stop program", exception); return Set.of("monster_pause", "precipice_pause");
        }
    }
    public static List<VolcanicAbyssV2.SegmentSettings> motionSettings(ServerLevel level, Course course) {
        if (!supported(course)) return VolcanicAbyssV2.defaultSegments();
        try {
            List<VolcanicAbyssV2.SegmentSettings> configured = new ArrayList<>(VolcanicAbyssV2.defaultSegments());
            for (var section : runtime(level, course).definition.motionSections()) {
                var stage = VolcanicAbyssV2.Stage.valueOf(section.stage());
                configured.removeIf(setting -> setting.stage() == stage);
                configured.add(new VolcanicAbyssV2.SegmentSettings(stage, section.maximumAcceleration(), section.maximumBraking(), section.speedMultiplier()));
            }
            return List.copyOf(configured);
        } catch (RuntimeException failure) { failOpen("motion settings", failure); return VolcanicAbyssV2.defaultSegments(); }
    }
    public static void onInterrupted(ServerLevel level, CoasterEntity leader, Course course) {
        if (!supported(course)) return;
        try {
            Runtime runtime = runtime(level, course); runtime.timeline.interrupt(); resetPresentation(level, runtime);
            AttractionSavedData.get(level).setDirty(); send(level, leader, course, runtime, false);
        } catch (RuntimeException exception) { failOpen("interruption", exception); }
    }
    public static void onStationArrival(ServerLevel level, CoasterEntity leader, Course course) {
        if (!supported(course)) return;
        try {
            Runtime runtime = runtime(level, course); runtime.timeline.arrive(); resetPresentation(level, runtime);
            AttractionSavedData.get(level).setDirty(); send(level, leader, course, runtime, false);
            CoasterEngineering.LOGGER.info("V2_ATTRACTION_ARRIVAL course={} run={} ticks={} executions={}", course.id(),
                    runtime.timeline.snapshot().runNumber(), runtime.timeline.elapsedTicks(), runtime.timeline.executionCounts());
        } catch (RuntimeException exception) { failOpen("arrival", exception); }
    }
    public static void reload(ServerLevel level, Course course) {
        if (!supported(course)) throw new IllegalArgumentException("Not a V2 attraction");
        if (runtime(level, course).timeline.active()) throw new IllegalStateException("Stop the ride before reloading its show script");
        RUNTIMES.getOrDefault(level, Map.of()).remove(course.id()); AttractionSavedData.get(level).forgetRuntime(course.id());
        runtime(level, course);
    }
    public static int executionCount(ServerLevel level, UUID courseId, String eventId) {
        AttractionTimeline timeline = AttractionSavedData.get(level).existing(courseId);
        return timeline == null ? 0 : timeline.executionCount(eventId);
    }
    public static Map<String, Integer> allExecutionCounts(ServerLevel level, UUID courseId) {
        AttractionTimeline timeline = AttractionSavedData.get(level).existing(courseId);
        return timeline == null ? Map.of() : timeline.executionCounts();
    }
    public static int holdRemaining(ServerLevel level, UUID courseId) {
        AttractionTimeline timeline = AttractionSavedData.get(level).existing(courseId); return timeline == null ? 0 : timeline.holdRemaining();
    }
    public static boolean active(ServerLevel level, UUID courseId) {
        AttractionTimeline timeline = AttractionSavedData.get(level).existing(courseId); return timeline != null && timeline.active();
    }
    public static String snapshot(ServerLevel level, UUID courseId) {
        var snapshot = AttractionSavedData.get(level).snapshot(courseId);
        return snapshot == null ? "No show installed" : AttractionDefinition.gson().toJson(snapshot);
    }
    public static String status(ServerLevel level, UUID courseId) {
        Course course = CoasterSavedData.get(level).getCourse(courseId);
        if (!supported(course)) return "Not a V2 attraction";
        try {
            Runtime runtime = runtime(level, course);
            return "stage=" + runtime.stage + " music=" + runtime.music + " silenceTicks=" + runtime.silenceRemaining
                    + " hold=" + runtime.timeline.holdId() + ":" + runtime.timeline.holdRemaining()
                    + " completedStops=" + runtime.timeline.completeStopIds() + " state=" + snapshot(level, courseId);
        } catch (RuntimeException failure) { return "Presentation unavailable: " + failure.getMessage(); }
    }
    /** Chunk reload cannot resurrect a monster from a previous run's serialized exposure. */
    public static void onMonsterLoaded(ServerLevel level, ShowMonsterEntity monster) {
        if (!VolcanicAbyssV2.COURSE_ID.equals(monster.courseId())) return;
        Runtime runtime = RUNTIMES.getOrDefault(level, Map.of()).get(monster.courseId());
        if (runtime != null && runtime.timeline.active() && runtime.monsterVisible) monster.setShowActive(true);
        else monster.resetHiddenImmediately();
    }
    public static void reloadConfiguration(ServerLevel level, UUID courseId) {
        Course course = CoasterSavedData.get(level).getCourse(courseId);
        if (!supported(course)) throw new IllegalArgumentException("Not a V2 attraction");
        reload(level, course);
    }
    private static boolean condition(AttractionDefinition.EventSpec event, CoasterEntity leader) {
        return switch (event.condition()) {
            case ALWAYS -> true; case RUNNING -> leader.isRunning();
            case RIDERS -> leader.getLoadedFormation().stream().anyMatch(CoasterEntity::isVehicle);
        };
    }
    private static void updateStage(Runtime runtime, double distance) {
        AttractionDefinition.Stage selected = runtime.stages.get(0).stage();
        for (PositionedStage stage : runtime.stages) if (stage.distance() <= distance + 1e-7) selected = stage.stage();
        runtime.stage = selected.id(); runtime.music = selected.music(); runtime.gain = selected.gain();
    }
    private static void execute(ServerLevel level, CoasterEntity leader, Course course, Runtime runtime, AttractionDefinition.EventSpec event) {
        try {
            switch (event.type()) {
                case LIGHTS -> {
                    runtime.lighting.put(event.text("rig", ""), !event.parameters().has("active") || event.parameters().get("active").getAsBoolean());
                    applyLighting(level, runtime);
                }
                case ALARM -> level.playSound(null, leader.blockPosition(), CoasterSounds.ALARM.get(), SoundSource.BLOCKS, .7F, 1);
                case MONSTER_SHOW -> {
                    runtime.monsterVisible = true;
                    var monster = monster(level, course); if (monster != null) { monster.setShowActive(true); monster.lookAt(leader.position()); }
                }
                case MONSTER_HIDE -> { runtime.monsterVisible = false; hideMonster(level); }
                case ROAR -> { var monster = monster(level, course); if (monster != null) monster.roar(); }
                case MONSTER_ATTACK -> { var monster = monster(level, course); if (monster != null) monster.threaten(); }
                case ROCKFALL -> {
                    Vec3 p = leader.position().add(4, 9, 3);
                    level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.BASALT.defaultBlockState()),
                            p.x, p.y, p.z, 100, 2.5, 2, 2.5, .18);
                    level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, p.x, p.y, p.z, 30, 3, .5, 3, .03);
                }
                case ERUPTION -> {
                    Vec3 p = leader.position().add(5, -2, 5);
                    level.sendParticles(ParticleTypes.LAVA, p.x, p.y, p.z, 70, 2, 1, 2, .3);
                    level.sendParticles(ParticleTypes.FLAME, p.x, p.y + 3, p.z, 90, 3, 2, 3, .12);
                    level.sendParticles(ParticleTypes.EXPLOSION, p.x, p.y + 3, p.z, 8, 2, 2, 2, .02);
                    level.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, p.x, p.y + 6, p.z, 45, 3, 3, 3, .05);
                }
                case LAUNCH -> level.playSound(null, leader.blockPosition(), CoasterSounds.LAUNCH.get(), SoundSource.BLOCKS, .65F, 1.2F);
                case DOOR_OPEN -> { runtime.doorOpen = true; applyDoor(level, runtime); }
                case DOOR_CLOSE -> { runtime.doorOpen = false; applyDoor(level, runtime); }
                case SILENCE -> runtime.silenceRemaining = event.ticks(40);
                case GAZE -> runtime.gazeRemaining = event.ticks(80);
                case STOP -> { /* Required motion hold is started by the entity at an exact, already-braked position. */ }
            }
            runtime.effect = event.type().name().toLowerCase(java.util.Locale.ROOT);
            AttractionSavedData.get(level).nextSequence(course.id()); AttractionSavedData.get(level).setDirty();
            updateStage(runtime, leader.getDistance()); send(level, leader, course, runtime, true);
            CoasterEngineering.LOGGER.info("V2_ATTRACTION_EVENT course={} id={} type={} distance={} elapsedTicks={} count={}", course.id(),
                    event.id(), event.type(), leader.getDistance(), runtime.timeline.elapsedTicks(), runtime.timeline.executionCount(event.id()));
        } catch (RuntimeException failure) { failOpen("event " + event.id(), failure); throw failure; }
    }
    private static ShowMonsterEntity monster(ServerLevel level, Course course) {
        if (!level.hasChunkAt(BlockPos.containing(MONSTER_ANCHOR))) return null;
        ShowMonsterEntity monster = ShowMonsterEntity.ensure(level, course.id(), MONSTER_ANCHOR);
        monster.setYRot(MONSTER_YAW); return monster;
    }
    private static void hideMonster(ServerLevel level) {
        for (ShowMonsterEntity monster : level.getEntitiesOfClass(ShowMonsterEntity.class, new AABB(MONSTER_ANCHOR, MONSTER_ANCHOR).inflate(160),
                entity -> VolcanicAbyssV2.COURSE_ID.equals(entity.courseId()))) monster.setShowActive(false);
    }
    private static void resetPresentation(ServerLevel level, Runtime runtime) {
        runtime.silenceRemaining = runtime.gazeRemaining = 0; runtime.effect = ""; runtime.doorOpen = false; runtime.monsterVisible = false;
        runtime.lighting.replaceAll((id, value) -> false); hideMonster(level); applyLighting(level, runtime); applyDoor(level, runtime);
    }
    private static void applyLighting(ServerLevel level, Runtime runtime) {
        for (var rig : runtime.definition.lightRigs()) {
            int value = runtime.lighting.getOrDefault(rig.id(), false) ? rig.activeLevel() : rig.idleLevel();
            for (TrackVec3 point : rig.positions()) {
                BlockPos pos = block(point);
                if (!runtime.safeLights.contains(pos) || !level.hasChunkAt(pos)) continue;
                var original = level.getBlockState(pos);
                if (!original.isAir() && !original.is(Blocks.LIGHT)) continue;
                var desired = Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, value);
                if (!desired.equals(original)) level.setBlock(pos, desired, 3);
            }
        }
    }
    private static void applyDoor(ServerLevel level, Runtime runtime) {
        for (BlockPos pos : runtime.safeDoors) {
            if (!level.hasChunkAt(pos)) continue;
            var original = level.getBlockState(pos);
            if (runtime.doorOpen && original.is(Blocks.IRON_BARS)) level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            else if (!runtime.doorOpen && original.isAir() && level.getEntities(null, new AABB(pos)).isEmpty())
                level.setBlock(pos, Blocks.IRON_BARS.defaultBlockState(), 3);
        }
    }
    private static void send(ServerLevel level, CoasterEntity leader, Course course, Runtime runtime, boolean active) {
        AttractionStatePacket packet = new AttractionStatePacket(course.id(), runtime.stage, runtime.music, runtime.gain,
                runtime.silenceRemaining, MONSTER_LOOK_TARGET.x, MONSTER_LOOK_TARGET.y, MONSTER_LOOK_TARGET.z,
                runtime.gazeRemaining, runtime.effect, AttractionSavedData.get(level).sequence(course.id()), active);
        Set<UUID> sent = new HashSet<>();
        for (CoasterEntity car : leader.getLoadedFormation()) for (Entity passenger : car.getPassengers())
            if (passenger instanceof ServerPlayer player && sent.add(player.getUUID()))
                CoasterNetwork.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), packet);
    }
    private static boolean farFromPath(TrackVec3 p, List<TrackVec3> path) {
        // Five blocks accommodates rotated train bodies, upright riders, rounding and sampling errors.
        for (TrackVec3 sample : path) if (sample.subtract(p).length() < 5) return false;
        return true;
    }
    private static BlockPos block(TrackVec3 p) { return BlockPos.containing(p.x(), p.y(), p.z()); }
    private static void failOpen(String phase, RuntimeException failure) {
        CoasterEngineering.LOGGER.warn("V2 attraction cosmetic failure during {}: {}", phase, failure.toString());
    }
    private AttractionDirector() { }
}
