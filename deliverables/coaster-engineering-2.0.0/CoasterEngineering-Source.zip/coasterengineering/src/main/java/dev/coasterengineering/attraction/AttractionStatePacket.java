package dev.coasterengineering.attraction;

import dev.coasterengineering.client.ClientAttractionState;
import dev.coasterengineering.network.CoasterNetwork;
import io.netty.handler.codec.DecoderException;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkEvent;

/** S2C presentation intent. Client values never control motion or world blocks. */
public record AttractionStatePacket(UUID courseId, String stage, String music, double musicGain, int silenceTicks,
                                    double lookX, double lookY, double lookZ, int gazeTicks, String effect,
                                    long sequence, boolean active) {
    public static void register() {
        CoasterNetwork.CHANNEL.messageBuilder(AttractionStatePacket.class, 2, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(AttractionStatePacket::encode).decoder(AttractionStatePacket::decode)
                .consumerMainThread(AttractionStatePacket::handle).add();
    }
    public static void encode(AttractionStatePacket packet, FriendlyByteBuf buffer) {
        buffer.writeUUID(packet.courseId()); buffer.writeUtf(packet.stage(), 64); buffer.writeUtf(packet.music(), 64);
        buffer.writeDouble(packet.musicGain()); buffer.writeVarInt(packet.silenceTicks());
        buffer.writeDouble(packet.lookX()); buffer.writeDouble(packet.lookY()); buffer.writeDouble(packet.lookZ());
        buffer.writeVarInt(packet.gazeTicks()); buffer.writeUtf(packet.effect(), 64); buffer.writeLong(packet.sequence()); buffer.writeBoolean(packet.active());
    }
    public static AttractionStatePacket decode(FriendlyByteBuf buffer) {
        var packet = new AttractionStatePacket(buffer.readUUID(), buffer.readUtf(64), buffer.readUtf(64), buffer.readDouble(),
                buffer.readVarInt(), buffer.readDouble(), buffer.readDouble(), buffer.readDouble(), buffer.readVarInt(),
                buffer.readUtf(64), buffer.readLong(), buffer.readBoolean());
        if (!Double.isFinite(packet.musicGain()) || packet.musicGain() < 0 || packet.musicGain() > 1
                || packet.silenceTicks() < 0 || packet.silenceTicks() > 12000 || packet.gazeTicks() < 0 || packet.gazeTicks() > 12000
                || !Double.isFinite(packet.lookX()) || !Double.isFinite(packet.lookY()) || !Double.isFinite(packet.lookZ())
                || Math.abs(packet.lookX()) > 29_999_000 || Math.abs(packet.lookZ()) > 29_999_000 || Math.abs(packet.lookY()) > 2048
                || packet.sequence() < 0) throw new DecoderException("Invalid attraction presentation packet");
        return packet;
    }
    public static void handle(AttractionStatePacket packet, Supplier<NetworkEvent.Context> context) {
        DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> {
            if (!packet.active()) ClientAttractionState.clear();
            else ClientAttractionState.update(packet.courseId(), packet.stage(), packet.music(), packet.musicGain(), packet.silenceTicks(),
                    packet.lookX(), packet.lookY(), packet.lookZ(), packet.gazeTicks(), packet.effect(), packet.sequence());
        });
        context.get().setPacketHandled(true);
    }
}
