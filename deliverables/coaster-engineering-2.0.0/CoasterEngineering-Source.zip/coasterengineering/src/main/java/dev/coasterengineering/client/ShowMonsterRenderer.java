package dev.coasterengineering.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import dev.coasterengineering.entity.ShowMonsterEntity;
import dev.coasterengineering.registry.CoasterRegistries;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "coasterengineering", bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ShowMonsterRenderer extends EntityRenderer<ShowMonsterEntity> {
    private static final ModelLayerLocation LAYER = new ModelLayerLocation(
            new ResourceLocation("coasterengineering", "show_monster"), "main");
    private static final ResourceLocation TEXTURE = new ResourceLocation("coasterengineering", "textures/entity/show_monster.png");
    private static final ResourceLocation EYES = new ResourceLocation("coasterengineering", "textures/entity/show_monster_eyes.png");
    private final ShowMonsterModel model;

    public ShowMonsterRenderer(EntityRendererProvider.Context context) {
        super(context);
        model = new ShowMonsterModel(context.bakeLayer(LAYER));
        shadowRadius = 0;
    }

    @SubscribeEvent public static void layers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(LAYER, ShowMonsterModel::createLayer);
    }
    @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(CoasterRegistries.SHOW_MONSTER.get(), ShowMonsterRenderer::new);
    }

    @Override
    public void render(ShowMonsterEntity entity, float entityYaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffers, int light) {
        float exposure = entity.exposure(partialTick);
        if (exposure <= .001F) return;
        pose.pushPose();
        // Only the mesh emerges from the nest. The server entity stays at its safe fixed anchor.
        pose.translate(0, -12 * (1 - exposure) * (1 - exposure), 0);
        pose.mulPose(Axis.YP.rotationDegrees(-Mth.rotLerp(partialTick, entity.yRotO, entity.getYRot())));
        pose.scale(ShowMonsterModel.SCALE, ShowMonsterModel.SCALE, ShowMonsterModel.SCALE);
        model.setupAnim(entity, 0, 0, entity.tickCount + partialTick, 0, 0);
        model.renderToBuffer(pose, buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE)),
                light, OverlayTexture.NO_OVERLAY, 1, 1, 1, 1);
        // Minecraft's standard eyes pass supplies emission without shaders or colored-light mods.
        model.renderEyes(pose, buffers.getBuffer(RenderType.eyes(EYES)), OverlayTexture.NO_OVERLAY);
        pose.popPose();
        super.render(entity, entityYaw, partialTick, pose, buffers, light);
    }

    @Override public ResourceLocation getTextureLocation(ShowMonsterEntity entity) { return TEXTURE; }
}
