package dev.coasterengineering.world;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** The attraction becomes available only after live construction audits pass. */
public final class VolcanicV2BuildData extends SavedData {
    public static final String FILE_NAME = "coasterengineering_volcanic_v2";
    private CompoundTag report = new CompoundTag();

    public static VolcanicV2BuildData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(VolcanicV2BuildData::load,
                VolcanicV2BuildData::new, FILE_NAME);
    }

    private static VolcanicV2BuildData load(CompoundTag tag) {
        VolcanicV2BuildData data = new VolcanicV2BuildData();
        data.report = tag.copy();
        return data;
    }

    public boolean isReady() { return report.getInt("buildVersion") == 2 && report.getBoolean("ready"); }
    public CompoundTag report() { return report.copy(); }
    public void complete(CompoundTag report) { this.report = report.copy(); setDirty(); }
    @Override public CompoundTag save(CompoundTag tag) { tag.merge(report); return tag; }
}
