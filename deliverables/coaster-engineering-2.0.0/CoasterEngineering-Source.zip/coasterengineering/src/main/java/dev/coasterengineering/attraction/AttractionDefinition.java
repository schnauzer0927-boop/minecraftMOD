package dev.coasterengineering.attraction;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.coasterengineering.track.TrackVec3;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Validated, editable show script. Distances are blocks, delays are server ticks. */
public record AttractionDefinition(String id, int formatVersion, List<Stage> stages, List<EventSpec> events,
                                   List<LightRig> lightRigs, List<TrackVec3> doorBlocks, List<MotionSection> motionSections) {
    public enum EventType { LIGHTS, ALARM, MONSTER_SHOW, MONSTER_HIDE, ROAR, MONSTER_ATTACK,
        ROCKFALL, ERUPTION, LAUNCH, DOOR_OPEN, DOOR_CLOSE, SILENCE, GAZE, STOP }
    public enum Condition { ALWAYS, RIDERS, RUNNING }
    public record Trigger(Integer controlPoint, Double distance) {
        public Trigger {
            if ((controlPoint == null) == (distance == null)) throw new IllegalArgumentException("Exactly one controlPoint or distance is required");
            if (controlPoint != null && (controlPoint < 0 || controlPoint >= 128)) throw new IllegalArgumentException("Invalid control point");
            if (distance != null && (!Double.isFinite(distance) || distance < 0 || distance > 16000)) throw new IllegalArgumentException("Invalid trigger distance");
        }
    }
    public record Stage(String id, Trigger trigger, String music, double gain) {
        public Stage {
            identifier(id);
            if (!Set.of("exploration", "ruins_chase", "monster_encounter", "eruption_escape", "finale").contains(music))
                throw new IllegalArgumentException("Unknown music key: " + music);
            if (!Double.isFinite(gain) || gain < 0 || gain > 1) throw new IllegalArgumentException("Music gain outside 0..1");
        }
    }
    public record EventSpec(String id, Trigger trigger, Condition condition, int delayTicks, EventType type,
                            boolean retrigger, JsonObject parameters) {
        public EventSpec {
            identifier(id);
            if (trigger == null || condition == null || type == null) throw new IllegalArgumentException("Incomplete event");
            if (delayTicks < 0 || delayTicks > 12000) throw new IllegalArgumentException("Delay outside 0..12000 ticks");
            parameters = parameters == null ? new JsonObject() : parameters.deepCopy();
            if (parameters.toString().length() > 4096) throw new IllegalArgumentException("Event parameters too large");
            if (parameters.has("ticks")) {
                int ticks = parameters.get("ticks").getAsInt();
                if (ticks < 0 || ticks > 12000) throw new IllegalArgumentException("Invalid event duration");
            }
        }
        public int ticks(int fallback) { return parameters.has("ticks") ? parameters.get("ticks").getAsInt() : fallback; }
        public String text(String key, String fallback) { return parameters.has(key) ? parameters.get(key).getAsString() : fallback; }
    }
    public record LightRig(String id, List<TrackVec3> positions, int idleLevel, int activeLevel) {
        public LightRig {
            identifier(id); positions = List.copyOf(positions);
            if (positions.size() > 128 || idleLevel < 0 || idleLevel > 15 || activeLevel < 0 || activeLevel > 15)
                throw new IllegalArgumentException("Invalid light rig");
        }
    }
    public record MotionSection(String stage, double maximumAcceleration, double maximumBraking, double speedMultiplier) {
        public MotionSection {
            if (!Set.of("EXPLORE", "RUINS", "MONSTER", "ESCAPE_MONSTER", "ERUPTION", "DROP", "FINAL_ESCAPE", "RETURN").contains(stage))
                throw new IllegalArgumentException("Unknown motion stage");
            if (!Double.isFinite(maximumAcceleration) || maximumAcceleration <= 0 || maximumAcceleration > .025
                    || !Double.isFinite(maximumBraking) || maximumBraking <= 0 || maximumBraking > .035
                    || !Double.isFinite(speedMultiplier) || speedMultiplier < .1 || speedMultiplier > 2)
                throw new IllegalArgumentException("Invalid motion section limits");
        }
    }
    public AttractionDefinition(String id, int formatVersion, List<Stage> stages, List<EventSpec> events,
                                List<LightRig> lightRigs, List<TrackVec3> doorBlocks) {
        this(id, formatVersion, stages, events, lightRigs, doorBlocks, List.of());
    }

    public AttractionDefinition {
        identifier(id);
        if (formatVersion != 1) throw new IllegalArgumentException("Unsupported attraction format");
        stages = List.copyOf(stages); events = List.copyOf(events); lightRigs = List.copyOf(lightRigs); doorBlocks = List.copyOf(doorBlocks);
        motionSections = List.copyOf(motionSections);
        if (stages.isEmpty() || stages.size() > 32 || events.size() > 128 || lightRigs.size() > 32 || doorBlocks.size() > 64)
            throw new IllegalArgumentException("Attraction script exceeds limits");
        Set<String> ids = new HashSet<>();
        for (EventSpec event : events) if (!ids.add(event.id())) throw new IllegalArgumentException("Duplicate event id: " + event.id());
        ids.clear();
        for (Stage stage : stages) if (!ids.add(stage.id())) throw new IllegalArgumentException("Duplicate stage id: " + stage.id());
        ids.clear();
        for (LightRig rig : lightRigs) if (!ids.add(rig.id())) throw new IllegalArgumentException("Duplicate light rig");
        for (EventSpec event : events) if (event.type() == EventType.LIGHTS && !ids.contains(event.text("rig", "")))
            throw new IllegalArgumentException("Unknown lighting rig in " + event.id());
        ids.clear();
        for (MotionSection section : motionSections) if (!ids.add(section.stage())) throw new IllegalArgumentException("Duplicate motion stage");
    }

    public static AttractionDefinition parse(Reader reader) {
        JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
        List<Stage> stages = new ArrayList<>();
        for (JsonElement element : root.getAsJsonArray("stages")) {
            JsonObject object = element.getAsJsonObject();
            stages.add(new Stage(object.get("id").getAsString(), trigger(object), object.get("music").getAsString(),
                    object.has("gain") ? object.get("gain").getAsDouble() : 1));
        }
        List<EventSpec> events = new ArrayList<>();
        for (JsonElement element : root.getAsJsonArray("events")) {
            JsonObject object = element.getAsJsonObject();
            events.add(new EventSpec(object.get("id").getAsString(), trigger(object),
                    Condition.valueOf(object.has("condition") ? object.get("condition").getAsString() : "ALWAYS"),
                    object.has("delayTicks") ? object.get("delayTicks").getAsInt() : 0,
                    EventType.valueOf(object.get("type").getAsString()),
                    !object.has("retrigger") || object.get("retrigger").getAsBoolean(), object.getAsJsonObject("parameters")));
        }
        List<LightRig> rigs = new ArrayList<>();
        if (root.has("lightRigs")) for (JsonElement element : root.getAsJsonArray("lightRigs")) {
            JsonObject object = element.getAsJsonObject();
            List<TrackVec3> positions = new ArrayList<>();
            for (JsonElement position : object.getAsJsonArray("positions")) positions.add(position(position));
            rigs.add(new LightRig(object.get("id").getAsString(), positions, object.get("idleLevel").getAsInt(), object.get("activeLevel").getAsInt()));
        }
        List<TrackVec3> doors = new ArrayList<>();
        if (root.has("doorBlocks")) for (JsonElement element : root.getAsJsonArray("doorBlocks")) doors.add(position(element));
        List<MotionSection> motion = new ArrayList<>();
        if (root.has("motionSections")) for (JsonElement element : root.getAsJsonArray("motionSections")) {
            JsonObject object = element.getAsJsonObject();
            motion.add(new MotionSection(object.get("stage").getAsString(), object.get("maximumAcceleration").getAsDouble(),
                    object.get("maximumBraking").getAsDouble(), object.get("speedMultiplier").getAsDouble()));
        }
        return new AttractionDefinition(root.get("id").getAsString(), root.get("formatVersion").getAsInt(), stages, events, rigs, doors, motion);
    }
    public static Gson gson() { return new Gson(); }
    private static Trigger trigger(JsonObject object) {
        return new Trigger(object.has("controlPoint") ? object.get("controlPoint").getAsInt() : null,
                object.has("distance") ? object.get("distance").getAsDouble() : null);
    }
    private static TrackVec3 position(JsonElement element) {
        JsonArray array = element.getAsJsonArray();
        if (array.size() != 3) throw new IllegalArgumentException("Position needs three coordinates");
        TrackVec3 value = new TrackVec3(array.get(0).getAsDouble(), array.get(1).getAsDouble(), array.get(2).getAsDouble());
        if (Math.abs(value.x()) > 29_999_000 || Math.abs(value.z()) > 29_999_000 || value.y() < -2048 || value.y() > 2048)
            throw new IllegalArgumentException("Show position outside world bounds");
        return value;
    }
    private static void identifier(String value) {
        if (value == null || !value.matches("[a-zA-Z0-9_.-]{1,64}")) throw new IllegalArgumentException("Invalid attraction identifier");
    }
}
