package dev.coasterengineering.client;

/** Bounded optional look hint. Mouse input and server-facing player angles stay intact. */
public final class RideGazeMotion {
    private double previousBlend;
    private double blend;

    public void tick(boolean requested, double maximumBlend) {
        double limit = Double.isFinite(maximumBlend) ? clamp(maximumBlend, 0, .45) : 0;
        if (limit == 0) { reset(); return; }
        previousBlend = blend;
        blend += ((requested ? limit : 0) - blend) * .12;
        if (!requested && blend < .0001) blend = 0;
    }

    public Sample sample(double partialTick, double yaw, double pitch, double targetYaw, double targetPitch) {
        if (!Double.isFinite(yaw) || !Double.isFinite(pitch) || !Double.isFinite(targetYaw)
                || !Double.isFinite(targetPitch)) return new Sample(0, 0);
        double partial = Double.isFinite(partialTick) ? clamp(partialTick, 0, 1) : 0;
        double amount = previousBlend + (blend - previousBlend) * partial;
        return new Sample(clamp(wrap(targetYaw - yaw), -45, 45) * amount,
                clamp(targetPitch - pitch, -20, 20) * amount);
    }

    public void reset() { previousBlend = blend = 0; }
    private static double wrap(double angle) {
        double wrapped = angle % 360;
        if (wrapped >= 180) wrapped -= 360;
        if (wrapped < -180) wrapped += 360;
        return wrapped;
    }
    private static double clamp(double value, double low, double high) { return Math.max(low, Math.min(high, value)); }
    public record Sample(double yawDegrees, double pitchDegrees) { }
}
