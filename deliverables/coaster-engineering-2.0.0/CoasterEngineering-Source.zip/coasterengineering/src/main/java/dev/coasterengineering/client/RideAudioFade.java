package dev.coasterengineering.client;

/** Deterministic mix envelope: normal fades stay gentle; scripted silence clears before the roar. */
public final class RideAudioFade {
    public static final int NORMAL_TICKS = 40;
    public static final int SILENCE_TICKS = 10;
    private double target;
    private double volume;
    private int remaining;

    public void setTarget(double requested) { setTarget(requested, false); }

    public void setTarget(double requested, boolean scriptedSilence) {
        requested = Double.isFinite(requested) ? Math.max(0, Math.min(1, requested)) : 0;
        if (Double.compare(target, requested) == 0) {
            // A song already fading out during a crossfade must also quiet
            // before the encounter, without restarting its envelope each tick.
            if (scriptedSilence && target == 0 && remaining > SILENCE_TICKS) remaining = SILENCE_TICKS;
            return;
        }
        target = requested;
        remaining = scriptedSilence && target == 0 ? SILENCE_TICKS : NORMAL_TICKS;
    }

    public double tick() {
        if (remaining > 0) {
            volume += (target - volume) / remaining;
            remaining--;
        } else volume = target;
        return volume;
    }

    public boolean finishedSilent() { return target == 0 && remaining == 0; }
}
