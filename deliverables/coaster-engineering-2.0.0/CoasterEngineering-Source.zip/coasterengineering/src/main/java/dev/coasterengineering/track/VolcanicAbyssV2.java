package dev.coasterengineering.track;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;

/**
 * New 2.0 route: crystal lake, ruins, creature encounter, rising helix, summit drop,
 * and outdoor escape. This route intentionally has no vehicle inversions.
 * The 1.1 route and saved data remain independent and unchanged.
 */
public final class VolcanicAbyssV2 {
    public static final UUID COURSE_ID = UUID.nameUUIDFromBytes(
            "CoasterEngineering:VolcanicAbyss:2.0".getBytes(StandardCharsets.UTF_8));
    public static final TrackVec3 STATION = new TrackVec3(0, 94, -165);
    public static final int STATION_DWELL_TICKS = 140;
    public static final double STATION_ARRIVAL_SPEED = .025;
    public static final double STOP_APPROACH_SPEED = .025;
    private static final Map<SplineTrack, Map<ProfileConfiguration, Profile>> PROFILES = new WeakHashMap<>();

    private VolcanicAbyssV2() { }

    public static SplineTrack create(TrackVec3 origin) {
        return new SplineTrack(points(origin), true);
    }

    public static List<ControlPoint> points(TrackVec3 origin) {
        Objects.requireNonNull(origin, "origin");
        return List.of(
                p(origin, 0, 94, -165, 0, RailKind.STATION, 0.22),
                p(origin, 0, 94, -142, 0, RailKind.STATION, 0.4),
                p(origin, -4, 94, -122, -4, RailKind.BOOST, 0.43),
                p(origin, -28, 92, -100, -12, RailKind.BOOST, 0.45),
                p(origin, -62, 89, -95, -8, RailKind.BOOST, 0.48),
                p(origin, -100, 88, -90, -18, RailKind.BOOST, 0.48),
                p(origin, -125, 85, -65, -22, RailKind.BOOST, 0.48),
                p(origin, -126, 82, -25, -18, RailKind.BOOST, 0.42),
                p(origin, -110, 83, 8, -15, RailKind.BOOST, 0.44),
                p(origin, -77, 86, 15, -22, RailKind.BOOST, 0.46),
                p(origin, -53, 90, -8, 18, RailKind.BOOST, 0.54),
                p(origin, -45, 98, -35, 20, RailKind.BOOST, 0.72),
                p(origin, -22, 102, -48, 10, RailKind.BOOST, 0.95),
                p(origin, 10, 106, -50, 8, RailKind.BOOST, 1),
                p(origin, 35, 111, -63, -18, RailKind.BOOST, 1.12),
                p(origin, 65, 120, -62, -30, RailKind.BOOST, 1.3),
                p(origin, 92, 121, -40, -36, RailKind.BOOST, 1.18),
                p(origin, 90, 103, -13, -20, RailKind.BOOST, 1.15),
                p(origin, 63, 96, -4, 24, RailKind.BOOST, 0.95),
                p(origin, 45, 110, 20, 28, RailKind.BOOST, 1.08),
                p(origin, 59, 123, 37, -32, RailKind.BOOST, 1),
                p(origin, 89, 111, 25, -38, RailKind.BOOST, 0.88),
                p(origin, 111, 94, 37, 35, RailKind.BOOST, 0.88),
                p(origin, 110, 87, 74, 22, RailKind.BOOST, 0.55),
                p(origin, 84, 84, 96, 10, RailKind.BOOST, 0.38),
                p(origin, 54, 82, 109, 0, RailKind.BOOST, 0.38),
                p(origin, 20, 84, 117, -12, RailKind.BOOST, 1.4),
                p(origin, -13, 88, 102, -28, RailKind.BOOST, 1.66666666667),
                p(origin, -26, 105, 76, -35, RailKind.BOOST, 1.3),
                p(origin, -53, 114, 63, -38, RailKind.BOOST, 1.2),
                p(origin, -88, 109, 62, -42, RailKind.BOOST, 1.35),
                p(origin, -110, 90, 82, -42, RailKind.BOOST, 1.33),
                p(origin, -98, 82, 109, -42, RailKind.BOOST, 1.15),
                p(origin, -73, 97, 121, -42, RailKind.BOOST, 1.35),
                p(origin, -47, 112, 111, -40, RailKind.BOOST, 1.22),
                p(origin, -48, 121, 84, -38, RailKind.BOOST, 1),
                p(origin, -66, 130, 62, -35, RailKind.LIFT, 0.95),
                p(origin, -92, 136, 57, -32, RailKind.LIFT, 0.92),
                p(origin, -127, 144, 71, -26, RailKind.LIFT, 0.86),
                p(origin, -145, 157, 108, -20, RailKind.LIFT, 0.6),
                p(origin, -139, 166, 143, -8, RailKind.LIFT, 0.36),
                p(origin, -115, 166, 160, 0, RailKind.LIFT, 0.28),
                p(origin, -90, 165, 165, 0, RailKind.LIFT, 0.4),
                p(origin, -51, 112, 180, 0, RailKind.NORMAL, 0.95),
                p(origin, -20, 84, 187, 0, RailKind.NORMAL, 1.66666666667),
                p(origin, 30, 82, 180, -12, RailKind.BOOST, 1.66666666667),
                p(origin, 73, 93, 167, -26, RailKind.BOOST, 1.55),
                p(origin, 95, 112, 145, -34, RailKind.BOOST, 1.18),
                p(origin, 122, 129, 127, -36, RailKind.BOOST, 1.22),
                p(origin, 151, 143, 105, -30, RailKind.BOOST, 1.45),
                p(origin, 166, 147, 63, -28, RailKind.BOOST, 1.6),
                p(origin, 168, 135, 13, -24, RailKind.BOOST, 1.55),
                p(origin, 151, 117, -31, -18, RailKind.BOOST, 1.35),
                p(origin, 125, 108, -62, -15, RailKind.BOOST, 1.1),
                p(origin, 96, 100, -92, -12, RailKind.BOOST, 0.95),
                p(origin, 66, 97, -116, -8, RailKind.BRAKE, 0.75),
                p(origin, 40, 95, -147, -4, RailKind.BRAKE, 0.65),
                p(origin, 25, 94, -179, -4, RailKind.BRAKE, 0.5),
                p(origin, 8, 94, -200, -3, RailKind.BRAKE, 0.4),
                p(origin, 0, 94, -200, 0, RailKind.BRAKE, 0.32),
                p(origin, 0, 94, -187, 0, RailKind.BRAKE, 0.25),
                p(origin, 0, 94, -176, 0, RailKind.BRAKE, 0.18));
    }

    public enum Stage {
        EXPLORE(0, .012, .024), RUINS(13, .020, .030), MONSTER(24, .014, .030),
        ESCAPE_MONSTER(26, .025, .030), ERUPTION(29, .021, .030), DROP(42, .024, .032),
        FINAL_ESCAPE(45, .025, .030), RETURN(55, .015, .030);
        private final int point;
        private final double acceleration, braking;
        Stage(int point, double acceleration, double braking) {
            this.point = point; this.acceleration = acceleration; this.braking = braking;
        }
        public int firstPoint() { return point; }
        public double acceleration() { return acceleration; }
        public double braking() { return braking; }
    }

    public record Stop(String id, int controlPoint, int durationTicks, double distance) { }

    public static List<Stop> showStops(SplineTrack track) {
        requirePointCount(track);
        return List.of(new Stop("monster_pause", 25, 60, track.controlPointDistance(25)),
                new Stop("precipice_pause", 42, 35, track.controlPointDistance(42)));
    }

    public static Stage stageAt(SplineTrack track, double distance) {
        requirePointCount(track);
        if (!Double.isFinite(distance)) throw new IllegalArgumentException("Distance must be finite");
        Stage result = Stage.EXPLORE;
        double bounded = Math.max(0, Math.min(track.length(), distance));
        for (Stage stage : Stage.values()) {
            if (bounded >= track.controlPointDistance(stage.firstPoint())) result = stage;
        }
        return result;
    }

    public static double stageStart(SplineTrack track, Stage stage) {
        requirePointCount(track);
        return track.controlPointDistance(Objects.requireNonNull(stage, "stage").firstPoint());
    }

    /** Elevated exterior from the rising helix exit through the outdoor escape. */
    public static boolean outdoor(SplineTrack track, double distance) {
        requirePointCount(track);
        return distance >= track.controlPointDistance(39) && distance < track.controlPointDistance(55);
    }

    public static Profile profile(SplineTrack track) { return profile(track, Set.of()); }

    /**
     * Four immutable profiles cover the two completed-stop bits. Values contain
     * numeric arrays only and do not retain the weak-key track. The director owns
     * hold timers, stop completion, persistence and exactly-once event delivery.
     */
    public static Profile profile(SplineTrack track, Set<String> completedStopIds) {
        requirePointCount(track);
        Objects.requireNonNull(completedStopIds, "completedStopIds");
        int mask = (completedStopIds.contains("monster_pause") ? 1 : 0)
                | (completedStopIds.contains("precipice_pause") ? 2 : 0);
        synchronized (PROFILES) {
            Map<ProfileConfiguration, Profile> variants = PROFILES.computeIfAbsent(track, ignored -> new HashMap<>());
            ProfileConfiguration configuration = new ProfileConfiguration(mask, defaultSegments());
            return variants.computeIfAbsent(configuration, ignored -> new Profile(track, mask, configuration.settings()));
        }
    }

    /** Explicit editing API used by the JSON configuration loader. */
    public static Profile profile(SplineTrack track, Set<String> completedStopIds,
                                  List<SegmentSettings> settings) {
        requirePointCount(track);
        int mask = (completedStopIds.contains("monster_pause") ? 1 : 0)
                | (completedStopIds.contains("precipice_pause") ? 2 : 0);
        ProfileConfiguration configuration = new ProfileConfiguration(mask, List.copyOf(settings));
        synchronized (PROFILES) {
            Map<ProfileConfiguration, Profile> variants = PROFILES.computeIfAbsent(track, ignored -> new HashMap<>());
            return variants.computeIfAbsent(configuration, ignored -> new Profile(track, mask, configuration.settings()));
        }
    }

    private record ProfileConfiguration(int completedStops, List<SegmentSettings> settings) { }

    public record SegmentSettings(Stage stage, double maximumAcceleration, double maximumBraking,
                                  double speedMultiplier) {
        public SegmentSettings(Stage stage, double maximumAcceleration, double maximumBraking) {
            this(stage, maximumAcceleration, maximumBraking, 1.0);
        }
        public SegmentSettings {
            Objects.requireNonNull(stage, "stage");
            if (!Double.isFinite(maximumAcceleration) || maximumAcceleration <= 0 || maximumAcceleration > .025
                    || !Double.isFinite(maximumBraking) || maximumBraking <= 0 || maximumBraking > .035
                    || !Double.isFinite(speedMultiplier) || speedMultiplier < .1 || speedMultiplier > 2) {
                throw new IllegalArgumentException("Segment limits must be positive; acceleration <= .025, braking <= .035; speed multiplier .1..2");
            }
        }
    }

    public static List<SegmentSettings> defaultSegments() {
        List<SegmentSettings> result = new ArrayList<>();
        for (Stage stage : Stage.values()) result.add(new SegmentSettings(stage, stage.acceleration(), stage.braking()));
        return List.copyOf(result);
    }

    public static final class Profile implements RideDynamics.SpeedProfile {
        private static final double MAX_INTERVAL = .25;
        private static final double LATERAL_ACCELERATION = .065;
        /** Up to four original cars at four-block spacing share the leader's speed. */
        private static final double PROTECTED_FORMATION_LENGTH = 12;
        private final double length, interval;
        private final double[] knots, targets, safeTargets, stageStarts, acceleration, braking, speedMultipliers;
        private final List<Stop> activeStops;
        private final boolean monsterReleased, precipiceReleased;

        private Profile(SplineTrack track, int completedStops, List<SegmentSettings> settings) {
            length = track.length();
            monsterReleased = (completedStops & 1) != 0;
            precipiceReleased = (completedStops & 2) != 0;
            knots = new double[track.points().size() + 1];
            targets = new double[knots.length];
            for (int i = 0; i < track.points().size(); i++) {
                knots[i] = track.controlPointDistance(i); targets[i] = track.points().get(i).targetSpeed();
            }
            knots[knots.length - 1] = length;
            targets[targets.length - 1] = STATION_ARRIVAL_SPEED;
            Stage[] stages = Stage.values();
            stageStarts = new double[stages.length];
            acceleration = new double[stages.length]; braking = new double[stages.length];
            speedMultipliers = new double[stages.length];
            if (settings.size() != stages.length) throw new IllegalArgumentException("One setting per stage is required");
            boolean[] found = new boolean[stages.length];
            for (SegmentSettings setting : settings) {
                int index = setting.stage().ordinal();
                if (found[index]) throw new IllegalArgumentException("Duplicate stage setting");
                found[index] = true;
                stageStarts[index] = track.controlPointDistance(setting.stage().firstPoint());
                acceleration[index] = setting.maximumAcceleration(); braking[index] = setting.maximumBraking();
                speedMultipliers[index] = setting.speedMultiplier();
            }
            List<Stop> pending = new ArrayList<>();
            List<Stop> all = showStops(track);
            if ((completedStops & 1) == 0) pending.add(all.get(0));
            if ((completedStops & 2) == 0) pending.add(all.get(1));
            activeStops = List.copyOf(pending);
            int intervals = (int) Math.ceil(length / MAX_INTERVAL);
            interval = length / intervals;
            safeTargets = new double[intervals + 1];
            double[] curvatures = new double[intervals + 1];
            for (int i = 0; i <= intervals; i++) {
                double d = i * interval;
                double curvature = 0;
                // Use a narrow differential and local maximum; a one-block chord
                // underestimates the station turn where curvature changes quickly.
                for (double offset : new double[] {-.25, 0, .25}) {
                    TrackVec3 before = track.sample(d + offset - .1).tangent();
                    TrackVec3 after = track.sample(d + offset + .1).tangent();
                    curvature = Math.max(curvature, after.subtract(before).length() / .2);
                }
                curvatures[i] = curvature;
            }
            int protectedIntervals = (int) Math.ceil(PROTECTED_FORMATION_LENGTH / interval);
            for (int i = 0; i <= intervals; i++) {
                double d = i * interval;
                double curvature = curvatures[i];
                // Every car is kinematically linked to the leader. Keep the
                // formation speed low until its last car clears the curve,
                // including wrapped followers across the station seam.
                for (int back = 1; back <= protectedIntervals; back++) {
                    curvature = Math.max(curvature, curvatures[Math.floorMod(i - back, intervals)]);
                }
                double curveLimit = curvature > 1e-8 ? Math.min(Math.sqrt(LATERAL_ACCELERATION / curvature), Math.toRadians(3.5) / curvature)
                        : RideDynamics.MAX_SUPPORTED_SPEED;
                double target = Math.min(rawTargetSpeed(d), Math.min(curveLimit, RideDynamics.MAX_SUPPORTED_SPEED));
                for (Stop stop : activeStops) {
                    double approach = stop.distance() - d;
                    if (approach >= -.001) {
                        // Slightly conservative continuous envelope allows the entity to
                        // clamp at the exact stop without a high-speed discontinuity.
                        target = Math.min(target, stopApproachTarget(Math.max(0, approach), minimumBrakingBetween(d, stop.distance())));
                    }
                }
                safeTargets[i] = target;
            }
            for (int i = intervals - 1; i >= 0; i--) {
                double brake = .9 * Math.min(maximumBraking(i * interval), maximumBraking((i + 1) * interval));
                safeTargets[i] = Math.min(safeTargets[i], Math.sqrt(safeTargets[i + 1] * safeTargets[i + 1]
                        + 2 * brake * interval));
            }
        }

        @Override public double targetSpeed(double distance) {
            double index = bound(distance) / interval;
            int lower = Math.min((int) index, safeTargets.length - 2);
            double fraction = index - lower;
            double target = safeTargets[lower] + (safeTargets[lower + 1] - safeTargets[lower]) * fraction;
            double d = bound(distance);
            for (Stop stop : activeStops) {
                double remaining = stop.distance() - d;
                if (remaining >= 0) target = Math.min(target, stopApproachTarget(remaining, minimumBrakingBetween(d, stop.distance())));
            }
            return target;
        }

        @Override public double maximumAcceleration(double distance) { return stageLimit(distance, acceleration); }
        @Override public double maximumBraking(double distance) { return stageLimit(distance, braking); }

        public double rawTargetSpeed(double distance) {
            double d = bound(distance);
            // These are distance-preserving launch commands, not velocity jumps.
            // The following saved point remains the editable launch target, and
            // the narrative section's JSON multiplier/drive limits still apply.
            if (monsterReleased && d >= knots[25] && d < knots[26]) {
                return targets[26] * speedMultipliers[Stage.ESCAPE_MONSTER.ordinal()];
            }
            if (precipiceReleased && d >= knots[42] && d < knots[43]) {
                return targets[43] * speedMultipliers[Stage.DROP.ordinal()];
            }
            int segment = Arrays.binarySearch(knots, d);
            if (segment >= 0) return targets[segment] * stageLimit(d, speedMultipliers);
            segment = -segment - 2;
            double t = (d - knots[segment]) / (knots[segment + 1] - knots[segment]);
            double smooth = t * t * (3 - 2 * t);
            return (targets[segment] + (targets[segment + 1] - targets[segment]) * smooth)
                    * stageLimit(d, speedMultipliers);
        }

        public Stage stage(double distance) {
            double d = bound(distance); Stage result = Stage.EXPLORE;
            for (Stage stage : Stage.values()) if (d >= stageStarts[stage.ordinal()]) result = stage;
            return result;
        }

        public double stageStart(Stage stage) { return stageStarts[stage.ordinal()]; }
        public List<Stop> activeStops() { return activeStops; }

        private double stageLimit(double distance, double[] limits) {
            double d = bound(distance); int selected = stage(d).ordinal();
            // Begin escape thrust with the creature attack, immediately after
            // its hold. Preserve it through the old boundary's blend window.
            if (monsterReleased && d >= knots[25] && d < knots[26] + 8) {
                return limits[Stage.ESCAPE_MONSTER.ordinal()];
            }
            if (precipiceReleased && d >= knots[42] && d < knots[42] + 8) {
                return limits[Stage.DROP.ordinal()];
            }
            // Smooth drive authority over sixteen blocks around every narrative transition.
            for (int i = 1; i < stageStarts.length; i++) {
                if (Math.abs(d - stageStarts[i]) < 8) {
                    double t = (d - stageStarts[i] + 8) / 16;
                    t = t * t * (3 - 2 * t);
                    return limits[i - 1] + (limits[i] - limits[i - 1]) * t;
                }
            }
            return limits[selected];
        }

        private static double stopApproachTarget(double remaining, double braking) {
            return Math.min(Math.sqrt(STOP_APPROACH_SPEED * STOP_APPROACH_SPEED + 2 * .9 * braking * remaining),
                    STOP_APPROACH_SPEED + .035 * remaining);
        }

        private double minimumBrakingBetween(double a, double b) {
            double minimum = Math.min(maximumBraking(a), maximumBraking(b));
            for (int i = 0; i < stageStarts.length; i++) {
                if (stageStarts[i] >= a - 8 && stageStarts[i] <= b + 8) minimum = Math.min(minimum, braking[i]);
            }
            return minimum;
        }

        private double bound(double distance) {
            if (!Double.isFinite(distance)) throw new IllegalArgumentException("Distance must be finite");
            return Math.max(0, Math.min(length, distance));
        }
    }

    private static void requirePointCount(SplineTrack track) {
        Objects.requireNonNull(track, "track");
        if (!track.closed() || track.points().size() != 62) {
            throw new IllegalArgumentException("The V2 narrative program requires its closed 62-point route");
        }
    }

    private static ControlPoint p(TrackVec3 origin, double x, double y, double z, double bank,
                                 RailKind kind, double target) {
        return new ControlPoint(origin.add(new TrackVec3(x, y, z)), bank, kind, target);
    }
}
