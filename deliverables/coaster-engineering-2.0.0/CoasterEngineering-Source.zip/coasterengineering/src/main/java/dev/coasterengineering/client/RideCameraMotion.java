package dev.coasterengineering.client;

/** Bounded visual motion only; never changes the player's look or train physics. */
public final class RideCameraMotion {
    private static final double MAX_VIBRATION_DEGREES = .25;
    private static final double MAX_FOV_PERCENT = 3;
    private static final double EASING = .18;
    private double previousVibration;
    private double vibration;
    private double previousFov;
    private double fov;

    /** Called once per client tick, with speed in blocks/tick. */
    public void tick(double speed, boolean running, double vibrationDegrees, double fovPercent) {
        tick(speed, running, vibrationDegrees, fovPercent, 0);
    }

    /** Acceleration texture is gentle and uses the same separately disabled vibration limit. */
    public void tick(double speed, boolean running, double vibrationDegrees, double fovPercent, double acceleration) {
        if (!running || !Double.isFinite(speed) || speed <= 0) {
            reset();
            return;
        }
        double highSpeed = clamp((speed * 72 - 60) / 60, 0, 1);
        double strength = highSpeed * highSpeed * (3 - 2 * highSpeed);
        double accelerationTexture = Double.isFinite(acceleration)
                ? clamp(Math.abs(acceleration) / .025, 0, 1) * .30 : 0;
        double vibrationLimit = finiteLimit(vibrationDegrees, MAX_VIBRATION_DEGREES);
        double fovLimit = finiteLimit(fovPercent, MAX_FOV_PERCENT) / 100;
        vibration = Math.min(vibration, vibrationLimit);
        fov = Math.min(fov, fovLimit);
        previousVibration = vibration;
        previousFov = fov;
        vibration += (Math.max(strength, accelerationTexture) * vibrationLimit - vibration) * EASING;
        fov += (strength * fovLimit - fov) * EASING;
        // Turning an option off must also remove its previous interpolation value.
        if (vibrationLimit == 0) previousVibration = vibration = 0;
        if (fovLimit == 0) previousFov = fov = 0;
    }

    public Sample sample(double partialTick, double animationTicks) {
        double partial = Double.isFinite(partialTick) ? clamp(partialTick, 0, 1) : 0;
        double amplitude = previousVibration + (vibration - previousVibration) * partial;
        double widening = previousFov + (fov - previousFov) * partial;
        if (amplitude == 0) return new Sample(0, 0, 1 + widening);
        double time = Double.isFinite(animationTicks) ? animationTicks / 20 : 0;
        // Gentle, deterministic frequencies give rail texture without random
        // frame-to-frame jumps. Each combined waveform stays within its limit.
        double roll = amplitude * (.7 * Math.sin(time * Math.PI * 2 * 1.7)
                + .3 * Math.sin(time * Math.PI * 2 * 2.9));
        double pitch = amplitude * (.65 * Math.sin(time * Math.PI * 2 * 2.3)
                + .35 * Math.sin(time * Math.PI * 2 * 1.1));
        return new Sample(roll, pitch, 1 + widening);
    }

    public void reset() {
        previousVibration = vibration = previousFov = fov = 0;
    }

    private static double finiteLimit(double value, double maximum) {
        return Double.isFinite(value) ? clamp(value, 0, maximum) : 0;
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    public record Sample(double rollDegrees, double pitchDegrees, double fovScale) { }
}
