package dev.coasterengineering;

import net.minecraftforge.common.ForgeConfigSpec;

/** Separate server-authoritative motion limits and per-client comfort settings. */
public final class CoasterConfig {
    public static final ForgeConfigSpec SERVER_SPEC;
    public static final ForgeConfigSpec CLIENT_SPEC;
    public static final ForgeConfigSpec.DoubleValue MAX_SPEED_KMH;
    public static final ForgeConfigSpec.DoubleValue MAX_ACCELERATION;
    public static final ForgeConfigSpec.DoubleValue CAMERA_ROLL_LIMIT;
    public static final ForgeConfigSpec.BooleanValue BANK_CAMERA;
    public static final ForgeConfigSpec.BooleanValue FOLLOW_TRACK_CAMERA;
    public static final ForgeConfigSpec.BooleanValue MUSIC_ENABLED;
    public static final ForgeConfigSpec.DoubleValue MUSIC_VOLUME;
    public static final ForgeConfigSpec.DoubleValue EFFECTS_INTENSITY;
    public static final ForgeConfigSpec.BooleanValue RIDE_SOUNDS;
    public static final ForgeConfigSpec.DoubleValue RIDE_SOUND_VOLUME;
    public static final ForgeConfigSpec.DoubleValue CAMERA_VIBRATION_DEGREES;
    public static final ForgeConfigSpec.DoubleValue CAMERA_FOV_PERCENT;
    public static final ForgeConfigSpec.BooleanValue AUTOMATIC_GAZE;
    public static final ForgeConfigSpec.DoubleValue AUTOMATIC_GAZE_BLEND;

    static {
        ForgeConfigSpec.Builder server = new ForgeConfigSpec.Builder();
        MAX_SPEED_KMH = server.comment("Maximum server-authoritative coaster speed in km/h equivalent.")
                .defineInRange("maximumSpeedKmh", 120.0, 1.0, 120.0);
        MAX_ACCELERATION = server.comment("Positive acceleration limit in blocks/tick squared; lower values soften launch and drops.")
                .defineInRange("maximumAcceleration", 0.025, 0.001, 0.025);
        SERVER_SPEC = server.build();
        ForgeConfigSpec.Builder client = new ForgeConfigSpec.Builder();
        BANK_CAMERA = client.comment("Apply bank roll to the rider camera. Disable for motion comfort.")
                .define("bankCamera", true);
        FOLLOW_TRACK_CAMERA = client.comment("Follow the interpolated track heading and pitch, keeping mouse free look relative to the car.")
                .define("followTrackCamera", true);
        CAMERA_ROLL_LIMIT = client.comment("Camera roll limit in degrees; vehicle banking remains unchanged.")
                .defineInRange("cameraRollLimitDegrees", 25.0, 0.0, 60.0);
        MUSIC_ENABLED = client.comment("Play original streamed attraction music while riding; the Minecraft Music slider also applies.")
                .define("attractionMusic", true);
        MUSIC_VOLUME = client.comment("Attraction music volume before the Minecraft Music/master sliders.")
                .defineInRange("attractionMusicVolume", 0.8, 0.0, 1.0);
        RIDE_SOUNDS = client.comment("Play speed-dependent wheel and wind sounds while riding; the Music/master sliders apply.")
                .define("rideSounds", true);
        RIDE_SOUND_VOLUME = client.comment("Wheel and wind mix level; these effects stay below the attraction music mix.")
                .defineInRange("rideSoundVolume", 0.35, 0.0, 1.0);
        CAMERA_VIBRATION_DEGREES = client.comment("Maximum additional high-speed camera vibration in degrees; zero disables it.")
                .defineInRange("cameraVibrationDegrees", 0.18, 0.0, 0.25);
        CAMERA_FOV_PERCENT = client.comment("Maximum high-speed FOV increase in percent; zero disables it.")
                .defineInRange("cameraFovPercent", 2.0, 0.0, 3.0);
        AUTOMATIC_GAZE = client.comment("Brief first-person look hint toward the encounter. Disable to keep entirely manual mouse look.")
                .define("automaticGaze", true);
        AUTOMATIC_GAZE_BLEND = client.comment("Optional encounter look influence; at 0.30 the added yaw stays within 13.5 degrees and pitch within 6 degrees. Zero disables it.")
                .defineInRange("automaticGazeBlend", 0.30, 0.0, 0.45);
        EFFECTS_INTENSITY = client.comment("Cosmetic particles, soft light cues and stinger volume; zero disables these effects.")
                .defineInRange("effectsIntensity", 0.55, 0.0, 1.0);
        CLIENT_SPEC = client.build();
    }

    private CoasterConfig() { }
}
