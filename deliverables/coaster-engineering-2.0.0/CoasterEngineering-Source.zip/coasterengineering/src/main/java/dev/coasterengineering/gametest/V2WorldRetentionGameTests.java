package dev.coasterengineering.gametest;

import dev.coasterengineering.track.VolcanicAbyssV2;
import dev.coasterengineering.world.VolcanicV2WorldBuilder;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.server.level.DistanceManager;
import net.minecraft.server.level.ServerChunkCache;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.Ticket;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/** Regression for the real delayed construction-ticket expiry, without rebuilding the entire attraction. */
@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class V2WorldRetentionGameTests {
    private V2WorldRetentionGameTests() { }

    @GameTest(template = "empty", timeoutTicks = 30)
    public static void expiredConstructionRetentionReleasesItsTicketAndKeepsServerTicking(GameTestHelper helper) {
        ServerLevel level = helper.getLevel();
        ChunkPos chunk = new ChunkPos(helper.absolutePos(new BlockPos(8, 2, 8)));
        helper.assertTrue(level.getChunkSource().getChunkNow(chunk.x, chunk.z) != null,
                "Ticket-expiry fixture must use an already loaded GameTest chunk, without generating a large world");
        Map<ServerLevel, Object> retention = retention();
        TicketType<UUID> ticketType = constructionTicket();
        helper.assertFalse(retention.containsKey(level), "The fixture must not replace a real pending construction retention");
        helper.assertFalse(hasTicket(level, chunk, ticketType), "The chosen existing chunk must not already have this construction ticket");
        long initialGameTime = level.getGameTime();
        int initialServerTick = level.getServer().getTickCount();
        Object retained = retained(List.of(chunk), initialGameTime + 4);
        level.getChunkSource().addRegionTicket(ticketType, chunk, 2, VolcanicAbyssV2.COURSE_ID);
        retention.put(level, retained);
        helper.assertTrue(hasTicket(level, chunk, ticketType), "The fixture must install a real region ticket in Minecraft's distance manager");
        helper.runAfterDelay(2, () -> {
            helper.assertTrue(retention.get(level) == retained && hasTicket(level, chunk, ticketType),
                    "Normal server ticks must retain the same real ticket before its four-tick deadline");
        });
        helper.runAfterDelay(8, () -> {
            try {
                helper.assertTrue(level.getGameTime() >= initialGameTime + 8
                                && level.getServer().getTickCount() >= initialServerTick + 8,
                        "The actual server must continue ticking beyond the construction retention deadline");
                helper.assertFalse(retention.containsKey(level),
                        "The actual ServerTickEvent expiry path must remove its identity-map retention entry");
                helper.assertFalse(hasTicket(level, chunk, ticketType),
                        "Expired retention must release the actual construction ticket, not only its bookkeeping entry");
                helper.succeed();
            } finally {
                retention.remove(level);
                level.getChunkSource().removeRegionTicket(ticketType, chunk, 2, VolcanicAbyssV2.COURSE_ID);
            }
        });
    }

    @SuppressWarnings("unchecked")
    private static Map<ServerLevel, Object> retention() {
        return (Map<ServerLevel, Object>) field(VolcanicV2WorldBuilder.class, "RETENTION", null);
    }

    @SuppressWarnings("unchecked")
    private static TicketType<UUID> constructionTicket() {
        return (TicketType<UUID>) field(VolcanicV2WorldBuilder.class, "TICKET", null);
    }

    private static Object retained(List<ChunkPos> chunks, long until) {
        try {
            Class<?> type = Class.forName(VolcanicV2WorldBuilder.class.getName() + "$Retention");
            Constructor<?> constructor = type.getDeclaredConstructor(List.class, long.class);
            constructor.setAccessible(true);
            return constructor.newInstance(chunks, until);
        } catch (ReflectiveOperationException failure) {
            throw new IllegalStateException("Could not install the private construction-retention test fixture", failure);
        }
    }

    private static boolean hasTicket(ServerLevel level, ChunkPos chunk, TicketType<UUID> type) {
        DistanceManager manager = (DistanceManager) field(ServerChunkCache.class, "distanceManager", level.getChunkSource());
        Map<?, ?> tickets = (Map<?, ?>) field(DistanceManager.class, "tickets", manager);
        Object entry = tickets.get(chunk.toLong());
        if (!(entry instanceof Iterable<?> values)) return false;
        for (Object value : values) if (value instanceof Ticket<?> ticket && ticket.getType() == type) return true;
        return false;
    }

    private static Object field(Class<?> owner, String name, Object instance) {
        try {
            Field field = owner.getDeclaredField(name);
            field.setAccessible(true);
            return field.get(instance);
        } catch (ReflectiveOperationException failure) {
            throw new IllegalStateException("Could not inspect the real ticket-expiry fixture field " + name, failure);
        }
    }
}
