package dev.coasterengineering.gametest;

import dev.coasterengineering.attraction.AttractionDirector;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.track.TrainSpacing;
import dev.coasterengineering.track.VolcanicAbyssV2;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import dev.coasterengineering.world.TrainService;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.DoubleTag;
import net.minecraft.nbt.FloatTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/** Normal entity ticks recover a paused saved formation; deliberate running show stops remain separate. */
@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class V2EmptyReturnGameTests {
    private V2EmptyReturnGameTests() { }

    @GameTest(template = "empty", timeoutTicks = 230)
    public static void emptyV2FormationReturnsOnlyAfterRiderAlarmAndStationObstructionAreCleared(GameTestHelper helper) {
        CoasterSavedData data = CoasterSavedData.get(helper.getLevel());
        helper.assertTrue(data.getCourse(VolcanicAbyssV2.COURSE_ID) == null,
                "Recovery fixture must not overwrite another existing V2 course");
        Vec3 stationRail = helper.absoluteVec(new Vec3(8.5, 3, 6.5));
        TrackVec3 offset = new TrackVec3(stationRail.x, stationRail.y, stationRail.z).subtract(VolcanicAbyssV2.STATION);
        SplineTrack track = VolcanicAbyssV2.create(offset);
        Course course = new Course(VolcanicAbyssV2.COURSE_ID, "V2 saved-empty recovery fixture", track,
                helper.absolutePos(new BlockPos(8, 2, 4)), true);
        data.putCourse(course);
        CoasterEntity leader = CoasterRegistries.COASTER.get().create(helper.getLevel());
        helper.assertTrue(leader != null, "The fixture must create the actual registered coaster entity");
        leader.setCourse(course.id());
        helper.assertTrue(leader.resetToStation() && helper.getLevel().addFreshEntity(leader)
                        && TrainService.setCarCount(leader, 3), "Recovery fixture must reserve and link three real cars");
        List<CoasterEntity> cars = leader.getLoadedFormation();
        List<UUID> originalIds = cars.stream().map(Entity::getUUID).toList();
        restorePausedPose(cars, track, 12);
        Player rider = helper.makeMockSurvivalPlayer();
        CoasterEntity rear = cars.get(2);
        rider.moveTo(rear.position());
        helper.assertTrue(rider.startRiding(rear), "A real mounted player on the rear car must block whole-train empty recovery");
        BlockPos stationObstacle = BlockPos.containing(stationRail).above();
        BlockState previousStationBlock = helper.getLevel().getBlockState(stationObstacle);
        helper.assertTrue(previousStationBlock.isAir(), "Station obstacle must be an explicit temporary test fixture");
        helper.runAfterDelay(70, () -> {
            pausedAt(helper, cars, track, 12);
            helper.assertTrue(rider.getVehicle() == rear, "Seventy occupied paused ticks must neither return nor eject a valid passenger");
            rider.stopRiding();
            data.setEmergency(course.id(), true);
        });
        helper.runAfterDelay(140, () -> {
            pausedAt(helper, cars, track, 12);
            helper.assertTrue(data.isEmergency(course.id()), "Empty recovery must preserve the authoritative emergency alarm");
            data.setEmergency(course.id(), false);
            helper.getLevel().setBlock(stationObstacle, Blocks.STONE.defaultBlockState(), 3);
        });
        helper.runAfterDelay(170, () -> {
            pausedAt(helper, cars, track, 12);
            helper.assertFalse(data.isEmergency(course.id()), "The explicit operator action must clear the alarm without dispatching");
        });
        helper.runAfterDelay(205, () -> {
            pausedAt(helper, cars, track, 12);
            helper.assertTrue(helper.getLevel().getBlockState(stationObstacle).is(Blocks.STONE),
                    "Recovery must not clear an obstructed station to make a destination fit");
            helper.getLevel().setBlock(stationObstacle, previousStationBlock, 3);
        });
        helper.runAfterDelay(211, () -> {
            pausedAt(helper, cars, track, 0);
            helper.assertTrue(leader.getLoadedFormation().stream().map(Entity::getUUID).toList().equals(originalIds)
                            && data.vehicleId(course.id()).equals(leader.getUUID()),
                    "Safe empty recovery must return the same three UUIDs and reserved leader without replacements");
            helper.assertFalse(AttractionDirector.active(helper.getLevel(), course.id()),
                    "Successful recovery must leave stale attraction effects interrupted rather than silently restarting them");
            cars.forEach(Entity::discard);
            data.removeCourse(course.id());
            helper.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 95)
    public static void legacyEmptyPausedCoasterRetainsItsSavedDistance(GameTestHelper helper) {
        ServerCourseFixture fixture = ServerCourseFixture.create(helper);
        restorePausedPose(List.of(fixture.vehicle()), fixture.course().track(), 12);
        helper.runAfterDelay(80, () -> {
            pausedAt(helper, List.of(fixture.vehicle()), fixture.course().track(), 12);
            fixture.cleanup(helper);
            helper.succeed();
        });
    }

    /** Real serialized entity state models a save/relog during a stopped ride, without ticking fake movement. */
    private static void restorePausedPose(List<CoasterEntity> cars, SplineTrack track, double leaderDistance) {
        for (int index = 0; index < cars.size(); index++) {
            CoasterEntity car = cars.get(index);
            double distance = TrainSpacing.distance(track, leaderDistance, index, 4);
            TrackSample sample = track.sample(distance);
            CompoundTag saved = car.saveWithoutId(new CompoundTag());
            saved.putDouble("CoasterDistance", distance);
            saved.putDouble("CoasterSpeed", 0);
            saved.putBoolean("CoasterRunning", false);
            saved.putFloat("CoasterBank", (float) sample.bankDegrees());
            ListTag position = new ListTag();
            position.add(DoubleTag.valueOf(sample.position().x()));
            position.add(DoubleTag.valueOf(sample.position().y()));
            position.add(DoubleTag.valueOf(sample.position().z()));
            saved.put("Pos", position);
            ListTag rotation = new ListTag();
            rotation.add(FloatTag.valueOf((float) Math.toDegrees(Math.atan2(-sample.tangent().x(), sample.tangent().z()))));
            rotation.add(FloatTag.valueOf((float) -Math.toDegrees(Math.atan2(sample.tangent().y(),
                    Math.hypot(sample.tangent().x(), sample.tangent().z())))));
            saved.put("Rotation", rotation);
            car.load(saved);
        }
    }

    private static void pausedAt(GameTestHelper helper, List<CoasterEntity> cars, SplineTrack track, double leaderDistance) {
        for (int index = 0; index < cars.size(); index++) {
            CoasterEntity car = cars.get(index);
            double distance = TrainSpacing.distance(track, leaderDistance, index, 4);
            TrackVec3 expected = track.sample(distance).position();
            helper.assertTrue(!car.isRunning() && car.getSpeed() == 0
                            && Math.abs(car.getDistance() - distance) < 1.0E-6
                            && car.position().distanceTo(new Vec3(expected.x(), expected.y(), expected.z())) < .01,
                    "The actual paused car " + index + " must stay on its saved arc with unchanged spacing; got " + car.getDistance());
        }
    }
}
