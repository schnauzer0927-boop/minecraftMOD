package dev.coasterengineering.gametest;

import com.google.gson.JsonObject;
import dev.coasterengineering.attraction.AttractionDefinition;
import dev.coasterengineering.attraction.AttractionSavedData;
import dev.coasterengineering.attraction.AttractionTimeline;
import dev.coasterengineering.entity.ShowMonsterEntity;
import dev.coasterengineering.registry.CoasterRegistries;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.gametest.GameTestHolder;
import net.minecraftforge.gametest.PrefixGameTestTemplate;

/** Actual registered-entity and Minecraft NBT integration; full-size ride commissioning is separate. */
@GameTestHolder("coasterengineering")
@PrefixGameTestTemplate(false)
public final class V2AttractionGameTests {
    private V2AttractionGameTests() { }

    @GameTest(template = "empty", timeoutTicks = 50)
    public static void pendingShowStateSurvivesRealNbtWithoutRestartingAHoldOnReload(GameTestHelper helper) {
        UUID courseId = UUID.randomUUID();
        AttractionDefinition definition = definition();
        AttractionSavedData original = AttractionSavedData.get(helper.getLevel());
        AttractionTimeline timeline = original.timeline(courseId, definition, event -> event.distance());
        List<String> delivered = new ArrayList<>();
        timeline.dispatch(0, 0, event -> true, event -> delivered.add(event.id()));
        timeline.cross(0, 5, 0, 0, 30, event -> true, event -> delivered.add(event.id()));
        timeline.beginHold("scheduled_stop", 7);
        helper.assertTrue(timeline.active() && timeline.holdRemaining() == 7,
                "A live dimension-local timeline must begin its actual scheduled hold");
        helper.assertTrue(delivered.equals(List.of("departure", "scheduled_stop")),
                "Delayed roar must remain pending while immediate crossing events execute once");
        long sequence = original.nextSequence(courseId);
        CompoundTag nbt = original.save(new CompoundTag());
        helper.assertTrue(nbt.getInt("FormatVersion") == 1 && nbt.getList("Courses", 10).size() > 0,
                "The actual SavedData codec must write a versioned Minecraft list of course snapshots");
        AttractionSavedData restored = AttractionSavedData.load(nbt);
        AttractionTimeline reloaded = restored.timeline(courseId, definition, trigger -> trigger.distance());
        helper.assertFalse(reloaded.active(), "A saved active show must remain stopped after server load");
        helper.assertTrue(reloaded.holdRemaining() == 0 && restored.sequence(courseId) == sequence
                        && reloaded.executionCount("departure") == 1 && reloaded.executionCount("scheduled_stop") == 1,
                "Reload must retain event history and packet sequence without silently continuing a hold");
        helper.runAfterDelay(8, () -> {
            for (int tick = 0; tick < 8; tick++) reloaded.tick(event -> delivered.add(event.id()));
            helper.assertTrue(delivered.equals(List.of("departure", "scheduled_stop"))
                            && reloaded.executionCount("delayed_roar") == 0,
                    "Interrupted pending effects must not run just because world ticks elapsed after reload");
            reloaded.dispatch(0, 5, event -> true, event -> delivered.add(event.id()));
            helper.assertTrue(reloaded.active() && reloaded.completeStopIds().contains("scheduled_stop"),
                    "Explicit resume at a passed stop must not trap the paused train in the old hold");
            helper.assertTrue(reloaded.executionCount("departure") == 1,
                    "A past departure event must not replay when dispatch resumes from a later distance");
            original.existing(courseId).interrupt();
            helper.succeed();
        });
    }

    @GameTest(template = "empty", timeoutTicks = 50)
    public static void delayedCosmeticEffectsRunOnceOnActualServerTicksAndFailureIsContained(GameTestHelper helper) {
        UUID courseId = UUID.randomUUID();
        AttractionTimeline timeline = AttractionSavedData.get(helper.getLevel())
                .timeline(courseId, definition(), trigger -> trigger.distance());
        List<String> delivered = new ArrayList<>();
        timeline.dispatch(0, 0, event -> true, event -> delivered.add(event.id()));
        timeline.cross(0, 5, 0, 0, 30, event -> true, event -> delivered.add(event.id()));
        timeline.cross(0, 5, 0, 0, 30, event -> true, event -> delivered.add(event.id()));
        helper.assertTrue(timeline.executionCount("scheduled_stop") == 1 && timeline.executionCount("departure") == 1,
                "An overlapping travelled interval must not invoke already executed triggers again");
        long beginTick = helper.getLevel().getGameTime();
        for (int tick = 1; tick <= 7; tick++) {
            int expectedTick = tick;
            helper.runAfterDelay(tick, () -> {
                helper.assertTrue(helper.getLevel().getGameTime() >= beginTick + expectedTick,
                        "Delay integration must use elapsed real ServerLevel ticks");
                timeline.tick(event -> {
                    delivered.add(event.id());
                    if (event.id().equals("delayed_roar")) throw new IllegalStateException("Intentional unavailable cosmetic fixture");
                });
                if (expectedTick < 5)
                    helper.assertTrue(timeline.executionCount("delayed_roar") == 0, "The delayed effect must not execute early");
                else helper.assertTrue(timeline.executionCount("delayed_roar") == 1, "The delayed effect must execute exactly once despite its error");
                if (expectedTick == 7) {
                    helper.assertTrue(timeline.active() && timeline.snapshot().executions().stream()
                                    .anyMatch(event -> event.id().equals("delayed_roar") && event.status() == AttractionTimeline.Status.FAILED),
                            "Cosmetic failure must be observable and contained inside its own event state");
                    helper.assertTrue(delivered.stream().filter("delayed_roar"::equals).count() == 1,
                            "A failed effect must not repeatedly throw on subsequent normal server ticks");
                    timeline.interrupt();
                    helper.succeed();
                }
            });
        }
    }

    @GameTest(template = "empty", timeoutTicks = 125)
    public static void registeredMonsterAnimatesWithoutMovingOrDamagingTrackAndRestoresItsPose(GameTestHelper helper) {
        ServerCourseFixture fixture = ServerCourseFixture.create(helper);
        Vec3 anchor = fixture.vehicle().position().add(0, 0, 3);
        ShowMonsterEntity monster = ShowMonsterEntity.ensure(helper.getLevel(), fixture.course().id(), anchor);
        helper.assertTrue(ShowMonsterEntity.ensure(helper.getLevel(), fixture.course().id(), anchor) == monster,
                "Dispatch must reuse the actual saved puppet instead of spawning duplicate monsters");
        helper.assertFalse(monster.isShowActive() || monster.isPushable() || monster.canBeCollidedWith()
                        || monster.canCollideWith(fixture.vehicle()), "The initial puppet must be dormant and noncolliding");
        BlockPos rock = helper.absolutePos(new BlockPos(13, 2, 13));
        helper.getLevel().setBlock(rock, Blocks.BASALT.defaultBlockState(), 3);
        monster.lookAt(anchor.add(8, 7, 10));
        monster.roar();
        monster.threaten();
        helper.runAfterDelay(20, () -> {
            helper.assertTrue(monster.position().distanceTo(anchor) < 1.0E-9 && monster.exposure(1) > .5,
                    "Twenty real entity ticks must animate emergence without translating the stage anchor");
            helper.assertTrue(monster.roarTicksRemaining() > 0 && monster.roarTicksRemaining() < ShowMonsterEntity.ROAR_TICKS
                            && monster.threatTicksRemaining() > 0 && monster.threatTicksRemaining() < ShowMonsterEntity.THREAT_TICKS,
                    "Actual server entity ticks must advance both head/jaw and foreleg animation timers");
            helper.assertTrue(Math.abs(monster.headYaw(1)) > 1 && !monster.hurt(helper.getLevel().damageSources().generic(), 100),
                    "The puppet must track its audience and remain outside ordinary combat damage");
            CompoundTag saved = new CompoundTag();
            helper.assertTrue(monster.save(saved), "Registered puppet must use the actual Minecraft entity NBT writer");
            ShowMonsterEntity restored = CoasterRegistries.SHOW_MONSTER.get().create(helper.getLevel());
            helper.assertTrue(restored != null, "The registry must create a second codec-only monster instance");
            restored.load(saved);
            helper.assertTrue(monster.getUUID().equals(restored.getUUID()) && monster.courseId().equals(restored.courseId())
                            && restored.isShowActive() && Math.abs(monster.exposure(1) - restored.exposure(1)) < 1.0E-6
                            && monster.roarTicksRemaining() == restored.roarTicksRemaining()
                            && monster.threatTicksRemaining() == restored.threatTicksRemaining(),
                    "Actual entity reload must retain its identity, course and in-progress animation pose");
            helper.assertTrue(fixture.vehicle().canUseTrackSample(fixture.course().track().sample(0)),
                    "Even an emerged animated puppet must not obstruct the coaster's real rider/body collision check");
            monster.setShowActive(false);
        });
        helper.runAfterDelay(90, () -> {
            helper.assertTrue(!monster.isShowActive() && monster.exposure(1) == 0
                            && monster.roarTicksRemaining() == 0 && monster.threatTicksRemaining() == 0,
                    "Reset must clear threat and roar and fade the visible puppet back to its dormant state");
            helper.assertTrue(monster.position().distanceTo(anchor) < 1.0E-9
                            && helper.getLevel().getBlockState(rock).is(Blocks.BASALT),
                    "The complete show cycle must neither move its anchor nor destroy scenery blocks");
            monster.discard();
            fixture.cleanup(helper);
            helper.succeed();
        });
    }

    private static AttractionDefinition definition() {
        return new AttractionDefinition("test_show", 1,
                List.of(new AttractionDefinition.Stage("departure", trigger(0), "exploration", 1)),
                List.of(event("departure", 0, 0, AttractionDefinition.EventType.LAUNCH),
                        event("scheduled_stop", 5, 0, AttractionDefinition.EventType.STOP),
                        event("delayed_roar", 5, 5, AttractionDefinition.EventType.ROAR)), List.of(), List.of());
    }

    private static AttractionDefinition.Trigger trigger(double distance) {
        return new AttractionDefinition.Trigger(null, distance);
    }

    private static AttractionDefinition.EventSpec event(String id, double distance, int delay,
                                                         AttractionDefinition.EventType type) {
        return new AttractionDefinition.EventSpec(id, trigger(distance), AttractionDefinition.Condition.ALWAYS,
                delay, type, true, new JsonObject());
    }
}
