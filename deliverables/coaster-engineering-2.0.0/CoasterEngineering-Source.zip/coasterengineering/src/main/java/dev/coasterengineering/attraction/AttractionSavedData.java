package dev.coasterengineering.attraction;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.UUID;
import java.util.function.ToDoubleFunction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Dimension-local show state is independent of course geometry and physics serialization. */
public final class AttractionSavedData extends SavedData {
    public static final String FILE_NAME = "coasterengineering_attractions_v2";
    private final Map<UUID, AttractionTimeline.Snapshot> snapshots = new LinkedHashMap<>();
    private final Map<UUID, AttractionTimeline> timelines = new LinkedHashMap<>();
    private final Map<UUID, Long> sequences = new LinkedHashMap<>();

    public static AttractionSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(AttractionSavedData::load, AttractionSavedData::new, FILE_NAME);
    }
    public AttractionTimeline timeline(UUID id, AttractionDefinition definition,
                                      ToDoubleFunction<AttractionDefinition.Trigger> resolver) {
        return timelines.computeIfAbsent(id, ignored -> {
            AttractionTimeline timeline = new AttractionTimeline(definition, resolver);
            AttractionTimeline.Snapshot snapshot = snapshots.get(id);
            if (snapshot != null) timeline.restore(snapshot);
            return timeline;
        });
    }
    public AttractionTimeline existing(UUID id) { return timelines.get(id); }
    public AttractionTimeline.Snapshot snapshot(UUID id) {
        AttractionTimeline existing = timelines.get(id);
        return existing == null ? snapshots.get(id) : existing.snapshot();
    }
    public long sequence(UUID id) { return sequences.getOrDefault(id, 0L); }
    public long nextSequence(UUID id) {
        long previous = sequence(id), next = previous == Long.MAX_VALUE ? Long.MAX_VALUE : previous + 1;
        sequences.put(id, next); setDirty(); return next;
    }
    public void forgetRuntime(UUID id) {
        AttractionTimeline timeline = timelines.remove(id);
        if (timeline != null) snapshots.put(id, timeline.snapshot());
        setDirty();
    }
    public static AttractionSavedData load(CompoundTag root) {
        AttractionSavedData data = new AttractionSavedData();
        ListTag courses = root.getList("Courses", Tag.TAG_COMPOUND);
        for (int index = 0; index < Math.min(courses.size(), 64); index++) {
            CompoundTag tag = courses.getCompound(index);
            if (!tag.hasUUID("Id")) continue;
            UUID id = tag.getUUID("Id");
            LinkedHashSet<String> completed = new LinkedHashSet<>();
            ListTag stops = tag.getList("CompletedStops", Tag.TAG_STRING);
            for (int j = 0; j < Math.min(stops.size(), 128); j++) completed.add(stops.getString(j));
            ArrayList<AttractionTimeline.Execution> executions = new ArrayList<>();
            ListTag values = tag.getList("Executions", Tag.TAG_COMPOUND);
            for (int j = 0; j < Math.min(values.size(), 128); j++) {
                CompoundTag value = values.getCompound(j);
                try {
                    executions.add(new AttractionTimeline.Execution(value.getString("Id"),
                            AttractionTimeline.Status.valueOf(value.getString("Status")), value.getLong("DueTick"), value.getInt("Count")));
                } catch (IllegalArgumentException invalid) { /* Ignore an invalid cosmetic entry, never the course. */ }
            }
            data.snapshots.put(id, new AttractionTimeline.Snapshot(tag.getLong("RunNumber"), tag.getBoolean("Active"),
                    tag.getBoolean("Interrupted"), tag.getLong("ElapsedTicks"), tag.getInt("Lap"), tag.getDouble("Distance"),
                    tag.getString("HoldId"), Math.max(0, Math.min(12000, tag.getInt("HoldRemaining"))), completed, executions));
            data.sequences.put(id, Math.max(0, tag.getLong("Sequence")));
        }
        return data;
    }
    @Override public CompoundTag save(CompoundTag root) {
        root.putInt("FormatVersion", 1);
        Map<UUID, AttractionTimeline.Snapshot> merged = new LinkedHashMap<>(snapshots);
        timelines.forEach((id, timeline) -> merged.put(id, timeline.snapshot()));
        ListTag courses = new ListTag();
        merged.forEach((id, state) -> {
            CompoundTag tag = new CompoundTag();
            tag.putUUID("Id", id); tag.putLong("RunNumber", state.runNumber()); tag.putBoolean("Active", state.active());
            tag.putBoolean("Interrupted", state.interrupted()); tag.putLong("ElapsedTicks", state.elapsedTicks());
            tag.putInt("Lap", state.lap()); tag.putDouble("Distance", state.distance());
            tag.putString("HoldId", state.holdId()); tag.putInt("HoldRemaining", state.holdRemaining());
            tag.putLong("Sequence", sequence(id));
            ListTag stops = new ListTag(); state.completedStops().stream().sorted().forEach(value -> stops.add(StringTag.valueOf(value)));
            tag.put("CompletedStops", stops);
            ListTag executions = new ListTag();
            for (var execution : state.executions()) {
                CompoundTag value = new CompoundTag(); value.putString("Id", execution.id()); value.putString("Status", execution.status().name());
                value.putLong("DueTick", execution.dueTick()); value.putInt("Count", execution.count()); executions.add(value);
            }
            tag.put("Executions", executions); courses.add(tag);
        });
        root.put("Courses", courses); return root;
    }
}
