package dev.coasterengineering.command;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.item.CourseEditorItem;
import dev.coasterengineering.network.CoasterNetwork;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.station.StationControllerBlockEntity;
import dev.coasterengineering.track.ControlPoint;
import dev.coasterengineering.track.RailKind;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.world.CoasterSavedData;
import dev.coasterengineering.world.Course;
import dev.coasterengineering.world.CourseEditService;
import dev.coasterengineering.world.DemoCourseBuilder;
import dev.coasterengineering.world.TrainService;
import dev.coasterengineering.world.VolcanicWorldBuilder;
import dev.coasterengineering.world.VolcanicV2WorldBuilder;
import dev.coasterengineering.attraction.AttractionDirector;
import dev.coasterengineering.track.VolcanicAbyssV2;
import dev.coasterengineering.world.RideValidationService;
import dev.coasterengineering.world.WorldQualityUpgradeService;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.UuidArgument;
import net.minecraft.commands.arguments.coordinates.BlockPosArgument;
import net.minecraft.commands.arguments.coordinates.Vec3Argument;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.function.Supplier;
import java.util.function.Function;

/** Commands run on the server thread. Riding itself remains available to non-operators. */
@Mod.EventBusSubscriber(modid = CoasterEngineering.MOD_ID)
public final class CoasterCommands {
    private CoasterCommands() { }

    @SubscribeEvent
    public static void register(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("coaster")
                .executes(context -> help(context.getSource()))
                .then(Commands.literal("demo").requires(source -> source.hasPermission(2))
                        .executes(context -> demo(context.getSource())))
                .then(Commands.literal("volcano").requires(source -> source.hasPermission(2))
                        .executes(context -> volcano(context.getSource()))
                        .then(Commands.literal("status").executes(context -> volcanoStatus(context.getSource())))
                        .then(Commands.literal("cancel").executes(context -> volcanoCancel(context.getSource()))))
                .then(Commands.literal("volcano2").requires(source -> source.hasPermission(2))
                        .executes(context -> volcano2(context.getSource()))
                        .then(Commands.literal("status").executes(context -> volcano2Status(context.getSource())))
                        .then(Commands.literal("cancel").executes(context -> volcano2Cancel(context.getSource()))))
                .then(Commands.literal("attraction").requires(source -> source.hasPermission(2))
                        .then(Commands.literal("status")
                                .executes(context -> attractionStatus(context.getSource(), VolcanicAbyssV2.COURSE_ID))
                                .then(Commands.argument("course", UuidArgument.uuid())
                                        .executes(context -> attractionStatus(context.getSource(), UuidArgument.getUuid(context, "course")))))
                        .then(Commands.literal("reload")
                                .executes(context -> attractionReload(context.getSource(), VolcanicAbyssV2.COURSE_ID))
                                .then(Commands.argument("course", UuidArgument.uuid())
                                        .executes(context -> attractionReload(context.getSource(), UuidArgument.getUuid(context, "course"))))))
                .then(Commands.literal("upgrade").requires(source -> source.hasPermission(2))
                        .then(Commands.literal("volcano")
                                .executes(context -> upgradeVolcano(context.getSource(), false))
                                .then(Commands.literal("status").executes(context -> upgradeStatus(context.getSource())))
                                .then(Commands.literal("cancel").executes(context -> upgradeCancel(context.getSource())))
                                .then(Commands.literal("reapply").executes(context -> upgradeVolcano(context.getSource(), true)))))
                .then(Commands.literal("validate").requires(source -> source.hasPermission(2))
                        .then(Commands.literal("status").executes(context -> validationStatus(context.getSource())))
                        .then(Commands.literal("cancel").executes(context -> validationCancel(context.getSource())))
                        .then(Commands.argument("course", UuidArgument.uuid())
                                .suggests((context, builder) -> courseSuggestions(context.getSource(), builder))
                                .executes(context -> validate(context.getSource(), UuidArgument.getUuid(context, "course")))))
                .then(Commands.literal("create").requires(source -> source.hasPermission(2))
                        .then(Commands.argument("name", StringArgumentType.string())
                                .executes(context -> create(context.getSource(), StringArgumentType.getString(context, "name")))))
                .then(Commands.literal("clear").requires(source -> source.hasPermission(2))
                        .executes(context -> clear(context.getSource())))
                .then(Commands.literal("spawn").requires(source -> source.hasPermission(2))
                        .then(Commands.argument("course", UuidArgument.uuid())
                                .suggests((context, builder) -> courseSuggestions(context.getSource(), builder))
                                .executes(context -> spawn(context.getSource(), UuidArgument.getUuid(context, "course")))))
                .then(Commands.literal("delete").requires(source -> source.hasPermission(2))
                        .then(Commands.argument("course", UuidArgument.uuid())
                                .suggests((context, builder) -> courseSuggestions(context.getSource(), builder))
                                .executes(context -> delete(context.getSource(), UuidArgument.getUuid(context, "course")))))
                .then(Commands.literal("start").requires(source -> source.hasPermission(2))
                        .executes(context -> start(context.getSource())))
                .then(Commands.literal("stop").requires(source -> source.hasPermission(2))
                        .executes(context -> stop(context.getSource())))
                .then(Commands.literal("clear_alarm").requires(source -> source.hasPermission(2))
                        .executes(context -> clearAlarm(context.getSource(), null))
                        .then(Commands.argument("course", UuidArgument.uuid())
                                .suggests((context, builder) -> courseSuggestions(context.getSource(), builder))
                                .executes(context -> clearAlarm(context.getSource(), UuidArgument.getUuid(context, "course")))))
                .then(Commands.literal("train").requires(source -> source.hasPermission(2))
                        .then(Commands.argument("cars", IntegerArgumentType.integer(1, 4))
                                .executes(context -> train(context.getSource(), IntegerArgumentType.getInteger(context, "cars")))))
                .then(Commands.literal("reset").requires(source -> source.hasPermission(2))
                        .executes(context -> reset(context.getSource())))
                .then(Commands.literal("status").executes(context -> status(context.getSource())))
                .then(Commands.literal("list").executes(context -> list(context.getSource())))
                .then(editBranch())
                .then(Commands.literal("supports").requires(source -> source.hasPermission(2))
                        .then(Commands.argument("course", UuidArgument.uuid())
                                .suggests((context, builder) -> courseSuggestions(context.getSource(), builder))
                                .executes(context -> supports(context.getSource(), UuidArgument.getUuid(context, "course")))))
                .then(Commands.literal("station").requires(source -> source.hasPermission(2))
                        .then(Commands.literal("bind")
                                .then(Commands.argument("course", UuidArgument.uuid())
                                        .suggests((context, builder) -> courseSuggestions(context.getSource(), builder))
                                        .executes(context -> bindStation(context.getSource(), UuidArgument.getUuid(context, "course"))))))
                .then(Commands.literal("editor").requires(source -> source.hasPermission(2))
                        .then(Commands.literal("draft").executes(context -> draft(context.getSource())))
                        .then(Commands.literal("select")
                                .then(Commands.argument("course", UuidArgument.uuid())
                                        .suggests((context, builder) -> courseSuggestions(context.getSource(), builder))
                                        .then(Commands.argument("index", IntegerArgumentType.integer(1, 128))
                                                .executes(context -> select(context.getSource(), UuidArgument.getUuid(context, "course"), IntegerArgumentType.getInteger(context, "index"))))))
                        .then(Commands.literal("kind")
                                .then(Commands.argument("kind", StringArgumentType.word())
                                        .suggests((context, builder) -> SharedSuggestionProvider.suggest(
                                                Arrays.stream(RailKind.values()).map(kind -> kind.name().toLowerCase(Locale.ROOT)), builder))
                                        .executes(context -> setKind(context.getSource(), StringArgumentType.getString(context, "kind")))))
                        .then(Commands.literal("bank")
                                .then(Commands.argument("degrees", DoubleArgumentType.doubleArg(-75, 75))
                                        .executes(context -> setBank(context.getSource(), DoubleArgumentType.getDouble(context, "degrees")))))
                        .then(Commands.literal("speed")
                                .then(Commands.argument("kmh", DoubleArgumentType.doubleArg(0, 120))
                                        .executes(context -> setSpeed(context.getSource(), DoubleArgumentType.getDouble(context, "kmh")))))));
    }

    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<CommandSourceStack> editBranch() {
        return Commands.literal("edit").requires(source -> source.hasPermission(2))
                .then(Commands.argument("course", UuidArgument.uuid())
                        .suggests((context, builder) -> courseSuggestions(context.getSource(), builder))
                        .then(Commands.literal("move")
                                .then(Commands.argument("index", IntegerArgumentType.integer(1, 128))
                                        .then(Commands.argument("position", Vec3Argument.vec3())
                                                .executes(context -> editMove(context.getSource(), UuidArgument.getUuid(context, "course"),
                                                        IntegerArgumentType.getInteger(context, "index"), Vec3Argument.getVec3(context, "position"))))))
                        .then(Commands.literal("remove")
                                .then(Commands.argument("index", IntegerArgumentType.integer(1, 128))
                                        .executes(context -> editResult(context.getSource(), () -> CourseEditService.removePoint(context.getSource().getLevel(),
                                                UuidArgument.getUuid(context, "course"), IntegerArgumentType.getInteger(context, "index"))))))
                        .then(Commands.literal("bank")
                                .then(Commands.argument("index", IntegerArgumentType.integer(1, 128))
                                        .then(Commands.argument("degrees", DoubleArgumentType.doubleArg(-75, 75))
                                                .executes(context -> editResult(context.getSource(), () -> CourseEditService.setBank(context.getSource().getLevel(),
                                                        UuidArgument.getUuid(context, "course"), IntegerArgumentType.getInteger(context, "index"), DoubleArgumentType.getDouble(context, "degrees")))))))
                        .then(Commands.literal("kind")
                                .then(Commands.argument("index", IntegerArgumentType.integer(1, 128))
                                        .then(Commands.argument("kind", StringArgumentType.word())
                                                .suggests((context, builder) -> SharedSuggestionProvider.suggest(
                                                        Arrays.stream(RailKind.values()).map(kind -> kind.name().toLowerCase(Locale.ROOT)), builder))
                                                .executes(context -> editResult(context.getSource(), () -> CourseEditService.setKind(context.getSource().getLevel(),
                                                        UuidArgument.getUuid(context, "course"), IntegerArgumentType.getInteger(context, "index"),
                                                        RailKind.valueOf(StringArgumentType.getString(context, "kind").toUpperCase(Locale.ROOT))))))))
                        .then(Commands.literal("speed")
                                .then(Commands.argument("index", IntegerArgumentType.integer(1, 128))
                                        .then(Commands.argument("kmh", DoubleArgumentType.doubleArg(0, 120))
                                                .executes(context -> editResult(context.getSource(), () -> CourseEditService.setSpeed(context.getSource().getLevel(),
                                                        UuidArgument.getUuid(context, "course"), IntegerArgumentType.getInteger(context, "index"), DoubleArgumentType.getDouble(context, "kmh") / 72))))))
                        .then(Commands.literal("landing")
                                .then(Commands.argument("position", BlockPosArgument.blockPos())
                                        .executes(context -> editResult(context.getSource(), () -> CourseEditService.setStation(context.getSource().getLevel(),
                                                UuidArgument.getUuid(context, "course"), BlockPosArgument.getBlockPos(context, "position")))))));
    }

    private static int editMove(CommandSourceStack source, UUID id, int index, Vec3 position) {
        return editResult(source, () -> CourseEditService.movePoint(source.getLevel(), id, index, new TrackVec3(position.x, position.y, position.z)));
    }

    private static int editResult(CommandSourceStack source, Supplier<Course> action) {
        try {
            Course result = action.get();
            source.sendSuccess(() -> Component.literal("Saved edits to " + result.name() + ". The empty train is parked at the course start."), true);
            return 1;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return fail(source, "Edit refused: " + ex.getMessage());
        }
    }

    private static int supports(CommandSourceStack source, UUID id) {
        try {
            int count = CourseEditService.addSupports(source.getLevel(), id);
            source.sendSuccess(() -> Component.literal("Placed " + count + " support beam blocks beneath the course."), true);
            return 1;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return fail(source, "Support generation refused: " + ex.getMessage());
        }
    }

    private static int bindStation(CommandSourceStack source, UUID id) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        Vec3 eye = player.getEyePosition();
        HitResult hit = source.getLevel().clip(new ClipContext(eye, eye.add(player.getLookAngle().scale(8)),
                ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
        if (!(hit instanceof BlockHitResult blockHit) || hit.getType() != HitResult.Type.BLOCK
                || !(source.getLevel().getBlockEntity(blockHit.getBlockPos()) instanceof StationControllerBlockEntity controller)) {
            return fail(source, "Look at a station controller within eight blocks to bind it.");
        }
        if (CoasterSavedData.get(source.getLevel()).getCourse(id) == null) return fail(source, "No course with that UUID in this dimension.");
        try {
            if (!controller.bind(id)) return fail(source, "Binding requires a controller within eight blocks of the course landing and no other controller already bound to that course.");
            source.sendSuccess(() -> Component.literal("Station controller bound to course " + id + ". Right-click it to open station controls."), true);
            return 1;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return fail(source, "Station binding refused: " + ex.getMessage());
        }
    }

    private static java.util.concurrent.CompletableFuture<com.mojang.brigadier.suggestion.Suggestions> courseSuggestions(
            CommandSourceStack source, com.mojang.brigadier.suggestion.SuggestionsBuilder builder) {
        return SharedSuggestionProvider.suggest(CoasterSavedData.get(source.getLevel()).courses().stream()
                .map(course -> course.id().toString()), builder);
    }

    private static int help(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal("Coaster Engineering: demo, volcano [status|cancel], upgrade volcano [status|cancel|reapply], validate <UUID>|status|cancel, create <name>, spawn <UUID>, start, stop, clear_alarm [UUID], train <1..4>, reset, status, list, delete <UUID>. Edit: /coaster edit <UUID> move|remove|bank|kind|speed <point 1..128> ...; supports <UUID>; station bind <UUID>. Editor: select <UUID> <point>, draft, kind, bank, speed; clear."), false);
        return 1;
    }

    private static int volcano(CommandSourceStack source) {
        try {
            if (!VolcanicWorldBuilder.begin(source.getLevel())) return fail(source, "Construction did not start: " + VolcanicWorldBuilder.status(source.getLevel()));
            source.sendSuccess(() -> Component.literal("Volcanic Abyss construction started. Use /coaster volcano status to follow progress."), true);
            return 1;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return fail(source, "Construction refused: " + ex.getMessage());
        }
    }

    private static int volcano2(CommandSourceStack source) {
        try {
            if (!VolcanicV2WorldBuilder.begin(source.getLevel()))
                return fail(source, "2.0 construction did not start: " + VolcanicV2WorldBuilder.status(source.getLevel()));
            source.sendSuccess(() -> Component.literal("Volcanic Abyss 2.0 construction started in this new dedicated world. Use /coaster volcano2 status until READY."), true);
            return 1;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return fail(source, "2.0 construction refused: " + ex.getMessage());
        }
    }

    private static int volcano2Status(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal(VolcanicV2WorldBuilder.status(source.getLevel())), false);
        return 1;
    }

    private static int volcano2Cancel(CommandSourceStack source) {
        if (!VolcanicV2WorldBuilder.cancel(source.getLevel()))
            return fail(source, "No active 2.0 construction job. " + VolcanicV2WorldBuilder.status(source.getLevel()));
        source.sendSuccess(() -> Component.literal(VolcanicV2WorldBuilder.status(source.getLevel())), true);
        return 1;
    }

    private static int attractionStatus(CommandSourceStack source, UUID id) {
        source.sendSuccess(() -> Component.literal(AttractionDirector.status(source.getLevel(), id)), false);
        return 1;
    }

    private static int attractionReload(CommandSourceStack source, UUID id) {
        try {
            Course course = CoasterSavedData.get(source.getLevel()).getCourse(id);
            UUID leaderId = CoasterSavedData.get(source.getLevel()).vehicleId(id);
            Entity entity = leaderId == null ? null : source.getLevel().getEntity(leaderId);
            CoasterEntity leader = entity instanceof CoasterEntity coaster ? coaster : null;
            if (course == null) return fail(source, "Unknown attraction course.");
            if (leader == null) return fail(source, "Load the complete train before reloading attraction settings.");
            if (leader != null && leader.isRunning()) return fail(source, "Stop the train before reloading the attraction JSON.");
            AttractionDirector.reloadConfiguration(source.getLevel(), id);
            return attractionStatus(source, id);
        } catch (IllegalArgumentException | IllegalStateException invalid) {
            return fail(source, "Attraction configuration refused: " + invalid.getMessage());
        }
    }

    private static int upgradeVolcano(CommandSourceStack source, boolean reapply) {
        if (!WorldQualityUpgradeService.begin(source.getLevel(), reapply))
            return fail(source, "Quality update did not start: " + WorldQualityUpgradeService.status(source.getLevel()));
        source.sendSuccess(() -> Component.literal("Volcanic quality update started. Keep the original train stopped and empty; use /coaster upgrade volcano status until COMPLETED."), true);
        return 1;
    }

    private static int upgradeStatus(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal(WorldQualityUpgradeService.status(source.getLevel())), false);
        return 1;
    }

    private static int upgradeCancel(CommandSourceStack source) {
        if (!WorldQualityUpgradeService.cancel(source.getLevel())) return fail(source, "No quality update is active. " + WorldQualityUpgradeService.status(source.getLevel()));
        source.sendSuccess(() -> Component.literal(WorldQualityUpgradeService.status(source.getLevel())), true);
        return 1;
    }

    private static int volcanoStatus(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal(VolcanicWorldBuilder.status(source.getLevel())), false);
        return 1;
    }

    private static int volcanoCancel(CommandSourceStack source) {
        if (!VolcanicWorldBuilder.cancel(source.getLevel())) return fail(source, "No active volcanic construction job can be cancelled. " + VolcanicWorldBuilder.status(source.getLevel()));
        source.sendSuccess(() -> Component.literal("Construction cancellation requested. " + VolcanicWorldBuilder.status(source.getLevel())), true);
        return 1;
    }

    private static int validate(CommandSourceStack source, UUID id) {
        try {
            if (!RideValidationService.begin(source.getLevel(), id)) return fail(source, "Ride validation did not start: " + RideValidationService.status(source.getLevel()));
            source.sendSuccess(() -> Component.literal("Started an actual server-side lap validation. Keep the train empty and use /coaster validate status to follow the result."), true);
            return 1;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return fail(source, "Ride validation refused: " + ex.getMessage());
        }
    }

    private static int validationStatus(CommandSourceStack source) {
        source.sendSuccess(() -> Component.literal(RideValidationService.status(source.getLevel())), false);
        return 1;
    }

    private static int validationCancel(CommandSourceStack source) {
        if (!RideValidationService.cancel(source.getLevel())) return fail(source, "No active ride validation can be cancelled. " + RideValidationService.status(source.getLevel()));
        source.sendSuccess(() -> Component.literal("Ride validation cancelled. " + RideValidationService.status(source.getLevel())), true);
        return 1;
    }

    private static int demo(CommandSourceStack source) {
        try {
            Course course = DemoCourseBuilder.build(source.getLevel(), BlockPos.containing(source.getPosition()).offset(8, 6, 8));
            if (source.getEntity() instanceof ServerPlayer player) {
                BlockPos station = course.station();
                player.teleportTo(source.getLevel(), station.getX() + 0.5, station.getY(), station.getZ() + 0.5, player.getYRot(), player.getXRot());
            }
            source.sendSuccess(() -> Component.literal("Created " + course.name() + " (" + course.id() + "). Right-click the coaster to board, then use /coaster start."), true);
            return 1;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return fail(source, "Demo course could not be created: " + ex.getMessage());
        }
    }

    private static int create(CommandSourceStack source, String name) throws CommandSyntaxException {
        if (name.isBlank() || name.length() > 64 || name.chars().anyMatch(Character::isISOControl)) return fail(source, "Course names must contain 1 to 64 characters without control characters.");
        ItemStack editor = editor(source);
        if (editor.isEmpty()) return 0;
        if (CourseEditorItem.isEditing(editor)) return fail(source, "Return the editor to draft mode with /coaster editor draft before creating a new course.");
        if (!CourseEditorItem.matchesDimension(editor, source.getLevel())) return fail(source, "This editor draft belongs to another dimension.");
        try {
            List<ControlPoint> points = CourseEditorItem.readPoints(editor);
            if (points.size() < 4) return fail(source, "Place at least four distinct control points before creating a closed course.");
            // Dispatch needs a powered first segment; the final arc returns to this station.
            ControlPoint first = points.get(0);
            points.set(0, new ControlPoint(first.position(), first.bankDegrees(), RailKind.STATION, Math.max(0.15, first.targetSpeed())));
            SplineTrack track = new SplineTrack(points, true);
            if (track.length() < 8 || track.length() > 16_000) return fail(source, "Course length must be between 8 and 16,000 blocks.");
            ServerLevel level = source.getLevel();
            for (double distance = 0; distance < track.length(); distance += 2) {
                var p = track.sample(distance).position();
                BlockPos block = BlockPos.containing(p.x(), p.y(), p.z());
                if (p.y() < level.getMinBuildHeight() + 2 || p.y() + 3 >= level.getMaxBuildHeight() || !level.getWorldBorder().isWithinBounds(block)) {
                    return fail(source, "The spline must stay inside the world border and safe build height.");
                }
            }
            BlockPos station = CourseEditorItem.station(editor, source.getPlayerOrException().blockPosition());
            if (!CourseEditService.safeStation(level, station)) return fail(source, "The station landing recorded at the first point must still have a solid floor, two blocks of free space, and a loaded chunk. Clear the editor and place the first point while standing on safe ground.");
            if (!CourseEditService.stationNearStart(track, station)) return fail(source, "The first control point must be within six blocks of its recorded station landing. Clear the editor and place the first point while standing nearby.");
            Course course = new Course(UUID.randomUUID(), name, track, station, true);
            CoasterSavedData.get(level).putCourse(course);
            CoasterNetwork.broadcastCourse(level, course);
            // Keep the draft so another misplaced point can be undone without losing work.
            source.sendSuccess(() -> Component.literal("Saved " + name + " (" + course.id() + "), " + String.format(Locale.ROOT, "%.1f", track.length()) + " blocks. First segment is the dispatch station. Use /coaster spawn " + course.id() + "."), true);
            return 1;
        } catch (IllegalArgumentException ex) {
            return fail(source, "Cannot create course: " + ex.getMessage());
        }
    }

    private static int clear(CommandSourceStack source) throws CommandSyntaxException {
        ItemStack editor = editor(source);
        if (editor.isEmpty()) return 0;
        CourseEditorItem.clear(editor);
        source.sendSuccess(() -> Component.literal("Cleared this editor's points and settings. Saved courses are unchanged."), false);
        return 1;
    }

    private static int spawn(CommandSourceStack source, UUID id) {
        Course course = CoasterSavedData.get(source.getLevel()).getCourse(id);
        if (course == null) return fail(source, "No course with that UUID in this dimension.");
        String error = spawnVehicle(source.getLevel(), course);
        if (error != null) return fail(source, error);
        source.sendSuccess(() -> Component.literal("Placed a two-seat coaster at " + course.name() + "'s station."), true);
        return 1;
    }

    /** Null means success. Called by both the command and placement item on the server thread. */
    public static String spawnVehicle(ServerLevel level, Course course) {
        CoasterSavedData data = CoasterSavedData.get(level);
        if (data.vehicleId(course.id()) != null) return "This course already has a reserved vehicle, possibly in an unloaded chunk. Return to its station or load its last location instead of spawning a duplicate.";
        for (Entity entity : level.getAllEntities()) {
            if (entity instanceof CoasterEntity cart && course.id().equals(cart.courseId()) && !cart.isRemoved()) return "This course already has a coaster train. One train per course is supported.";
        }
        if (!level.hasChunkAt(course.station())) return "The station chunk must be loaded before placing a coaster.";
        CoasterEntity cart = CoasterRegistries.COASTER.get().create(level);
        if (cart == null) return "Unable to create coaster entity.";
        cart.setCourse(course.id());
        if (!cart.resetToStation()) {
            data.releaseVehicle(course.id(), cart.getUUID());
            return "The track start is outside safe bounds or crosses unloaded chunks.";
        }
        if (!data.claimVehicle(course.id(), cart.getUUID())) return "This course already has a reserved coaster.";
        if (!level.addFreshEntity(cart)) {
            data.releaseVehicle(course.id(), cart.getUUID());
            return "Minecraft rejected the coaster entity spawn.";
        }
        CoasterNetwork.broadcastCourse(level, course);
        return null;
    }

    private static int delete(CommandSourceStack source, UUID id) {
        ServerLevel level = source.getLevel();
        CoasterSavedData data = CoasterSavedData.get(level);
        Course course = data.getCourse(id);
        if (course == null) return fail(source, "No course with that UUID in this dimension.");
        List<CoasterEntity> removed = new ArrayList<>();
        for (Entity entity : level.getAllEntities()) {
            if (entity instanceof CoasterEntity cart && id.equals(cart.courseId())) removed.add(cart);
        }
        for (CoasterEntity cart : removed) {
            cart.emergencyStop();
            cart.ejectPassengers();
            cart.discard();
        }
        data.removeCourse(id);
        CoasterNetwork.removeCourse(level, id);
        source.sendSuccess(() -> Component.literal("Deleted " + course.name() + " and " + removed.size() + " loaded vehicle(s). Existing station blocks remain. Any unloaded old vehicle will stop safely when loaded."), true);
        return 1;
    }

    private static int start(CommandSourceStack source) {
        CoasterEntity cart = nearestCart(source);
        if (cart == null) return fail(source, "No coaster within 32 blocks.");
        if (!cart.startRide()) return fail(source, "Dispatch refused: check the course, loaded track space, complete train, and emergency alarm. Use /coaster clear_alarm to clear an alarm before dispatching.");
        source.sendSuccess(() -> Component.literal("Coaster dispatched. It returns to its station after one lap."), true);
        return 1;
    }

    private static int stop(CommandSourceStack source) {
        CoasterEntity cart = nearestCart(source);
        if (cart == null) return fail(source, "No coaster within 32 blocks.");
        CoasterSavedData.get(source.getLevel()).setEmergency(cart.courseId(), true);
        cart.emergencyStop();
        StationControllerBlockEntity controller = loadedController(source.getLevel(), cart.courseId());
        if (controller != null) controller.stopEmergency();
        source.sendSuccess(() -> Component.literal("Emergency stop latched for this course. Use /coaster clear_alarm, then /coaster start when it is safe to resume."), true);
        return 1;
    }

    private static int clearAlarm(CommandSourceStack source, UUID requestedCourse) {
        UUID id = requestedCourse;
        if (id == null) {
            CoasterEntity cart = nearestCart(source);
            if (cart == null) return fail(source, "No coaster within 32 blocks. Use /coaster clear_alarm <UUID> to clear a known course alarm.");
            id = cart.courseId();
        }
        CoasterSavedData data = CoasterSavedData.get(source.getLevel());
        Course course = data.getCourse(id);
        if (course == null) return fail(source, "No course with that UUID in this dimension.");
        data.setEmergency(id, false);
        StationControllerBlockEntity controller = loadedController(source.getLevel(), id);
        if (controller != null) controller.clearEmergency();
        source.sendSuccess(() -> Component.literal("Emergency alarm cleared for " + course.name() + ". The train remains stopped; use /coaster start to dispatch."), true);
        return 1;
    }

    private static StationControllerBlockEntity loadedController(ServerLevel level, UUID id) {
        if (id == null) return null;
        BlockPos pos = CoasterSavedData.get(level).controllerPos(id);
        if (pos == null || !level.hasChunkAt(pos)) return null;
        return level.getBlockEntity(pos) instanceof StationControllerBlockEntity controller && id.equals(controller.courseId()) ? controller : null;
    }

    private static int train(CommandSourceStack source, int cars) {
        CoasterEntity cart = nearestCart(source);
        if (cart == null) return fail(source, "No coaster within 32 blocks.");
        if (!TrainService.setCarCount(cart, cars))
            return fail(source, "Changing the formation requires all cars loaded, stopped and empty, with clear track space.");
        source.sendSuccess(() -> Component.literal("Formation set to " + cars + " cars, " + cars*2 + " seats."), true);
        return 1;
    }

    private static int reset(CommandSourceStack source) {
        CoasterEntity cart = nearestCart(source);
        if (cart == null) return fail(source, "No coaster within 32 blocks.");
        var formation = cart.getLoadedFormation();
        if (formation.isEmpty() || formation.stream().anyMatch(car -> !car.getPassengers().isEmpty()))
            return fail(source, "Load every car and unload all riders before resetting the formation to the station.");
        if (!cart.resetToStation()) return fail(source, "Reset refused: the station's track area must be loaded and safe.");
        source.sendSuccess(() -> Component.literal("Coaster parked at the start of its course."), true);
        return 1;
    }

    private static int status(CommandSourceStack source) {
        CoasterEntity cart = nearestCart(source);
        if (cart == null) return fail(source, "No coaster within 32 blocks.");
        Course course = CoasterSavedData.get(source.getLevel()).getCourse(cart.courseId());
        source.sendSuccess(() -> Component.literal(String.format(Locale.ROOT, "%s | %s | %.1f km/h | %.1f / %.1f blocks | laps %d | riders %d/2",
                course == null ? "Missing course" : course.name(), CoasterSavedData.get(source.getLevel()).isEmergency(cart.courseId()) ? "ALARM" : cart.isRunning() ? "RUNNING" : "STOPPED", cart.getSpeed() * 72,
                cart.getDistance(), course == null ? 0 : course.track().length(), cart.getLaps(), cart.getPassengers().size())), false);
        return 1;
    }

    private static int list(CommandSourceStack source) {
        var courses = CoasterSavedData.get(source.getLevel()).courses();
        if (courses.isEmpty()) {
            source.sendSuccess(() -> Component.literal("No courses in this dimension. /coaster demo builds a minimal riding loop."), false);
            return 0;
        }
        for (Course course : courses) source.sendSuccess(() -> Component.literal(course.name() + " | " + course.id() + " | "
                + String.format(Locale.ROOT, "%.1f", course.track().length()) + " blocks | " + (course.enabled() ? "enabled" : "disabled")), false);
        return courses.size();
    }

    private static CoasterEntity nearestCart(CommandSourceStack source) {
        if (source.getEntity() instanceof ServerPlayer player && player.getVehicle() instanceof CoasterEntity cart) return cart;
        return source.getLevel().getEntitiesOfClass(CoasterEntity.class, new AABB(source.getPosition(), source.getPosition()).inflate(32), cart -> !cart.isRemoved()).stream()
                .min(Comparator.comparingDouble(cart -> cart.position().distanceToSqr(source.getPosition()))).orElse(null);
    }

    private static ItemStack editor(CommandSourceStack source) throws CommandSyntaxException {
        ServerPlayer player = source.getPlayerOrException();
        if (player.getMainHandItem().getItem() instanceof CourseEditorItem) return player.getMainHandItem();
        if (player.getOffhandItem().getItem() instanceof CourseEditorItem) return player.getOffhandItem();
        fail(source, "Hold a Coaster Engineering course editor in either hand.");
        return ItemStack.EMPTY;
    }

    private static int draft(CommandSourceStack source) throws CommandSyntaxException {
        ItemStack stack = editor(source);
        if (stack.isEmpty()) return 0;
        CourseEditorItem.draft(stack);
        source.sendSuccess(() -> Component.literal("Editor switched to draft mode. Right-click adds a point; shift-right-click removes the last draft point."), false);
        return 1;
    }

    private static int select(CommandSourceStack source, UUID id, int index) throws CommandSyntaxException {
        ItemStack stack = editor(source);
        if (stack.isEmpty()) return 0;
        Course course = CoasterSavedData.get(source.getLevel()).getCourse(id);
        if (course == null) return fail(source, "No course with that UUID in this dimension.");
        try {
            CourseEditorItem.select(stack, source.getLevel(), course, index);
            source.sendSuccess(() -> Component.literal("Selected point " + index + " of " + course.name() + ". Click near another point to select it; shift-right-click a block to move the selected point. Editor kind, bank, and speed now edit this point."), false);
            return 1;
        } catch (IllegalArgumentException ex) {
            return fail(source, "Selection refused: " + ex.getMessage());
        }
    }

    private static int updateSelection(CommandSourceStack source, ItemStack stack, Function<CourseEditorItem.Selection, Course> action) {
        try {
            CourseEditorItem.Selection selection = CourseEditorItem.requireSelection(stack, source.getLevel());
            Course updated = action.apply(selection);
            CourseEditorItem.select(stack, source.getLevel(), updated, selection.index());
            source.sendSuccess(() -> Component.literal("Updated selected point " + selection.index() + " of " + updated.name() + ". The empty train is parked at the station."), true);
            return 1;
        } catch (IllegalArgumentException | IllegalStateException ex) {
            return fail(source, "Edit refused: " + ex.getMessage());
        }
    }

    private static int setKind(CommandSourceStack source, String name) throws CommandSyntaxException {
        ItemStack editor = editor(source);
        if (editor.isEmpty()) return 0;
        try {
            RailKind kind = RailKind.valueOf(name.toUpperCase(Locale.ROOT));
            if (CourseEditorItem.isEditing(editor)) return updateSelection(source, editor,
                    selection -> CourseEditService.setKind(source.getLevel(), selection.course().id(), selection.index(), kind));
            CourseEditorItem.setRailKind(editor, kind);
            source.sendSuccess(() -> Component.literal("New control points use " + kind.name() + " sections."), false);
            return 1;
        } catch (IllegalArgumentException ex) {
            return fail(source, "Rail kind must be normal, boost, brake, lift, or station.");
        }
    }

    private static int setBank(CommandSourceStack source, double degrees) throws CommandSyntaxException {
        if (!Double.isFinite(degrees)) return fail(source, "Bank must be finite.");
        ItemStack editor = editor(source);
        if (editor.isEmpty()) return 0;
        if (CourseEditorItem.isEditing(editor)) return updateSelection(source, editor,
                selection -> CourseEditService.setBank(source.getLevel(), selection.course().id(), selection.index(), degrees));
        CourseEditorItem.setBank(editor, degrees);
        source.sendSuccess(() -> Component.literal("New control points use bank " + degrees + " degrees."), false);
        return 1;
    }

    private static int setSpeed(CommandSourceStack source, double kmh) throws CommandSyntaxException {
        if (!Double.isFinite(kmh)) return fail(source, "Speed must be finite.");
        ItemStack editor = editor(source);
        if (editor.isEmpty()) return 0;
        if (CourseEditorItem.isEditing(editor)) return updateSelection(source, editor,
                selection -> CourseEditService.setSpeed(source.getLevel(), selection.course().id(), selection.index(), kmh / 72.0));
        CourseEditorItem.setTargetSpeed(editor, kmh / 72.0);
        source.sendSuccess(() -> Component.literal("New control points use target speed " + kmh + " km/h."), false);
        return 1;
    }

    private static int fail(CommandSourceStack source, String message) {
        source.sendFailure(Component.literal(message));
        return 0;
    }

    /** Placement can target any nearby rail segment, but creates the vehicle at the station. */
    public static Course nearestCourse(ServerLevel level, Vec3 position, double radius) {
        double nearestSquared = radius * radius;
        Course nearest = null;
        for (Course course : CoasterSavedData.get(level).courses()) {
            double length = course.track().length();
            // At most 20,001 samples even for externally loaded very long courses.
            double spacing = Math.max(1, length / 20_000);
            for (double distance = 0; distance < length; distance += spacing) {
                var p = course.track().sample(distance).position();
                double squared = position.distanceToSqr(p.x(), p.y(), p.z());
                if (squared <= nearestSquared) {
                    nearestSquared = squared;
                    nearest = course;
                }
            }
        }
        return nearest;
    }
}
