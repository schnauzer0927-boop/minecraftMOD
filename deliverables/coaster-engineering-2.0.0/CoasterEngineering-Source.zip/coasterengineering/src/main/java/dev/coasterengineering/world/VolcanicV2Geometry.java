package dev.coasterengineering.world;

import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import java.util.BitSet;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.AABB;

/** Bounded compact voxel masks; no world access and no millions of BlockPos objects. */
public final class VolcanicV2Geometry {
    public static final int MIN_X = -215, MAX_X = 215, MIN_Z = -215, MAX_Z = 215;
    public static final int MIN_Y = 64, MAX_Y = 200;
    static final int WIDTH = MAX_X - MIN_X + 1, DEPTH = MAX_Z - MIN_Z + 1;
    static final int HEIGHT = MAX_Y - MIN_Y + 1, VOLUME = WIDTH * DEPTH * HEIGHT;
    static final double[][] ROOMS = {
            {-85, 89, -30, 68, 35, 79}, {55, 107, -20, 79, 45, 79},
            {50, 91, 105, 78, 39, 50}, {-80, 108, 100, 85, 50, 82}
    };
    public final BitSet protectedCells = new BitSet(VOLUME);
    final BitSet tunnelAir = new BitSet(VOLUME), tunnelWall = new BitSet(VOLUME);
    public final SplineTrack track;

    public VolcanicV2Geometry(SplineTrack track) {
        this.track = track;
        for (double d = 0; d <= track.length(); d += .25) {
            TrackSample sample = track.sample(d);
            for (AABB box : envelopes(sample)) markBox(protectedCells, box.inflate(.35));
        }
        // Overlapping complete balls form a thick tube at room joints. The
        // inner carve is applied only after every wall has been constructed.
        double outdoorStart = track.controlPointDistance(39), outdoorEnd = track.controlPointDistance(55);
        for (double d = 0; d <= track.length(); d += 1.25) {
            TrackVec3 p = track.sample(d).position();
            sphere(tunnelAir, p, 5.8);
            if (d < outdoorStart || d > outdoorEnd) sphere(tunnelWall, p, 8.4);
            else ravine(p);
        }
        tunnelWall.andNot(tunnelAir);
    }

    private void ravine(TrackVec3 p) {
        // A low part of the escape route runs below the mountain's outside
        // surface. Carve a genuine open-to-sky gorge rather than calling the
        // hollow space beneath an opaque volcano roof "outdoors".
        int cx=(int)Math.floor(p.x()),cz=(int)Math.floor(p.z());
        int base=Math.max(MIN_Y,(int)Math.floor(p.y())-5);
        for(int z=cz-8;z<=cz+8;z++)for(int x=cx-8;x<=cx+8;x++) {
            double dx=x+.5-p.x(),dz=z+.5-p.z();
            double radius=7.6+.7*Math.sin(x*.19+z*.27);
            if(dx*dx+dz*dz>radius*radius)continue;
            for(int y=base;y<=MAX_Y;y++) {
                // Exterior gorges cannot remove a neighbouring chamber's
                // enclosing rock. The ordinary rail-radius carve, added
                // above, still provides the exact track portal and headroom.
                if(enclosesRoom(x,y,z))continue;
                int i=index(x,y,z);if(i>=0)tunnelAir.set(i);
            }
        }
    }

    static boolean enclosesRoom(int x,int y,int z) {
        for(double[] room:ROOMS)if(roomValue(room,x,y,z)<1.32)return true;
        return false;
    }

    public boolean isProtected(BlockPos pos) { int i = index(pos); return i >= 0 && protectedCells.get(i); }
    public static int index(BlockPos p) { return index(p.getX(), p.getY(), p.getZ()); }
    static int index(int x, int y, int z) {
        if (x < MIN_X || x > MAX_X || y < MIN_Y || y > MAX_Y || z < MIN_Z || z > MAX_Z) return -1;
        return ((y - MIN_Y) * DEPTH + z - MIN_Z) * WIDTH + x - MIN_X;
    }
    static BlockPos position(int index) {
        return new BlockPos(MIN_X + index % WIDTH, MIN_Y + index / (WIDTH * DEPTH), MIN_Z + index / WIDTH % DEPTH);
    }
    static boolean insideStation(int x, int y, int z) {
        return x >= -23 && x <= 9 && y >= 94 && y <= 112 && z >= -205 && z <= -145;
    }
    static double roomValue(double[] r, int x, int y, int z) {
        double dx = (x - r[0]) / r[3], dy = (y - r[1]) / r[4], dz = (z - r[2]) / r[5];
        double rough = .025 * Math.sin(x * .23 + z * .19) * Math.sin(y * .31)
                + .015 * Math.sin(x * .41 - z * .27 + y * .12);
        return dx * dx + dy * dy + dz * dz + rough;
    }
    static boolean roomAir(double[] r, int x, int y, int z) { return y >= 76 && roomValue(r, x, y, z) < 1; }
    private static void sphere(BitSet cells, TrackVec3 p, double radius) {
        int cx = (int) Math.floor(p.x()), cy = (int) Math.floor(p.y()), cz = (int) Math.floor(p.z());
        int r = (int) Math.ceil(radius);
        for (int y = cy-r; y <= cy+r; y++) for (int z = cz-r; z <= cz+r; z++) for (int x = cx-r; x <= cx+r; x++) {
            double dx = x+.5-p.x(), dy = y+.5-p.y(), dz = z+.5-p.z();
            if (dx*dx+dy*dy+dz*dz <= radius*radius) { int i = index(x,y,z); if(i>=0) cells.set(i); }
        }
    }
    private static void markBox(BitSet cells, AABB b) {
        for (int y = (int)Math.floor(b.minY); y <= (int)Math.floor(b.maxY-1e-7); y++)
            for (int z = (int)Math.floor(b.minZ); z <= (int)Math.floor(b.maxZ-1e-7); z++)
                for(int x = (int)Math.floor(b.minX); x <= (int)Math.floor(b.maxX-1e-7); x++) {
                    int i=index(x,y,z); if(i>=0) cells.set(i);
                }
    }
    public static AABB[] envelopes(TrackSample sample) {
        TrackFrame f = TrackFrame.from(sample); TrackVec3 p = sample.position();
        double minX=Double.POSITIVE_INFINITY,minY=minX,minZ=minX,maxX=Double.NEGATIVE_INFINITY,maxY=maxX,maxZ=maxX;
        for(double x:new double[]{-.9,.9}) for(double y:new double[]{-.05,1.2}) for(double z:new double[]{-1.5,1.5}) {
            TrackVec3 q=p.add(f.right().scale(x)).add(f.up().scale(y)).add(f.forward().scale(z));
            minX=Math.min(minX,q.x());minY=Math.min(minY,q.y());minZ=Math.min(minZ,q.z());
            maxX=Math.max(maxX,q.x());maxY=Math.max(maxY,q.y());maxZ=Math.max(maxZ,q.z());
        }
        AABB[] boxes = new AABB[3]; boxes[0]=new AABB(minX,minY,minZ,maxX,maxY,maxZ);
        for(int seat=0;seat<2;seat++) {
            TrackVec3 q=p.add(f.right().scale(seat==0?-.45:.45)).add(f.up().scale(.45));
            boxes[seat+1]=new AABB(q.x()-.3,q.y(),q.z()-.3,q.x()+.3,q.y()+1.8,q.z()+.3);
        }
        return boxes;
    }
}
