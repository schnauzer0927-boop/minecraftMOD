package dev.coasterengineering.track;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Mathematical test fixture for future inversions. It is intentionally NOT used
 * by CoasterEntity, its seats, its renderer, its camera or the shipping V2 route.
 * Continuous frames alone do not establish safe inverted gameplay.
 */
public final class ParallelTransportFrameDiagnostic {
    private ParallelTransportFrameDiagnostic() { }

    public static List<TrackFrame> frames(SplineTrack track, double maximumInterval) {
        Objects.requireNonNull(track, "track");
        if (!Double.isFinite(maximumInterval) || maximumInterval <= 0) {
            throw new IllegalArgumentException("A positive finite sampling interval is required");
        }
        int count = (int) Math.ceil(track.length() / maximumInterval);
        if (count > 1_000_000) throw new IllegalArgumentException("Diagnostic sampling is too dense");
        List<TrackFrame> frames = new ArrayList<>(count + 1);
        TrackSample initial = track.sample(0);
        TrackVec3 oldForward = initial.tangent().normalized();
        TrackVec3 reference = Math.abs(oldForward.y()) < .95 ? new TrackVec3(0, 1, 0)
                : new TrackVec3(0, 0, 1);
        TrackVec3 right = reference.cross(oldForward).normalized();
        for (int i = 0; i <= count; i++) {
            TrackSample sample = track.sample(track.length() * i / count);
            TrackVec3 forward = sample.tangent().normalized();
            TrackVec3 axis = oldForward.cross(forward);
            double sine = axis.length();
            double cosine = Math.max(-1, Math.min(1, oldForward.dot(forward)));
            if (cosine < -.999999) {
                throw new IllegalArgumentException("Antiparallel tangent requires finer diagnostic samples");
            }
            if (sine > 1e-12) {
                axis = axis.scale(1 / sine);
                // Rodrigues minimal rotation transports the previous right vector.
                right = right.scale(cosine).add(axis.cross(right).scale(sine))
                        .add(axis.scale(axis.dot(right) * (1 - cosine)));
            }
            right = right.subtract(forward.scale(right.dot(forward))).normalized();
            TrackVec3 up = forward.cross(right).normalized();
            double bank = Math.toRadians(sample.bankDegrees());
            frames.add(new TrackFrame(right.scale(Math.cos(bank)).add(up.scale(Math.sin(bank))),
                    up.scale(Math.cos(bank)).subtract(right.scale(Math.sin(bank))), forward));
            oldForward = forward;
        }
        return List.copyOf(frames);
    }
}
