package dev.coasterengineering.client;

import dev.coasterengineering.track.TrackVec3;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/** Read-only server presentation snapshots; never advances or controls a train. */
public final class ClientAttractionState {
    private static final int EXPIRE_TICKS = 80;
    private static final Map<UUID, Snapshot> STATES = new HashMap<>();
    private static final Map<UUID, ArrayDeque<String>> EFFECTS = new HashMap<>();
    private static long clientTicks;

    private ClientAttractionState() { }

    /** Packet consumer, called only on the client main thread. */
    public static void update(UUID course, String stage, String music, double gain, int silenceTicks,
                              double lookX, double lookY, double lookZ, int gazeTicks,
                              String effect, long sequence) {
        Objects.requireNonNull(course, "course");
        if (!Double.isFinite(gain) || gain < 0 || gain > 1 || silenceTicks < 0 || gazeTicks < 0
                || silenceTicks > 12_000 || gazeTicks > 12_000 || sequence < 0)
            throw new IllegalArgumentException("Invalid attraction presentation snapshot");
        stage = bounded(stage);
        music = bounded(music);
        effect = bounded(effect);
        Snapshot next = new Snapshot(course, stage, music, gain, silenceTicks,
                new TrackVec3(lookX, lookY, lookZ), gazeTicks, effect, sequence, clientTicks);
        Snapshot previous = STATES.get(course);
        // Old snapshots cannot retrigger a one-shot. A first snapshot is state
        // restoration, so joining halfway through a ride does not replay its roar.
        if (previous != null && sequence < previous.sequence()) return;
        if (previous != null && sequence > previous.sequence() && !effect.isBlank()) {
            ArrayDeque<String> pending = EFFECTS.computeIfAbsent(course, unused -> new ArrayDeque<>());
            if (pending.size() >= 16) pending.removeFirst();
            pending.addLast(effect);
        }
        STATES.put(course, next);
    }

    public static void clientTick() {
        clientTicks++;
        STATES.entrySet().removeIf(entry -> {
            if (clientTicks - entry.getValue().receivedClientTick() <= EXPIRE_TICKS) return false;
            EFFECTS.remove(entry.getKey());
            return true;
        });
    }

    /** The caller freezes this clock while the integrated single-player game is paused. */
    public static void tick(boolean paused) { if (!paused) clientTick(); }

    public static Snapshot snapshot(UUID course) { return STATES.get(course); }
    public static Snapshot current(UUID course) { return snapshot(course); }

    public static String consumeEffect(UUID course) {
        ArrayDeque<String> pending = EFFECTS.get(course);
        return pending == null || pending.isEmpty() ? null : pending.removeFirst();
    }

    public static void discardEffects() { EFFECTS.clear(); }

    public static void clear() { STATES.clear(); EFFECTS.clear(); clientTicks = 0; }

    private static String bounded(String value) {
        Objects.requireNonNull(value, "presentation string");
        if (value.length() > 96) throw new IllegalArgumentException("Presentation identifier too long");
        return value;
    }

    public record Snapshot(UUID courseId, String stage, String music, double musicGain,
                           int silenceTicks, TrackVec3 lookTarget, int gazeTicks,
                           String effect, long sequence, long receivedClientTick) {
        public int remainingSilenceTicks() {
            return (int) Math.max(0, silenceTicks - (clientTicks - receivedClientTick));
        }
        public int remainingGazeTicks() {
            return (int) Math.max(0, gazeTicks - (clientTicks - receivedClientTick));
        }
        public double effectiveMusicGain() { return remainingSilenceTicks() > 0 ? 0 : musicGain; }
    }
}
