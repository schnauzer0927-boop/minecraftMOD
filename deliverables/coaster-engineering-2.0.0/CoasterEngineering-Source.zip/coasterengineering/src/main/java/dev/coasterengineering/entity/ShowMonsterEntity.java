package dev.coasterengineering.entity;

import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.registry.CoasterSounds;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/** A fixed stage puppet: it never fights, moves the train, damages blocks or collides with riders. */
public final class ShowMonsterEntity extends Entity {
    public static final int ROAR_TICKS = 60;
    public static final int THREAT_TICKS = 80;
    private static final EntityDataAccessor<Optional<UUID>> COURSE = SynchedEntityData.defineId(
            ShowMonsterEntity.class, EntityDataSerializers.OPTIONAL_UUID);
    private static final EntityDataAccessor<Boolean> ACTIVE = SynchedEntityData.defineId(
            ShowMonsterEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> EXPOSURE = SynchedEntityData.defineId(
            ShowMonsterEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> HEAD_YAW = SynchedEntityData.defineId(
            ShowMonsterEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> HEAD_PITCH = SynchedEntityData.defineId(
            ShowMonsterEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> ROAR = SynchedEntityData.defineId(
            ShowMonsterEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> THREAT = SynchedEntityData.defineId(
            ShowMonsterEntity.class, EntityDataSerializers.INT);
    private float oldExposure;
    private float oldHeadYaw;
    private float oldHeadPitch;
    private int oldRoar;
    private int oldThreat;
    private Vec3 lookTarget;

    public ShowMonsterEntity(EntityType<? extends ShowMonsterEntity> type, Level level) {
        super(type, level);
        noPhysics = true;
        setNoGravity(true);
        setInvulnerable(true);
    }

    /** Reuses the saved puppet, rather than creating another one each dispatch or reload. */
    public static ShowMonsterEntity ensure(ServerLevel level, UUID courseId, Vec3 anchor) {
        if (!level.hasChunkAt(net.minecraft.core.BlockPos.containing(anchor))) {
            throw new IllegalStateException("Load the show monster's anchor chunk before creating its puppet");
        }
        for (ShowMonsterEntity monster : level.getEntitiesOfClass(ShowMonsterEntity.class,
                new AABB(anchor, anchor).inflate(160), entity -> courseId.equals(entity.courseId()))) {
            return monster;
        }
        ShowMonsterEntity monster = CoasterRegistries.SHOW_MONSTER.get().create(level);
        if (monster == null) throw new IllegalStateException("Show monster entity could not be created");
        monster.entityData.set(COURSE, Optional.of(courseId));
        monster.setPos(anchor);
        if (!level.addFreshEntity(monster)) throw new IllegalStateException("Show monster could not be added");
        return monster;
    }

    @Override
    protected void defineSynchedData() {
        entityData.define(COURSE, Optional.empty());
        entityData.define(ACTIVE, false);
        entityData.define(EXPOSURE, 0F);
        entityData.define(HEAD_YAW, 0F);
        entityData.define(HEAD_PITCH, 0F);
        entityData.define(ROAR, 0);
        entityData.define(THREAT, 0);
    }

    public UUID courseId() { return entityData.get(COURSE).orElse(null); }
    public boolean isShowActive() { return entityData.get(ACTIVE); }
    public void setShowActive(boolean active) {
        if (level().isClientSide) return;
        entityData.set(ACTIVE, active);
        if (!active) {
            entityData.set(ROAR, 0);
            entityData.set(THREAT, 0);
            lookTarget = null;
        }
    }

    /** A dormant attraction loaded after a chunk reload must not briefly reveal an old active mesh. */
    public void resetHiddenImmediately() {
        if (level().isClientSide) return;
        setShowActive(false);
        entityData.set(EXPOSURE, 0F);
        entityData.set(HEAD_YAW, 0F);
        entityData.set(HEAD_PITCH, 0F);
        oldExposure = 0;
        oldHeadYaw = 0;
        oldHeadPitch = 0;
        oldRoar = 0;
        oldThreat = 0;
    }

    /** One audible roar per command; an event's repeat policy decides whether to call again. */
    public void roar() {
        if (level().isClientSide) return;
        setShowActive(true);
        entityData.set(ROAR, ROAR_TICKS);
        level().playSound(null, getX(), getY() + 6, getZ(), CoasterSounds.MONSTER.get(),
                SoundSource.NEUTRAL, 2F, .65F);
    }

    /** The animated foreleg strike has no collision, damage, block edits or train side effects. */
    public void threaten() {
        if (level().isClientSide) return;
        setShowActive(true);
        entityData.set(THREAT, THREAT_TICKS);
    }

    public void lookAt(Vec3 target) { if (!level().isClientSide) lookTarget = target; }
    public int roarTicksRemaining() { return entityData.get(ROAR); }
    public int threatTicksRemaining() { return entityData.get(THREAT); }
    public float exposure(float partialTick) { return Mth.lerp(partialTick, oldExposure, entityData.get(EXPOSURE)); }
    public float headYaw(float partialTick) { return Mth.rotLerp(partialTick, oldHeadYaw, entityData.get(HEAD_YAW)); }
    public float headPitch(float partialTick) { return Mth.lerp(partialTick, oldHeadPitch, entityData.get(HEAD_PITCH)); }
    public float roarProgress(float partialTick) { return progress(ROAR, oldRoar, ROAR_TICKS, partialTick); }
    public float threatProgress(float partialTick) { return progress(THREAT, oldThreat, THREAT_TICKS, partialTick); }

    private float progress(EntityDataAccessor<Integer> timer, int previous, int duration, float partialTick) {
        int current = entityData.get(timer);
        if (current <= 0 && previous <= 0) return -1;
        // A new attack begins at phase zero, avoiding interpolation from the expired animation.
        float remaining = current > previous ? current : Mth.lerp(partialTick, previous, current);
        return Mth.clamp(1 - remaining / duration, 0, 1);
    }

    @Override
    public void tick() {
        oldExposure = entityData.get(EXPOSURE);
        oldHeadYaw = entityData.get(HEAD_YAW);
        oldHeadPitch = entityData.get(HEAD_PITCH);
        oldRoar = entityData.get(ROAR);
        oldThreat = entityData.get(THREAT);
        super.tick();
        setDeltaMovement(Vec3.ZERO);
        noPhysics = true;
        if (level().isClientSide) return;
        float targetExposure = isShowActive() ? 1 : 0;
        entityData.set(EXPOSURE, Mth.clamp(oldExposure + (isShowActive() ? .035F : -.025F), 0, 1));
        if (oldRoar > 0) entityData.set(ROAR, oldRoar - 1);
        if (oldThreat > 0) entityData.set(THREAT, oldThreat - 1);
        if (isShowActive()) {
            CoasterEntity train = level().getEntitiesOfClass(CoasterEntity.class, getBoundingBox().inflate(90),
                    entity -> entity.isTrainLeader() && java.util.Objects.equals(courseId(), entity.courseId()))
                    .stream().min(java.util.Comparator.comparingDouble(this::distanceToSqr)).orElse(null);
            if (train != null) lookTarget = train.position().add(0, 1.6, 0);
        }
        float yaw = 0;
        float pitch = 0;
        if (targetExposure > 0 && lookTarget != null) {
            double heading = Math.toRadians(getYRot());
            Vec3 headOrigin = position().add(-Math.sin(heading) * 5.6, 6.2, Math.cos(heading) * 5.6);
            Vec3 direction = lookTarget.subtract(headOrigin);
            yaw = Mth.clamp(Mth.wrapDegrees((float) Math.toDegrees(Math.atan2(-direction.x, direction.z)) - getYRot()), -65, 65);
            pitch = Mth.clamp((float) -Math.toDegrees(Math.atan2(direction.y,
                    Math.sqrt(direction.x * direction.x + direction.z * direction.z))), -28, 35);
        }
        entityData.set(HEAD_YAW, Mth.rotLerp(.12F, oldHeadYaw, yaw));
        entityData.set(HEAD_PITCH, Mth.lerp(.12F, oldHeadPitch, pitch));
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(COURSE, tag.hasUUID("ShowCourse") ? Optional.of(tag.getUUID("ShowCourse")) : Optional.empty());
        entityData.set(ACTIVE, tag.getBoolean("ShowActive"));
        entityData.set(EXPOSURE, Mth.clamp(tag.getFloat("ShowExposure"), 0, 1));
        entityData.set(HEAD_YAW, Mth.clamp(tag.getFloat("ShowHeadYaw"), -65, 65));
        entityData.set(HEAD_PITCH, Mth.clamp(tag.getFloat("ShowHeadPitch"), -28, 35));
        entityData.set(ROAR, Mth.clamp(tag.getInt("ShowRoarTicks"), 0, ROAR_TICKS));
        entityData.set(THREAT, Mth.clamp(tag.getInt("ShowThreatTicks"), 0, THREAT_TICKS));
        oldExposure = entityData.get(EXPOSURE);
        oldHeadYaw = entityData.get(HEAD_YAW);
        oldHeadPitch = entityData.get(HEAD_PITCH);
        oldRoar = entityData.get(ROAR);
        oldThreat = entityData.get(THREAT);
    }

    @Override protected void addAdditionalSaveData(CompoundTag tag) {
        if (courseId() != null) tag.putUUID("ShowCourse", courseId());
        tag.putBoolean("ShowActive", isShowActive());
        tag.putFloat("ShowExposure", entityData.get(EXPOSURE));
        tag.putFloat("ShowHeadYaw", entityData.get(HEAD_YAW));
        tag.putFloat("ShowHeadPitch", entityData.get(HEAD_PITCH));
        tag.putInt("ShowRoarTicks", roarTicksRemaining());
        tag.putInt("ShowThreatTicks", threatTicksRemaining());
    }

    @Override public boolean isPickable() { return false; }
    @Override public boolean isPushable() { return false; }
    @Override public boolean canBeCollidedWith() { return false; }
    @Override public boolean canCollideWith(Entity other) { return false; }
    @Override public void push(Entity other) { }
    @Override public boolean hurt(DamageSource source, float amount) { return false; }
    @Override public AABB getBoundingBoxForCulling() { return new AABB(getX() - 10, getY() - 13, getZ() - 11,
            getX() + 10, getY() + 12, getZ() + 11); }
    @Override public boolean shouldRenderAtSqrDistance(double distance) { return distance < 256 * 256; }
    @Override public Packet<ClientGamePacketListener> getAddEntityPacket() { return NetworkHooks.getEntitySpawningPacket(this); }
}
