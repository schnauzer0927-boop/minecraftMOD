package dev.coasterengineering.world;

import com.mojang.datafixers.util.Either;
import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.CoasterEntity;
import dev.coasterengineering.entity.ShowMonsterEntity;
import dev.coasterengineering.network.CoasterNetwork;
import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.attraction.AttractionDirector;
import dev.coasterengineering.station.StationControllerBlockEntity;
import dev.coasterengineering.track.SplineTrack;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import dev.coasterengineering.track.VolcanicAbyssV2;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ChunkHolder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.TicketType;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkStatus;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.levelgen.FlatLevelSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** A new, budgeted attraction; never mutates or upgrades the existing V1 world. */
@Mod.EventBusSubscriber(modid=CoasterEngineering.MOD_ID)
public final class VolcanicV2WorldBuilder {
    public static final long WORLD_SEED=20261012L;
    public static final BlockPos LANDING=new BlockPos(-3,94,-165), CONTROLLER=new BlockPos(-6,94,-165);
    private static final TicketType<UUID> TICKET=TicketType.create("coasterengineering_v2_build",Comparator.<UUID>naturalOrder());
    private static final Map<ServerLevel,Job> JOBS=new IdentityHashMap<>();
    private static final Map<ServerLevel,String> STATUS=new IdentityHashMap<>();
    private static final Map<ServerLevel,Retention> RETENTION=new IdentityHashMap<>();
    private VolcanicV2WorldBuilder() { }

    public static boolean begin(ServerLevel level) {
        if(level==null) return false;
        if(JOBS.containsKey(level)) return reject(level,"A V2 construction job is already running");
        if(!level.dimension().equals(Level.OVERWORLD) || level.getSeed()!=WORLD_SEED
                || !(level.getChunkSource().getGenerator() instanceof FlatLevelSource))
            return reject(level,"Use a NEW dedicated flat Overworld with seed 20261012 and grass at Y63; existing V1 saves are protected");
        if(!CoasterSavedData.get(level).courses().isEmpty()) return reject(level,"The new world already contains a course");
        if(!level.getWorldBorder().isWithinBounds(new BlockPos(VolcanicV2Geometry.MIN_X,80,VolcanicV2Geometry.MIN_Z))
                || !level.getWorldBorder().isWithinBounds(new BlockPos(VolcanicV2Geometry.MAX_X,180,VolcanicV2Geometry.MAX_Z)))
            return reject(level,"Attraction footprint lies outside the world border");
        JOBS.put(level,new Job(level));
        CoasterEngineering.LOGGER.info("VOLCANIC_V2_BUILD_STARTED seed={} course={}",WORLD_SEED,VolcanicAbyssV2.COURSE_ID);
        return true;
    }
    public static boolean isActive(ServerLevel level) { return JOBS.containsKey(level); }
    public static String status(ServerLevel level) {
        if(level==null) return "Server world is not ready";
        Job job=JOBS.get(level); if(job!=null)return job.describe();
        if(VolcanicV2BuildData.get(level).isReady()) return STATUS.getOrDefault(level,"READY VOLCANIC ABYSS 2.0; saved construction audits passed");
        return STATUS.getOrDefault(level,"No V2 construction has been started");
    }
    public static boolean cancel(ServerLevel level) {
        Job job=JOBS.remove(level);
        if(job==null) { Retention old=RETENTION.remove(level);if(old==null)return false;release(level,old.chunks);return true; }
        job.rollback();release(level,job.chunks);STATUS.put(level,"CANCELLED; use a fresh world before retrying; generated scenery remains");return true;
    }
    private static boolean reject(ServerLevel level,String why) { STATUS.put(level,why);return false; }
    private static void release(ServerLevel level,List<ChunkPos> chunks) {
        for(ChunkPos p:chunks) level.getChunkSource().removeRegionTicket(TICKET,p,2,VolcanicAbyssV2.COURSE_ID);
    }
    @SubscribeEvent public static void tick(TickEvent.ServerTickEvent event) {
        if(event.phase!=TickEvent.Phase.END)return;
        for(Job job:new ArrayList<>(JOBS.values())) if(job.level.getServer()==event.getServer()) {
            try { job.tick(); } catch(RuntimeException failure) {
                JOBS.remove(job.level);job.rollback();release(job.level,job.chunks);
                STATUS.put(job.level,"FAILED at "+job.stage+": "+failure.getMessage()+"; recreate a fresh dedicated world");
                CoasterEngineering.LOGGER.error("VOLCANIC_V2_FAILED stage={}",job.stage,failure);
            }
        }
        Iterator<Map.Entry<ServerLevel,Retention>> iterator=RETENTION.entrySet().iterator();
        while(iterator.hasNext()) {var e=iterator.next();if(e.getKey().getServer()==event.getServer()&&e.getKey().getGameTime()>=e.getValue().until) {
            Retention retained=e.getValue();
            release(e.getKey(),retained.chunks);iterator.remove();
            CoasterEngineering.LOGGER.info("VOLCANIC_V2_BUILD_TICKETS_RELEASED chunks={}",retained.chunks.size());
        }}
    }
    @SubscribeEvent public static void stopping(ServerStoppingEvent event) {
        for(Job job:new ArrayList<>(JOBS.values())) if(job.level.getServer()==event.getServer()) {job.rollback();release(job.level,job.chunks);JOBS.remove(job.level);}
        RETENTION.entrySet().removeIf(e->{if(e.getKey().getServer()!=event.getServer())return false;release(e.getKey(),e.getValue().chunks);return true;});
        STATUS.keySet().removeIf(level->level.getServer()==event.getServer());
    }
    private record Retention(List<ChunkPos> chunks,long until) { }
    private enum Stage { CHUNKS,PREFLIGHT,PLAN,SHELL,ROOM_WALLS,TUBE_WALLS,CARVE_ROOMS,CARVE_TUBE,STATION_VOID,DECOR,LIGHTING,LIGHT_WAIT,CLEARANCE,WALL_AUDIT,LIGHT_AUDIT,COMMIT }
    private static final class Budget {
        final long deadline=System.nanoTime()+14_000_000L;int checks,writes;
        boolean room(){return checks<30000&&writes<4096&&System.nanoTime()<deadline;}
    }
    private static final class Job {
        final ServerLevel level;final SplineTrack track=VolcanicAbyssV2.create(TrackVec3.ZERO);
        final List<ChunkPos> chunks=new ArrayList<>();final CoasterEntity probe;
        Stage stage=Stage.CHUNKS;int cursor,inner,room,bitCursor,preflightY=63;long checked,placed,lastProgress,waitUntil;
        int lightProbes,minBlock=15,minCombined=15,stationMin=15,dark,wallFailures,lightPass;
        double distance;boolean waiting,committed;CoasterEntity leader;
        CompletableFuture<Either<ChunkAccess,ChunkHolder.ChunkLoadingFailure>> pendingChunk;
        CompletableFuture<VolcanicV2Geometry> pendingGeometry;
        CompletableFuture<Map<BlockPos,BlockState>> pendingPlan;Iterator<Map.Entry<BlockPos,BlockState>> plan;
        VolcanicV2Geometry geometry;final BlockPos.MutableBlockPos pos=new BlockPos.MutableBlockPos();
        Job(ServerLevel level) {this.level=level;probe=CoasterRegistries.COASTER.get().create(level);if(probe==null)throw new IllegalStateException("Cannot create geometry validator");}
        String describe(){return "VOLCANIC ABYSS 2.0 "+stage+"; checked="+checked+", placed="+placed+", chunks="+chunks.size()+", dark="+dark;}
        void enter(Stage next) {stage=next;cursor=inner=bitCursor=0;distance=0;plan=null;pendingPlan=null;CoasterEngineering.LOGGER.info("VOLCANIC_V2_BUILD_STAGE {}",describe());}
        void tick() {
            level.resetEmptyTime();
            Budget b=new Budget();waiting=false;
            while(b.room()&&!waiting) switch(stage) {
                case CHUNKS -> chunks(b);case PREFLIGHT -> preflight(b);case PLAN -> geometry();case SHELL -> shell(b);
                case ROOM_WALLS -> rooms(b,false);case TUBE_WALLS -> bits(b,false);case CARVE_ROOMS -> rooms(b,true);
                case CARVE_TUBE -> bits(b,true);case STATION_VOID -> stationVoid(b);case DECOR -> planned(b,false);
                case LIGHTING -> planned(b,true);case LIGHT_WAIT -> lightWait();case CLEARANCE -> clearance(b);
                case WALL_AUDIT -> wallAudit(b);case LIGHT_AUDIT -> lightAudit(b);case COMMIT -> {commit();return;}
            }
            if(level.getGameTime()-lastProgress>=200){lastProgress=level.getGameTime();CoasterEngineering.LOGGER.info("{}",describe());}
        }
        void chunks(Budget b) {
            int minX=VolcanicV2Geometry.MIN_X>>4,minZ=VolcanicV2Geometry.MIN_Z>>4;
            int width=(VolcanicV2Geometry.MAX_X>>4)-minX+1,total=width*((VolcanicV2Geometry.MAX_Z>>4)-minZ+1);
            if(pendingChunk!=null) {
                if(!pendingChunk.isDone()){waiting=true;return;}
                if(pendingChunk.join().left().isEmpty())throw new IllegalStateException("Failed FULL construction chunk");
                pendingChunk=null;cursor++;waiting=true;
            }
            if(cursor>=total){enter(Stage.PREFLIGHT);return;}
            if(waiting)return;
            ChunkPos p=new ChunkPos(minX+cursor%width,minZ+cursor/width);
            level.getChunkSource().addRegionTicket(TICKET,p,2,VolcanicAbyssV2.COURSE_ID);chunks.add(p);
            pendingChunk=level.getChunkSource().getChunkFuture(p.x,p.z,ChunkStatus.FULL,true);b.checks++;waiting=true;
        }
        void preflight(Budget b) {
            int w=VolcanicV2Geometry.WIDTH;
            if(cursor>=w*VolcanicV2Geometry.DEPTH){enter(Stage.PLAN);return;}
            int x=VolcanicV2Geometry.MIN_X+cursor%w,z=VolcanicV2Geometry.MIN_Z+cursor/w;
            LevelChunk chunk=level.getChunkSource().getChunkNow(x>>4,z>>4);if(chunk==null)throw new IllegalStateException("Construction chunk unloaded");
            pos.set(x,preflightY,z);b.checks++;checked++;
            if(preflightY==63){if(!chunk.getBlockState(pos).is(Blocks.GRASS_BLOCK))throw new IllegalStateException("Expected untouched Y63 grass at "+pos);preflightY=64;}
            else if(chunk.getSections()[level.getSectionIndex(preflightY)].hasOnlyAir())preflightY=(preflightY|15)+1;
            else {if(!chunk.getBlockState(pos).isAir())throw new IllegalStateException("Dedicated footprint already contains blocks at "+pos);preflightY++;}
            if(preflightY>=level.getMaxBuildHeight()){cursor++;preflightY=63;}
        }
        void geometry() {
            if(pendingGeometry==null)pendingGeometry=CompletableFuture.supplyAsync(()->new VolcanicV2Geometry(track),Util.backgroundExecutor());
            if(!pendingGeometry.isDone()){waiting=true;return;}
            geometry=pendingGeometry.join();pendingGeometry=null;enter(Stage.SHELL);
        }
        void shell(Budget b) {
            if(cursor>=VolcanicV2Geometry.WIDTH*VolcanicV2Geometry.DEPTH){enter(Stage.ROOM_WALLS);return;}
            int x=VolcanicV2Geometry.MIN_X+cursor%VolcanicV2Geometry.WIDTH,z=VolcanicV2Geometry.MIN_Z+cursor/VolcanicV2Geometry.WIDTH;
            double radius=Math.hypot(x,z);
            if(radius>210){cursor++;inner=0;b.checks++;return;}
            int top=surfaceHeight(x,z);
            int y=inner<12?64+inner:top-12+(inner-12);
            place(new BlockPos(x,y,z),stone(x,y,z),b);
            if(++inner>=25){inner=0;cursor++;}
        }
        void rooms(Budget b,boolean carve) {
            if(room>=VolcanicV2Geometry.ROOMS.length){room=0;enter(carve?Stage.CARVE_TUBE:Stage.TUBE_WALLS);return;}
            double[] r=VolcanicV2Geometry.ROOMS[room];
            int rx=(int)Math.ceil(r[3]*1.17),ry=(int)Math.ceil(r[4]*1.17),rz=(int)Math.ceil(r[5]*1.17);
            int w=rx*2+1,h=ry*2+1;
            if(cursor>=w*h*(rz*2+1)){cursor=0;room++;return;}
            int x=(int)r[0]+cursor%w-rx,y=(int)r[1]+cursor/w%h-ry,z=(int)r[2]+cursor/(w*h)-rz;cursor++;b.checks++;checked++;
            if(VolcanicV2Geometry.index(x,y,z)<0)return;
            double value=VolcanicV2Geometry.roomValue(r,x,y,z);
            if(carve) {if(VolcanicV2Geometry.roomAir(r,x,y,z))place(new BlockPos(x,y,z),Blocks.AIR.defaultBlockState(),b);}
            else if(value>=1&&value<1.32 || y<=75&&value<1.32)place(new BlockPos(x,y,z),stone(x,y,z),b);
        }
        void bits(Budget b,boolean carve) {
            var mask=carve?geometry.tunnelAir:geometry.tunnelWall;
            int i=mask.nextSetBit(bitCursor);
            if(i<0){enter(carve?Stage.STATION_VOID:Stage.CARVE_ROOMS);return;}
            bitCursor=i+1;BlockPos p=VolcanicV2Geometry.position(i);
            place(p,carve?Blocks.AIR.defaultBlockState():stone(p.getX(),p.getY(),p.getZ()),b);
        }
        void stationVoid(Budget b) {
            final int w=42,h=19,zs=69;
            if(cursor>=w*h*zs){enter(Stage.DECOR);return;}
            int x=-22+cursor%w,y=94+cursor/w%h,z=-208+cursor/(w*h);cursor++;
            place(new BlockPos(x,y,z),Blocks.AIR.defaultBlockState(),b);
        }
        void planned(Budget b,boolean lighting) {
            if(plan==null) {
                if(pendingPlan==null)pendingPlan=CompletableFuture.supplyAsync(()->lighting?VolcanicV2Scenery.lighting(geometry):VolcanicV2Scenery.decorations(geometry),Util.backgroundExecutor());
                if(!pendingPlan.isDone()){waiting=true;return;}
                plan=pendingPlan.join().entrySet().iterator();pendingPlan=null;
            }
            if(!plan.hasNext()){enter(lighting?Stage.LIGHT_WAIT:Stage.LIGHTING);if(lighting)waitUntil=level.getGameTime()+100;return;}
            var e=plan.next();BlockState old=level.getBlockState(e.getKey());b.checks++;
            if(lighting&&e.getValue().is(Blocks.LIGHT)&&!old.isAir()&&!old.is(Blocks.LIGHT))return;
            if(lighting&&e.getValue().is(Blocks.LIGHT)&&old.is(Blocks.LIGHT)&&old.getValue(LightBlock.LEVEL)>e.getValue().getValue(LightBlock.LEVEL))return;
            place(e.getKey(),e.getValue(),b);
        }
        void lightWait(){if(level.getGameTime()<waitUntil){waiting=true;return;}enter(Stage.CLEARANCE);}
        void clearance(Budget b) {
            if(distance>track.length()){enter(Stage.WALL_AUDIT);return;}
            if(!probe.canUseTrackSample(track.sample(distance)))throw new IllegalStateException("Actual body/rider clearance failed at "+distance);
            distance+=.25;b.checks++;checked++;
        }
        void wallAudit(Budget b) {
            if(distance>track.length()){if(wallFailures!=0)throw new IllegalStateException("Unsealed indoor sightlines: "+wallFailures);enter(Stage.LIGHT_AUDIT);return;}
            double d=distance;distance+=12;
            if(d>=track.controlPointDistance(39)-12&&d<=track.controlPointDistance(55)+12)return;
            if(d<50||d>track.length()-80)return; // platform/return has deliberate station access.
            TrackSample s=track.sample(d);TrackFrame f=TrackFrame.from(s);TrackVec3 eye=s.position().add(new TrackVec3(0,2,0));
            for(TrackVec3 direction:new TrackVec3[]{f.right(),f.right().scale(-1),new TrackVec3(0,1,0)}) {
                boolean sealed=false;
                for(double step=3;step<160;step+=1) {
                    TrackVec3 q=eye.add(direction.scale(step));BlockPos p=BlockPos.containing(q.x(),q.y(),q.z());
                    if(VolcanicV2Geometry.index(p)<0)break;
                    BlockState state=level.getBlockState(p);b.checks++;
                    if(!state.isAir()&&!state.is(Blocks.LIGHT)&&!state.getCollisionShape(level,p).isEmpty()){sealed=true;break;}
                }
                if(!sealed){wallFailures++;CoasterEngineering.LOGGER.warn("VOLCANIC_V2_OPEN_SIGHTLINE distance={} direction={}",d,direction);}
            }
        }
        void lightAudit(Budget b) {
            if(distance>track.length()) {
                CoasterEngineering.LOGGER.info("VOLCANIC_V2_LIGHT_AUDIT pass={} probes={} minBlock={} minCombined={} stationMin={} belowTarget={}",lightPass,lightProbes,minBlock,minCombined,stationMin,dark);
                if(dark!=0) {
                    if(++lightPass>=10)throw new IllegalStateException("Live light audit below required brightness in "+dark+" seat probes");
                    distance=0;lightProbes=dark=0;minBlock=minCombined=stationMin=15;waitUntil=level.getGameTime()+40;waiting=true;return;
                }
                enter(Stage.COMMIT);return;
            }
            if(level.getGameTime()<waitUntil){waiting=true;return;}
            TrackSample sample=track.sample(distance);TrackFrame f=TrackFrame.from(sample);
            boolean station=distance<24||distance>track.length()-25;
            for(int seat=0;seat<2;seat++) {
                TrackVec3 feet=sample.position().add(f.right().scale(seat==0?-.45:.45)).add(f.up().scale(.45));
                BlockPos eye=BlockPos.containing(feet.x(),feet.y()+1.62,feet.z());
                int block=level.getBrightness(LightLayer.BLOCK,eye),sky=level.getBrightness(LightLayer.SKY,eye),combined=Math.max(block,sky);
                lightProbes++;minBlock=Math.min(minBlock,block);minCombined=Math.min(minCombined,combined);if(station)stationMin=Math.min(stationMin,combined);
                if(combined<(station?9:6)){dark++;if(dark<9)CoasterEngineering.LOGGER.warn("VOLCANIC_V2_DIM_SEAT distance={} seat={} pos={} block={} sky={} required={}",distance,seat,eye,block,sky,station?9:6);}
                b.checks++;checked++;
            }
            distance+=1;
        }
        void place(BlockPos p,BlockState state,Budget b) {
            if(VolcanicV2Geometry.index(p)<0)throw new IllegalStateException("Plan left V2 footprint: "+p);
            b.checks++;checked++;if(level.getBlockState(p)==state)return;
            if(!level.setBlock(p,state,Block.UPDATE_CLIENTS))throw new IllegalStateException("Block write failed at "+p);
            b.writes++;placed++;
        }
        void commit() {
            CoasterSavedData data=CoasterSavedData.get(level);if(!data.courses().isEmpty())throw new IllegalStateException("Another course was created during construction");
            Course course=new Course(VolcanicAbyssV2.COURSE_ID,"VOLCANIC ABYSS 2.0",track,LANDING,true);
            data.putCourse(course);committed=true;
            leader=CoasterRegistries.COASTER.get().create(level);if(leader==null)throw new IllegalStateException("Train entity unavailable");
            leader.setCourse(course.id());
            if(!data.claimVehicle(course.id(),leader.getUUID())||!leader.resetToStation()||!level.addFreshEntity(leader))throw new IllegalStateException("Could not place station train");
            if(!TrainService.setCarCount(leader,3))throw new IllegalStateException("Could not create three-car formation");
            if(!(level.getBlockEntity(CONTROLLER) instanceof StationControllerBlockEntity station)||!station.bind(course.id()))throw new IllegalStateException("Station controller unavailable");
            station.setDwellTicks(140);station.setAutoDeparture(true);
            level.setDefaultSpawnPos(LANDING,-90);
            GameRules rules=level.getGameRules();rules.getRule(GameRules.RULE_SPAWN_RADIUS).set(0,level.getServer());
            rules.getRule(GameRules.RULE_DOMOBSPAWNING).set(false,level.getServer());rules.getRule(GameRules.RULE_DOFIRETICK).set(false,level.getServer());
            rules.getRule(GameRules.RULE_MOBGRIEFING).set(false,level.getServer());rules.getRule(GameRules.RULE_DAYLIGHT).set(false,level.getServer());
            rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(false,level.getServer());rules.getRule(GameRules.RULE_DOINSOMNIA).set(false,level.getServer());
            rules.getRule(GameRules.RULE_DO_PATROL_SPAWNING).set(false,level.getServer());rules.getRule(GameRules.RULE_DO_TRADER_SPAWNING).set(false,level.getServer());
            level.setDayTime(6000);level.setWeatherParameters(6000,0,false,false);
            CompoundTag report=new CompoundTag();report.putInt("buildVersion",2);report.putBoolean("ready",true);report.putString("courseId",course.id().toString());
            report.putLong("placed",placed);report.putDouble("length",track.length());report.putInt("probes",lightProbes);report.putInt("minBlockLight",minBlock);
            report.putInt("minCombinedLight",minCombined);report.putInt("stationMinCombinedLight",stationMin);report.putInt("darkProbes",dark);report.putInt("wallAuditFailures",wallFailures);
            VolcanicV2BuildData.get(level).complete(report);
            ShowMonsterEntity.ensure(level,course.id(),new Vec3(32,78,132)).setYRot(-136.273F);
            AttractionDirector.install(level,course);
            CoasterNetwork.broadcastCourse(level,course);
            JOBS.remove(level);RETENTION.put(level,new Retention(List.copyOf(chunks),level.getGameTime()+1200));
            STATUS.put(level,"READY VOLCANIC ABYSS 2.0; three cars/six seats; actual clearance and light audits passed");
            CoasterEngineering.LOGGER.info("VOLCANIC_V2_READY course={} placed={} length={} probes={} minCombined={} stationMin={} dark={} wallFailures={}",
                    course.id(),placed,track.length(),lightProbes,minCombined,stationMin,dark,wallFailures);
        }
        void rollback(){if(!committed)return;if(leader!=null){for(CoasterEntity car:leader.getLoadedFormation())car.discard();leader.discard();}CoasterSavedData.get(level).removeCourse(VolcanicAbyssV2.COURSE_ID);CompoundTag report=VolcanicV2BuildData.get(level).report();report.putBoolean("ready",false);VolcanicV2BuildData.get(level).complete(report);committed=false;}
    }
    private static int surfaceHeight(int x,int z) {
        double r=Math.hypot(x,z),ridge=4*Math.sin(x*.045+z*.029)+2*Math.sin(x*.14-z*.075);
        return (int)Math.floor(Math.max(88,Math.min(195,193-99*Math.pow(r/210,1.55)+ridge)));
    }
    private static BlockState stone(int x,int y,int z) {
        long h=WORLD_SEED^x*341873128712L^y*132897987541L^z*42317861L;h^=h>>>31;int n=(int)Math.floorMod(h,100);
        if(y<78)return(n<80?Blocks.DEEPSLATE:Blocks.BLACKSTONE).defaultBlockState();
        // Broad geological bands keep the rock readable, while fine noise
        // breaks the surface without obvious alternating block patterns.
        double band=Math.sin(x*.04+z*.05+y*.2);
        return(n<10?Blocks.BLACKSTONE:n<25?Blocks.TUFF:band>.45?Blocks.BASALT:Blocks.DEEPSLATE).defaultBlockState();
    }
}
