package dev.coasterengineering.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import dev.coasterengineering.entity.ShowMonsterEntity;
import dev.coasterengineering.show.MonsterPose;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

/** Original basalt plated stage creature. Uses the same world-up geometry as the editable Blockbench file. */
public final class ShowMonsterModel extends EntityModel<ShowMonsterEntity> {
    public static final float SCALE = 2.8F;
    private static final JsonObject GEOMETRY = readGeometry();
    private final ModelPart root;
    private final Map<String, ModelPart> parts = new LinkedHashMap<>();
    private final Map<String, JsonObject> boneData = new LinkedHashMap<>();
    private float eyeBrightness;

    public ShowMonsterModel(ModelPart root) {
        this.root = root;
        parts.put("root", root);
        for (var element : GEOMETRY.getAsJsonArray("bones")) {
            JsonObject bone = element.getAsJsonObject();
            boneData.put(bone.get("name").getAsString(), bone);
            parts.put(bone.get("name").getAsString(), parts.get(bone.get("parent").getAsString())
                    .getChild(bone.get("name").getAsString()));
        }
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        Map<String, PartDefinition> bones = new LinkedHashMap<>();
        bones.put("root", mesh.getRoot());
        for (var element : GEOMETRY.getAsJsonArray("bones")) {
            JsonObject bone = element.getAsJsonObject();
            CubeListBuilder cubes = CubeListBuilder.create();
            for (var cubeElement : bone.getAsJsonArray("cubes")) {
                JsonObject cube = cubeElement.getAsJsonObject();
                JsonArray start = cube.getAsJsonArray("from");
                JsonArray size = cube.getAsJsonArray("size");
                JsonArray uv = cube.getAsJsonArray("uv");
                cubes.texOffs(uv.get(0).getAsInt(), uv.get(1).getAsInt())
                        .addBox(start.get(0).getAsFloat(), start.get(1).getAsFloat(), start.get(2).getAsFloat(),
                                size.get(0).getAsFloat(), size.get(1).getAsFloat(), size.get(2).getAsFloat());
            }
            JsonArray pivot = bone.getAsJsonArray("pivot");
            bones.put(bone.get("name").getAsString(), bones.get(bone.get("parent").getAsString())
                    .addOrReplaceChild(bone.get("name").getAsString(), cubes,
                            PartPose.offset(pivot.get(0).getAsFloat(), pivot.get(1).getAsFloat(), pivot.get(2).getAsFloat())));
        }
        return LayerDefinition.create(mesh, GEOMETRY.get("texture_width").getAsInt(), GEOMETRY.get("texture_height").getAsInt());
    }

    private static JsonObject readGeometry() {
        try (InputStream stream = ShowMonsterModel.class.getResourceAsStream(
                "/assets/coasterengineering/models/entity/show_monster.json")) {
            if (stream == null) throw new IllegalStateException("Missing show monster geometry asset");
            return JsonParser.parseReader(new InputStreamReader(stream, StandardCharsets.UTF_8)).getAsJsonObject();
        } catch (java.io.IOException exception) {
            throw new IllegalStateException("Could not load show monster geometry", exception);
        }
    }

    @Override
    public void setupAnim(ShowMonsterEntity entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        for (ModelPart part : parts.values()) part.resetPose();
        float partialTick = Math.max(0, Math.min(1, ageInTicks - entity.tickCount));
        MonsterPose.Pose animated = MonsterPose.sample(entity.exposure(partialTick),
                entity.roarProgress(partialTick), entity.threatProgress(partialTick), ageInTicks);
        parts.get("body").y += (float) animated.bodyBob();
        parts.get("neck").xRot = (float) animated.neckPitch();
        parts.get("neck").yRot = (float) -Math.toRadians(entity.headYaw(partialTick)) * .3F;
        parts.get("head").xRot = (float) Math.toRadians(entity.headPitch(partialTick)) + (float) animated.headPitch();
        parts.get("head").yRot = (float) -Math.toRadians(entity.headYaw(partialTick)) * .7F;
        parts.get("jaw").xRot = (float) animated.jawAngle();
        parts.get("left_front_leg").xRot = (float) animated.leftLegAngle();
        parts.get("right_front_leg").xRot = (float) animated.rightLegAngle();
        parts.get("tail").yRot = (float) Math.sin(ageInTicks * .027) * .045F * entity.exposure(partialTick);
        eyeBrightness = (float) animated.eyeBrightness();
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer vertices, int light, int overlay,
                               float red, float green, float blue, float alpha) {
        renderPass(pose, vertices, light, overlay, alpha, false);
    }

    public void renderEyes(PoseStack pose, VertexConsumer vertices, int overlay) {
        if (eyeBrightness > .001F) renderPass(pose, vertices, 15728880, overlay, 1, true);
    }

    /** Visits actual cube transforms, so glowing eyes follow both animated neck and head. */
    private void renderPass(PoseStack pose, VertexConsumer vertices, int light,
                            int overlay, float alpha, boolean emissivePass) {
        root.visit(pose, (visitedPose, path, index, cube) -> {
            String name = path.substring(path.lastIndexOf('/') + 1);
            JsonObject data = boneData.get(name);
            if (data != null && data.get("emissive").getAsBoolean() == emissivePass) {
                JsonArray color = data.getAsJsonArray("color");
                float brightness = emissivePass ? eyeBrightness : 1;
                cube.compile(visitedPose, vertices, light, overlay,
                        color.get(0).getAsFloat() * brightness, color.get(1).getAsFloat() * brightness,
                        color.get(2).getAsFloat() * brightness, alpha);
            }
        });
    }
}
