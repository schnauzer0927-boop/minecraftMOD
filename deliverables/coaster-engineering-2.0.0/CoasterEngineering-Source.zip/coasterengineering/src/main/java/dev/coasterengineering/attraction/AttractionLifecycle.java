package dev.coasterengineering.attraction;

import dev.coasterengineering.CoasterEngineering;
import dev.coasterengineering.entity.ShowMonsterEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Presentation state is re-established by the director, rather than stale entity NBT, on chunk load. */
@Mod.EventBusSubscriber(modid = CoasterEngineering.MOD_ID)
public final class AttractionLifecycle {
    @SubscribeEvent public static void joined(EntityJoinLevelEvent event) {
        if (event.getLevel() instanceof ServerLevel level && event.getEntity() instanceof ShowMonsterEntity monster)
            AttractionDirector.onMonsterLoaded(level, monster);
    }
    private AttractionLifecycle() { }
}
