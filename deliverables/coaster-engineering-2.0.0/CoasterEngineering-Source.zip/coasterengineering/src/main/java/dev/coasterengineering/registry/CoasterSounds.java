package dev.coasterengineering.registry;

import dev.coasterengineering.CoasterEngineering;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Common sound identifiers. Playback and streamed audio remain client responsibilities. */
public final class CoasterSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, CoasterEngineering.MOD_ID);
    public static final RegistryObject<SoundEvent> MUSIC_RESEARCH = register("music.research");
    public static final RegistryObject<SoundEvent> MUSIC_ABYSS = register("music.abyss");
    public static final RegistryObject<SoundEvent> MUSIC_ESCAPE = register("music.escape");
    public static final RegistryObject<SoundEvent> EXPLORATION = register("music.exploration");
    public static final RegistryObject<SoundEvent> RUINS_CHASE = register("music.ruins_chase");
    public static final RegistryObject<SoundEvent> MONSTER_ENCOUNTER = register("music.monster_encounter");
    public static final RegistryObject<SoundEvent> ERUPTION_ESCAPE = register("music.eruption_escape");
    public static final RegistryObject<SoundEvent> FINALE = register("music.finale");
    public static final RegistryObject<SoundEvent> LAUNCH = register("coaster.launch");
    public static final RegistryObject<SoundEvent> BRAKE = register("coaster.brake");
    public static final RegistryObject<SoundEvent> ALARM = register("coaster.alarm");
    public static final RegistryObject<SoundEvent> MONSTER = register("abyss.monster");
    public static final RegistryObject<SoundEvent> WIND = register("coaster.wind");
    public static final RegistryObject<SoundEvent> WHEELS = register("coaster.wheels");

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(CoasterEngineering.MOD_ID, name)));
    }

    private CoasterSounds() { }
}
