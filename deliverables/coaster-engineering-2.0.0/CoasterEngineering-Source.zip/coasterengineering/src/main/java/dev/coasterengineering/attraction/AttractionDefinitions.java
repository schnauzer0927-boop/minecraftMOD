package dev.coasterengineering.attraction;

import dev.coasterengineering.CoasterEngineering;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.storage.LevelResource;

/** A world-local JSON copy is editable without recompiling the MOD. Invalid edits fall back safely. */
public final class AttractionDefinitions {
    public static final String RESOURCE = "/data/coasterengineering/attractions/volcanic_abyss_v2.json";
    public static Path worldPath(ServerLevel level) {
        return level.getServer().getWorldPath(LevelResource.ROOT).resolve("coasterengineering/attractions/volcanic_abyss_v2.json");
    }
    public static AttractionDefinition bundled() {
        try (var input = AttractionDefinitions.class.getResourceAsStream(RESOURCE)) {
            if (input == null) throw new IllegalStateException("Bundled attraction script missing");
            try (Reader reader = new InputStreamReader(input, StandardCharsets.UTF_8)) { return AttractionDefinition.parse(reader); }
        } catch (IOException exception) { throw new IllegalStateException("Cannot read bundled attraction script", exception); }
    }
    public static void installEditableCopy(ServerLevel level) {
        Path path = worldPath(level);
        if (Files.exists(path)) return;
        try (var input = AttractionDefinitions.class.getResourceAsStream(RESOURCE)) {
            if (input == null) throw new IOException("Bundled script missing");
            Files.createDirectories(path.getParent()); Files.copy(input, path);
        } catch (IOException exception) {
            CoasterEngineering.LOGGER.warn("Attraction JSON remains bundled: {}", exception.getMessage());
        }
    }
    public static AttractionDefinition load(ServerLevel level) {
        Path path = worldPath(level);
        if (Files.isRegularFile(path)) {
            try {
                if (Files.size(path) > 262144) throw new IOException("Script exceeds 256 KiB");
                try (Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) { return AttractionDefinition.parse(reader); }
            } catch (IOException | RuntimeException invalid) {
                CoasterEngineering.LOGGER.warn("Invalid attraction JSON {}; using bundled script: {}", path, invalid.getMessage());
            }
        }
        return bundled();
    }
    private AttractionDefinitions() { }
}
