package dev.coasterengineering.world;

import dev.coasterengineering.registry.CoasterRegistries;
import dev.coasterengineering.track.TrackFrame;
import dev.coasterengineering.track.TrackSample;
import dev.coasterengineering.track.TrackVec3;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Four original landmarks, designed for the view from the train rather than a tiled corridor. */
public final class VolcanicV2Scenery {
    private final VolcanicV2Geometry geometry;
    private final LinkedHashMap<BlockPos,BlockState> blocks = new LinkedHashMap<>();
    private VolcanicV2Scenery(VolcanicV2Geometry geometry) { this.geometry = geometry; }

    public static Map<BlockPos,BlockState> decorations(VolcanicV2Geometry geometry) {
        VolcanicV2Scenery p = new VolcanicV2Scenery(geometry);
        p.areaTransitions(); p.lake(); p.city(); p.nest(); p.heart(); p.station(); p.trackSupports();
        return p.blocks;
    }

    private void areaTransitions() {
        // Overlapping giant ellipsoids used to merge three differently themed
        // scenes into a single 200-block view. A five-block geological ridge
        // and ruined city gate distinguish those scenes. Exact continuous
        // rail-radius portals stay open; a car or upright rider is never used
        // as an excuse to place a temporary obstruction on the route.
        for(int z=38;z<=42;z++)for(int y=76;y<=164;y++)for(int x=-178;x<=148;x++) {
            BlockPos p=new BlockPos(x,y,z);int index=VolcanicV2Geometry.index(p);
            if(!VolcanicV2Geometry.enclosesRoom(x,y,z)||geometry.tunnelAir.get(index)||geometry.isProtected(p))continue;
            int noise=hash(x,y,z);
            BlockState state;
            if(x<0||y>139)state=(noise%7==0?Blocks.TUFF:noise%3==0?Blocks.BASALT:Blocks.DEEPSLATE).defaultBlockState();
            else if(x%17==0||y==105||y==126)state=Blocks.CHISELED_STONE_BRICKS.defaultBlockState();
            else state=(noise%5<2?Blocks.CRACKED_STONE_BRICKS:Blocks.STONE_BRICKS).defaultBlockState();
            put(x,y,z,state);
        }
        // Accent the lake-facing geological facets, and the single ride gate
        // into the fossil chamber. The ridge retains a long lake/city vista.
        for(int x:new int[]{-105,-71,-35}) {
            put(x,92,37,Blocks.AMETHYST_BLOCK.defaultBlockState());
            light(new TrackVec3(x,94,36),12);
        }
        for(int x:new int[]{103,119})for(int y=93;y<=105;y++)put(x,y,37,Blocks.DEEPSLATE_BRICKS.defaultBlockState());
        for(int x=103;x<=119;x++)put(x,106,37,Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
        light(new TrackVec3(111,104,36),13);
    }

    public static Map<BlockPos,BlockState> lighting(VolcanicV2Geometry geometry) {
        VolcanicV2Scenery p = new VolcanicV2Scenery(geometry);
        for(double d=0;d<geometry.track.length();d+=2) {
            TrackSample s=geometry.track.sample(d); TrackFrame f=TrackFrame.from(s); TrackVec3 a=s.position();
            // Multiple candidate normals remain effective on steep drops and
            // banks; protected body/upright-rider cells are always excluded.
            p.light(a.add(f.up().scale(4)),14);
            p.light(a.add(new TrackVec3(0,3.8,0)),14);
            for(int sign:new int[]{-1,1}) {
                p.light(a.add(f.right().scale(sign*4.3)).add(f.up().scale(1.4)),14);
                p.light(a.add(f.right().scale(sign*3.9)).add(new TrackVec3(0,2.8,0)),14);
            }
            if(d%6<2 && d>=geometry.track.controlPointDistance(13) && d<geometry.track.controlPointDistance(24)) {
                TrackVec3 guide=a.add(f.right().scale(4.8)).add(f.up().scale(-.25));
                p.put(guide,Blocks.OCHRE_FROGLIGHT.defaultBlockState());
                p.put(guide.add(f.up()),Blocks.ORANGE_STAINED_GLASS.defaultBlockState());
            }
            if(d%6<2 && d>=geometry.track.controlPointDistance(42) && d<geometry.track.controlPointDistance(55)) {
                TrackVec3 guide=a.add(f.right().scale(-4.8)).add(f.up().scale(-.25));
                p.put(guide,Blocks.SEA_LANTERN.defaultBlockState());
                p.put(guide.add(f.up()),Blocks.CYAN_STAINED_GLASS.defaultBlockState());
            }
        }
        // Sparse concealed fill reveals the surfaces of enormous chambers;
        // the remaining rock recesses stay darker than the landmarks.
        for(double[] r:VolcanicV2Geometry.ROOMS)
            for(int y=82;y<r[1]+r[4]-3;y+=9) for(int z=(int)(r[2]-r[5]+8);z<r[2]+r[5]-8;z+=10)
                for(int x=(int)(r[0]-r[3]+8);x<r[0]+r[3]-8;x+=10)
                    if(VolcanicV2Geometry.roomValue(r,x,y,z)<.93) p.light(new TrackVec3(x,y,z),12);
        for(int z=-202;z<=-145;z+=4) for(int x=-19;x<=4;x+=6) p.light(new TrackVec3(x,101,z),14);
        return p.blocks;
    }

    private void lake() {
        BlockState floor=Blocks.PRISMARINE_BRICKS.defaultBlockState(), glass=Blocks.CYAN_STAINED_GLASS.defaultBlockState();
        for(int z=-87;z<=22;z++) for(int x=-135;x<=-35;x++) {
            double u=(x+85)/45.0,v=(z+30)/51.0;
            double value=u*u+v*v+.035*Math.sin(x*.4+z*.31);
            if(value<1) {
                put(x,75,z,floor);
                put(x,76,z,value>.89?glass:Blocks.WATER.defaultBlockState());
                if(value<.89 && Math.floorMod(x*37+z*13,89)==0) put(x,75,z,Blocks.SEA_LANTERN.defaultBlockState());
            }
        }
        containPool(Blocks.WATER.defaultBlockState(),glass);
        int[][] clusters={{-131,-61,20},{-115,-17,27},{-86,9,23},{-46,-5,30},{-43,-45,21},{-68,-82,26},{-116,-83,18},{-100,-38,32}};
        for(int i=0;i<clusters.length;i++) {
            int[] q=clusters[i]; crystal(q[0],77,q[1],q[2],3,i);
            crystal(q[0]+5,77,q[1]+3,q[2]/2,2,i+1);
            crystal(q[0]-4,77,q[1]+4,q[2]/3,2,i+2);
        }
        // A genuine water column contained by stained-glass sides; the glass
        // containment keeps fluid ticks away from the railway corridor.
        containedFall(-137,77,-13,110,Blocks.WATER.defaultBlockState(),glass);
        containedFall(-52,77,-90,105,Blocks.WATER.defaultBlockState(),glass);
        for(int a=0;a<36;a++) {
            double angle=a*Math.PI*2/36; int x=-85+(int)(Math.cos(angle)*58),z=-30+(int)(Math.sin(angle)*66);
            for(int y=76;y<80+Math.floorMod(a*7,7);y++) put(x,y,z,Blocks.CALCITE.defaultBlockState());
            if(a%3==0) put(x,81,z,Blocks.AMETHYST_BLOCK.defaultBlockState());
        }
    }

    private void crystal(int x,int y,int z,int height,int radius,int variant) {
        for(int h=0;h<height;h++) {
            int width=Math.max(0,(int)Math.floor(radius*(1-h/(double)height)));
            int bend=h/12*(variant%3-1);
            for(int dx=-width;dx<=width;dx++) for(int dz=-width;dz<=width;dz++) if(Math.abs(dx)+Math.abs(dz)<=width+1) {
                BlockState b=dx==0&&dz==0?Blocks.SEA_LANTERN.defaultBlockState():
                        (variant%2==0?Blocks.LIGHT_BLUE_STAINED_GLASS:Blocks.PURPLE_STAINED_GLASS).defaultBlockState();
                put(x+dx+bend,y+h,z+dz,b);
            }
        }
    }

    private void city() {
        int[][] towers={{15,-17,7,42},{45,-70,8,55},{104,-58,7,45},{119,3,8,46},{74,38,9,43},{28,24,6,33}};
        for(int i=0;i<towers.length;i++) {
            int[] q=towers[i]; int x=q[0],z=q[1],r=q[2],height=q[3];
            for(int y=76;y<76+height;y++) for(int dx=-r;dx<=r;dx++) for(int dz=-r;dz<=r;dz++) {
                boolean edge=Math.abs(dx)==r || Math.abs(dz)==r;
                boolean window=y>84 && y%9>=2 && y%9<=5 && ((Math.abs(dx)==r&&Math.abs(dz)<=1)||(Math.abs(dz)==r&&Math.abs(dx)<=1));
                boolean broken=y>76+height-8 && hash(x+dx,y,z+dz)%9<y-(76+height-8);
                if((edge||y==76)&&!window&&!broken) {
                    BlockState b=y%9==0?Blocks.CHISELED_STONE_BRICKS.defaultBlockState():
                            (hash(x+dx,y,z+dz)%7==0?Blocks.CRACKED_STONE_BRICKS:Blocks.STONE_BRICKS).defaultBlockState();
                    put(x+dx,y,z+dz,b);
                }
                if(window&&y%9==2) put(x+dx,y,z+dz,Blocks.OCHRE_FROGLIGHT.defaultBlockState());
            }
            for(int a=0;a<4;a++) {
                int dx=a<2?-r:r,dz=a%2==0?-r:r;
                for(int y=76;y<76+height-3;y++) put(x+dx,y,z+dz,Blocks.DEEPSLATE_BRICKS.defaultBlockState());
            }
        }
        // Monumental broken aqueduct, with visible gaps between spans rather
        // than a uniform row of complete structures.
        for(int x=5;x<=111;x++) {
            if((x>=30&&x<=39)||(x>=77&&x<=85)) continue;
            for(int z=-3;z<=3;z++) put(x,99,z-35,Blocks.STONE_BRICKS.defaultBlockState());
            for(int z:new int[]{-39,-31}) put(x,100,z,Blocks.COBBLESTONE_WALL.defaultBlockState());
            if(x%21<=3) for(int y=76;y<99;y++) for(int z=-2;z<=2;z++) put(x,y,z-35,Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
        }
        // A stepped central temple and carved portal provide one clear
        // landmark among the towers, not identical modules.
        for(int step=0;step<6;step++) for(int x=44+step*2;x<=79-step*2;x++)
            for(int z=-15+step*2;z<=13-step*2;z++) put(x,76+step,z,Blocks.CUT_SANDSTONE.defaultBlockState());
        for(int x:new int[]{48,72}) for(int z:new int[]{-10,9}) for(int y=82;y<=111;y++) put(x,y,z,Blocks.QUARTZ_PILLAR.defaultBlockState());
        for(int x=45;x<=75;x++) for(int z=-12;z<=11;z++) put(x,112,z,Blocks.SMOOTH_SANDSTONE.defaultBlockState());
        for(int x=51;x<72;x+=4) put(x,111,-11,Blocks.SHROOMLIGHT.defaultBlockState());
        for(int i=0;i<90;i++) {
            int x=3+Math.floorMod(i*47,117),z=-72+Math.floorMod(i*31,120);
            int height=1+Math.floorMod(i*17,4);
            for(int h=0;h<height;h++) put(x,76+h,z,(i%3==0?Blocks.MOSSY_COBBLESTONE:Blocks.CRACKED_STONE_BRICKS).defaultBlockState());
        }
    }

    private void nest() {
        // Massive irregular rib arches; their separate lengths and yaw angles
        // make a fossil field, leaving a broad sightline toward the creature.
        for(int rib=0;rib<8;rib++) {
            double yaw=.22*(rib-3); int z=65+rib*11,x=36+(rib%3)*8;
            for(double a=.12;a<Math.PI-.1;a+=.025) {
                double side=Math.cos(a)*(24+rib%3*3),height=Math.sin(a)*(23+rib%2*5);
                int px=x+(int)(side*Math.cos(yaw)),pz=z+(int)(side*Math.sin(yaw)),py=77+(int)height;
                for(int dy=0;dy<2;dy++) for(int dz=0;dz<2;dz++) put(px,py+dy,pz+dz,Blocks.BONE_BLOCK.defaultBlockState());
            }
        }
        for(int z=102;z<=162;z++) for(int x=6;x<=60;x++) {
            double dx=(x-32)/23.0,dz=(z-132)/24.0,rr=dx*dx+dz*dz;
            if(rr>.8&&rr<1.15) for(int y=76;y<=79+hash(x,1,z)%3;y++) put(x,y,z,Blocks.SCULK.defaultBlockState());
            if(rr<.85) put(x,75,z,Blocks.SOUL_SOIL.defaultBlockState());
            if(rr<.5) {
                // The puppet's anchor is Y78. Raise its concealed lair floor
                // to that surface, so fully emerged feet meet the terrain.
                put(x,76,z,(hash(x,76,z)%4==0?Blocks.BASALT:Blocks.SOUL_SOIL).defaultBlockState());
                put(x,77,z,(hash(x,77,z)%7==0?Blocks.BASALT:Blocks.SOUL_SOIL).defaultBlockState());
            }
        }
        for(int i=0;i<18;i++) {
            int x=4+Math.floorMod(i*41,110),z=59+Math.floorMod(i*29,94),height=4+Math.floorMod(i*7,12);
            for(int y=76;y<76+height-1;y++) {
                int width=y<78?1:0;
                for(int dx=-width;dx<=width;dx++)for(int dz=-width;dz<=width;dz++)put(x+dx,y,z+dz,Blocks.DRIPSTONE_BLOCK.defaultBlockState());
            }
            put(x,76+height-1,z,Blocks.POINTED_DRIPSTONE.defaultBlockState());
            put(x,77,z,Blocks.SCULK_CATALYST.defaultBlockState());
        }
        // Exact event-controlled rig; lights occupy scenery space, never the
        // track. The director edits only these dedicated original cells.
        put(50,108,105,Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL,10));
        put(65,102,105,Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL,10));
        put(35,102,105,Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL,10));
        // Soft frontal keys make the head and forelimbs readable when the
        // scripted creature rises; these positions are well off the track.
        light(new TrackVec3(39,87,126),13);
        light(new TrackVec3(30,89,128),12);
    }

    private void heart() {
        for(int z=45;z<=156;z++) for(int x=-144;x<=-15;x++) {
            double a=(x+80)/57.0,b=(z-100)/51.0,rr=a*a+b*b+.045*Math.sin(x*.31+z*.29);
            if(rr<1) {
                put(x,75,z,Blocks.BLACKSTONE.defaultBlockState());
                put(x,76,z,rr>.91?Blocks.MAGMA_BLOCK.defaultBlockState():Blocks.LAVA.defaultBlockState());
            }
        }
        containPool(Blocks.LAVA.defaultBlockState(),Blocks.MAGMA_BLOCK.defaultBlockState());
        containedFall(-139,77,85,134,Blocks.LAVA.defaultBlockState(),Blocks.ORANGE_STAINED_GLASS.defaultBlockState());
        containedFall(-36,77,146,120,Blocks.LAVA.defaultBlockState(),Blocks.RED_STAINED_GLASS.defaultBlockState());
        for(int crack=0;crack<13;crack++) {
            double a=crack*Math.PI*2/13;
            int x=-80+(int)(Math.cos(a)*68),z=100+(int)(Math.sin(a)*64);
            for(int y=79;y<131+crack%4*3;y++) {
                int drift=(int)(Math.sin(y*.17+crack)*2);
                put(x+drift,y,z,Blocks.SHROOMLIGHT.defaultBlockState());
                put(x+drift+(int)Math.cos(a),y,z+(int)Math.sin(a),Blocks.ORANGE_STAINED_GLASS.defaultBlockState());
            }
        }
        for(int i=0;i<19;i++) {
            double a=i*Math.PI*2/19; int x=-80+(int)(Math.cos(a)*52),z=100+(int)(Math.sin(a)*49),height=12+i%5*4;
            for(int y=77;y<77+height;y++) for(int dx=-2;dx<=2;dx++) for(int dz=-2;dz<=2;dz++)
                if(dx*dx+dz*dz<7) put(x+dx,y,z+dz,Blocks.BASALT.defaultBlockState());
            put(x,77+height,z,Blocks.MAGMA_BLOCK.defaultBlockState());
        }
    }

    private void containedFall(int x,int floor,int z,int top,BlockState fluid,BlockState glass) {
        for(int y=floor;y<=top;y++) for(int dx=-2;dx<=2;dx++) for(int dz=-2;dz<=2;dz++) {
            boolean side=Math.abs(dx)==2||Math.abs(dz)==2;
            put(x+dx,y,z+dz,(side||y==floor||y==top)?glass:fluid);
        }
    }

    private void containPool(BlockState fluid,BlockState rim) {
        var cells=new java.util.ArrayList<>(blocks.entrySet());
        for(var cell:cells) if(cell.getKey().getY()==76&&cell.getValue().is(fluid.getBlock())) {
            BlockPos p=cell.getKey();
            for(BlockPos neighbor:new BlockPos[]{p.north(),p.south(),p.east(),p.west()}) {
                BlockState current=blocks.get(neighbor);
                if(current==null)put(neighbor.getX(),76,neighbor.getZ(),rim);
            }
        }
    }

    private void station() {
        // The tall return turn reaches a low part of the outer volcano. A
        // complete independent lab shell keeps carving from opening its roof
        // to outside grass. Track portals are removed only by the swept mask.
        for(int z=-208;z<=-140;z++)for(int x=-22;x<=19;x++) {
            put(x,93,z,Blocks.POLISHED_DEEPSLATE.defaultBlockState());
            put(x,113,z,Blocks.BLACK_CONCRETE.defaultBlockState());
        }
        for(int z=-208;z<=-140;z++)for(int y=94;y<=112;y++)for(int x:new int[]{-22,19})
            put(x,y,z,(y>=99&&y<=104?Blocks.CYAN_STAINED_GLASS:Blocks.DEEPSLATE_TILES).defaultBlockState());
        for(int x=-22;x<=19;x++)for(int y=94;y<=112;y++)for(int z:new int[]{-208,-140})
            put(x,y,z,Blocks.DEEPSLATE_TILES.defaultBlockState());
        for(int z=-201;z<=-145;z++) {
            for(int x=-21;x<=-2;x++) put(x,93,z,Blocks.POLISHED_DEEPSLATE.defaultBlockState());
            for(int y=94;y<=105;y++) {
                put(-22,y,z,(y>=97&&y<=100?Blocks.CYAN_STAINED_GLASS:Blocks.DEEPSLATE_TILES).defaultBlockState());
                if(z%8==0) put(7,y,z,Blocks.POLISHED_BLACKSTONE.defaultBlockState());
            }
            for(int x=-22;x<=7;x++) put(x,106,z,Blocks.BLACK_CONCRETE.defaultBlockState());
            if(z%6==0) { put(-20,104,z,Blocks.SEA_LANTERN.defaultBlockState()); put(5,104,z,Blocks.SEA_LANTERN.defaultBlockState()); }
            if(z<-170||z>-157) put(-2,94,z,Blocks.IRON_BARS.defaultBlockState());
            put(-3,93,z,Blocks.YELLOW_CONCRETE.defaultBlockState());
        }
        for(int z=-195;z<=-147;z++) if(z<-174||z>-163) put(-12,94,z,Blocks.IRON_BARS.defaultBlockState());
        for(int x=-22;x<=-2;x++) for(int y=94;y<=105;y++) {
            put(x,y,-202,Blocks.DEEPSLATE_TILES.defaultBlockState());
            if(x<-12||x>-8) put(x,y,-144,Blocks.DEEPSLATE_TILES.defaultBlockState());
        }
        for(int x=-18;x<=-15;x++)for(int y=95;y<=98;y++)put(x,y,-144,Blocks.IRON_BARS.defaultBlockState());
        for(int y=96;y<=104;y++) {
            put(-14,y,-157,Blocks.BLACK_CONCRETE.defaultBlockState());
            put(-14,y,-156,Blocks.SEA_LANTERN.defaultBlockState());
        }
        put(-6,94,-165,CoasterRegistries.STATION_CONTROLLER.get().defaultBlockState());
        // Original CE research emblem on the lab wall.
        String[] emblem={"1110111","1000100","1000111","1000100","1110111"};
        for(int row=0;row<5;row++) for(int x=0;x<7;x++) if(emblem[row].charAt(x)=='1') put(-21,102-row,-180+x,Blocks.SEA_LANTERN.defaultBlockState());
    }

    private void trackSupports() {
        for(double d=0;d<geometry.track.length();d+=12) {
            TrackVec3 p=geometry.track.sample(d).position();
            int x=(int)Math.floor(p.x()),z=(int)Math.floor(p.z());
            for(int y=76;y<(int)Math.floor(p.y())-1;y++) put(x,y,z,CoasterRegistries.SUPPORT_BEAM.get().defaultBlockState());
        }
        geometry.track.points().forEach(point -> {
            var kind=point.kind(); var block=switch(kind) {
                case NORMAL -> CoasterRegistries.RAIL.get(); case BOOST -> CoasterRegistries.BOOST_RAIL.get();
                case BRAKE -> CoasterRegistries.BRAKE_RAIL.get(); case LIFT -> CoasterRegistries.LIFT_RAIL.get();
                case STATION -> CoasterRegistries.STATION_RAIL.get();
            };
            BlockPos pos=BlockPos.containing(point.position().x(),point.position().y(),point.position().z());
            // Rail block markers are non-colliding registered rail geometry.
            blocks.put(pos,block.defaultBlockState());
        });
    }

    private void light(TrackVec3 p,int level) { put(p,Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL,level)); }
    private void put(TrackVec3 p,BlockState b) { put((int)Math.floor(p.x()),(int)Math.floor(p.y()),(int)Math.floor(p.z()),b); }
    private void put(int x,int y,int z,BlockState b) {
        BlockPos p=new BlockPos(x,y,z);
        BlockState existing=blocks.get(p);
        if(b.is(Blocks.LIGHT)&&existing!=null&&existing.is(Blocks.LIGHT)&&existing.getValue(LightBlock.LEVEL)>b.getValue(LightBlock.LEVEL))return;
        if(VolcanicV2Geometry.index(p)>=0&&!geometry.isProtected(p)) blocks.put(p,b);
    }
    private static int hash(int x,int y,int z) { long h=x*341873128712L^y*132897987541L^z*42317861L^20261012L;h^=h>>>29;return (int)Math.floorMod(h,1000); }
}
