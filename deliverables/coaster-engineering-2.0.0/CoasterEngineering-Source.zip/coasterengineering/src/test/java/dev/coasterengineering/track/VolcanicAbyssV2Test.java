package dev.coasterengineering.track;

import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class VolcanicAbyssV2Test {
    @Test
    void theV2RouteRunsAtRealDistanceWithTwoTimedShowsAndReturnsInTheDesignWindow() {
        Simulation result = simulate(.025);
        System.out.printf("V2 measured: length=%.6f, ticks=%d, travel=%.2fs, peak=%.3fkm/h, "
                        + "max tangent rotation=%.3fdeg/tick, estimated curvature acceleration=%.3fG%n",
                result.length, result.ticks, result.ticks / 20.0, result.peak * 72,
                result.maximumAngularDegrees, result.maximumCentripetalG);
        assertTrue(result.completed);
        assertEquals(result.length, result.actualDistance, 1e-7);
        assertTrue(result.ticks >= 3000 && result.ticks <= 3600);
        assertEquals(Set.of("monster_pause", "precipice_pause"), result.completedStops);
        assertEquals(95, result.holdTicks);
        assertTrue(result.peak * 72 >= 110 && result.peak * 72 <= 120);
        assertTrue(result.maximumAngularDegrees < 5);
        assertTrue(result.maximumCentripetalG < 3);
        assertTrue(result.maximumStopEntrySpeed < .035, "Timed show clamp must follow a crawl-speed approach");
    }

    @Test
    void geometryFitsTheBuildEnvelopeAndIncludesADropWithoutInversions() {
        SplineTrack track = VolcanicAbyssV2.create(TrackVec3.ZERO);
        double low = Double.POSITIVE_INFINITY, high = Double.NEGATIVE_INFINITY, steepest = 0;
        for (double d = 0; d < track.length(); d += .25) {
            TrackSample sample = track.sample(d);
            assertTrue(Math.abs(sample.position().x()) <= 205);
            assertTrue(Math.abs(sample.position().z()) <= 205);
            assertTrue(sample.position().y() >= 72 && sample.position().y() <= 170);
            assertTrue(Math.abs(sample.bankDegrees()) <= 45);
            assertTrue(Math.abs(sample.tangent().y()) < .9, "Shipping route has no vertical inversion");
            assertTrue(TrackFrame.from(sample).up().y() > 0);
            low = Math.min(low, sample.position().y()); high = Math.max(high, sample.position().y());
            steepest = Math.max(steepest, Math.abs(sample.tangent().y()));
        }
        assertTrue(high - low >= 80);
        assertTrue(steepest > .75);
    }

    @Test
    void parkedThreeCarTrainHasExactlyMatchingHorizontalSeatsAndStraightTrack() {
        SplineTrack track = VolcanicAbyssV2.create(TrackVec3.ZERO);
        for (int index = 0; index < 3; index++) {
            TrackSample sample = track.sample(TrainSpacing.distance(track, 0, index, 4));
            assertEquals(0, sample.position().x(), 1e-10);
            assertEquals(94, sample.position().y(), 1e-10);
            assertEquals(-165 - index * 4, sample.position().z(), .0005);
            assertEquals(1, sample.tangent().z(), 1e-10);
            assertEquals(0, sample.bankDegrees(), 1e-10);
        }
    }

    @Test
    void nonAdjacentCourseSectionsDoNotOverlapInSampledGeometry() {
        SplineTrack track = VolcanicAbyssV2.create(TrackVec3.ZERO);
        int count = (int) Math.ceil(track.length() / 2);
        double interval = track.length() / count;
        TrackVec3[] positions = new TrackVec3[count];
        for (int i = 0; i < count; i++) positions[i] = track.sample(i * interval).position();
        double minimum = Double.POSITIVE_INFINITY;
        for (int i = 0; i < count; i++) for (int j = i + 1; j < count; j++) {
            double separation = (j - i) * interval;
            if (Math.min(separation, track.length() - separation) <= 18) continue;
            minimum = Math.min(minimum, positions[i].subtract(positions[j]).length());
        }
        assertTrue(minimum > 6, "Sampled route separation is independent of actual block clearance");
    }

    @Test
    void curveExitAccelerationProtectsAllFourLinkedCarsThroughTheStationSeam() {
        SplineTrack track = VolcanicAbyssV2.create(TrackVec3.ZERO);
        Set<String> completed = new HashSet<>();
        double distance = 0, speed = 0, maximumYaw = 0, maximumFrame = 0, maximumG = 0;
        int hold = 0;
        boolean finished = false;
        for (int tick = 0; tick < 12000; tick++) {
            if (hold > 0) { hold--; continue; }
            RideDynamics.Step step = RideDynamics.advanceProfiled(track, distance, speed, true,
                    RideDynamics.MAX_SUPPORTED_SPEED, .025, VolcanicAbyssV2.profile(track, completed));
            double next = step.crossedFinish() ? track.length() : step.distance();
            for (VolcanicAbyssV2.Stop stop : VolcanicAbyssV2.showStops(track)) {
                if (!completed.contains(stop.id()) && distance <= stop.distance() && next >= stop.distance()) {
                    next = stop.distance(); hold = stop.durationTicks(); completed.add(stop.id());
                    step = new RideDynamics.Step(next, 0, false, true); break;
                }
            }
            for (int car = 0; car < 4; car++) {
                TrackSample before = track.sample(distance - 4 * car), after = track.sample(next - 4 * car);
                double yawDelta = Math.toDegrees(Math.atan2(-after.tangent().x(), after.tangent().z())
                        - Math.atan2(-before.tangent().x(), before.tangent().z()));
                yawDelta = (yawDelta + 540) % 360 - 180;
                maximumYaw = Math.max(maximumYaw, Math.abs(yawDelta));
                TrackFrame a = TrackFrame.from(before), b = TrackFrame.from(after);
                double trace = a.right().dot(b.right()) + a.up().dot(b.up()) + a.forward().dot(b.forward());
                maximumFrame = Math.max(maximumFrame, Math.toDegrees(Math.acos(Math.max(-1,
                        Math.min(1, (trace - 1) / 2)))));
                double curvature = track.sample(distance - 4 * car + .1).tangent()
                        .subtract(track.sample(distance - 4 * car - .1).tangent()).length() / .2;
                maximumG = Math.max(maximumG, speed * speed * curvature * 400 / 9.81);
            }
            distance = step.distance(); speed = step.speed();
            if (step.crossedFinish()) { finished = true; break; }
        }
        assertTrue(finished);
        assertTrue(maximumYaw < 5, "Followers must remain protected when the leader has left a sharp curve");
        assertTrue(maximumFrame < 5, "Pitch and bank are included in the total pose change");
        assertTrue(maximumG < 3, "Estimated centripetal force is checked for every linked car");
        System.out.printf("Four-car formation: max yaw=%.6fdeg/tick, frame rotation=%.6fdeg/tick, "
                        + "estimated curvature acceleration=%.6fG%n", maximumYaw, maximumFrame, maximumG);
    }

    @Test
    void completedShowsReleaseTheBrakeEnvelopeAndDoNotMoveTheStopPoint() {
        SplineTrack track = VolcanicAbyssV2.create(TrackVec3.ZERO);
        for (VolcanicAbyssV2.Stop stop : VolcanicAbyssV2.showStops(track)) {
            assertEquals(.025, VolcanicAbyssV2.profile(track).targetSpeed(stop.distance()), 1e-12);
            assertTrue(VolcanicAbyssV2.profile(track, Set.of(stop.id())).targetSpeed(stop.distance()) > .25);
        }
        assertSame(VolcanicAbyssV2.profile(track), VolcanicAbyssV2.profile(track, Set.of()));
    }

    @Test
    void bothShowsLaunchImmediatelyWithMeasuredMovementAfterTheirHolds() {
        SplineTrack track = VolcanicAbyssV2.create(TrackVec3.ZERO);
        for (VolcanicAbyssV2.Stop stop : VolcanicAbyssV2.showStops(track)) {
            VolcanicAbyssV2.Profile released = VolcanicAbyssV2.profile(track, Set.of(stop.id()));
            RideDynamics.Step state = new RideDynamics.Step(stop.distance(), 0, false, true);
            for (int tick = 0; tick < 20; tick++) {
                state = RideDynamics.advanceProfiled(track, state.distance(), state.speed(), true,
                        RideDynamics.MAX_SUPPORTED_SPEED, .025, released);
            }
            assertTrue(state.speed() >= .45, "Show release should produce real acceleration within one second");
            assertTrue(state.distance() - stop.distance() >= 4.5,
                    "Launch should move the train, not only change its displayed speed");
            System.out.printf("Released show %s: 20ticks, %.6f blocks moved, %.6f km/h%n",
                    stop.id(), state.distance() - stop.distance(), state.speed() * 72);
        }
    }

    @Test
    void immediateEscapeUsesEditedNextPointAndConfiguredEscapeDriveLimits() {
        SplineTrack original = VolcanicAbyssV2.create(TrackVec3.ZERO);
        List<ControlPoint> points = new ArrayList<>(original.points());
        ControlPoint next = points.get(26);
        points.set(26, new ControlPoint(next.position(), next.bankDegrees(), next.kind(), .9));
        SplineTrack track = new SplineTrack(points, true);
        List<VolcanicAbyssV2.SegmentSettings> settings = new ArrayList<>(VolcanicAbyssV2.defaultSegments());
        settings.set(VolcanicAbyssV2.Stage.ESCAPE_MONSTER.ordinal(), new VolcanicAbyssV2.SegmentSettings(
                VolcanicAbyssV2.Stage.ESCAPE_MONSTER, .007, .018, .5));
        VolcanicAbyssV2.Profile released = VolcanicAbyssV2.profile(track, Set.of("monster_pause"), settings);
        double stopDistance = VolcanicAbyssV2.showStops(track).get(0).distance();
        assertEquals(.45, released.rawTargetSpeed(stopDistance), 1e-12);
        assertEquals(.007, released.maximumAcceleration(stopDistance), 1e-12);
        assertEquals(.018, released.maximumBraking(stopDistance), 1e-12);
        RideDynamics.Step state = new RideDynamics.Step(stopDistance, 0, false, true);
        for (int tick = 0; tick < 20; tick++) {
            state = RideDynamics.advanceProfiled(track, state.distance(), state.speed(), true,
                    RideDynamics.MAX_SUPPORTED_SPEED, .025, released);
        }
        assertEquals(.14, state.speed(), 1e-10);
        assertEquals(1.4, state.distance() - stopDistance, 1e-8);
    }

    @Test
    void editedSavedNodeSpeedsAndJsonSectionLimitsAffectTheActualMotionProfile() {
        SplineTrack original = VolcanicAbyssV2.create(TrackVec3.ZERO);
        List<ControlPoint> points = new ArrayList<>(original.points());
        ControlPoint old = points.get(5);
        points.set(5, new ControlPoint(old.position(), old.bankDegrees(), old.kind(), .25));
        SplineTrack edited = new SplineTrack(points, true);
        double at = edited.controlPointDistance(5);
        assertEquals(.25, VolcanicAbyssV2.profile(edited).rawTargetSpeed(at), 1e-12);
        List<VolcanicAbyssV2.SegmentSettings> settings = new ArrayList<>(VolcanicAbyssV2.defaultSegments());
        settings.set(0, new VolcanicAbyssV2.SegmentSettings(VolcanicAbyssV2.Stage.EXPLORE, .006, .015, .5));
        VolcanicAbyssV2.Profile custom = VolcanicAbyssV2.profile(edited, Set.of(), settings);
        assertEquals(.125, custom.rawTargetSpeed(at), 1e-12);
        assertEquals(.006, custom.maximumAcceleration(at), 1e-12);
        assertEquals(.015, custom.maximumBraking(at), 1e-12);
        assertSame(custom, VolcanicAbyssV2.profile(edited, Set.of(), List.copyOf(settings)));
    }

    @Test
    void invalidSectionLimitsAreRejectedBeforeIntegration() {
        assertThrows(IllegalArgumentException.class, () -> new VolcanicAbyssV2.SegmentSettings(
                VolcanicAbyssV2.Stage.EXPLORE, .026, .02, 1));
        assertThrows(IllegalArgumentException.class, () -> new VolcanicAbyssV2.SegmentSettings(
                VolcanicAbyssV2.Stage.EXPLORE, .01, .036, 1));
        assertThrows(IllegalArgumentException.class, () -> new VolcanicAbyssV2.SegmentSettings(
                VolcanicAbyssV2.Stage.EXPLORE, .01, .02, Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> VolcanicAbyssV2.profile(
                VolcanicAbyssV2.create(TrackVec3.ZERO), Set.of(), List.of()));
    }

    @Test
    void segmentAccelerationChangesAreContinuousAtNarrativeBoundaries() {
        SplineTrack track = VolcanicAbyssV2.create(TrackVec3.ZERO);
        VolcanicAbyssV2.Profile profile = VolcanicAbyssV2.profile(track);
        for (VolcanicAbyssV2.Stage stage : VolcanicAbyssV2.Stage.values()) {
            double boundary = profile.stageStart(stage);
            assertTrue(Math.abs(profile.maximumAcceleration(boundary - .01)
                    - profile.maximumAcceleration(boundary + .01)) < .00005);
        }
    }

    @Test
    void reducedComfortAccelerationCompletesWithoutStrandingAtEitherShow() {
        Simulation result = simulate(.006);
        assertTrue(result.completed);
        assertEquals(2, result.completedStops.size());
        assertTrue(result.ticks < 6000);
    }

    @Test
    void independentTransportDiagnosticRemainsContinuousAndInvertsOnAVerticalLoop() {
        List<ControlPoint> loop = new ArrayList<>();
        for (int i = 0; i < 32; i++) {
            double theta = 2 * Math.PI * i / 32;
            loop.add(new ControlPoint(new TrackVec3(0, 130 + 30 * Math.sin(theta),
                    30 * Math.cos(theta)), 0, RailKind.BOOST, .8));
        }
        SplineTrack track = new SplineTrack(loop, true);
        List<TrackFrame> frames = ParallelTransportFrameDiagnostic.frames(track, .25);
        double minimumUpY = 1;
        for (int i = 0; i < frames.size(); i++) {
            TrackFrame frame = frames.get(i); minimumUpY = Math.min(minimumUpY, frame.up().y());
            if (i > 0) {
                assertTrue(frame.up().dot(frames.get(i - 1).up()) > .999);
                assertTrue(frame.right().dot(frames.get(i - 1).right()) > .999);
            }
        }
        assertTrue(minimumUpY < -.99);
        assertTrue(frames.get(0).up().dot(frames.get(frames.size() - 1).up()) > .999999);
        double legacyAdjacentRightDot = 1;
        TrackFrame previous = null;
        int count = (int) Math.ceil(track.length() / .25);
        for (int i = 0; i <= count; i++) {
            TrackFrame legacy = TrackFrame.from(track.sample(track.length() * i / count));
            if (previous != null) legacyAdjacentRightDot = Math.min(legacyAdjacentRightDot,
                    previous.right().dot(legacy.right()));
            previous = legacy;
        }
        assertTrue(legacyAdjacentRightDot < -.99,
                "Existing world-up frame reverses at vertical tangents and cannot certify inverted vehicles");
        System.out.printf("Vertical-loop math diagnostic: transported up reaches %.6f; "
                        + "legacy adjacent right dot=%.6f (inverted vehicle runtime not implemented)%n",
                minimumUpY, legacyAdjacentRightDot);
        // This deliberately certifies mathematics only, not Entity/render/camera inversions.
    }

    @Test
    void v2IdentityAndStageBoundariesAreIndependentFromTheExistingWorld() {
        assertEquals(UUID.fromString("fd0fb037-a161-3b04-931f-de6e3c3a422e"), VolcanicAbyssV2.COURSE_ID);
        SplineTrack track = VolcanicAbyssV2.create(TrackVec3.ZERO);
        for (VolcanicAbyssV2.Stage stage : VolcanicAbyssV2.Stage.values()) {
            assertEquals(stage, VolcanicAbyssV2.stageAt(track, VolcanicAbyssV2.stageStart(track, stage)));
        }
        assertFalse(VolcanicAbyssV2.outdoor(track, 0));
        assertTrue(VolcanicAbyssV2.outdoor(track, track.controlPointDistance(43)));
        assertFalse(VolcanicAbyssV2.outdoor(track, track.controlPointDistance(56)));
        assertThrows(IllegalArgumentException.class, () -> VolcanicAbyssV2.profile(
                VolcanicCourseDesign.create(TrackVec3.ZERO)));
    }

    private static Simulation simulate(double acceleration) {
        SplineTrack track = VolcanicAbyssV2.create(TrackVec3.ZERO);
        Set<String> completed = new HashSet<>();
        double distance = 0, speed = 0, traveled = 0, peak = 0, angle = 0, g = 0, stopSpeed = 0;
        int holds = 0, remainingHold = 0;
        for (int tick = 1; tick <= 12000; tick++) {
            if (remainingHold > 0) { remainingHold--; holds++; continue; }
            TrackSample before = track.sample(distance);
            RideDynamics.Step step = RideDynamics.advanceProfiled(track, distance, speed, true,
                    RideDynamics.MAX_SUPPORTED_SPEED, acceleration, VolcanicAbyssV2.profile(track, completed));
            double next = step.crossedFinish() ? track.length() : step.distance();
            for (VolcanicAbyssV2.Stop stop : VolcanicAbyssV2.showStops(track)) {
                if (!completed.contains(stop.id()) && distance <= stop.distance() && next >= stop.distance()) {
                    stopSpeed = Math.max(stopSpeed, step.speed());
                    next = stop.distance(); remainingHold = stop.durationTicks(); completed.add(stop.id());
                    step = new RideDynamics.Step(next, 0, false, true); break;
                }
            }
            traveled += next - distance;
            TrackSample after = track.sample(next);
            angle = Math.max(angle, Math.toDegrees(Math.acos(Math.max(-1, Math.min(1,
                    before.tangent().dot(after.tangent()))))));
            double curvature = track.sample(distance + .1).tangent()
                    .subtract(track.sample(distance - .1).tangent()).length() / .2;
            g = Math.max(g, speed * speed * curvature * 400 / 9.81);
            peak = Math.max(peak, step.speed()); distance = step.distance(); speed = step.speed();
            if (step.crossedFinish()) return new Simulation(track.length(), traveled, tick, true,
                    peak, angle, g, stopSpeed, holds, Set.copyOf(completed));
            assertTrue(!step.stopped() || remainingHold > 0, "Train stalled before its station");
        }
        return new Simulation(track.length(), traveled, 12000, false, peak, angle, g, stopSpeed,
                holds, Set.copyOf(completed));
    }

    private record Simulation(double length, double actualDistance, int ticks, boolean completed,
                              double peak, double maximumAngularDegrees, double maximumCentripetalG,
                              double maximumStopEntrySpeed, int holdTicks, Set<String> completedStops) { }
}
