package dev.coasterengineering.attraction;

import static org.junit.jupiter.api.Assertions.*;
import com.google.gson.JsonObject;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import org.junit.jupiter.api.Test;

class AttractionTimelineTest {
    private static AttractionDefinition.EventSpec event(String id, double distance, int delay, boolean repeat) {
        return new AttractionDefinition.EventSpec(id, new AttractionDefinition.Trigger(null, distance),
                AttractionDefinition.Condition.ALWAYS, delay, AttractionDefinition.EventType.ALARM, repeat, new JsonObject());
    }
    private static AttractionDefinition definition(AttractionDefinition.EventSpec... events) {
        return new AttractionDefinition("test", 1, List.of(new AttractionDefinition.Stage("start",
                new AttractionDefinition.Trigger(null, 0.), "exploration", 1)), List.of(events), List.of(), List.of());
    }
    private static AttractionTimeline timeline(AttractionDefinition definition) { return new AttractionTimeline(definition, trigger -> trigger.distance()); }

    @Test void crossingAFastIntervalFiresEveryPassedEventInPositionOrderExactlyOnce() {
        var timeline = timeline(definition(event("later", 12, 0, true), event("earlier", 8, 0, true)));
        List<String> fired = new ArrayList<>(); timeline.dispatch(0, 0, e -> true, e -> fired.add(e.id()));
        timeline.cross(4, 14, 0, 0, 100, e -> true, e -> fired.add(e.id()));
        timeline.cross(14, 15, 0, 0, 100, e -> true, e -> fired.add(e.id()));
        assertEquals(List.of("earlier", "later"), fired);
        assertEquals(1, timeline.executionCount("earlier"));
    }
    @Test void delayCountsServerTicksAndDoesNotFireBeforeItsDeadline() {
        var timeline = timeline(definition(event("delayed", 5, 3, true)));
        List<String> fired = new ArrayList<>(); timeline.dispatch(0, 0, e -> true, e -> fired.add(e.id()));
        timeline.cross(4, 5, 0, 0, 100, e -> true, e -> fired.add(e.id()));
        timeline.tick(e -> fired.add(e.id())); timeline.tick(e -> fired.add(e.id())); assertTrue(fired.isEmpty());
        timeline.tick(e -> fired.add(e.id())); assertEquals(List.of("delayed"), fired);
        timeline.tick(e -> fired.add(e.id())); assertEquals(1, fired.size());
    }
    @Test void wrapProcessesFinalIntervalThenArrivalCancelsUnfulfilledDelayedCues() {
        var timeline = timeline(definition(event("end", 99, 0, true), event("pending", 98, 20, true)));
        List<String> fired = new ArrayList<>(); timeline.dispatch(0, 0, e -> true, e -> fired.add(e.id()));
        timeline.cross(97, 0, 0, 1, 100, e -> true, e -> fired.add(e.id())); timeline.arrive();
        for (int i = 0; i < 30; i++) timeline.tick(e -> fired.add(e.id()));
        assertEquals(List.of("end"), fired); assertFalse(timeline.active());
    }
    @Test void newDispatchRepeatsReusableCueButDoesNotRepeatOnceEverCue() {
        var timeline = timeline(definition(event("repeat", 5, 0, true), event("once", 5, 0, false)));
        List<String> fired = new ArrayList<>();
        for (int lap = 0; lap < 2; lap++) {
            timeline.dispatch(lap, 0, e -> true, e -> fired.add(e.id()));
            timeline.cross(0, 8, lap, lap, 100, e -> true, e -> fired.add(e.id())); timeline.arrive();
        }
        assertEquals(2, timeline.executionCount("repeat")); assertEquals(1, timeline.executionCount("once"));
    }
    @Test void failedCosmeticIsRecordedOnceAndDoesNotSuppressLaterCue() {
        var timeline = timeline(definition(event("broken", 5, 0, true), event("okay", 6, 0, true)));
        List<String> fired = new ArrayList<>(); timeline.dispatch(0, 0, e -> true, e -> {});
        assertDoesNotThrow(() -> timeline.cross(0, 8, 0, 0, 100, e -> true, e -> {
            if (e.id().equals("broken")) throw new IllegalStateException("missing presentation"); fired.add(e.id());
        }));
        assertEquals(List.of("okay"), fired); assertEquals(1, timeline.executionCount("broken"));
        assertEquals(AttractionTimeline.Status.FAILED, timeline.snapshot().executions().get(0).status());
    }
    @Test void rejectedTriggerConditionIsSkippedPermanentlyForThatRun() {
        var timeline = timeline(definition(event("riders_only", 5, 0, true)));
        timeline.dispatch(0, 0, e -> true, e -> fail());
        timeline.cross(0, 8, 0, 0, 100, e -> false, e -> fail());
        timeline.tick(e -> fail()); assertEquals(0, timeline.executionCount("riders_only"));
        assertEquals(AttractionTimeline.Status.SKIPPED, timeline.snapshot().executions().get(0).status());
    }
    @Test void holdHasExactlySpecifiedDurationAndReleaseIsPersistentWithinRun() {
        var timeline = timeline(definition(event("stop", 5, 0, true)));
        timeline.dispatch(0, 0, e -> true, e -> {}); timeline.beginHold("stop", 3);
        assertTrue(timeline.consumeHoldTick()); assertEquals(2, timeline.holdRemaining());
        assertTrue(timeline.consumeHoldTick()); assertTrue(timeline.consumeHoldTick());
        assertFalse(timeline.consumeHoldTick()); assertEquals(0, timeline.holdRemaining());
        assertTrue(timeline.completeStopIds().contains("stop")); timeline.beginHold("stop", 3); assertEquals(0, timeline.holdRemaining());
    }
    @Test void reloadInterruptsPendingCuesAndHoldThenExplicitResumeSkipsPassedStop() {
        var stop = new AttractionDefinition.EventSpec("stop", new AttractionDefinition.Trigger(null, 5.),
                AttractionDefinition.Condition.ALWAYS, 0, AttractionDefinition.EventType.STOP, true, new JsonObject());
        var definition = definition(stop, event("pending", 4, 20, true), event("future", 10, 0, true));
        var original = timeline(definition); original.dispatch(0, 0, e -> true, e -> {});
        original.cross(0, 5, 0, 0, 100, e -> true, e -> {}); original.beginHold("stop", 60);
        var restored = timeline(definition); restored.restore(original.snapshot());
        assertFalse(restored.active()); assertEquals(0, restored.holdRemaining());
        List<String> fired = new ArrayList<>(); restored.dispatch(0, 5, e -> true, e -> fired.add(e.id()));
        assertTrue(restored.completeStopIds().contains("stop"));
        restored.cross(5, 11, 0, 0, 100, e -> true, e -> fired.add(e.id()));
        assertEquals(List.of("future"), fired); assertEquals(1, restored.executionCount("stop"));
    }
    @Test void reverseOrTeleportProgressInterruptsRatherThanReplayingPastEvents() {
        var timeline = timeline(definition(event("cue", 5, 0, true)));
        timeline.dispatch(0, 0, e -> true, e -> {});
        timeline.cross(0, 7, 0, 0, 100, e -> true, e -> {});
        timeline.cross(7, 1, 0, 0, 100, e -> true, e -> fail());
        assertFalse(timeline.active()); assertEquals(1, timeline.executionCount("cue"));
    }
    @Test void zeroDistanceDepartureCueFiresOnlyAtStationDispatch() {
        var timeline = timeline(definition(event("departure", 0, 0, true)));
        List<String> fired = new ArrayList<>(); timeline.dispatch(0, 0, e -> true, e -> fired.add(e.id()));
        timeline.cross(0, 2, 0, 0, 100, e -> true, e -> fired.add(e.id())); assertEquals(1, fired.size());
        timeline.interrupt(); timeline.dispatch(0, 2, e -> true, e -> fail()); assertEquals(1, timeline.executionCount("departure"));
    }
    @Test void malformedDefinitionsAreRejectedBeforeCreatingRuntime() {
        assertThrows(IllegalArgumentException.class, () -> new AttractionDefinition.Trigger(1, 2.));
        assertThrows(IllegalArgumentException.class, () -> new AttractionDefinition.Trigger(null, Double.NaN));
        assertThrows(IllegalArgumentException.class, () -> definition(event("duplicate", 5, 0, true), event("duplicate", 6, 0, true)));
        assertThrows(IllegalArgumentException.class, () -> event("bad", 5, -1, true));
    }
    @Test void bundledScriptHasUniqueEventsBothPhysicalStopsAndFiveMusicKeys() {
        try (var input = getClass().getResourceAsStream(AttractionDefinitions.RESOURCE)) {
            assertNotNull(input);
            var definition = AttractionDefinition.parse(new java.io.InputStreamReader(input, java.nio.charset.StandardCharsets.UTF_8));
            assertEquals(24, definition.events().size()); assertEquals(8, definition.stages().size());
            assertEquals(2, definition.events().stream().filter(e -> e.type() == AttractionDefinition.EventType.STOP).count());
            assertEquals(5, definition.stages().stream().map(AttractionDefinition.Stage::music).distinct().count());
            var pause = definition.events().stream().filter(e -> e.id().equals("monster_pause")).findFirst().orElseThrow();
            var gaze = definition.events().stream().filter(e -> e.id().equals("nest_gaze")).findFirst().orElseThrow();
            var attack = definition.events().stream().filter(e -> e.id().equals("monster_attack")).findFirst().orElseThrow();
            assertEquals(pause.trigger(), gaze.trigger(), "Gaze must begin at the actual stopped reveal, rather than expire on approach");
            assertEquals(pause.trigger(), attack.trigger());
            assertEquals(pause.ticks(0), attack.delayTicks(), "Attack must coincide with the hold release and immediate escape acceleration");
        } catch (java.io.IOException exception) { fail(exception); }
    }
    @Test void unknownRigAndOutOfBoundsMusicGainFailScriptValidation() {
        String base = "{\"id\":\"test\",\"formatVersion\":1,\"stages\":[{\"id\":\"start\",\"distance\":0,\"music\":\"exploration\",\"gain\":2}],\"events\":[]}";
        assertThrows(IllegalArgumentException.class, () -> AttractionDefinition.parse(new StringReader(base)));
        var lights = new JsonObject(); lights.addProperty("rig", "unknown");
        var event = new AttractionDefinition.EventSpec("bad_rig", new AttractionDefinition.Trigger(null, 5.),
                AttractionDefinition.Condition.ALWAYS, 0, AttractionDefinition.EventType.LIGHTS, true, lights);
        assertThrows(IllegalArgumentException.class, () -> definition(event));
    }
}
