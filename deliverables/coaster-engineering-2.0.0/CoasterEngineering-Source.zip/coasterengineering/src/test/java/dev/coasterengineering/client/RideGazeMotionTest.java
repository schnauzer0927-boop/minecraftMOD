package dev.coasterengineering.client;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class RideGazeMotionTest {
    @Test void gazeHintsStaySmallEvenForTargetsBehindAndOverhead() {
        RideGazeMotion motion = new RideGazeMotion();
        for (int i = 0; i < 300; i++) motion.tick(true, .30);
        var sample = motion.sample(1, 0, 0, 170, -80);
        assertTrue(Math.abs(sample.yawDegrees()) <= 13.5);
        assertTrue(Math.abs(sample.pitchDegrees()) <= 6);
        assertEquals(13.5, sample.yawDegrees(), .00001);
    }

    @Test void angleWrapTakesShortPathAndDisablingHasImmediateEffect() {
        RideGazeMotion motion = new RideGazeMotion();
        for (int i = 0; i < 40; i++) motion.tick(true, .3);
        assertTrue(motion.sample(1, 179, 0, -179, 0).yawDegrees() > 0);
        motion.tick(true, 0);
        assertEquals(new RideGazeMotion.Sample(0, 0), motion.sample(.5, 0, 0, 90, 90));
    }

    @Test void endingHintEasesBackAndHandlesInvalidAngles() {
        RideGazeMotion motion = new RideGazeMotion();
        for (int i = 0; i < 40; i++) motion.tick(true, .3);
        double before = motion.sample(1, 0, 0, 45, 20).yawDegrees();
        motion.tick(false, .3);
        double after = motion.sample(1, 0, 0, 45, 20).yawDegrees();
        assertTrue(after < before && after > 0);
        for (int i = 0; i < 100; i++) motion.tick(false, .3);
        assertEquals(0, motion.sample(1, 0, 0, 45, 20).yawDegrees());
        assertEquals(new RideGazeMotion.Sample(0, 0), motion.sample(1, Double.NaN, 0, 45, 20));
    }

    @Test void lowSpeedLaunchTextureDoesNotWidenFovAndRespectsDisable() {
        RideCameraMotion motion = new RideCameraMotion();
        for (int i = 0; i < 80; i++) motion.tick(.3, true, .18, 2, .025);
        var sample = motion.sample(1, 4);
        assertTrue(Math.abs(sample.rollDegrees()) <= .054 && Math.abs(sample.pitchDegrees()) <= .054);
        assertTrue(Math.abs(sample.rollDegrees()) > .001);
        assertEquals(1, sample.fovScale());
        motion.tick(.3, true, 0, 0, .025);
        assertEquals(new RideCameraMotion.Sample(0, 0, 1), motion.sample(1, 4));
    }
}
