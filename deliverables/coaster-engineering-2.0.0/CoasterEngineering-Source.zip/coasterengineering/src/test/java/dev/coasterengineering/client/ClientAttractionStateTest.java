package dev.coasterengineering.client;

import static org.junit.jupiter.api.Assertions.*;

import java.util.UUID;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

class ClientAttractionStateTest {
    private final UUID course = UUID.fromString("07e54e16-4f54-4c44-88f2-99508b13b663");
    @AfterEach void clear() { ClientAttractionState.clear(); }
    private void update(long sequence, String effect, int silence, int gaze) {
        ClientAttractionState.update(course, "MONSTER", "monster_encounter", .8, silence,
                50, 94, 105, gaze, effect, sequence);
    }

    @Test void silenceAndGazeCountDownOnClientTicksAndFreezeOnPause() {
        update(3, "roar", 20, 40);
        ClientAttractionState.tick(true);
        assertEquals(20, ClientAttractionState.snapshot(course).remainingSilenceTicks());
        for (int i = 0; i < 20; i++) ClientAttractionState.clientTick();
        var state = ClientAttractionState.snapshot(course);
        assertEquals(0, state.remainingSilenceTicks());
        assertEquals(.8, state.effectiveMusicGain());
        assertEquals(20, state.remainingGazeTicks());
    }

    @Test void newCueRunsOnceAndRejoinDoesNotReplayHistoricalCue() {
        update(3, "roar", 0, 0);
        assertNull(ClientAttractionState.consumeEffect(course));
        update(4, "launch", 0, 0);
        update(4, "launch", 0, 0);
        update(2, "alarm", 0, 0);
        assertEquals("launch", ClientAttractionState.consumeEffect(course));
        assertNull(ClientAttractionState.consumeEffect(course));
        assertEquals(4, ClientAttractionState.snapshot(course).sequence());
        ClientAttractionState.clear();
        update(4, "launch", 0, 0);
        assertNull(ClientAttractionState.consumeEffect(course));
    }

    @Test void lostHeartbeatExpiresStateAndPendingEffects() {
        update(0, "", 0, 0);
        update(1, "alarm", 0, 0);
        for (int i = 0; i < 81; i++) ClientAttractionState.clientTick();
        assertNull(ClientAttractionState.snapshot(course));
        assertNull(ClientAttractionState.consumeEffect(course));
    }

    @Test void foreignCourseAndUnmountedCueDiscardDoNotLeak() {
        update(1, "", 0, 0);
        update(2, "roar", 0, 0);
        assertNull(ClientAttractionState.snapshot(UUID.randomUUID()));
        ClientAttractionState.discardEffects();
        assertNull(ClientAttractionState.consumeEffect(course));
        assertEquals(2, ClientAttractionState.snapshot(course).sequence());
    }

    @Test void invalidPresentationInputsAreRejectedBeforeMutation() {
        assertThrows(IllegalArgumentException.class, () ->
                ClientAttractionState.update(course, "MONSTER", "monster_encounter", Double.NaN, 0,
                        50, 94, 105, 0, "", 0));
        assertThrows(IllegalArgumentException.class, () -> update(0, "", -1, 0));
        assertNull(ClientAttractionState.snapshot(course));
    }
}
