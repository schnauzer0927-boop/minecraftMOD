package dev.coasterengineering.show;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

final class MonsterPoseTest {
    @Test void dormantEyesAndBreathingAreOff() {
        MonsterPose.Pose pose = MonsterPose.sample(0, -1, -1, 42);
        assertEquals(0, pose.eyeBrightness());
        assertEquals(0, pose.bodyBob());
        assertEquals(0, pose.leftLegAngle());
    }

    @Test void roarOpensAndClosesJawWithoutJumpAtEitherEnd() {
        double idle = MonsterPose.sample(1, -1, -1, 0).jawAngle();
        assertEquals(idle, MonsterPose.sample(1, 0, -1, 0).jawAngle(), 1e-12);
        assertEquals(idle, MonsterPose.sample(1, 1, -1, 0).jawAngle(), 1e-12);
        assertTrue(MonsterPose.sample(1, .5, -1, 0).jawAngle() > idle + .5);
    }

    @Test void threatRaisesForelegThenReturnsToItsStartingPose() {
        assertEquals(0, MonsterPose.sample(1, -1, 0, 0).leftLegAngle(), 1e-12);
        assertTrue(MonsterPose.sample(1, -1, .35, 0).leftLegAngle() < -.7);
        assertEquals(0, MonsterPose.sample(1, -1, 1, 0).leftLegAngle(), 1e-12);
    }

    @Test void animationsStayFiniteAndFrameToFrameMotionIsBounded() {
        MonsterPose.Pose previous = MonsterPose.sample(1, 0, 0, 0);
        for (int step = 1; step <= 240; step++) {
            double phase = step / 240.0;
            MonsterPose.Pose pose = MonsterPose.sample(1, phase, phase, step / 3.0);
            assertTrue(Double.isFinite(pose.jawAngle()));
            assertTrue(Math.abs(pose.leftLegAngle() - previous.leftLegAngle()) < .025);
            assertTrue(Math.abs(pose.jawAngle() - previous.jawAngle()) < .025);
            assertTrue(pose.eyeBrightness() >= .75 && pose.eyeBrightness() <= 1.01);
            previous = pose;
        }
    }
}
