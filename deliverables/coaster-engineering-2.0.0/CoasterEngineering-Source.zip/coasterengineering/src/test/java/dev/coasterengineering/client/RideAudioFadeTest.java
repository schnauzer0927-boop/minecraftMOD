package dev.coasterengineering.client;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class RideAudioFadeTest {
    private RideAudioFade playing() {
        RideAudioFade fade = new RideAudioFade();
        fade.setTarget(.8);
        for (int i = 0; i < 40; i++) fade.tick();
        return fade;
    }

    @Test void scriptedSilenceIsCompleteBeforeRoarAndDoesNotRestartOnHeartbeat() {
        RideAudioFade fade = playing();
        for (int i = 0; i < 9; i++) {
            fade.setTarget(0, true);
            assertTrue(fade.tick() > 0);
        }
        fade.setTarget(0, true);
        assertEquals(0, fade.tick());
        assertTrue(fade.finishedSilent());
    }

    @Test void normalDismountStillTakesFortyTicksAndRestartFadesInNormally() {
        RideAudioFade fade = playing();
        fade.setTarget(0);
        for (int i = 0; i < 39; i++) assertTrue(fade.tick() > 0);
        assertEquals(0, fade.tick());
        fade.setTarget(.8);
        assertEquals(.02, fade.tick(), 1e-12);
        assertFalse(fade.finishedSilent());
        for (int i = 0; i < 39; i++) fade.tick();
        assertEquals(.8, fade.tick(), 1e-12);
    }

    @Test void silenceAlsoRetiresTheOldSongInAnUnfinishedCrossfade() {
        RideAudioFade fade = playing();
        fade.setTarget(0);
        double volume = fade.tick();
        fade.setTarget(0, true);
        double next = fade.tick();
        assertEquals(volume * .9, next, 1e-12);
        for (int i = 0; i < 9; i++) fade.tick();
        assertTrue(fade.finishedSilent());
    }

    @Test void envelopesNeverOvershootOrBecomeNonfinite() {
        RideAudioFade fade = new RideAudioFade();
        fade.setTarget(99);
        for (int i = 0; i < 40; i++) {
            double volume = fade.tick();
            assertTrue(volume >= 0 && volume <= 1);
        }
        fade.setTarget(Double.NaN, true);
        for (int i = 0; i < 10; i++) assertTrue(Double.isFinite(fade.tick()));
        assertTrue(fade.finishedSilent());
    }
}
