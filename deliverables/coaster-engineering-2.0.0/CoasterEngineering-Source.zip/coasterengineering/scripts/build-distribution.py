#!/usr/bin/env python3
"""Package a Minecraft-saved world and the actual reobfuscated jar; no placeholder worlds."""
from __future__ import annotations

import argparse
from contextlib import contextmanager
import gzip
import hashlib
import re
from pathlib import Path
import shutil
import struct
import zipfile

PROJECT = Path(__file__).resolve().parents[1]
WORLD_FOLDER = "Coaster World - Volcanic Abyss"


@contextmanager
def stopped_world(world: Path):
    """Respect Minecraft's POSIX session lock while reading the complete save."""
    try:
        import fcntl
    except ImportError:
        raise RuntimeError("Package on a POSIX system so the Minecraft session lock can be verified")
    lock_path = world / "session.lock"
    if not lock_path.is_file():
        raise ValueError("Minecraft session.lock is missing; use a normally saved world")
    with lock_path.open("r+b") as lock:
        try:
            fcntl.lockf(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise ValueError("The world is still running; save and stop Minecraft before packaging") from None
        try:
            yield
        finally:
            fcntl.lockf(lock, fcntl.LOCK_UN)


class NbtCursor:
    """Skip binary NBT payloads while retaining their exact original bytes."""
    def __init__(self, data: bytes):
        self.data = data
        self.offset = 0

    def take(self, count: int) -> bytes:
        if count < 0 or self.offset + count > len(self.data):
            raise ValueError("Truncated or invalid NBT")
        result = self.data[self.offset:self.offset + count]
        self.offset += count
        return result

    def number(self, fmt: str) -> int:
        return struct.unpack(fmt, self.take(struct.calcsize(fmt)))[0]

    def string(self) -> bytes:
        return self.take(self.number(">H"))

    def skip(self, kind: int, depth: int = 0) -> None:
        if depth > 128:
            raise ValueError("NBT nesting limit exceeded")
        widths = {1: 1, 2: 2, 3: 4, 4: 8, 5: 4, 6: 8}
        if kind in widths:
            self.take(widths[kind])
        elif kind in (7, 11, 12):
            self.take(self.number(">i") * {7: 1, 11: 4, 12: 8}[kind])
        elif kind == 8:
            self.string()
        elif kind == 9:
            element, count = self.number(">B"), self.number(">i")
            if count < 0 or count > len(self.data):
                raise ValueError("Invalid NBT list length")
            for _ in range(count):
                self.skip(element, depth + 1)
        elif kind == 10:
            while (child := self.number(">B")) != 0:
                self.string()
                self.skip(child, depth + 1)
        else:
            raise ValueError(f"Unsupported NBT tag {kind}")


def clean_level(data: bytes) -> bytes:
    """Use the saved spawn and enable the single-player owner's development controls."""
    cursor = NbtCursor(data)
    if cursor.number(">B") != 10:
        raise ValueError("level.dat root must be a compound")
    cursor.string()
    output = bytearray(data[:cursor.offset])
    found_data = False
    while (kind := cursor.number(">B")) != 0:
        start = cursor.offset - 1
        name = cursor.string()
        if kind == 10 and name == b"Data":
            found_data = True
            output.extend(data[start:cursor.offset])
            while (child := cursor.number(">B")) != 0:
                child_start = cursor.offset - 1
                child_name = cursor.string()
                payload_start = cursor.offset
                cursor.skip(child)
                if child_name == b"allowCommands" and child == 1:
                    output.extend(data[child_start:payload_start])
                    output.append(1)
                elif child_name != b"Player":
                    output.extend(data[child_start:cursor.offset])
            output.append(0)
        else:
            cursor.skip(kind)
            output.extend(data[start:cursor.offset])
    output.append(0)
    if not found_data or cursor.offset != len(data):
        raise ValueError("Invalid Minecraft level.dat")
    return bytes(output)


def package_world(world: Path, destination: Path, world_folder: str = WORLD_FOLDER) -> None:
    required = (world / "level.dat", world / "data/coasterengineering_courses.dat")
    if not all(path.is_file() for path in required) or not any((world / "region").glob("*.mca")) or not any((world / "entities").glob("*.mca")):
        raise ValueError("A real saved attraction world with level.dat, regions and course data is required")
    level = clean_level(gzip.decompress(required[0].read_bytes()))
    cursor = NbtCursor(level)
    cursor.number(">B")
    cursor.string()
    cursor.skip(10)
    if cursor.offset != len(level):
        raise ValueError("Cleaned world metadata failed binary verification")
    omitted = {"playerdata", "advancements", "stats", "session.lock", "level.dat_old"}
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(world.rglob("*")):
            if not path.is_file() or path.is_symlink():
                continue
            relative = path.relative_to(world)
            if any(part in omitted for part in relative.parts):
                continue
            target = f"{world_folder}/{relative.as_posix()}"
            if relative.as_posix() == "level.dat":
                archive.writestr(target, gzip.compress(level, mtime=0))
            else:
                archive.write(path, target)
        if archive.testzip() is not None:
            raise ValueError("World ZIP CRC verification failed")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world", type=Path, required=True, help="Stopped server/client's saved world directory")
    parser.add_argument("--out", type=Path, default=PROJECT / "dist")
    parser.add_argument("--world-name", help="Folder inside the saved-world ZIP")
    parser.add_argument("--world-zip-name", help="Saved-world archive filename")
    args = parser.parse_args()
    world, output = args.world.resolve(), args.out.resolve()
    if output.is_relative_to(world) or PROJECT.is_relative_to(output):
        parser.error("Choose an output directory outside the world and below or outside the project")
    match = re.search(r"^version\s*=\s*['\"]([^'\"]+)['\"]", (PROJECT / "build.gradle").read_text(), re.MULTILINE)
    if match is None:
        parser.error("No declared Gradle project version was found")
    jar = PROJECT / f"build/libs/coasterengineering-{match.group(1)}.jar"
    if not jar.is_file():
        parser.error("Build the actual MOD with ./gradlew build first")
    with zipfile.ZipFile(jar) as archive:
        if "META-INF/mods.toml" not in archive.namelist() or "dev/coasterengineering/entity/CoasterEntity.class" not in archive.namelist():
            parser.error("MOD jar is missing Forge metadata or the actual coaster entity")
    output.mkdir(parents=True, exist_ok=True)
    folder = args.world_name or ("Coaster World - Volcanic Abyss 2.0" if match.group(1).startswith("2.") else WORLD_FOLDER)
    archive_name = args.world_zip_name or ("CoasterWorld-VolcanicAbyss-2.0.zip" if match.group(1).startswith("2.") else "CoasterWorld-VolcanicAbyss.zip")
    if any(character in folder for character in ("/", "\\")) or Path(archive_name).name != archive_name:
        parser.error("World folder and ZIP filename must each be a single path component")
    with stopped_world(world):
        package_world(world, output / archive_name, folder)
    shutil.copy2(jar, output / jar.name)
    for name in ("README.md", "CONTROLS.md", "TEST_RESULTS.md", "CHANGELOG.md", "BGM_GUIDE.md", "LICENSE"):
        if not (PROJECT / name).is_file():
            if name == "CHANGELOG.md" or (name == "BGM_GUIDE.md" and not match.group(1).startswith("2.")):
                continue
            parser.error(f"Required documentation is missing: {name}")
        shutil.copy2(PROJECT / name, output / name)
    excluded = {"build", "dist", ".gradle", ".git", ".idea", "__pycache__", "logs", "crash-reports", ".mixin.out"}
    with zipfile.ZipFile(output / "CoasterEngineering-Source.zip", "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(PROJECT.rglob("*")):
            relative = path.relative_to(PROJECT)
            if not path.is_file() or path.is_symlink() or path.suffix in {".log", ".hprof", ".pyc"} or path.is_relative_to(output) or path.is_relative_to(world) or any(part in excluded for part in relative.parts) or relative.parts[0].startswith("run"):
                continue
            archive.write(path, f"coasterengineering/{relative.as_posix()}")
        if archive.testzip() is not None:
            raise ValueError("Source ZIP CRC verification failed")
    artifacts = (jar.name, archive_name, "CoasterEngineering-Source.zip")
    checksums = []
    for name in artifacts:
        path = output / name
        checksums.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {name}")
        print(f"{path.name}: {path.stat().st_size:,} bytes")
    (output / "SHA256SUMS").write_text("\n".join(checksums) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
