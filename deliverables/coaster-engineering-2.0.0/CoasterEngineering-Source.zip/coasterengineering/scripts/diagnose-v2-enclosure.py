#!/usr/bin/env python3
"""Read-only diagnosis of failed V2 enclosure rays in a stopped generated save.

The procedural overlay evaluates the new boundary ridge before regeneration.
It does not modify saved blocks or certify Minecraft collision/light propagation.
"""
from __future__ import annotations
import argparse
import importlib.util
import json
import math
from pathlib import Path
import re


def module(path: Path):
    spec = importlib.util.spec_from_file_location("coaster_enclosure_reader", path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world", type=Path, required=True)
    parser.add_argument("--log", type=Path, required=True)
    parser.add_argument("--output", type=Path, default=Path("build/v2-enclosure-diagnosis.json"))
    args = parser.parse_args()
    if not (args.world / "level.dat").is_file() or not (args.world / "region").is_dir():
        raise ValueError("The stopped saved world is missing; use its current actual backup path")
    root = Path(__file__).resolve().parents[1]
    audit = module(root / "scripts/audit-world-quality.py")
    design = json.loads((root / "src/main/resources/assets/coasterengineering/attraction/volcanic_abyss_v2_course.json").read_text())
    points = [dict(X=p["position"][0], Y=p["position"][1], Z=p["position"][2], Bank=p["bankDegrees"]) for p in design["points"]]
    track = audit.SavedSpline(points)
    blocks = audit.SavedBlocks(args.world, track)
    if not blocks.chunks:
        raise ValueError("The stopped world contains no saved region chunks for this course")
    java = (root / "src/main/java/dev/coasterengineering/world/VolcanicV2Geometry.java").read_text()
    room_source = java.split("static final double[][] ROOMS = {", 1)[1].split("};", 1)[0]
    rooms = [[float(n.strip()) for n in row.split(",")] for row in re.findall(r"\{([0-9., \-]+)\}", room_source)]
    if len(rooms) != 4 or any(len(room) != 6 for room in rooms):
        raise ValueError("Could not parse the actual four Java room definitions")

    def encloses_room(pos):
        x, y, z = pos
        for cx, cy, cz, rx, ry, rz in rooms:
            rough = .025 * math.sin(x * .23 + z * .19) * math.sin(y * .31) + .015 * math.sin(x * .41 - z * .27 + y * .12)
            if ((x-cx)/rx)**2 + ((y-cy)/ry)**2 + ((z-cz)/rz)**2 + rough < 1.32:
                return True
        return False

    centres = [track.sample(i * 1.25)[0] for i in range(math.ceil(track.length / 1.25) + 1)]
    failure_pattern = r"VOLCANIC_V2_OPEN_SIGHTLINE distance=([0-9.]+) direction=TrackVec3\[x=([^,]+), y=([^,]+), z=([^\]]+)\]"
    rays = []
    for distance, *components in re.findall(failure_pattern, args.log.read_text()):
        distance = float(distance)
        direction = tuple(float(v) for v in components)
        anchor = track.sample(distance)[0]
        eye = audit.add(anchor, (0, 2, 0))
        old_wall = None
        new_wall = None
        footprint_exit = None
        for step in range(3, 620):
            position = tuple(math.floor(v) for v in audit.add(eye, audit.scale(direction, step)))
            if not (-215 <= position[0] <= 215 and 64 <= position[1] <= 200 and -215 <= position[2] <= 215):
                footprint_exit = {"distance": step, "position": position}
                break
            state = blocks.state(position)
            if old_wall is None and state is not None and state["Name"] not in audit.PASSABLE:
                old_wall = {"distance": step, "position": position, "block": state["Name"]}
            if new_wall is None and 38 <= position[2] <= 42 and 76 <= position[1] <= 164 and -178 <= position[0] <= 148 and encloses_room(position):
                centre = tuple(v+.5 for v in position)
                nearest = min(math.dist(centre, p) for p in centres)
                # Exact protected body/rider cells are excluded by the Java
                # builder. A centreline distance above the carved radius also
                # provides a conservative independent margin for these rays.
                if nearest > 5.8:
                    new_wall = {"distance": step, "position": position,
                                "nearest_sampled_track_centre_distance": nearest,
                                "inside_protected_carve": False, "type": "new_geological_ridge_or_ancient_gate"}
            if old_wall is not None and new_wall is not None:
                break
        rays.append({"distance": distance, "anchor": anchor, "direction": direction,
                     "actual_saved_first_wall": old_wall, "actual_footprint_exit": footprint_exit,
                     "diagnosis": "open_to_exterior_through_outdoor_ravine" if old_wall is None else "closed_wall_beyond_original_160_block_ray_extent",
                     "procedural_boundary_first_wall": new_wall,
                     "procedural_160_block_check": new_wall is not None and new_wall["distance"] < 160})
    if not rays:
        raise ValueError("The log contains no failed enclosure rays")
    result = {"world": str(args.world.resolve()), "world_was_modified": False,
              "procedural_simulation_only": True, "original_audit_extent": 160,
              "reproduced_rays": len(rays), "all_procedural_boundaries_close_within_original_extent": all(r["procedural_160_block_check"] for r in rays),
              "ravine_repair": "nest Z radius68 to50; ravine preserves normalized room enclosure below1.32; normal5.8-radius track portals stay open",
              "rays": rays, "limitations": ["New ridge blocks are a procedural overlay, not blocks already saved in this failed world.",
                                            "Regenerate a fresh world and run the authoritative live wall, light and body/rider audits."]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"rays": len(rays), "all_procedural_boundaries_close_within_original_extent": result["all_procedural_boundaries_close_within_original_extent"],
                      "old_wall_distances": [r["actual_saved_first_wall"]["distance"] if r["actual_saved_first_wall"] else None for r in rays],
                      "new_wall_distances": [r["procedural_boundary_first_wall"]["distance"] if r["procedural_boundary_first_wall"] else None for r in rays],
                      "output": str(args.output)}))
    if not result["all_procedural_boundaries_close_within_original_extent"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
