#!/usr/bin/env python3
"""Read only a stopped VOLCANIC ABYSS2.0 save; never construct or modify a world."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
import uuid

_SPEC = importlib.util.spec_from_file_location("coaster_nbt_readers", Path(__file__).with_name("inspect-world.py"))
_READERS = importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_READERS)
read_dat = _READERS.read_dat
region_chunks = _READERS.region_chunks
uuid_string = _READERS.uuid_string
block_position = _READERS.block_position
stable_save = _READERS.stable_save

# Java UUID.nameUUIDFromBytes uses the raw MD5 digest, without a namespace prefix.
COURSE_ID = str(uuid.UUID(bytes=hashlib.md5(b"CoasterEngineering:VolcanicAbyss:2.0").digest(), version=3))
WORLD_NAME = "Coaster World - Volcanic Abyss 2.0"
SEED = 20261012
POINT_COUNT = 62
STATION = [-3, 94, -165]  # Safe dismount landing; track control point0 is [0,94,-165].
CONTROLLER = [-6, 94, -165]
SPAWN = [-3, 94, -165]


def finite(value) -> bool:
    return isinstance(value, (int, float)) and math.isfinite(value)


def fingerprint(value) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def inspect_world(world: Path, design: dict | None = None) -> dict:
    level = read_dat(world / "level.dat")["Data"]
    course_data = read_dat(world / "data/coasterengineering_courses.dat")["data"]
    courses = []
    for course in course_data.get("Courses", []):
        points = course.get("Points", [])
        geometry = [{key: point.get(key) for key in ("X", "Y", "Z", "Bank")} for point in points]
        courses.append({"id": uuid_string(course.get("Id")), "name": course.get("Name"),
                        "enabled": course.get("Enabled"), "closed": course.get("Closed"),
                        "node_count": len(points), "station": block_position(course.get("Station")),
                        "controller_position": block_position(course.get("Controller")),
                        "vehicle_id": uuid_string(course.get("Vehicle")), "emergency": course.get("Emergency"),
                        "geometry_sha256": fingerprint(geometry), "settings_sha256": fingerprint(points),
                        "points": points})
    vehicles, monsters, controllers = [], [], []
    for chunk in region_chunks(world / "entities"):
        for entity in chunk.get("Entities", []):
            entity_id = entity.get("id", "")
            if entity_id == "coasterengineering:coaster":
                vehicles.append({"id": uuid_string(entity.get("UUID")), "course_id": uuid_string(entity.get("CoasterCourse")),
                                 "leader_id": uuid_string(entity.get("CoasterLeader")), "car_index": entity.get("CoasterCarIndex"),
                                 "car_count": entity.get("CoasterCarCount"), "distance": entity.get("CoasterDistance"),
                                 "speed": entity.get("CoasterSpeed"), "running": entity.get("CoasterRunning"),
                                 "laps": entity.get("CoasterLaps"), "spacing": entity.get("CoasterCarSpacing"),
                                 "position": entity.get("Pos"), "passenger_count": len(entity.get("Passengers", [])),
                                 "follower_ids": [uuid_string(entry.get("Id")) for entry in entity.get("CoasterFollowers", [])]})
            elif entity_id.startswith("coasterengineering:"):
                # Preserve actual named data; do not infer an appearance from an ID.
                monsters.append({"type": entity_id, "id": uuid_string(entity.get("UUID")), "position": entity.get("Pos"),
                                 "data": {key: value for key, value in entity.items()
                                          if key not in ("UUID", "Pos", "Motion", "Rotation", "Passengers")
                                          and isinstance(value, (str, int, float, list, dict))}})
                if isinstance(monsters[-1]["data"].get("ShowCourse"), list):
                    monsters[-1]["data"]["ShowCourse"] = uuid_string(monsters[-1]["data"]["ShowCourse"])
    vehicles.sort(key=lambda car: (car["car_index"] if isinstance(car["car_index"], int) else -1, car["id"] or ""))
    chunk_count = 0
    for chunk in region_chunks(world / "region"):
        chunk_count += 1
        for entity in chunk.get("block_entities", []):
            if entity.get("id") == "coasterengineering:station_controller":
                controllers.append({"position": [entity.get("x"), entity.get("y"), entity.get("z")],
                                    "course_id": uuid_string(entity.get("Course")), "automatic": entity.get("AutoDeparture"),
                                    "dwell_ticks": entity.get("DwellTicks"), "emergency": entity.get("EmergencyLatched")})
    forced_file = world / "data/chunks.dat"
    forced = read_dat(forced_file).get("data", {}) if forced_file.exists() else {}
    marker_file = world / "data/coasterengineering_volcanic_v2.dat"
    marker = read_dat(marker_file).get("data", {}) if marker_file.exists() else {}
    marker = dict(marker)
    if isinstance(marker.get("courseId"), list):
        marker["courseId"] = uuid_string(marker["courseId"])
    event_file = world / "data/coasterengineering_attractions_v2.dat"
    events = read_dat(event_file).get("data", {}) if event_file.exists() else {}
    events = dict(events)
    events["Courses"] = [dict(entry, Id=uuid_string(entry.get("Id"))) for entry in events.get("Courses", [])]
    generator = level.get("WorldGenSettings", {}).get("dimensions", {}).get("minecraft:overworld", {}).get("generator", {}).get("type")
    report = {"world": {"path": str(world), "name": level.get("LevelName"), "seed": level.get("WorldGenSettings", {}).get("seed"),
                        "game_type": level.get("GameType"), "data_version": level.get("DataVersion"),
                        "spawn": [level.get("SpawnX"), level.get("SpawnY"), level.get("SpawnZ")],
                        "generator": generator, "embedded_player": "Player" in level,
                        "saved_overworld_chunks": chunk_count,
                        "persistent_forced_chunks": len(forced.get("Forced", [])) + len(forced.get("ForgeForced", []))},
              "courses": courses, "vehicles": vehicles, "controllers": controllers,
              "show_entities": monsters, "construction": marker, "attraction_state": events}
    failures = []
    def require(condition: bool, message: str):
        if not condition:
            failures.append(message)
    metadata = report["world"]
    require(metadata["name"] == WORLD_NAME and metadata["seed"] == SEED, "The separate V2 world name and fixed seed must match")
    require(metadata["game_type"] == 2 and metadata["spawn"] == SPAWN, "Distributable adventure spawn must be the V2 safe station landing")
    require(metadata["data_version"] == 3465 and generator == "minecraft:flat", "Minecraft1.20.1 flat dedicated world must be retained")
    require(not metadata["embedded_player"], "Embedded Player must be absent from the distributable save")
    require(metadata["persistent_forced_chunks"] == 0, "Temporary commissioning must leave no persistent forced chunks")
    require(chunk_count > 0, "Actual saved Overworld chunks must exist")
    require(len(courses) == 1 and courses[0]["id"] == COURSE_ID and courses[0]["node_count"] == POINT_COUNT
            and courses[0]["station"] == STATION and courses[0]["controller_position"] == CONTROLLER
            and courses[0]["enabled"] == 1 and courses[0]["closed"] == 1 and courses[0]["emergency"] == 0,
            "Exactly the enabled, closed, nonalarmed V2 course and station must be saved")
    require(all(all(finite(point.get(key)) for key in ("X", "Y", "Z", "Bank", "TargetSpeed"))
                for course in courses for point in course["points"]), "Saved course geometry and speed targets must be finite")
    if design is not None and len(courses) == 1:
        expected_points = design.get("points", [])
        expected_settings = expected_points if expected_points and isinstance(expected_points[0], dict) else None
        actual_points = [[point.get(key) for key in ("X", "Y", "Z")] for point in courses[0]["points"]]
        if expected_points and isinstance(expected_points[0], dict):
            expected_points = [point.get("position", [point.get(key, point.get(key.lower())) for key in ("X", "Y", "Z")])
                               for point in expected_points]
        require(len(expected_points) == len(actual_points), "Design data and saved course must contain the same point count")
        if len(expected_points) == len(actual_points):
            require(all(len(expected) == 3 and all(finite(a) and finite(b) and abs(a - b) < 1e-8
                                                  for a, b in zip(expected, actual))
                        for expected, actual in zip(expected_points, actual_points)), "Saved XYZ must match the supplied design data")
            if expected_settings is not None:
                require(all(("bankDegrees" not in expected or expected["bankDegrees"] == actual.get("Bank"))
                            and ("kind" not in expected or expected["kind"] == actual.get("Kind"))
                            and ("targetSpeed" not in expected or expected["targetSpeed"] == actual.get("TargetSpeed"))
                            for expected, actual in zip(expected_settings, courses[0]["points"])),
                        "Saved bank, rail kind and node targets must match the supplied design when present")
    require(len(vehicles) == 3 and {car["car_index"] for car in vehicles} == {0, 1, 2}
            and len({car["id"] for car in vehicles}) == 3 and all(car["id"] and car["course_id"] == COURSE_ID for car in vehicles),
            "Three distinct actual saved V2 cars must exist")
    require(all(car["car_count"] == 3 and car["spacing"] == 4 and car["running"] == 0
                and car["speed"] == 0 and car["passenger_count"] == 0 and finite(car["distance"])
                and isinstance(car["position"], list) and len(car["position"]) == 3 and all(finite(v) for v in car["position"])
                for car in vehicles), "All cars must be paused, empty, finite and four-block spaced")
    leaders = [car for car in vehicles if car["car_index"] == 0]
    if len(courses) == 1 and len(leaders) == 1:
        leader = leaders[0]
        followers = [car for car in vehicles if car["car_index"] in (1, 2)]
        require(leader["leader_id"] is None and leader["id"] == courses[0]["vehicle_id"] and leader["distance"] == 0
                and leader["follower_ids"] == [car["id"] for car in followers]
                and all(car["leader_id"] == leader["id"] and car["laps"] == leader["laps"] for car in followers),
                "Reserved leader, follower order, lap counters and exact station parking must match")
    require(len(controllers) == 1 and controllers[0]["course_id"] == COURSE_ID
            and controllers[0]["position"] == CONTROLLER and controllers[0]["automatic"] == 1
            and controllers[0]["dwell_ticks"] == 140 and controllers[0]["emergency"] == 0,
            "One automatic140tick V2 station must be bound and not alarmed")
    require(marker.get("buildVersion") == 2 and marker.get("ready") == 1 and marker.get("courseId") == COURSE_ID,
            "The successful real V2 builder completion marker must be saved")
    require(finite(marker.get("length")) and marker.get("length", 0) > 1500
            and marker.get("probes", 0) > 0 and marker.get("minCombinedLight", 0) >= 6
            and marker.get("stationMinCombinedLight", 0) >= 9 and marker.get("darkProbes", -1) == 0
            and marker.get("wallAuditFailures", -1) == 0,
            "Builder must record nonempty real light/clearance audits with no failed probes")
    require(events.get("FormatVersion") == 1, "Versioned V2 attraction state must actually be saved")
    require(len(events["Courses"]) == 1 and all(entry.get("Id") == COURSE_ID and not entry.get("Active")
                                              and entry.get("HoldRemaining", 0) == 0
                                              for entry in events["Courses"]),
            "Exactly one inactive V2 attraction timeline must be saved with no pending hold")
    require(all(execution.get("Status") != "FAILED" and isinstance(execution.get("Count"), int)
                and execution["Count"] >= 0 for entry in events["Courses"] for execution in entry.get("Executions", [])),
            "No saved event execution may be failed or have an invalid count")
    require(len(monsters) == 1 and monsters[0]["type"] == "coasterengineering:show_monster"
            and monsters[0]["data"].get("ShowCourse") == COURSE_ID
            and not monsters[0]["data"].get("ShowActive")
            and monsters[0]["data"].get("ShowExposure", 0) == 0
            and monsters[0]["data"].get("ShowRoarTicks", 0) == 0
            and monsters[0]["data"].get("ShowThreatTicks", 0) == 0,
            "Exactly one original nonactive V2 monster puppet must be saved with cleared animations")
    report["ready"] = not failures
    report["readiness_failures"] = failures
    return report


def compare(report: dict, previous: dict) -> dict:
    changes = []
    for key in ("courses", "vehicles", "controllers"):
        before = previous.get(key, [])
        after = report.get(key, [])
        if key == "courses":
            stable_keys = ("id", "geometry_sha256", "settings_sha256", "vehicle_id", "station", "controller_position")
        elif key == "vehicles":
            stable_keys = ("id", "course_id", "leader_id", "car_index", "car_count", "spacing", "position", "distance", "speed", "running", "follower_ids")
        else:
            stable_keys = ("position", "course_id", "automatic", "dwell_ticks", "emergency")
        stable_before = [{k: entry.get(k) for k in stable_keys} for entry in before]
        stable_after = [{k: entry.get(k) for k in stable_keys} for entry in after]
        if stable_before != stable_after:
            changes.append(key)
    return {"same_course_and_formation": not changes, "changed_fields": changes,
            "limitation": "Lap/run counters may increase; this comparison excludes them and does not prove client visuals or audio."}


def inspect_executions(report: dict, definition: dict) -> dict:
    states = [entry for entry in report["attraction_state"].get("Courses", []) if entry.get("Id") == COURSE_ID]
    records = states[0].get("Executions", []) if len(states) == 1 else []
    actual = {entry.get("Id"): entry for entry in records}
    expected = definition.get("events", [])
    missing, failed, unexecuted = [], [], []
    for event in expected:
        record = actual.get(event.get("id"))
        if record is None:
            missing.append(event.get("id"))
        elif record.get("Status") == "FAILED":
            failed.append(event.get("id"))
        elif record.get("Status") != "EXECUTED" or record.get("Count", 0) < 1:
            unexecuted.append(event.get("id"))
    return {"passed": bool(expected) and not (missing or failed or unexecuted), "expected_count": len(expected),
            "missing": missing, "failed": failed, "unexecuted": unexecuted,
            "actual_counts": {key: value.get("Count") for key, value in actual.items()},
            "limitation": "Stored server execution states verify trigger handling, not human-perceived visibility or audibility."}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world", type=Path, required=True)
    parser.add_argument("--design", type=Path, help="Optional exported XYZ control-point design JSON")
    parser.add_argument("--compare", type=Path, help="Earlier stopped-save JSON report; preserve course/formation identities")
    parser.add_argument("--require-ready", action="store_true")
    parser.add_argument("--require-events", action="store_true", help="Also require all configured events to have executed after a real ride")
    parser.add_argument("--events", type=Path, help="Override the expected event-definition JSON; defaults to the world-local script")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        if args.output and args.output.resolve().is_relative_to(args.world.resolve()):
            raise ValueError("Write the report outside the read-only world")
        design = json.loads(args.design.read_text()) if args.design else None
        with stable_save(args.world):
            report = inspect_world(args.world.resolve(), design)
        if args.compare:
            report["comparison"] = compare(report, json.loads(args.compare.read_text()))
        if args.require_events:
            event_path = args.events or args.world / "coasterengineering/attractions/volcanic_abyss_v2.json"
            report["event_verification"] = inspect_executions(report, json.loads(event_path.read_text()))
        output = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(output, encoding="utf-8")
        print(output, end="")
        return 1 if (args.require_ready and not report["ready"]
                     or "comparison" in report and not report["comparison"]["same_course_and_formation"]
                     or args.require_events and not report["event_verification"]["passed"]) else 0
    except (OSError, ValueError, KeyError, ImportError, TypeError) as error:
        print(json.dumps({"error": str(error), "ready": False}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
