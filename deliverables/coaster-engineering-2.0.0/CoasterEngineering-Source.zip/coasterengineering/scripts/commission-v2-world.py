#!/usr/bin/env python3
"""Observe a real installed Forge server building/running/saving the 2.0 world."""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import queue
import re
import subprocess
import threading
import time
import uuid

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--server', type=Path, required=True)
parser.add_argument('--log', type=Path, required=True)
parser.add_argument('--result', type=Path, required=True)
parser.add_argument('--build', action='store_true')
parser.add_argument('--recover-station', action='store_true', help='Reset the existing saved empty formation through real server commands before validating')
parser.add_argument('--laps', type=int, default=1, choices=(1, 2, 3))
parser.add_argument('--timeout', type=int, default=1800)
args = parser.parse_args()
if args.build and args.recover_station:
    parser.error('--build and --recover-station are mutually exclusive')
raw = bytearray(hashlib.md5(b'CoasterEngineering:VolcanicAbyss:2.0').digest())
raw[6] = (raw[6] & 15) | 48
raw[8] = (raw[8] & 63) | 128
course = str(uuid.UUID(bytes=bytes(raw)))
recovery = None
owned_forces = set()
if args.recover_station:
    spec = importlib.util.spec_from_file_location('coaster_recovery_reader', Path(__file__).with_name('inspect-v2-world.py'))
    saved = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(saved)
    properties = dict(line.split('=', 1) for line in (args.server / 'server.properties').read_text().splitlines()
                      if line and not line.startswith('#') and '=' in line)
    world = args.server / properties.get('level-name', saved.WORLD_NAME)
    marker = saved.read_dat(world / 'data/coasterengineering_volcanic_v2.dat')['data']
    if not marker.get('ready') or marker.get('buildVersion') != 2:
        raise ValueError('Recovery requires the existing V2 world with passed live construction audits')
    courses = saved.read_dat(world / 'data/coasterengineering_courses.dat')['data'].get('Courses', [])
    matches = [entry for entry in courses if saved.uuid_string(entry.get('Id')) == course]
    if len(matches) != 1:
        raise ValueError('Recovery requires the single existing V2 course')
    leader_id = saved.uuid_string(matches[0].get('Vehicle'))
    formation = [entity for chunk in saved.region_chunks(world / 'entities') for entity in chunk.get('Entities', [])
                 if entity.get('id') == 'coasterengineering:coaster' and saved.uuid_string(entity.get('CoasterCourse')) == course]
    leaders = [entity for entity in formation if saved.uuid_string(entity.get('UUID')) == leader_id]
    if len(leaders) != 1 or len(formation) != 3 or any(entity.get('Passengers') for entity in formation):
        raise ValueError('Recovery requires the actual existing empty three-car formation and registered leader')
    if sorted(entity.get('CoasterCarIndex', -1) for entity in formation) != [0, 1, 2]:
        raise ValueError('Invalid saved formation indexes')
    if any(saved.uuid_string(entity.get('CoasterLeader')) != leader_id
           for entity in formation if saved.uuid_string(entity.get('UUID')) != leader_id):
        raise ValueError('Saved followers do not reference the existing registered leader')
    positions = [entity['Pos'] for entity in formation]
    if any(len(position) != 3 or not all(math.isfinite(float(v)) for v in position) for position in positions):
        raise ValueError('Invalid saved formation positions')
    previous_forced = set()
    forced_file = world / 'data/chunks.dat'
    if forced_file.exists():
        for packed in saved.read_dat(forced_file).get('data', {}).get('Forced', []):
            x, z = packed & 0xffffffff, (packed >> 32) & 0xffffffff
            previous_forced.add((x if x < 0x80000000 else x-0x100000000,
                                 z if z < 0x80000000 else z-0x100000000))
    min_x, max_x = math.floor(min(p[0] for p in positions)-5), math.floor(max(p[0] for p in positions)+5)
    min_z, max_z = math.floor(min(p[2] for p in positions)-5), math.floor(max(p[2] for p in positions)+5)
    needed = {(x, z) for x in range(min_x >> 4, (max_x >> 4)+1) for z in range(min_z >> 4, (max_z >> 4)+1)}
    needed.update((x, z) for x in range(-1, 1) for z in range(-12, -8))
    if len(needed) > 32:
        raise ValueError('Saved formation is spread too widely for bounded recovery')
    owned_forces = needed - previous_forced
    recovery = {'world': str(world.resolve()), 'leader_uuid': leader_id, 'saved_leader_position': leaders[0]['Pos'],
                'saved_car_positions': positions, 'required_chunks': sorted(needed),
                'preexisting_forced_chunks': sorted(previous_forced), 'nbt_writes': 0, 'completed': False,
                'phase': 'waiting_for_server', 'loaded_ticks': 0}
process = subprocess.Popen(['./run.sh', 'nogui'], cwd=args.server.resolve(),
                           stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, text=True, bufsize=1)
lines = queue.Queue()
def read_output():
    for line in process.stdout:
        lines.put(line)
reader = threading.Thread(target=read_output, daemon=True)
reader.start()
result = {'course_id': course, 'server_ready': False, 'built': False, 'laps': [], 'events': [], 'crash_observed': False}
if recovery:
    result['recovery'] = recovery
started = time.monotonic()
stopping = False
normal_stop_logged = False
recovery_tick_start = None
last_tick_query = 0.0
recovery_deadline = None
forces_added = False
def send(command):
    if process.poll() is not None:
        return
    try:
        process.stdin.write(command + '\n')
        process.stdin.flush()
    except (BrokenPipeError, OSError):
        result.setdefault('failure', 'Server command input closed before commissioning completed')
def release_forces():
    global forces_added
    if forces_added:
        for x, z in sorted(owned_forces):
            send(f'forceload remove {x*16} {z*16}')
        forces_added = False
        recovery['force_removal_requested'] = True
def stop():
    global stopping
    if not stopping:
        stopping = True
        release_forces()
        send('save-all flush')
        send('stop')
def detect_crash(line):
    global normal_stop_logged
    if any(token in line for token in ('Encountered an unexpected exception', 'Exception in server tick loop',
            'This crash report has been saved to:', 'Preparing crash report with UUID',
            'Failed to start the minecraft server', 'Exception caught during firing event:')):
        result['crash_observed'] = True
        result.setdefault('failure', line.strip())
        stop()
    if 'Stopping server' in line:
        normal_stop_logged = True
args.log.parent.mkdir(parents=True, exist_ok=True)
with args.log.open('w') as log:
    while process.poll() is None:
        now = time.monotonic()
        if time.monotonic() - started > args.timeout:
            result.setdefault('failure', f'Timed out after {args.timeout} real seconds')
            stop()
        if recovery and recovery['phase'] == 'loading_existing_chunks' and now-last_tick_query >= .5:
            send('time query gametime')
            last_tick_query = now
        if recovery_deadline and not recovery['completed'] and now > recovery_deadline:
            result.setdefault('failure', 'Existing-train recovery was not confirmed within45 real seconds')
            stop()
            recovery_deadline = None
        try:
            line = lines.get(timeout=.25)
        except queue.Empty:
            continue
        log.write(line)
        log.flush()
        detect_crash(line)
        if 'Done (' in line and not result['server_ready']:
            result['server_ready'] = True
            if recovery:
                recovery['phase'] = 'loading_existing_chunks'
                for x, z in sorted(owned_forces):
                    send(f'forceload add {x*16} {z*16}')
                forces_added = bool(owned_forces)
                recovery_deadline = time.monotonic()+45
                send('time query gametime')
                last_tick_query = time.monotonic()
            else:
                send('coaster volcano2' if args.build else 'coaster validate ' + course)
        if recovery and recovery['phase'] == 'loading_existing_chunks':
            match = re.search(r'The time is (\d+)', line)
            if match:
                tick = int(match.group(1))
                if recovery_tick_start is None:
                    recovery_tick_start = tick
                recovery['loaded_ticks'] = max(0, tick-recovery_tick_start)
                if recovery['loaded_ticks'] >= 40:
                    recovery['phase'] = 'checking_existing_leader'
                    send(f"execute if entity {recovery['leader_uuid']} run say COASTER_V2_RECOVERY_LEADER_LOADED")
        if recovery and 'COASTER_V2_RECOVERY_LEADER_LOADED' in line and recovery['phase'] == 'checking_existing_leader':
            recovery['phase'] = 'reset_requested'
            x, y, z = recovery['saved_leader_position']
            send(f"execute positioned {x:.8f} {y:.8f} {z:.8f} as {recovery['leader_uuid']} at @s run coaster reset")
        if recovery and 'Coaster parked at the start of its course.' in line and recovery['phase'] == 'reset_requested':
            recovery['phase'] = 'clearing_alarm'
            recovery['actual_reset_confirmation'] = line.strip()
            release_forces()
            send('coaster clear_alarm '+course)
        if recovery and 'Emergency alarm cleared for ' in line and recovery['phase'] == 'clearing_alarm':
            recovery['phase'] = 'completed'
            recovery['completed'] = True
            send('coaster validate '+course)
        if recovery and recovery['phase'] in ('reset_requested', 'clearing_alarm') and any(token in line for token in (
                'Reset refused:', 'Load every car and unload all riders', 'No coaster within 32 blocks.', 'No course with that UUID')):
            result['failure'] = line.strip()
            stop()
        if 'VOLCANIC_V2_READY' in line:
            result['built'] = True
            result['build_report'] = line.strip()
            send('coaster validate ' + course)
        if 'COASTER_RIDE_MOTION ' in line:
            result['motion'] = json.loads(line.split('COASTER_RIDE_MOTION ', 1)[1])
        if 'COASTER_RIDE_LIGHTING ' in line:
            result['lighting'] = json.loads(line.split('COASTER_RIDE_LIGHTING ', 1)[1])
        if 'ATTRACTION_EVENT' in line:
            result['events'].append(line.strip())
        if 'VOLCANIC_RIDE_VALIDATED PASSED' in line:
            result['laps'].append(line.strip())
            if len(result['laps']) < args.laps:
                send('coaster validate ' + course)
            else:
                send('coaster attraction status ' + course)
                stop()
        if 'VOLCANIC_V2_FAILED' in line or 'VOLCANIC_RIDE_VALIDATION_FAILED' in line:
            result['failure'] = line.strip()
            stop()
    reader.join(timeout=2)
    while not lines.empty():
        line = lines.get_nowait()
        log.write(line)
        detect_crash(line)
result['exit_code'] = process.wait()
result['normal_shutdown'] = stopping and result['exit_code'] == 0 and normal_stop_logged and not result['crash_observed']
result['elapsed_wall_seconds'] = round(time.monotonic() - started, 2)
result['passed'] = ('failure' not in result and result['server_ready']
                    and len(result['laps']) == args.laps and result['normal_shutdown']
                    and (not args.build or result['built']) and (not recovery or recovery['completed']))
if not result['passed']:
    result.setdefault('failure', 'Server ended without all commissioning conditions and normal shutdown being confirmed')
args.result.parent.mkdir(parents=True, exist_ok=True)
args.result.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('lighting','motion','events')}, ensure_ascii=False, indent=2))
raise SystemExit(0 if result['passed'] else 1)
