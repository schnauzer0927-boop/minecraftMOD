#!/usr/bin/env python3
"""Read-only V2 saved-seat lighting and conservative block-envelope diagnostics.

Minecraft voxel shapes and live light propagation remain authoritative. These
saved-block candidates do not certify rider comfort, scenery quality, or FPS.
"""
from __future__ import annotations

import argparse
import importlib.util
import itertools
import json
import math
from pathlib import Path
import sys


def module(name, filename):
    spec = importlib.util.spec_from_file_location(name, Path(__file__).with_name(filename))
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

SAVE = module("coaster_v2_reader", "inspect-v2-world.py")
AUDIT = module("coaster_geometry_reader", "audit-world-quality.py")
STAGES = ((0, "EXPLORE"), (13, "RUINS"), (24, "MONSTER"), (26, "ESCAPE_MONSTER"),
          (29, "ERUPTION"), (42, "DROP"), (45, "FINAL_ESCAPE"), (55, "RETURN"))


def audit_world(world: Path, step: float) -> dict:
    inventory = SAVE.inspect_world(world)
    matches = [course for course in inventory["courses"] if course["id"] == SAVE.COURSE_ID]
    if len(matches) != 1 or not matches[0]["closed"] or matches[0]["node_count"] != SAVE.POINT_COUNT:
        raise ValueError("Expected the actual closed V2 course in a stopped saved world")
    track = AUDIT.SavedSpline(matches[0]["points"])
    blocks = AUDIT.SavedBlocks(world, track)
    exposures = {name: {"BlockLight": [], "SkyLight": []} for _, name in STAGES}
    candidates = {}
    samples = []
    max_grade = 0
    for index in range(math.ceil(track.length / step)):
        distance = index * step
        anchor, right, up, forward, segment = track.sample(distance)
        stage = next(name for point_index, name in reversed(STAGES) if segment >= point_index)
        max_grade = max(max_grade, abs(forward[1]))
        eyes = [AUDIT.add(AUDIT.add(AUDIT.add(anchor, AUDIT.scale(right, seat)), AUDIT.scale(up, .45)), (0, 1.62, 0))
                for seat in (-.45, .45)]
        measurements = []
        for eye in eyes:
            position = tuple(math.floor(value) for value in eye)
            light = {layer: blocks.light(position, layer) for layer in ("BlockLight", "SkyLight")}
            measurements.append({"block_position": position, **light})
            for layer, value in light.items():
                exposures[stage][layer].append(value)
        for low, high in AUDIT.body_boxes(anchor, right, up, forward):
            for position in itertools.product(*(range(math.floor(a), math.floor(b - 1e-7) + 1) for a, b in zip(low, high))):
                state = blocks.state(position)
                if state is not None and state["Name"] not in AUDIT.PASSABLE:
                    candidates.setdefault(position, {"position": position, "state": state, "first_distance": distance, "stage": stage})
        samples.append({"distance": distance, "stage": stage, "position": anchor, "tangent": forward,
                        "eyes": measurements})
    stop_design = [{"id": "monster_pause", "control_point": 25, "distance": track.distances[25 * 128], "duration_ticks": 60},
                   {"id": "precipice_pause", "control_point": 42, "distance": track.distances[42 * 128], "duration_ticks": 35}]
    return {"world": inventory["world"], "course_id": SAVE.COURSE_ID, "length": track.length,
            "node_count": len(track.points), "step": step, "sample_count": len(samples),
            "seat_eye_sample_count": len(samples) * 2, "maximum_abs_vertical_tangent": max_grade,
            "stops": stop_design, "construction": inventory["construction"],
            "lighting": {stage: {layer: AUDIT.light_distribution(values) for layer, values in layers.items()}
                         for stage, layers in exposures.items()},
            "block_envelope_candidate_count": len(candidates), "block_envelope_candidates": list(candidates.values()),
            "missing_sample_chunks": sorted(blocks.missing), "route_samples": samples,
            "limitations": ["Block IDs are conservative saved-block diagnostics, not Minecraft collision voxel shapes.",
                            "Skylight with omitted storage is unknown; no fabricated brightness15 is substituted.",
                            "Uniform spatial sampling is distinct from the actual time-weighted moving-train light audit.",
                            "Room shell shape is not inferred from the old1.1 tunnel geometry; inspect live scenery screenshots."]}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--world", type=Path, required=True)
    parser.add_argument("--step", type=float, default=.5)
    parser.add_argument("--require-clear-candidates", action="store_true",
                        help="Fail on any conservative solid-block envelope candidate or missing sampled chunk")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        if not math.isfinite(args.step) or not .05 <= args.step <= 2:
            raise ValueError("Sample step must be finite and between0.05 and2 blocks")
        if args.output and args.output.resolve().is_relative_to(args.world.resolve()):
            raise ValueError("Write the diagnostic report outside the read-only world")
        with SAVE.stable_save(args.world):
            report = audit_world(args.world.resolve(), args.step)
        output = json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False) + "\n"
        if args.output:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(output, encoding="utf-8")
        print(json.dumps({key: value for key, value in report.items() if key not in ("route_samples", "block_envelope_candidates")}, indent=2))
        return 1 if args.require_clear_candidates and (report["block_envelope_candidate_count"] or report["missing_sample_chunks"]) else 0
    except (OSError, ValueError, KeyError, TypeError, ImportError) as error:
        print(json.dumps({"error": str(error)}), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
