#!/usr/bin/env python3
"""Compile only pure Java track code and measure the 2.0 ride at twenty ticks/sec.
This is not a Minecraft world, clearance, audio or camera runtime certification.
"""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import tempfile

JAVA = r'''
import dev.coasterengineering.track.*;
import java.util.*;
public final class V2CourseMeasurement {
 public static void main(String[] args) {
  SplineTrack track=VolcanicAbyssV2.create(TrackVec3.ZERO);
  Set<String> completed=new HashSet<>(); double distance=0,speed=0,total=0,peak=0,angle=0,g=0,stopSpeed=0;
  int pendingHold=0,holdTicks=0,tick=0;boolean finished=false;
  int[] ticks=new int[VolcanicAbyssV2.Stage.values().length];double[] meters=new double[ticks.length];
  double[] peaks=new double[ticks.length];
  double[] maxYaw=new double[4],maxPitch=new double[4],maxBank=new double[4],maxFrame=new double[4],maxFormationG=new double[4];
  for(tick=1;tick<=12000;tick++) {
   var stage=VolcanicAbyssV2.stageAt(track,distance);ticks[stage.ordinal()]++;
   if(pendingHold>0){pendingHold--;holdTicks++;continue;}
   var old=track.sample(distance);
   var state=RideDynamics.advanceProfiled(track,distance,speed,true,RideDynamics.MAX_SUPPORTED_SPEED,.025,
       VolcanicAbyssV2.profile(track,completed));
   double next=state.crossedFinish()?track.length():state.distance();
   for(var stop:VolcanicAbyssV2.showStops(track)) if(!completed.contains(stop.id())&&distance<=stop.distance()&&next>=stop.distance()) {
    stopSpeed=Math.max(stopSpeed,state.speed());next=stop.distance();pendingHold=stop.durationTicks();completed.add(stop.id());
    state=new RideDynamics.Step(next,0,false,true);break;
   }
   double moved=next-distance;total+=moved;meters[stage.ordinal()]+=moved;
   var now=track.sample(next);
   angle=Math.max(angle,Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,old.tangent().dot(now.tangent()))))));
   double curvature=track.sample(distance+.1).tangent().subtract(track.sample(distance-.1).tangent()).length()/.2;
   g=Math.max(g,speed*speed*curvature*400/9.81);peak=Math.max(peak,state.speed());
   peaks[stage.ordinal()]=Math.max(peaks[stage.ordinal()],state.speed()*72);
   for(int car=0;car<4;car++) {
    var oldCar=track.sample(distance-car*4);var newCar=track.sample(next-car*4);
    double oldYaw=Math.toDegrees(Math.atan2(-oldCar.tangent().x(),oldCar.tangent().z()));
    double newYaw=Math.toDegrees(Math.atan2(-newCar.tangent().x(),newCar.tangent().z()));
    double yawDelta=(newYaw-oldYaw)%360;if(yawDelta>=180)yawDelta-=360;if(yawDelta< -180)yawDelta+=360;
    double oldPitch=-Math.toDegrees(Math.atan2(oldCar.tangent().y(),Math.hypot(oldCar.tangent().x(),oldCar.tangent().z())));
    double newPitch=-Math.toDegrees(Math.atan2(newCar.tangent().y(),Math.hypot(newCar.tangent().x(),newCar.tangent().z())));
    maxYaw[car]=Math.max(maxYaw[car],Math.abs(yawDelta));maxPitch[car]=Math.max(maxPitch[car],Math.abs(newPitch-oldPitch));
    maxBank[car]=Math.max(maxBank[car],Math.abs(newCar.bankDegrees()-oldCar.bankDegrees()));
    var oldFrame=TrackFrame.from(oldCar);var newFrame=TrackFrame.from(newCar);
    double trace=oldFrame.right().dot(newFrame.right())+oldFrame.up().dot(newFrame.up())+oldFrame.forward().dot(newFrame.forward());
    maxFrame[car]=Math.max(maxFrame[car],Math.toDegrees(Math.acos(Math.max(-1,Math.min(1,(trace-1)/2)))));
    double carCurvature=track.sample(distance-car*4+.1).tangent().subtract(track.sample(distance-car*4-.1).tangent()).length()/.2;
    maxFormationG[car]=Math.max(maxFormationG[car],speed*speed*carCurvature*400/9.81);
   }
   distance=state.distance();speed=state.speed();
   if(state.crossedFinish()){finished=true;break;}
   if(state.stopped()&&pendingHold==0)throw new IllegalStateException("Unexpected stall at "+distance);
  }
  double minY=Double.POSITIVE_INFINITY,maxY=Double.NEGATIVE_INFINITY,maxGrade=0;
  for(double d=0;d<track.length();d+=.25){var sample=track.sample(d);minY=Math.min(minY,sample.position().y());
   maxY=Math.max(maxY,sample.position().y());maxGrade=Math.max(maxGrade,Math.abs(sample.tangent().y()));}
  System.out.printf(Locale.ROOT,"{\"status\":\"%s\",\"simulationOnly\":true,\"courseId\":\"%s\",\"controlPoints\":%d,"+
   "\"lengthBlocks\":%.12f,\"actualTravelDistance\":%.12f,\"ticksIncludingShows\":%d,\"secondsAt20TPS\":%.2f,"+
   "\"holdTicks\":%d,\"peakSpeedKmh\":%.9f,\"maximumTangentDegreesPerTick\":%.9f,"+
   "\"estimatedCentripetalG\":%.9f,\"maximumStopEntrySpeed\":%.9f,\"minimumY\":%.9f,\"maximumY\":%.9f,"+
   "\"maximumAbsoluteTangentY\":%.9f,\"stages\":[",finished?"PASSED":"FAILED",VolcanicAbyssV2.COURSE_ID,
   track.points().size(),track.length(),total,tick,tick/20.,holdTicks,peak*72,angle,g,stopSpeed,minY,maxY,maxGrade);
  int i=0;for(var stage:VolcanicAbyssV2.Stage.values()){
   if(i++>0)System.out.print(",");int n=stage.ordinal();
   System.out.printf(Locale.ROOT,"{\"id\":\"%s\",\"controlPoint\":%d,\"startDistance\":%.9f,\"ticks\":%d,"+
    "\"secondsAt20TPS\":%.2f,\"distanceTraveled\":%.9f,\"meanSpeedKmhIncludingShows\":%.9f,\"peakSpeedKmh\":%.9f}",
    stage,stage.firstPoint(),VolcanicAbyssV2.stageStart(track,stage),ticks[n],ticks[n]/20.,meters[n],
    meters[n]/Math.max(1,ticks[n])*72,peaks[n]);}
  System.out.print("],\"fourCarFormationMaximumYawDegreesPerTick\":"+Arrays.toString(maxYaw));
  System.out.print(",\"fourCarFormationMaximumPitchDegreesPerTick\":"+Arrays.toString(maxPitch));
  System.out.print(",\"fourCarFormationMaximumBankDegreesPerTick\":"+Arrays.toString(maxBank));
  System.out.print(",\"fourCarFormationMaximumFrameRotationDegreesPerTick\":"+Arrays.toString(maxFrame));
  System.out.print(",\"fourCarFormationEstimatedCentripetalG\":"+Arrays.toString(maxFormationG));
  System.out.println("}");if(!finished)System.exit(1);
 }
}
'''

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=Path('build/v2-course-design-measurement.json'))
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    with tempfile.TemporaryDirectory(prefix='coaster-v2-measure-') as temporary:
        folder = Path(temporary)
        probe = folder / 'V2CourseMeasurement.java'
        probe.write_text(JAVA, encoding='utf-8')
        sources = sorted((root / 'src/main/java/dev/coasterengineering/track').glob('*.java'))
        subprocess.run(['javac', '-encoding', 'UTF-8', '-d', str(folder), *map(str, sources), str(probe)], check=True)
        measured = subprocess.check_output(['java', '-cp', str(folder), 'V2CourseMeasurement'], text=True)
    import json
    data = json.loads(measured)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(data, indent=2) + '\n', encoding='utf-8')
    print(f"{data['status']}: {data['lengthBlocks']:.3f} blocks, {data['secondsAt20TPS']:.2f} seconds, "
          f"{data['peakSpeedKmh']:.2f} km/h; {args.out}")

if __name__ == '__main__':
    main()
