Thunder Mine Expedition 1.1.0 導入セット

Minecraft Java Edition 1.21.1 / NeoForge 21.1.228 / Java 21用。
本セットには独自補助MODと保存ワールドだけを収録。添付Create6.0.10/Sable2.0.6/SimulatedCoasters0.1.5の3JARは別途modsに必要。

1. Minecraftを終了し、使用中のゲームディレクトリを開く（標準は%APPDATA%\.minecraft）。
2. old thunder-mine-tools-1.0.0/1.0.1.jarをmods外へ移す。
3. 本セットのmodsの中身をゲームのmodsへコピー。補助MODは1.1.0の1本だけにする。
4. 新しく遊ぶ場合はsavesの中身をゲームのsavesへコピー。別名の1.1.0フォルダなので旧ワールドは上書きしない。今のワールドを続ける場合はsavesをコピーせず補助MODだけ追加・交換する。先に現在のワールドをバックアップする。
5. ゲームを起動し、ワールド選択の下のフォルダ名に1.1.0がある鉱山ワールドを開く。
6. 木製BOARDを右クリックして乗車・自動発車。帰還して停車後Shiftで降りる。灰色STARTは手動発車・条件を満たすずれた車両の駅帰還。黒色は緊急停止。

/mine_world status はチートなしで補助MOD1.1.0と運転状態を確認できる。不明なコマンドならゲームのMOD一覧とその起動構成のmodsを確認。
ゲームモードは/gamemode creative等で変更可能（セットの新規ワールドはコマンド許可済み）。

1.1.0実シングルプレイ: 171.425秒完走、最高59.27km/h相当、駅停止、BGM3曲の切替・降車後停止を確認。実際の聞こえ方・WindowsFPSは未検証。詳細はTEST_RESULTS.md。
BGM音量・ON/OFFはconfig/thunder-mine-tools-client.toml。速度はconfig/thunder_mine_tools-common.toml。
