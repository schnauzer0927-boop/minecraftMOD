package dev.thundermine.tools;

import org.junit.jupiter.api.Test;

/** JUnit discovery for the same original, independently runnable measurement scenarios. */
final class NativeCircuitProgressTest {
    @Test
    void measuresTwoCounterclockwiseCircuits() {
        NativeCircuitProgressStandaloneTest.twoActualCircuits(false);
    }

    @Test
    void measuresTwoClockwiseCircuits() {
        NativeCircuitProgressStandaloneTest.twoActualCircuits(true);
    }

    @Test
    void crossesTheAtan2BoundaryWithoutInventingALap() {
        NativeCircuitProgressStandaloneTest.wrapsAcrossNegativePi();
    }

    @Test
    void reverseTravelDoesNotCountAsCompletedCircuits() {
        NativeCircuitProgressStandaloneTest.reversingCannotInventLaps();
    }

    @Test
    void aRejectedPositionJumpDoesNotChangeMeasurements() {
        NativeCircuitProgressStandaloneTest.rejectedJumpLeavesMeasurementUnchanged();
    }

    @Test
    void rejectsInvalidMeasurementAndSavedValues() {
        NativeCircuitProgressStandaloneTest.invalidInputsAreRejected();
    }

    @Test
    void continuesSavedMeasurementsFromTheActualReloadPosition() {
        NativeCircuitProgressStandaloneTest.savedMeasurementsContinueFromReloadPosition();
    }

    @Test
    void usesMeasuredProgressForTheStationStoppingEnvelope() {
        NativeCircuitProgressStandaloneTest.stoppingDistanceUsesMeasuredProgress();
    }
}
