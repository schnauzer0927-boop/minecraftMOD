package dev.thundermine.tools;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

final class MineResumeStateTest {
    @Test
    void continuesDistanceTimeAndTargetProgressInsteadOfBeginningANewLap() {
        var restored = MineResumeState.restore(1000, 1000, 1, 0, 420, 420.02,
                420, 418.6, 71.25, 0.03);
        assertEquals(420.02, restored.unwrapped(), 1.0e-8);
        assertEquals(418.63, restored.measuredDistance(), 1.0e-8);
        assertEquals(71.25, restored.elapsedSeconds(), 0);
        assertEquals(0, restored.completedLaps());
    }

    @Test
    void preservesContinuousProgressAcrossTheCanonicalStationWrap() {
        var restored = MineResumeState.restore(1000, 1000, 2, 0, 999.9, 0.1,
                999.9, 999.2, 180, 0.2);
        assertEquals(1000.1, restored.unwrapped(), 1.0e-8);
        assertEquals(0.2, restored.projectionDelta(), 1.0e-8);
        assertEquals(999.4, restored.measuredDistance(), 1.0e-8);
    }

    @Test
    void supportsTinyNativeReloadRoundingWithoutCompletingAnUnfinishedJourney() {
        var restored = MineResumeState.restore(1035.979, 1035.979, 1, 0,
                678.123, 678.12292, 678.123, 677.7, 131.9, 0.00008);
        assertTrue(restored.unwrapped() < 1035.979 - 300);
        assertEquals(131.9, restored.elapsedSeconds(), 0);
        assertEquals(0, restored.completedLaps());
    }

    @Test
    void refusesChangedNativeGeometryAndPositionJumps() {
        assertThrows(IllegalArgumentException.class, () -> MineResumeState.restore(1000, 999,
                1, 0, 100, 100, 100, 100, 20, 0));
        assertThrows(IllegalArgumentException.class, () -> MineResumeState.restore(1000, 1000,
                1, 0, 100, 104, 100, 100, 20, 0.1));
        assertThrows(IllegalArgumentException.class, () -> MineResumeState.restore(1000, 1000,
                1, 0, 100, 100.1, 100, 100, 20, 5));
    }

    @Test
    void rejectsNonFiniteOrImpossibleSavedBookkeeping() {
        assertThrows(IllegalArgumentException.class, () -> MineResumeState.restore(1000, 1000,
                1, 0, 100, 100, 100, Double.NaN, 20, 0));
        assertThrows(IllegalArgumentException.class, () -> MineResumeState.restore(1000, 1000,
                1, 2, 100, 100, 100, 100, 20, 0));
        assertThrows(IllegalArgumentException.class, () -> MineResumeState.restore(1000, 1000,
                1, 0, 100, 100, 3000, 100, 20, 0));
        assertThrows(IllegalArgumentException.class, () -> MineResumeState.restore(1000, 1000,
                1, 0, 100, 100, 100, 100, 999, 0));
    }

    @Test
    void preservesAnInProgressStationHoldWithoutInventingDisconnectedTime() {
        var restored = MineResumeState.restore(1000, 1000, 1, 1, 999.9, 999.90001,
                999.9, 999.5, 189.0, 0.00001);
        assertEquals(1, restored.completedLaps());
        assertEquals(189.0, restored.elapsedSeconds(), 0);
        assertEquals(999.90001, restored.unwrapped(), 1.0e-8);
    }
}
