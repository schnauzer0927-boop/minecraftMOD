package dev.thundermine.tools;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

final class MineReturnEligibilityTest {
    @Test
    void acceptsTheRecordedCompletedJourneyAfterOldControllerDisplacement() {
        assertTrue(MineReturnEligibility.completedJourneyWasInterrupted("INTERRUPTED", 1, 1,
                1035.979211703434, 1035.564595930269, 189.275, 3.025));
    }

    @Test
    void refusesAnUnfinishedRideEvenIfItHasBeenHeldForALongTime() {
        assertFalse(MineReturnEligibility.completedJourneyWasInterrupted("INTERRUPTED", 0, 1,
                1035.979211703434, 193.0, 51.0, 30.0));
        assertFalse(MineReturnEligibility.completedJourneyWasInterrupted("INTERRUPTED", 1, 1,
                1035.979211703434, 193.0, 51.0, 30.0));
    }

    @Test
    void refusesFailedOrManuallyStoppedRidesDespiteOldCompletionMeasurements() {
        for (String phase : new String[]{"FAILED", "STOPPED", "RUNNING", "PASSED"})
            assertFalse(MineReturnEligibility.completedJourneyWasInterrupted(phase, 1, 1,
                    1035.979, 1035.5, 189.25, 3.025));
    }

    @Test
    void rejectsMissingStationEvidenceAndInvalidMeasurements() {
        assertFalse(MineReturnEligibility.completedJourneyWasInterrupted("INTERRUPTED", 1, 1,
                1035.979, 1035.5, 189.25, 0));
        assertFalse(MineReturnEligibility.completedJourneyWasInterrupted("INTERRUPTED", 1, 1,
                1035.979, Double.NaN, 189.25, 3.025));
        assertFalse(MineReturnEligibility.completedJourneyWasInterrupted("INTERRUPTED", 1, 1,
                1035.979, 10000, 189.25, 3.025));
        assertFalse(MineReturnEligibility.completedJourneyWasInterrupted("INTERRUPTED", 4, 4,
                1035.979, 1035.5 * 4, 189.25 * 4, 3.025));
    }
}
