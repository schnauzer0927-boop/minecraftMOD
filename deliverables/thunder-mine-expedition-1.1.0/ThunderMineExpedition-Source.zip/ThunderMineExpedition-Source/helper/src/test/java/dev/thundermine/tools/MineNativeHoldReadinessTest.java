package dev.thundermine.tools;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

final class MineNativeHoldReadinessTest {
    private static void observe(MineNativeHoldReadiness hold, boolean valid, double speed, double x,
                                double qz, double qw) {
        hold.observe(valid, speed, 0.025, x, 123.0128707886, 110.8446731567, 0, 0, qz, qw);
    }

    @Test
    void acceptsTheRecordedNativeResidualOnlyAfterTheActualPoseStaysHeld() {
        var hold = new MineNativeHoldReadiness();
        for (int i = 0; i < 20; i++) observe(hold, true, 0.051566454634, 60.6152458191, 0, 1);
        assertFalse(hold.ready());
        observe(hold, true, 0.051566454634, 60.6152458191, 0, 1);
        assertTrue(hold.ready());
    }

    @Test
    void rejectsRealContinuousMovementDespiteSmallNativeVelocity() {
        var hold = new MineNativeHoldReadiness();
        for (int i = 0; i < 80; i++) observe(hold, true, 0.051566, 60 + i * 0.025 * 0.051566, 0, 1);
        assertFalse(hold.ready());
    }

    @Test
    void requiresAValidNativeConstraintAndBoundedResidual() {
        var hold = new MineNativeHoldReadiness();
        for (int i = 0; i < 30; i++) observe(hold, true, 0.08, 60, 0, 1);
        assertTrue(hold.ready());
        observe(hold, false, 0.08, 60, 0, 1);
        assertFalse(hold.ready());
        for (int i = 0; i < 30; i++) observe(hold, true, 0.101, 60, 0, 1);
        assertFalse(hold.ready());
    }

    @Test
    void treatsQuaternionSignsAsTheSamePoseButRejectsActualRotation() {
        var hold = new MineNativeHoldReadiness();
        for (int i = 0; i < 30; i++) observe(hold, true, 0.01, 60, 0, i % 2 == 0 ? 1 : -1);
        assertTrue(hold.ready());
        observe(hold, true, 0.01, 60, Math.sin(Math.toRadians(0.5)), Math.cos(Math.toRadians(0.5)));
        assertFalse(hold.ready());
    }

    @Test
    void rejectsNonFinitePoseAndBrokenTimeMeasurements() {
        var hold = new MineNativeHoldReadiness();
        for (int i = 0; i < 30; i++) observe(hold, true, 0.01, 60, 0, 1);
        assertTrue(hold.ready());
        observe(hold, true, 0.01, Double.NaN, 0, 1);
        assertFalse(hold.ready());
        hold.observe(true, 0.01, Double.NaN, 60, 123, 110, 0, 0, 0, 1);
        assertFalse(hold.ready());
    }
}
