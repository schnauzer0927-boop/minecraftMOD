package dev.thundermine.tools;

/** Original dependency-free tests; these verify measurement arithmetic, not a Minecraft ride. */
public final class NativeCircuitProgressStandaloneTest {
    private static int checks;

    public static void main(String[] args) {
        twoActualCircuits(false);
        twoActualCircuits(true);
        wrapsAcrossNegativePi();
        reversingCannotInventLaps();
        rejectedJumpLeavesMeasurementUnchanged();
        invalidInputsAreRejected();
        savedMeasurementsContinueFromReloadPosition();
        stoppingDistanceUsesMeasuredProgress();
        System.out.println("PASS NativeCircuitProgress: 8 scenarios, " + checks + " assertions; native Minecraft runtime not executed");
    }

    static void twoActualCircuits(boolean clockwise) {
        double sign = clockwise ? -1.0 : 1.0;
        NativeCircuitProgress progress = new NativeCircuitProgress(12.5, -3.5,
                36.5, -3.5, 0.0, sign);
        int samples = 7200;
        for (int i = 1; i <= samples; i++) {
            double angle = sign * 4.0 * Math.PI * i / samples;
            progress.observeChecked(12.5 + 24.0 * Math.cos(angle),
                    -3.5 + 24.0 * Math.sin(angle), 0.025, 8.0, 0.10);
        }
        close(progress.progressRadians(), 4.0 * Math.PI, 1.0e-10, "Two actual position windings");
        close(progress.measuredDistance(), 24.0 * 4.0 * Math.PI, 0.001,
                "Distance from sampled positions agrees with a converged circuit perimeter");
        close(progress.remainingDistance(2, 24.0), 0.0, 1.0e-8, "Completed measured circuit has no remaining distance");
    }

    static void wrapsAcrossNegativePi() {
        double a = Math.PI - 0.002;
        NativeCircuitProgress progress = new NativeCircuitProgress(0, 0,
                24 * Math.cos(a), 24 * Math.sin(a), -Math.sin(a), Math.cos(a));
        double b = -Math.PI + 0.002;
        progress.observeChecked(24 * Math.cos(b), 24 * Math.sin(b), 0.025, 8.0, 0.10);
        close(progress.progressRadians(), 0.004, 1.0e-12, "Crossing atan2 branch cut does not invent a full lap");
        check(progress.measuredDistance() < 0.10, "Branch-cut distance remains physical");
    }

    static void reversingCannotInventLaps() {
        NativeCircuitProgress progress = new NativeCircuitProgress(0, 0, 24, 0, 0, 1);
        for (int i = 1; i <= 1000; i++) {
            double a = Math.PI * i / 1000.0;
            progress.observeChecked(24 * Math.cos(a), 24 * Math.sin(a), 0.025, 8.0, 0.10);
        }
        for (int i = 999; i >= 0; i--) {
            double a = Math.PI * i / 1000.0;
            progress.observeChecked(24 * Math.cos(a), 24 * Math.sin(a), 0.025, 8.0, 0.10);
        }
        close(progress.progressRadians(), 0, 1.0e-10, "Out-and-back movement completes no circuit");
        close(progress.measuredDistance(), 48 * Math.PI, 0.001, "Reverse travel still contributes real travelled distance");
        close(progress.remainingDistance(2, 24.0), 96 * Math.PI, 1.0e-8,
                "Travelled distance alone cannot satisfy two-lap completion");
    }

    static void rejectedJumpLeavesMeasurementUnchanged() {
        NativeCircuitProgress progress = new NativeCircuitProgress(0, 0, 24, 0, 0, 1);
        expectFailure(() -> progress.observeChecked(-24, 0, 0.025, 8, 0.10), "Teleport discontinuity is rejected");
        close(progress.progressRadians(), 0, 0, "Rejected jump does not advance circuit");
        close(progress.measuredDistance(), 0, 0, "Rejected jump does not increase distance");
        progress.observeChecked(24 * Math.cos(0.001), 24 * Math.sin(0.001), 0.025, 8, 0.10);
        close(progress.progressRadians(), 0.001, 1.0e-12, "Next real sample starts at the last valid position");
    }

    static void invalidInputsAreRejected() {
        expectFailure(() -> new NativeCircuitProgress(0, 0, 24, 0, 1, 0), "Radial station direction rejected");
        expectFailure(() -> new NativeCircuitProgress(Double.NaN, 0, 24, 0, 0, 1), "Non-finite origin rejected");
        NativeCircuitProgress progress = new NativeCircuitProgress(0, 0, 24, 0, 0, 1);
        expectFailure(() -> progress.observeChecked(24, 0, 0, 8, 0.1), "Zero timestep rejected");
        expectFailure(() -> progress.observeChecked(Double.POSITIVE_INFINITY, 0, 0.025, 8, 0.1), "Non-finite position rejected");
        expectFailure(() -> progress.restoreMeasurement(1, -1), "Negative saved distance rejected");
        expectFailure(() -> progress.restoreMeasurement(Double.NaN, 10), "Non-finite saved progress rejected");
    }

    static void savedMeasurementsContinueFromReloadPosition() {
        NativeCircuitProgress original = new NativeCircuitProgress(0, 0, 24, 0, 0, 1);
        double previousAngle = 0;
        for (int i = 1; i <= 1000; i++) {
            previousAngle = 3.0 * Math.PI * i / 1000.0;
            original.observe(24 * Math.cos(previousAngle), 24 * Math.sin(previousAngle));
        }
        NativeCircuitProgress loaded = new NativeCircuitProgress(0, 0,
                24 * Math.cos(previousAngle), 24 * Math.sin(previousAngle),
                -Math.sin(previousAngle), Math.cos(previousAngle));
        loaded.restoreMeasurement(original.progressRadians(), original.measuredDistance());
        double nextAngle = previousAngle + 0.001;
        loaded.observeChecked(24 * Math.cos(nextAngle), 24 * Math.sin(nextAngle), 0.025, 8, 0.1);
        original.observeChecked(24 * Math.cos(nextAngle), 24 * Math.sin(nextAngle), 0.025, 8, 0.1);
        close(loaded.progressRadians(), original.progressRadians(), 1.0e-12,
                "Reloaded observation uses real restored position without changing winding history");
        close(loaded.measuredDistance(), original.measuredDistance(), 1.0e-12,
                "Reload preserves prior measured distance and only adds new actual travel");
    }

    static void stoppingDistanceUsesMeasuredProgress() {
        NativeCircuitProgress progress = new NativeCircuitProgress(0, 0, 24, 0, 0, 1);
        double stopAngle = 4 * Math.PI - 0.12 / 24;
        for (int i = 1; i <= 7200; i++) {
            double a = stopAngle * i / 7200;
            progress.observeChecked(24 * Math.cos(a), 24 * Math.sin(a), 0.025, 8, 0.1);
        }
        close(progress.remainingDistance(2, 24), 0.12, 1.0e-9,
                "Measured angular progress leaves the intended station stopping offset");
        check(progress.progressRadians() >= 4 * Math.PI - 0.025,
                "Station's allowed final angular envelope includes the controlled stop offset");
        check(2 * 24 * Math.sin((4 * Math.PI - progress.progressRadians()) / 2) < 0.65,
                "Measured final position is inside the station's spatial envelope");
    }

    private static void close(double actual, double expected, double tolerance, String message) {
        check(Math.abs(actual - expected) <= tolerance,
                message + ": actual=" + actual + " expected=" + expected);
    }

    private static void expectFailure(Runnable action, String message) {
        boolean failed = false;
        try { action.run(); } catch (IllegalArgumentException expected) { failed = true; }
        check(failed, message);
    }

    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }
}
