package dev.thundermine.tools.audio;

import com.mojang.logging.LogUtils;
import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartSeatedEntityCollision;
import dev.thundermine.tools.NativeMineCourse;
import dev.thundermine.tools.ThunderMineTools;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.SelectMusicEvent;
import org.slf4j.Logger;

/** Physical-client-only onboard streams; never controls an entity, camera, or physics. */
@EventBusSubscriber(modid = ThunderMineTools.MOD_ID, value = Dist.CLIENT)
public final class RideAudioClient {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final List<OnboardLoop> LOOPS = new ArrayList<>();
    private static final Set<String> MISSING_RESOURCES = new HashSet<>();
    private static boolean receiverInstalled;
    private static long ticks;
    private static long lastPacketTick = -1000;
    private static RideAudioPayload latest;
    private static ClientLevel knownLevel;
    private static String desiredTrack;

    private RideAudioClient() {}

    private static void receive(RideAudioPayload payload) {
        Minecraft client = Minecraft.getInstance();
        if (client.player == null || client.level == null
                || !client.player.getUUID().equals(payload.playerId())
                || !client.level.dimension().location().equals(payload.dimension())
                || !NativeMineCourse.route().fingerprint().equals(payload.routeFingerprint())) return;
        boolean changed = latest == null || latest.active() != payload.active()
                || !latest.area().equals(payload.area()) || !latest.cartId().equals(payload.cartId());
        latest = payload;
        lastPacketTick = ticks;
        if (changed) LOGGER.info("MINE_AUDIO_CLIENT_STATE cart={} active={} area={} actualSpeed={} dimension={}",
                payload.cartId(), payload.active(), payload.area(), payload.actualSpeed(), payload.dimension());
    }

    @SubscribeEvent
    public static void onTick(ClientTickEvent.Post event) {
        if (!receiverInstalled) {
            // Common networking contains no direct reference to this client class.
            RideAudio.setClientReceiver(RideAudioClient::receive);
            receiverInstalled = true;
        }
        try {
            tickAudio();
        } catch (RuntimeException error) {
            desiredTrack = null;
            for (var loop : LOOPS) loop.finish("audio_exception");
            LOOPS.clear();
            if (ticks % 100L == 0L) LOGGER.warn("MINE_AUDIO_CLIENT_FAILED reason={}; native ride is unaffected", error.toString());
        }
    }

    private static void tickAudio() {
        Minecraft client = Minecraft.getInstance();
        if (client.isPaused()) return;
        ++ticks;
        if (knownLevel != client.level) {
            for (var loop : LOOPS) {
                loop.finish("world_changed");
                client.getSoundManager().stop(loop);
            }
            LOOPS.clear();
            knownLevel = client.level;
            latest = null;
            lastPacketTick = -1000;
        }
        boolean riding = genuineLocalRider(client);
        boolean enabled = RideAudioConfig.enabled() && RideAudioConfig.volume() > 0.0
                && client.options.getSoundSourceVolume(SoundSource.MUSIC) > 0.0F
                && client.options.getSoundSourceVolume(SoundSource.MASTER) > 0.0F;
        desiredTrack = riding && enabled ? RideAudioProgram.track(latest.area(), latest.actualSpeed()) : null;
        var manager = client.getSoundManager();
        LOOPS.removeIf(loop -> {
            if (loop.isStopped()) return true;
            if (!manager.isActive(loop) && ticks - loop.startedAt > 40L) {
                loop.finish("audio_engine_reloaded_or_unavailable");
                return true;
            }
            return false;
        });
        if (desiredTrack != null && LOOPS.stream().noneMatch(loop -> loop.track.equals(desiredTrack))) {
            if (hasResource(client, desiredTrack)) {
                // Only these three streams exist; at most one instance of each may fade.
                var loop = new OnboardLoop(desiredTrack, eventFor(desiredTrack), ticks);
                LOOPS.add(loop);
                manager.play(loop);
                LOGGER.info("MINE_AUDIO_CLIENT_START track={} cart={} source=MUSIC attenuation=NONE looping=true gain={} fadeSeconds={} registered=true resource=true",
                        desiredTrack, latest.cartId(), RideAudioConfig.volume(), RideAudioConfig.fadeSeconds());
            } else if (MISSING_RESOURCES.add(desiredTrack)) {
                LOGGER.warn("MINE_AUDIO_MISSING_RESOURCE track={}; ride continues normally", desiredTrack);
            }
        }
        for (var loop : LOOPS) {
            loop.targetVolume = loop.track.equals(desiredTrack) ? (float)RideAudioConfig.volume() : 0.0F;
        }
        if (ticks % 100L == 0L && !LOOPS.isEmpty()) {
            for (var loop : LOOPS) LOGGER.info("MINE_AUDIO_CLIENT_SAMPLE track={} playing={} volume={} target={} rider={} packetAgeTicks={} source=MUSIC attenuation=NONE",
                    loop.track, manager.isActive(loop), loop.volumeNow(), loop.targetVolume,
                    riding, ticks - lastPacketTick);
        }
    }

    private static boolean genuineLocalRider(Minecraft client) {
        if (latest == null || !latest.active() || ticks - lastPacketTick > 100L
                || client.player == null || client.level == null
                || !client.player.getUUID().equals(latest.playerId())
                || !client.level.dimension().location().equals(latest.dimension())
                || !(client.player.getVehicle() instanceof SeatEntity)) return false;
        try {
            var host = CoasterCartSeatedEntityCollision.hostCartFromVehicleChain(client.player);
            return host != null && host.getUniqueId().equals(latest.cartId());
        } catch (RuntimeException unavailableNativeClientState) {
            return false;
        }
    }

    /** Avoid unrelated vanilla music masking the onboard score; release when our fade ends. */
    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void onSelectMusic(SelectMusicEvent event) {
        if (LOOPS.stream().anyMatch(loop -> !loop.isStopped() && loop.volumeNow() > 0.005F)) {
            event.overrideMusic(null);
        }
    }

    private static boolean hasResource(Minecraft client, String track) {
        String file = switch (track) {
            case "ride_suspense" -> "mine_suspense";
            case "ride_chase" -> "canyon_chase";
            default -> "exploration";
        };
        return client.getSoundManager().getSoundEvent(
                ResourceLocation.fromNamespaceAndPath(ThunderMineTools.MOD_ID, track)) != null
                && client.getResourceManager().getResource(ResourceLocation.fromNamespaceAndPath(
                        ThunderMineTools.MOD_ID, "sounds/music/" + file + ".ogg")).isPresent();
    }

    private static SoundEvent eventFor(String track) {
        return switch (track) {
            case "ride_suspense" -> RideAudio.SUSPENSE.get();
            case "ride_chase" -> RideAudio.CHASE.get();
            default -> RideAudio.EXPLORATION.get();
        };
    }

    private static final class OnboardLoop extends AbstractTickableSoundInstance {
        private final String track;
        private final long startedAt;
        private float targetVolume;

        private OnboardLoop(String track, SoundEvent event, long startedAt) {
            super(event, SoundSource.MUSIC, SoundInstance.createUnseededRandom());
            this.track = track;
            this.startedAt = startedAt;
            volume = 0.0F;
            pitch = 1.0F;
            relative = true;
            attenuation = SoundInstance.Attenuation.NONE;
            looping = true;
            delay = 0;
            x = y = z = 0.0;
        }

        @Override public boolean canStartSilent() { return true; }

        @Override public void tick() {
            float step = (float)(Math.max(0.05, RideAudioConfig.volume())
                    / Math.max(4.0, RideAudioConfig.fadeSeconds() * 20.0));
            float delta = targetVolume - volume;
            volume += Math.max(-step, Math.min(step, delta));
            if (targetVolume <= 0.0F && volume <= 0.0001F) finish("fade_complete");
        }

        private float volumeNow() { return volume; }
        private void finish(String reason) {
            if (!isStopped()) LOGGER.info("MINE_AUDIO_CLIENT_STOP track={} reason={}", track, reason);
            stop();
        }
    }
}
