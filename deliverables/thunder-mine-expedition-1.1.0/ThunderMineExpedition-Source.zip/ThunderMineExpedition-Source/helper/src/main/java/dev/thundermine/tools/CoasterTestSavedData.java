package dev.thundermine.tools;

import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Our construction receipt only. Native tracks and carts remain in native storage. */
public final class CoasterTestSavedData extends SavedData {
    private static final String FILE_ID = "thunder_mine_test_course";
    private static final String DESIGN = "radius24-four-quarter-bezier-lift0-v1";
    private static final Factory<CoasterTestSavedData> FACTORY =
            new Factory<>(CoasterTestSavedData::new, CoasterTestSavedData::load, null);

    private boolean reserved;
    private boolean built;
    private boolean pending;
    private long pendingSinceTick;
    private boolean delayedInitialSnapApplied;
    private boolean invalid;
    private UUID cartId;
    private String lastMessage = "Not constructed";

    public CoasterTestSavedData() {}

    public static CoasterTestSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(FACTORY, FILE_ID);
    }

    private static CoasterTestSavedData load(CompoundTag tag, HolderLookup.Provider registries) {
        var data = new CoasterTestSavedData();
        data.reserved = tag.getBoolean("Reserved");
        data.built = tag.getBoolean("Built");
        data.pending = tag.getBoolean("Pending");
        data.pendingSinceTick = tag.getLong("PendingSinceTick");
        data.delayedInitialSnapApplied = tag.getBoolean("DelayedInitialSnapApplied");
        data.cartId = tag.hasUUID("Cart") ? tag.getUUID("Cart") : null;
        data.lastMessage = tag.getString("Message");
        data.invalid = tag.getBoolean("Invalid") || tag.getInt("Schema") != 1
                || !DESIGN.equals(tag.getString("Design"))
                || (data.built && (!data.reserved || data.cartId == null))
                || (data.pending && (!data.reserved || data.cartId == null || data.built));
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider registries) {
        tag.putInt("Schema", 1);
        tag.putString("Design", DESIGN);
        tag.putBoolean("Reserved", reserved);
        tag.putBoolean("Built", built);
        tag.putBoolean("Pending", pending);
        tag.putLong("PendingSinceTick", pendingSinceTick);
        tag.putBoolean("DelayedInitialSnapApplied", delayedInitialSnapApplied);
        tag.putBoolean("Invalid", invalid);
        if (cartId != null) tag.putUUID("Cart", cartId);
        tag.putString("Message", lastMessage);
        return tag;
    }

    public boolean reserved() { return reserved; }
    public boolean built() { return built; }
    public boolean pending() { return pending; }
    public long pendingSinceTick() { return pendingSinceTick; }
    public boolean delayedInitialSnapApplied() { return delayedInitialSnapApplied; }
    public boolean invalid() { return invalid; }
    public UUID cartId() { return cartId; }
    public String lastMessage() { return lastMessage; }

    void reserve() {
        reserved = true;
        built = false;
        pending = false;
        delayedInitialSnapApplied = false;
        cartId = null;
        lastMessage = "Construction reserved; completion not yet verified";
        setDirty();
    }

    void recordCart(UUID id) {
        cartId = id;
        setDirty();
    }

    void complete() {
        built = true;
        pending = false;
        lastMessage = "Native course and seated cart constructed; ride unverified";
        setDirty();
    }

    void fail(String message) {
        built = false;
        pending = false;
        lastMessage = message;
        setDirty();
    }

    void clear() {
        reserved = false;
        built = false;
        pending = false;
        cartId = null;
        delayedInitialSnapApplied = false;
        lastMessage = "Helper-owned test construction removed";
        setDirty();
    }

    void awaitNativeInitialization(long gameTick) {
        pending = true;
        pendingSinceTick = gameTick;
        delayedInitialSnapApplied = false;
        lastMessage = "Native objects placed; awaiting real physics engagement and stationary checks";
        setDirty();
    }

    void recordDelayedInitialSnap() {
        delayedInitialSnapApplied = true;
        setDirty();
    }
}
