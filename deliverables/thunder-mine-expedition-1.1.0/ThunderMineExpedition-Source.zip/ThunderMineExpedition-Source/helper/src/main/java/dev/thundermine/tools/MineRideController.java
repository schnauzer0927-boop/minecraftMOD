package dev.thundermine.tools;

import com.mojang.logging.LogUtils;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.contraptions.actors.seat.SeatBlock;
import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import dev.ryanhcode.sable.neoforge.event.ForgeSablePostPhysicsTickEvent;
import dev.ryanhcode.sable.neoforge.event.ForgeSablePrePhysicsTickEvent;
import dev.ryanhcode.sable.api.physics.constraint.ConstraintJointAxis;
import dev.ryanhcode.sable.api.physics.constraint.GenericConstraintConfiguration;
import dev.ryanhcode.sable.api.physics.constraint.GenericConstraintHandle;
import dev.ryanhcode.sable.physics.config.dimension_physics.DimensionPhysicsData;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartLinkPlacement;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartSeatedEntityCollision;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathGraphManager;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathTrackFrame;
import java.util.IdentityHashMap;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import org.joml.Quaterniond;
import org.joml.Vector3d;
import org.slf4j.Logger;

/** Native rail-guide motor/brake, real telemetry and station dispatch for Thunder Mine. */
public final class MineRideController {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final String SAVE_KEY = "thunder_mine_expedition";
    private static final Map<ServerLevel, State> STATES = new IdentityHashMap<>();
    private static final Map<ServerLevel, String> RESTORE_ERRORS = new IdentityHashMap<>();
    private static final Map<ServerLevel, GenericConstraintHandle> SAFETY_HOLDS = new IdentityHashMap<>();
    private static final BlockPos BOARD_BUTTON = new BlockPos(178, 84, -2);
    private static final BlockPos START_BUTTON = new BlockPos(178, 84, 0);
    private static final BlockPos STOP_BUTTON = new BlockPos(178, 84, 2);
    private static final double MAX_TARGET_SPEED = 16.5;
    private static final double MAX_CENTRIPETAL_ACCELERATION = 7.0;
    private static final double STATION_TOLERANCE = 0.65;
    private static final double STATION_STOP_OFFSET = 0.10;
    private static final double STATION_HOLD_SECONDS = 3.0;
    private static final double RETURN_TARGET_SPEED = 3.2;

    private MineRideController() {}

    public static void register(IEventBus gameBus) {
        gameBus.addListener(EventPriority.LOWEST, MineRideController::onPrePhysicsTick);
        gameBus.addListener(EventPriority.LOWEST, MineRideController::onPostPhysicsTick);
        gameBus.addListener(MineRideController::onLevelUnload);
        gameBus.addListener(MineRideController::onRightClickStation);
    }

    public static void armStationHold(ServerLevel level, ServerSubLevel cart) {
        State state = create(level, cart, "PARKED");
        STATES.put(level, state);
        physics(level).resetVelocity(cart);
        safetyHold(level, cart);
        persist(level, cart, state);
        LOGGER.info("MINE_MAIN_PARKED cart={} gameTick={} nativeLength={} fingerprint={} bearing={}",
                cart.getUniqueId(), level.getGameTime(), state.arc.totalLength(), NativeMineCourse.route().fingerprint(), bearing(cart));
    }

    /** Manual commissioning start: one real closed-course traversal, then stop at canonical station S0. */
    public static String start(ServerLevel level) {
        if (!heldAtStation(level) && eligibleForStationReturn(level)) return returnToStation(level);
        return validate(level, 1);
    }

    /** Physical recovery of a displaced, genuinely completed train; it does not fabricate a lap. */
    public static String returnToStation(ServerLevel level) {
        if (!eligibleForStationReturn(level))
            throw new IllegalStateException("Return refused: only a safely held interrupted train with valid completed-journey evidence may return. Failed or unfinished rides must not be bypassed.");
        ServerSubLevel cart = NativeMineCourse.cart(level);
        State previous = STATES.get(level);
        NativeMineCourse.requireClosedNativeTopology(level);
        verifyRevision(level, cart, previous);
        State returning = create(level, cart, "RUNNING");
        returning.unwrapped = returning.lastCanonical;
        returning.returningToStation = true;
        returning.manual = true;
        STATES.put(level, returning);
        begin(level, cart, returning, true);
        LOGGER.info("MINE_MAIN_RETURN_STARTED run={} cart={} gameTick={} canonicalStartS={} nativeLength={} targetSpeedCap={} nativePoseAssignments=0",
                returning.runId, returning.cartId, level.getGameTime(), returning.lastCanonical,
                returning.arc.totalLength(), RETURN_TARGET_SPEED);
        return "Returning the existing native train to the next station at at most 3.2 blocks/s; no teleport or completed lap is claimed.";
    }

    private static boolean eligibleForStationReturn(ServerLevel level) {
        if (!available(level) || RESTORE_ERRORS.containsKey(level)) return false;
        ServerSubLevel cart = NativeMineCourse.cart(level);
        if (cart == null || !ensure(level, cart)) return false;
        State state = STATES.get(level);
        if (state.returningToStation || !MineReturnEligibility.completedJourneyWasInterrupted(state.phase,
                state.completedLaps, state.targetLaps, state.arc.totalLength(), state.measuredDistance,
                state.elapsedSeconds, state.holdSeconds)) return false;
        GenericConstraintHandle hold = SAFETY_HOLDS.get(level);
        if (hold == null || !hold.isValid() || !state.nativeHoldReadiness.ready() || !NativeMineCourse.nativeEngaged(cart)) return false;
        Vec3 actual = bearing(cart);
        if (!safePose(cart, actual) || physics(level).getLinearVelocity(cart, new Vector3d()).length() > MineNativeHoldReadiness.MAX_RESIDUAL_SPEED) return false;
        CompoundTag user = cart.getUserDataTag();
        CompoundTag saved = user == null ? new CompoundTag() : user.getCompound(SAVE_KEY);
        if (!saved.hasUUID("cart_id") || !cart.getUniqueId().equals(saved.getUUID("cart_id"))
                || !NativeMineCourse.route().fingerprint().equals(saved.getString("route_fingerprint"))) return false;
        try {
            NativeMineCourse.requireClosedNativeTopology(level);
            verifyRevision(level, cart, state);
            MineNativeArc.Point point = state.arc.atHit(hit(level, actual));
            return Double.isFinite(point.distance()) && point.distance() >= 0.0 && point.distance() < state.arc.totalLength()
                    && chunksLoaded(level, actual, state.arc.positionAt(point.distance() + 8.0));
        } catch (RuntimeException error) { return false; }
    }

    public static String validate(ServerLevel level, int laps) {
        if (laps < 1 || laps > 3) throw new IllegalStateException("Commissioning permits one through three laps.");
        prepareExplicitStationRestart(level);
        if (!heldAtStation(level)) throw new IllegalStateException("Start refused: the native train must be held at its canonical station.");
        ServerSubLevel cart = NativeMineCourse.cart(level);
        State state = create(level, cart, "RUNNING");
        state.targetLaps = laps;
        state.manual = true;
        STATES.put(level, state);
        begin(level, cart, state, true);
        return "Native Thunder Mine run started: " + laps + " lap(s), "
                + String.format(Locale.ROOT, "%.2f", state.arc.totalLength()) + " measured rail blocks per lap.";
    }

    public static String stop(ServerLevel level) {
        ServerSubLevel cart = NativeMineCourse.cart(level);
        if (cart == null) return "No loaded native mine train.";
        physics(level).resetVelocity(cart);
        if (STATES.containsKey(level)) {
            State state = STATES.get(level);
            // Repeating an emergency-stop button must retain the original eligible journey.
            state.manualResumePermitted = state.running()
                    || "STOPPED".equals(state.phase) && state.manualResumePermitted
                    || "INTERRUPTED".equals(state.phase) && state.autoResumePermitted && runningPhase(state.resumePhase);
            if (state.running()) state.resumePhase = state.phase;
            state.autoResumePermitted = false;
            state.phase = "STOPPED";
            state.failure = "Manual stop: no automatic return or successful lap was invented";
            safetyHold(level, cart);
            persist(level, cart, state);
        }
        return "Actual native velocity stopped in place; the train was not teleported.";
    }

    /** Explicit resume preserves the physical journey; ordinary-save pauses may also resume after remount. */
    public static String resume(ServerLevel level) {
        if (!available(level)) throw new IllegalStateException("No committed native mine course.");
        ServerSubLevel cart = NativeMineCourse.cart(level);
        if (cart == null || !ensure(level, cart)) throw new IllegalStateException("Native mine train is unavailable.");
        State state = STATES.get(level);
        if (!("INTERRUPTED".equals(state.phase) && state.autoResumePermitted)
                && !("STOPPED".equals(state.phase) && state.manualResumePermitted)) {
            throw new IllegalStateException("This native hold is not a resumable saved ride or explicit manual stop.");
        }
        if (!resumeReady(level, cart, state)) throw new IllegalStateException("Resume refused: live native guide, course and loaded chunks must match the saved journey.");
        releaseSafetyHold(level);
        Vec3 actual = bearing(cart);
        MineNativeArc.Point point = state.arc.atHit(hit(level, actual));
        double delta = state.arc.signedDelta(state.lastCanonical, point.distance());
        state.unwrapped += delta;
        state.measuredDistance += actual.distanceTo(state.lastBearing);
        state.lastCanonical = point.distance();
        state.lastBearing = actual;
        state.lastVelocity.zero();
        state.phase = state.resumePhase;
        state.autoResumePermitted = false;
        state.manualResumePermitted = false;
        state.resumeWaitSeconds = 0.0;
        state.failure = "";
        physics(level).resetVelocity(cart);
        persist(level, cart, state);
        LOGGER.info("MINE_MAIN_RIDE_RESUMED run={} cart={} gameTick={} phase={} canonicalS={} unwrapped={} measuredDistance={} elapsedSeconds={} completedLaps={} seated={} nativePoseAssignments=0",
                state.runId, state.cartId, level.getGameTime(), state.phase, state.lastCanonical, state.unwrapped,
                state.measuredDistance, state.elapsedSeconds, state.completedLaps, seatedPlayers(level, cart));
        return "Resumed the existing native journey at its actual saved position; its distance, time and station target were retained.";
    }

    public static String status(ServerLevel level) {
        if (!available(level)) return "Main native course is not committed.";
        ServerSubLevel cart = NativeMineCourse.cart(level);
        if (cart == null) return "Saved mine train is unloaded: " + NativeMineCourse.cartId(level);
        if (!ensure(level, cart)) return "Native restore refused: " + RESTORE_ERRORS.get(level);
        State state = STATES.get(level);
        double speed = physics(level).getLinearVelocity(cart, new Vector3d()).length();
        return String.format(Locale.ROOT,
                "cart=%s phase=%s s=%.3f/%.3f measured=%.3f speed=%.3f blocks/s (%.2f km/h) laps=%d/%d seated=%d elapsed=%.2fs engaged=%s failure=%s",
                cart.getUniqueId(), state.phase, state.lastCanonical, state.arc.totalLength(), state.measuredDistance,
                speed, speed * 3.6, state.completedLaps, state.targetLaps, seatedPlayers(level, cart),
                state.elapsedSeconds, NativeMineCourse.nativeEngaged(cart), state.failure.isEmpty() ? "none" : state.failure);
    }

    public static boolean heldAtStation(ServerLevel level) {
        if (!available(level)) return false;
        ServerSubLevel cart = NativeMineCourse.cart(level);
        if (cart == null || !ensure(level, cart)) return false;
        State state = STATES.get(level);
        Vec3 point = bearing(cart);
        return ("PARKED".equals(state.phase) || "PASSED".equals(state.phase))
                && NativeMineCourse.nativeEngaged(cart) && point != null
                && point.distanceTo(NativeMineCourse.stationBearing(level)) <= STATION_TOLERANCE
                && state.arc.distanceFromStation(state.lastCanonical) <= STATION_TOLERANCE
                && (physics(level).getLinearVelocity(cart, new Vector3d()).length() <= 0.05
                || state.nativeHoldReadiness.ready()
                && physics(level).getLinearVelocity(cart, new Vector3d()).length() <= MineNativeHoldReadiness.MAX_RESIDUAL_SPEED);
    }

    public static String board(CommandSourceStack source) {
        if (!(source.getEntity() instanceof ServerPlayer player)) throw new IllegalStateException("A real station player is required.");
        ServerLevel level = player.serverLevel();
        if (level != source.getLevel() || player.getVehicle() != null) throw new IllegalStateException("Disembark before boarding in this world.");
        boolean stationBoarding = heldAtStation(level);
        if (!stationBoarding) {
            ServerSubLevel paused = NativeMineCourse.cart(level);
            if (paused == null || !ensure(level, paused)) throw new IllegalStateException("No available native train.");
            State state = STATES.get(level);
            if (!("INTERRUPTED".equals(state.phase) && state.autoResumePermitted
                    || "STOPPED".equals(state.phase) && state.manualResumePermitted)
                    || !resumeReady(level, paused, state)) {
                throw new IllegalStateException("The train must be at its station or safely held in a verified resumable journey.");
            }
        }
        ServerSubLevel cart = NativeMineCourse.cart(level);
        Vec3 point = bearing(cart);
        if (point == null || player.position().distanceToSqr(point) > 25.0) throw new IllegalStateException("Stand within five world blocks of the train.");
        BlockPos selected = null;
        for (BlockPos local : NativeMineCourse.seatLocals()) {
            BlockPos global = cart.getPlot().getCenterBlock().offset(local);
            if (level.getBlockState(global).is(AllBlocks.SEATS.get(DyeColor.BROWN).get())
                    && !SeatBlock.isSeatOccupied(level, global)) { selected = global; break; }
        }
        if (selected == null) throw new IllegalStateException("No empty original Create seat is available.");
        SeatBlock.sitDown(level, selected, player);
        Entity vehicle = player.getVehicle();
        var host = CoasterCartSeatedEntityCollision.hostCartFromVehicleChain(player);
        if (!(vehicle instanceof SeatEntity) || !"create:seat".equals(BuiltInRegistries.ENTITY_TYPE.getKey(vehicle.getType()).toString())
                || host == null || !host.getUniqueId().equals(cart.getUniqueId())) {
            player.stopRiding();
            if (vehicle instanceof SeatEntity seat && !seat.isVehicle()) seat.discard();
            throw new IllegalStateException("The actual Create seat/native cart identity did not match; boarding cancelled.");
        }
        LOGGER.info("MINE_MAIN_BOARDING player={} cart={} seat={} nativeHost={} gameTick={} playerWorld={} bearingWorld={}",
                player.getUUID(), cart.getUniqueId(), vehicle.getUUID(), host.getUniqueId(), level.getGameTime(), player.position(), point);
        return stationBoarding ? "Boarded the genuine Create seat. Automatic departure follows after the station wait. Shift disembarks."
                : "Remounted the genuine Create seat. An ordinary saved ride resumes after three seconds; a manual stop requires explicit resume.";
    }

    public static int seatedPlayers(ServerLevel level, ServerSubLevel cart) {
        int count = 0;
        for (ServerPlayer player : level.players()) {
            if (!(player.getVehicle() instanceof SeatEntity)) continue;
            var host = CoasterCartSeatedEntityCollision.hostCartFromVehicleChain(player);
            if (host != null && host.getUniqueId().equals(cart.getUniqueId())) count++;
        }
        return count;
    }

    public static Snapshot snapshot(ServerLevel level) {
        if (!available(level)) return null;
        ServerSubLevel cart = NativeMineCourse.cart(level);
        if (cart == null || !ensure(level, cart)) return null;
        State state = STATES.get(level);
        return new Snapshot(state.cartId, state.phase, state.lastCanonical, state.measuredDistance,
                state.arc.totalLength(), physics(level).getLinearVelocity(cart, new Vector3d()).length(),
                state.elapsedSeconds, state.completedLaps, state.area, seatedPlayers(level, cart));
    }

    /** Actual world buttons use the same guarded seat/dispatch API without operator commands. */
    public static void onRightClickStation(PlayerInteractEvent.RightClickBlock event) {
        if (event.getHand() != InteractionHand.MAIN_HAND || event.getLevel().isClientSide()) return;
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        ServerLevel level = player.serverLevel();
        if (!available(level) || !level.getBlockState(event.getPos()).is(BlockTags.BUTTONS)) return;
        BlockPos position = event.getPos();
        if (!position.equals(BOARD_BUTTON) && !position.equals(START_BUTTON) && !position.equals(STOP_BUTTON)) return;
        if (player.position().distanceToSqr(Vec3.atCenterOf(position)) > 25.0) return;
        String action = position.equals(BOARD_BUTTON) ? "BOARD" : position.equals(START_BUTTON) ? "START" : "STOP";
        try {
            String result = position.equals(BOARD_BUTTON) ? board(player.createCommandSourceStack())
                    : position.equals(START_BUTTON) ? start(level) : stop(level);
            player.sendSystemMessage(Component.literal(result));
            LOGGER.info("MINE_MAIN_BUTTON action={} player={} gameTick={} result={}", action, player.getUUID(), level.getGameTime(), result);
        } catch (RuntimeException error) {
            player.sendSystemMessage(Component.literal(message(error)));
            LOGGER.warn("MINE_MAIN_BUTTON_REFUSED action={} player={} reason={}", action, player.getUUID(), message(error));
        }
        // Leave vanilla button interaction intact for its physical pressed state and sound.
    }

    public static void onPrePhysicsTick(ForgeSablePrePhysicsTickEvent event) {
        ServerLevel level = event.getPhysicsSystem().getLevel();
        if (!available(level)) return;
        ServerSubLevel cart = NativeMineCourse.cart(level);
        if (cart == null || cart.isRemoved() || !ensure(level, cart)) return;
        State state = STATES.get(level);
        var pipeline = event.getPhysicsSystem().getPipeline();
        if (!state.running()) {
            pipeline.resetVelocity(cart);
            safetyHold(level, cart);
            return;
        }
        Vec3 actual = bearing(cart);
        if (!safePose(cart, actual) || !NativeMineCourse.nativeEngaged(cart)) {
            fail(level, cart, state, "Invalid native pose or disengaged rail guide"); return;
        }
        try {
            verifyRevision(level, cart, state);
            var hit = hit(level, actual);
            MineNativeArc.Point point = state.arc.atHit(hit);
            if (!chunksLoaded(level, point.point(), state.arc.positionAt(point.distance() + 8.0))) {
                fail(level, cart, state, "A required native track/scenery chunk is unloaded"); return;
            }
            var node = NativeMineCourse.nodes().get(point.segmentIndex());
            var next = NativeMineCourse.nodes().get((point.segmentIndex() + 1) % NativeMineCourse.nodes().size());
            double blend = Math.max(0.0, Math.min(1.0, (point.segmentT() - 0.65) / 0.35));
            blend = blend * blend * (3.0 - 2.0 * blend);
            double target = mix(MineRideSettings.target(node.area(), point.segmentIndex(), node.targetSpeed()),
                    MineRideSettings.target(next.area(), (point.segmentIndex() + 1) % NativeMineCourse.nodes().size(), next.targetSpeed()), blend);
            double acceleration = mix(node.acceleration(), next.acceleration(), blend);
            double braking = mix(node.braking(), next.braking(), blend);
            if (!Double.isFinite(target) || target < 0.0 || acceleration <= 0.0 || braking <= 0.0) {
                fail(level, cart, state, "Invalid authored segment motor/brake parameters"); return;
            }
            target = Math.min(state.returningToStation ? RETURN_TARGET_SPEED : MAX_TARGET_SPEED, target);
            if (point.curvature() > 1.0e-8) target = Math.min(target, Math.sqrt(MAX_CENTRIPETAL_ACCELERATION / point.curvature()));
            double remaining = state.targetLaps * state.arc.totalLength() - state.unwrapped;
            // Canonical S0 and authored station approach braking prevent cumulative parking drift.
            double stationBraking = Math.max(6.0, Math.min(8.0, braking));
            if (remaining < 25.0 || "HOLDING".equals(state.phase)) {
                braking = stationBraking;
                target = Math.min(target, Math.sqrt(2.0 * braking * Math.max(0.0, remaining - STATION_STOP_OFFSET)));
                state.phase = "HOLDING".equals(state.phase) ? "HOLDING" : "BRAKING";
            }
            if ("HOLDING".equals(state.phase)) target = 0.0;
            Vec3 forward = point.forward();
            Vector3d velocity = pipeline.getLinearVelocity(cart, new Vector3d());
            double along = velocity.x * forward.x + velocity.y * forward.y + velocity.z * forward.z;
            double dt = event.getTimeStep();
            double desiredEnd = along + clamp(target - along, -braking * dt, acceleration * dt);
            // Feed-forward uses Sable's actual configured gravity, preserving native geometry/constraints.
            Vector3d gravity = DimensionPhysicsData.getGravity(level);
            double gravityAlong = gravity.x * forward.x + gravity.y * forward.y + gravity.z * forward.z;
            double delta = desiredEnd - along - gravityAlong * dt;
            pipeline.addLinearAndAngularVelocity(cart, new Vector3d(forward.x, forward.y, forward.z).mul(delta), new Vector3d());
            state.area = node.area();
            state.maxCurvature = Math.max(state.maxCurvature, point.curvature());
            state.maxGuideError = Math.max(state.maxGuideError, actual.distanceTo(point.point()));
        } catch (RuntimeException error) { fail(level, cart, state, message(error)); }
    }

    public static void onPostPhysicsTick(ForgeSablePostPhysicsTickEvent event) {
        ServerLevel level = event.getPhysicsSystem().getLevel();
        if (!available(level)) return;
        ServerSubLevel cart = NativeMineCourse.cart(level);
        if (cart == null || cart.isRemoved() || !ensure(level, cart)) return;
        State state = STATES.get(level);
        Vec3 actual = bearing(cart);
        if (!safePose(cart, actual)) { fail(level, cart, state, "Invalid native pose after physics"); return; }
        Vector3d velocity = event.getPhysicsSystem().getPipeline().getLinearVelocity(cart, new Vector3d());
        double dt = event.getTimeStep();
        GenericConstraintHandle held = SAFETY_HOLDS.get(level);
        var heldPosition = cart.logicalPose().position();
        var heldOrientation = cart.logicalPose().orientation();
        state.nativeHoldReadiness.observe(held != null && held.isValid() && NativeMineCourse.nativeEngaged(cart),
                velocity.length(), dt, heldPosition.x(), heldPosition.y(), heldPosition.z(),
                heldOrientation.x(), heldOrientation.y(), heldOrientation.z(), heldOrientation.w());
        try {
            verifyRevision(level, cart, state);
            MineNativeArc.Point point = state.arc.atHit(hit(level, actual));
            if (state.running()) {
                if (!NativeMineCourse.nativeEngaged(cart)) { fail(level, cart, state, "Native guide disengaged during physical movement"); return; }
                double step = actual.distanceTo(state.lastBearing);
                double arcStep = state.arc.signedDelta(state.lastCanonical, point.distance());
                if (step > 18.0 * dt + 0.12 || Math.abs(arcStep) > 18.0 * dt + 0.35) {
                    fail(level, cart, state, "Discontinuous actual native position/arc sample"); return;
                }
                if (arcStep < -0.10) {
                    fail(level, cart, state, "Native train backtracked beyond the projection tolerance"); return;
                }
                state.unwrapped += arcStep;
                state.measuredDistance += step;
                state.elapsedSeconds += dt;
                state.maxNativeSpeed = Math.max(state.maxNativeSpeed, velocity.length());
                state.maxMeasuredSpeed = Math.max(state.maxMeasuredSpeed, step / dt);
                state.maxAcceleration = Math.max(state.maxAcceleration, velocity.distance(state.lastVelocity) / dt);
                state.lastVelocity.set(velocity);
                state.lastBearing = actual;
                state.lastCanonical = point.distance();
                state.completedLaps = Math.max(0, Math.min(state.targetLaps - 1,
                        (int)Math.floor(Math.max(0.0, state.unwrapped) / state.arc.totalLength())));
                double remaining = state.targetLaps * state.arc.totalLength() - state.unwrapped;
                boolean finalStation = remaining <= STATION_TOLERANCE
                        && actual.distanceTo(NativeMineCourse.stationBearing(level)) <= STATION_TOLERANCE;
                if (finalStation && velocity.length() <= 0.05) {
                    state.phase = "HOLDING";
                    state.holdSeconds += dt;
                    state.completedLaps = state.targetLaps;
                } else if ("HOLDING".equals(state.phase)) {
                    fail(level, cart, state, "Train left the canonical stationary station envelope"); return;
                }
                if (state.holdSeconds >= STATION_HOLD_SECONDS) {
                    boolean returned = state.returningToStation;
                    state.phase = returned ? "PARKED" : "PASSED";
                    state.returningToStation = false;
                    state.waitSeconds = 0.0;
                    state.waitRequired = 10.0;
                    safetyHold(level, cart);
                    if (returned) {
                        state.completedLaps = 0;
                        LOGGER.info("MINE_MAIN_RETURNED_TO_STATION run={} cart={} gameTick={} phase=PARKED measuredDistance={} elapsedSeconds={} maxNativeSpeed={} maxMeasuredSpeed={} stationDistance={} stationarySeconds={} completedLaps=0 nativePoseAssignments=0",
                                state.runId, state.cartId, level.getGameTime(), state.measuredDistance, state.elapsedSeconds,
                                state.maxNativeSpeed, state.maxMeasuredSpeed, actual.distanceTo(NativeMineCourse.stationBearing(level)), state.holdSeconds);
                    } else LOGGER.info("MINE_MAIN_RIDE_PASSED run={} cart={} gameTick={} laps={} nativeArcLength={} measuredDistance={} elapsedSeconds={} maxNativeSpeed={} maxMeasuredSpeed={} maxAcceleration={} maxCurvature={} maxGuideError={} stationDistance={} stationarySeconds={} nativePoseAssignments=0",
                            state.runId, state.cartId, level.getGameTime(), state.completedLaps, state.arc.totalLength(),
                            state.measuredDistance, state.elapsedSeconds, state.maxNativeSpeed, state.maxMeasuredSpeed,
                            state.maxAcceleration, state.maxCurvature, state.maxGuideError,
                            actual.distanceTo(NativeMineCourse.stationBearing(level)), state.holdSeconds);
                    persist(level, cart, state);
                } else if (state.elapsedSeconds > 480.0 * state.targetLaps) {
                    fail(level, cart, state, "Native ride exceeded its safe commissioning timeout"); return;
                }
            } else if (("PARKED".equals(state.phase) || "PASSED".equals(state.phase)) && heldAtStation(level)) {
                state.lastCanonical = point.distance();
                if (seatedPlayers(level, cart) > 0) {
                    state.waitSeconds += dt;
                    if (state.waitSeconds >= state.waitRequired) {
                        State fresh = create(level, cart, "RUNNING");
                        STATES.put(level, fresh);
                        begin(level, cart, fresh, false);
                        state = fresh;
                    }
                } else state.waitSeconds = 0.0;
            } else if ("INTERRUPTED".equals(state.phase) && state.autoResumePermitted) {
                if (seatedPlayers(level, cart) > 0 && resumeReady(level, cart, state)) {
                    state.resumeWaitSeconds += dt;
                    if (state.resumeWaitSeconds >= 3.0) resume(level);
                } else state.resumeWaitSeconds = 0.0;
            }
            // Keep native save evidence current even when saving between console log samples.
            if (state.running()) persist(level, cart, state);
            if (state.lastLogTick != level.getGameTime() && level.getGameTime() % 20L == 0L) {
                state.lastLogTick = level.getGameTime();
                if (state.running() || state.waitSeconds > 0.0) {
                    LOGGER.info("MINE_MAIN_SAMPLE run={} cart={} gameTick={} phase={} s={} unwrapped={} total={} measuredDistance={} nativeSpeed={} elapsed={} laps={} area={} engaged={} seated={} bearing={} quaternion={} loadedAhead={}",
                            state.runId, state.cartId, level.getGameTime(), state.phase, state.lastCanonical, state.unwrapped,
                            state.arc.totalLength(), state.measuredDistance, velocity.length(), state.elapsedSeconds,
                            state.completedLaps, state.area, NativeMineCourse.nativeEngaged(cart), seatedPlayers(level, cart),
                            actual, cart.logicalPose().orientation(), chunksLoaded(level, actual, state.arc.positionAt(point.distance() + 8.0)));
                }
                persist(level, cart, state);
            }
        } catch (RuntimeException error) { fail(level, cart, state, message(error)); }
    }

    public static void detach(ServerLevel level) {
        STATES.remove(level); RESTORE_ERRORS.remove(level);
        GenericConstraintHandle hold = SAFETY_HOLDS.remove(level);
        if (hold != null && hold.isValid()) hold.remove();
    }
    private static void onLevelUnload(LevelEvent.Unload event) { if (event.getLevel() instanceof ServerLevel level) detach(level); }

    private static boolean available(ServerLevel level) {
        if (!level.dimension().equals(Level.OVERWORLD)) return false;
        MineCourseSavedData receipt = MineCourseSavedData.get(level);
        // Display names are player-editable; construction identity belongs to the native receipt.
        return receipt.built() && receipt.reserved() && !receipt.invalid() && receipt.cartId() != null
                && NativeMineCourse.route().fingerprint().equals(receipt.fingerprint());
    }

    private static State create(ServerLevel level, ServerSubLevel cart, String phase) {
        MineNativeArc arc = new MineNativeArc(level);
        Vec3 actual = bearing(cart);
        if (!safePose(cart, actual)) throw new IllegalStateException("Invalid native train pose");
        MineNativeArc.Point point = arc.atHit(hit(level, actual));
        State state = new State(cart.getUniqueId(), arc, phase, actual, point.distance());
        state.unwrapped = point.distance() > arc.totalLength() / 2.0 ? point.distance() - arc.totalLength() : point.distance();
        state.area = NativeMineCourse.nodes().get(point.segmentIndex()).area();
        return state;
    }

    private static boolean ensure(ServerLevel level, ServerSubLevel cart) {
        if (STATES.containsKey(level)) return true;
        if (RESTORE_ERRORS.containsKey(level)) {
            physics(level).resetVelocity(cart);
            // Native body registration may settle after a failed first restore attempt.
            // Keep trying the supported physical hold; do not rewrite the saved ride or report success.
            safetyHold(level, cart);
            return false;
        }
        try {
            State state = create(level, cart, "INTERRUPTED");
            CompoundTag user = cart.getUserDataTag();
            CompoundTag saved = user == null ? new CompoundTag() : user.getCompound(SAVE_KEY);
            boolean identity = saved.hasUUID("cart_id") && cart.getUniqueId().equals(saved.getUUID("cart_id"));
            boolean fingerprint = NativeMineCourse.route().fingerprint().equals(saved.getString("route_fingerprint"));
            double speed = physics(level).getLinearVelocity(cart, new Vector3d()).length();
            boolean parked = bearing(cart).distanceTo(NativeMineCourse.stationBearing(level)) <= STATION_TOLERANCE
                    && state.arc.distanceFromStation(state.lastCanonical) <= STATION_TOLERANCE
                    && NativeMineCourse.nativeEngaged(cart) && speed <= 0.05;
            String previous = saved.getString("phase");
            if (identity && fingerprint) restoreMeasurements(state, saved);
            if (identity && fingerprint && parked && ("PARKED".equals(previous) || "PASSED".equals(previous))) {
                state.phase = previous;
                state.completedLaps = saved.getInt("completed_laps");
                state.targetLaps = Math.max(1, saved.getInt("target_laps"));
                if (state.targetLaps > 3) throw new IllegalStateException("Invalid saved lap target");
                state.measuredDistance = finiteNonnegative(saved.getDouble("measured_distance"));
                state.elapsedSeconds = finiteNonnegative(saved.getDouble("elapsed_seconds"));
                state.maxNativeSpeed = finiteNonnegative(saved.getDouble("max_native_speed"));
                state.maxMeasuredSpeed = finiteNonnegative(saved.getDouble("max_measured_speed"));
                state.maxAcceleration = finiteNonnegative(saved.getDouble("max_acceleration"));
                state.maxCurvature = finiteNonnegative(saved.getDouble("max_curvature"));
                state.maxGuideError = finiteNonnegative(saved.getDouble("max_guide_error"));
                state.holdSeconds = finiteNonnegative(saved.getDouble("hold_seconds"));
                double savedUnwrapped = saved.getDouble("unwrapped_distance");
                double savedLength = saved.getDouble("native_arc_length");
                if ("PASSED".equals(previous) && (state.completedLaps != state.targetLaps
                        || !Double.isFinite(savedUnwrapped)
                        || savedUnwrapped < state.arc.totalLength() * state.targetLaps - STATION_TOLERANCE
                        || savedUnwrapped > state.arc.totalLength() * state.targetLaps + STATION_TOLERANCE
                        || !Double.isFinite(savedLength) || Math.abs(savedLength - state.arc.totalLength()) > 0.05
                        || state.measuredDistance < state.arc.totalLength() * state.targetLaps * 0.95
                        || state.holdSeconds < STATION_HOLD_SECONDS)) {
                    state.phase = "INTERRUPTED";
                    state.failure = "Saved ride evidence did not meet the native completion criteria";
                } else if ("PASSED".equals(previous)) state.unwrapped = savedUnwrapped;
            } else if (identity && fingerprint && (runningPhase(previous)
                    || "INTERRUPTED".equals(previous) && saved.getBoolean("auto_resume_permitted")
                    || "STOPPED".equals(previous) && saved.getBoolean("manual_resume_permitted"))) {
                String restorePhase = runningPhase(previous) ? previous : saved.getString("resume_phase");
                if (!runningPhase(restorePhase)) throw new IllegalStateException("Invalid saved resume phase");
                Vec3 actual = bearing(cart);
                double actualBearingDelta = saved.contains("bearing_x") ? actual.distanceTo(new Vec3(
                        saved.getDouble("bearing_x"), saved.getDouble("bearing_y"), saved.getDouble("bearing_z"))) : Double.NaN;
                MineResumeState.Restored restored = MineResumeState.restore(state.arc.totalLength(),
                        saved.getDouble("native_arc_length"), state.targetLaps, state.completedLaps,
                        saved.getDouble("canonical_distance"), state.lastCanonical, saved.getDouble("unwrapped_distance"),
                        state.measuredDistance, state.elapsedSeconds, actualBearingDelta);
                state.unwrapped = restored.unwrapped();
                state.measuredDistance = restored.measuredDistance();
                state.elapsedSeconds = restored.elapsedSeconds();
                state.resumePhase = restorePhase;
                state.autoResumePermitted = !"STOPPED".equals(previous);
                state.manualResumePermitted = "STOPPED".equals(previous);
                state.phase = "STOPPED".equals(previous) ? "STOPPED" : "INTERRUPTED";
                state.failure = state.autoResumePermitted ? "Ordinary saved journey held until a genuine passenger remounts"
                        : "Explicit manual stop retained; only explicit resume may release it";
                LOGGER.info("MINE_MAIN_RESUME_AVAILABLE cart={} savedPhase={} restorePhase={} unwrapped={} measuredDistance={} elapsed={} projectionDelta={} automaticAfterRemount={}",
                        cart.getUniqueId(), previous, restorePhase, state.unwrapped, state.measuredDistance,
                        state.elapsedSeconds, restored.projectionDelta(), state.autoResumePermitted);
            } else {
                if (identity && fingerprint && "STOPPED".equals(previous)) state.phase = "STOPPED";
                if (identity && fingerprint && "FAILED".equals(previous)) state.phase = "FAILED";
                state.failure = "Unfinished/mismatched reload held safely in place; no station return was fabricated";
            }
            if (saved.hasUUID("run_id")) state.runId = saved.getUUID("run_id");
            STATES.put(level, state);
            safetyHold(level, cart);
            Vec3 actual = bearing(cart);
            double savedDelta = saved.contains("bearing_x") ? actual.distanceTo(new Vec3(saved.getDouble("bearing_x"), saved.getDouble("bearing_y"), saved.getDouble("bearing_z"))) : Double.NaN;
            LOGGER.info("MINE_MAIN_RELOAD cart={} gameTick={} savedPhase={} restoredPhase={} uuidMatches={} fingerprintMatches={} actualSpeed={} savedBearingDelta={} actualBearing={} canonicalS={}",
                    cart.getUniqueId(), level.getGameTime(), previous, state.phase, identity, fingerprint, speed, savedDelta, actual, state.lastCanonical);
            persist(level, cart, state);
            return true;
        } catch (RuntimeException error) {
            RESTORE_ERRORS.put(level, message(error)); physics(level).resetVelocity(cart); safetyHold(level, cart);
            LOGGER.error("MINE_MAIN_RESTORE_REFUSED cart={} reason={}", cart.getUniqueId(), message(error)); return false;
        }
    }

    private static void verifyRevision(ServerLevel level, ServerSubLevel cart, State state) {
        if (state.arc.graphRevision() == CoasterPathGraphManager.get(level).revision()) return;
        MineNativeArc refreshed = new MineNativeArc(level);
        if (Math.abs(refreshed.totalLength() - state.arc.totalLength()) > 0.05) throw new IllegalStateException("Native course geometry changed while commissioned");
        state.arc = refreshed;
    }

    private static void begin(ServerLevel level, ServerSubLevel cart, State state, boolean manual) {
        state.manual = manual;
        releaseSafetyHold(level);
        state.nativeHoldReadiness.reset();
        physics(level).resetVelocity(cart);
        persist(level, cart, state);
        LOGGER.info("MINE_MAIN_RIDE_STARTED run={} cart={} gameTick={} manual={} targetLaps={} nativeLength={} canonicalStartS={} seated={}",
                state.runId, state.cartId, level.getGameTime(), manual, state.targetLaps, state.arc.totalLength(), state.lastCanonical, seatedPlayers(level, cart));
    }

    private static void restoreMeasurements(State state, CompoundTag saved) {
        state.returningToStation = saved.getBoolean("returning_to_station");
        state.completedLaps = saved.getInt("completed_laps");
        state.targetLaps = Math.max(1, saved.getInt("target_laps"));
        if (state.targetLaps > 3 || state.completedLaps < 0 || state.completedLaps > state.targetLaps) throw new IllegalStateException("Invalid saved lap bookkeeping");
        state.measuredDistance = finiteNonnegative(saved.getDouble("measured_distance"));
        state.elapsedSeconds = finiteNonnegative(saved.getDouble("elapsed_seconds"));
        state.maxNativeSpeed = finiteNonnegative(saved.getDouble("max_native_speed"));
        state.maxMeasuredSpeed = finiteNonnegative(saved.getDouble("max_measured_speed"));
        state.maxAcceleration = finiteNonnegative(saved.getDouble("max_acceleration"));
        state.maxCurvature = finiteNonnegative(saved.getDouble("max_curvature"));
        state.maxGuideError = finiteNonnegative(saved.getDouble("max_guide_error"));
        state.holdSeconds = finiteNonnegative(saved.getDouble("hold_seconds"));
    }

    private static boolean runningPhase(String phase) {
        return "RUNNING".equals(phase) || "BRAKING".equals(phase) || "HOLDING".equals(phase);
    }

    private static boolean resumeReady(ServerLevel level, ServerSubLevel cart, State state) {
        if (!NativeMineCourse.nativeEngaged(cart) || !runningPhase(state.resumePhase)) return false;
        GenericConstraintHandle hold = SAFETY_HOLDS.get(level);
        if (hold == null || !hold.isValid()) return false;
        Vec3 actual = bearing(cart);
        if (!safePose(cart, actual) || !state.nativeHoldReadiness.ready()
                || physics(level).getLinearVelocity(cart, new Vector3d()).length() > MineNativeHoldReadiness.MAX_RESIDUAL_SPEED) return false;
        try {
            verifyRevision(level, cart, state);
            if (!NativeMineCourse.route().fingerprint().equals(MineCourseSavedData.get(level).fingerprint())) return false;
            MineNativeArc.Point point = state.arc.atHit(hit(level, actual));
            return chunksLoaded(level, actual, state.arc.positionAt(point.distance() + 8.0))
                    && Math.abs(state.arc.signedDelta(state.lastCanonical, point.distance())) <= MineResumeState.MAX_RESTORE_POSITION_DELTA
                    && actual.distanceTo(state.lastBearing) <= MineResumeState.MAX_RESTORE_POSITION_DELTA;
        } catch (RuntimeException error) { return false; }
    }

    private static void releaseSafetyHold(ServerLevel level) {
        GenericConstraintHandle hold = SAFETY_HOLDS.remove(level);
        if (hold != null && hold.isValid()) hold.remove();
    }

    /** A manual station start may release its own STOP latch; interrupted/failed runs remain latched. */
    private static void prepareExplicitStationRestart(ServerLevel level) {
        if (!available(level)) return;
        ServerSubLevel cart = NativeMineCourse.cart(level);
        if (cart == null || !ensure(level, cart)) return;
        State state = STATES.get(level);
        if (!"STOPPED".equals(state.phase)) return;
        Vec3 point = bearing(cart);
        if (point == null || !NativeMineCourse.nativeEngaged(cart)
                || point.distanceTo(NativeMineCourse.stationBearing(level)) > STATION_TOLERANCE
                || state.arc.distanceFromStation(state.lastCanonical) > STATION_TOLERANCE
                || physics(level).getLinearVelocity(cart, new Vector3d()).length() > 0.05) return;
        state.phase = "PARKED";
        state.failure = "";
        LOGGER.info("MINE_MAIN_EXPLICIT_STATION_RESTART cart={} gameTick={} actualBearing={}", cart.getUniqueId(), level.getGameTime(), point);
    }

    private static void fail(ServerLevel level, ServerSubLevel cart, State state, String reason) {
        if ("FAILED".equals(state.phase)) return;
        state.phase = "FAILED"; state.failure = reason;
        state.autoResumePermitted = false; state.manualResumePermitted = false;
        physics(level).resetVelocity(cart); safetyHold(level, cart); persist(level, cart, state);
        LOGGER.error("MINE_MAIN_RIDE_FAILED run={} cart={} gameTick={} reason={} bearing={}", state.runId, state.cartId, level.getGameTime(), reason, bearing(cart));
    }

    private static void persist(ServerLevel level, ServerSubLevel cart, State state) {
        CompoundTag user = cart.getUserDataTag(); user = user == null ? new CompoundTag() : user.copy();
        CompoundTag tag = new CompoundTag();
        tag.putInt("schema", 2); tag.putUUID("cart_id", cart.getUniqueId()); tag.putUUID("run_id", state.runId);
        tag.putString("route_fingerprint", NativeMineCourse.route().fingerprint()); tag.putString("phase", state.phase);
        tag.putString("failure", state.failure); tag.putLong("game_tick", level.getGameTime());
        tag.putInt("completed_laps", state.completedLaps); tag.putInt("target_laps", state.targetLaps);
        tag.putDouble("canonical_distance", state.lastCanonical); tag.putDouble("native_arc_length", state.arc.totalLength());
        tag.putDouble("unwrapped_distance", state.unwrapped);
        tag.putDouble("measured_distance", state.measuredDistance); tag.putDouble("elapsed_seconds", state.elapsedSeconds);
        tag.putDouble("max_native_speed", state.maxNativeSpeed); tag.putDouble("max_measured_speed", state.maxMeasuredSpeed);
        tag.putDouble("max_acceleration", state.maxAcceleration); tag.putDouble("max_curvature", state.maxCurvature);
        tag.putDouble("max_guide_error", state.maxGuideError); tag.putDouble("hold_seconds", state.holdSeconds);
        tag.putBoolean("auto_resume_permitted", state.autoResumePermitted);
        tag.putBoolean("manual_resume_permitted", state.manualResumePermitted);
        tag.putString("resume_phase", state.resumePhase);
        tag.putBoolean("returning_to_station", state.returningToStation);
        tag.putInt("native_pose_assignments", 0);
        Vec3 actual = bearing(cart);
        if (actual != null) { tag.putDouble("bearing_x", actual.x); tag.putDouble("bearing_y", actual.y); tag.putDouble("bearing_z", actual.z); }
        user.put(SAVE_KEY, tag); cart.setUserDataTag(user);
    }

    private static CoasterPathTrackFrame.GraphHit hit(ServerLevel level, Vec3 point) {
        var hit = CoasterPathTrackFrame.nearestGraphHit(level, CoasterPathGraphManager.get(level), point, 1.0);
        if (hit == null) throw new IllegalStateException("Native train bearing is not within one block of the actual rail graph");
        return hit;
    }
    /** Lock the existing native body to its actual pose using Sable's supported constraint API. */
    private static void safetyHold(ServerLevel level, ServerSubLevel cart) {
        GenericConstraintHandle existing = SAFETY_HOLDS.get(level);
        if (existing != null && existing.isValid()) return;
        Vec3 point = bearing(cart);
        BlockPos plotCell = dev.silvergold.simulatedcoasters.track.cart.CoasterCartTrackSnap.representativeBearingPlotPos(cart);
        if (!safePose(cart, point) || plotCell == null) return;
        try {
            GenericConstraintConfiguration configuration = new GenericConstraintConfiguration(
                    new Vector3d(point.x, point.y, point.z),
                    new Vector3d(plotCell.getX() + 0.5, plotCell.getY() + 0.5, plotCell.getZ() + 0.5),
                    new Quaterniond(cart.logicalPose().orientation()), new Quaterniond(), EnumSet.allOf(ConstraintJointAxis.class));
            GenericConstraintHandle hold = physics(level).addConstraint(null, cart, configuration);
            if (hold == null || !hold.isValid()) throw new IllegalStateException("Native emergency constraint was not created");
            SAFETY_HOLDS.put(level, hold);
            LOGGER.info("MINE_MAIN_NATIVE_HOLD cart={} gameTick={} actualBearing={} nativePoseAssignments=0", cart.getUniqueId(), level.getGameTime(), point);
        } catch (RuntimeException error) {
            LOGGER.error("MINE_MAIN_NATIVE_HOLD_FAILED cart={} reason={}", cart.getUniqueId(), message(error));
        }
    }
    private static Vec3 bearing(ServerSubLevel cart) { return CoasterCartLinkPlacement.bearingCenterWorld(cart, cart.logicalPose()); }
    private static dev.ryanhcode.sable.api.physics.PhysicsPipeline physics(ServerLevel level) {
        return dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem.require(level).getPipeline();
    }
    private static boolean safePose(ServerSubLevel cart, Vec3 point) {
        var q = cart.logicalPose().orientation();
        return point != null && Double.isFinite(point.x) && Double.isFinite(point.y) && Double.isFinite(point.z)
                && Double.isFinite(q.x) && Double.isFinite(q.y) && Double.isFinite(q.z) && Double.isFinite(q.w);
    }
    private static boolean chunksLoaded(ServerLevel level, Vec3 current, Vec3 ahead) {
        return level.hasChunkAt(BlockPos.containing(current)) && level.hasChunkAt(BlockPos.containing(ahead));
    }
    private static double mix(double a, double b, double blend) { return a + (b - a) * blend; }
    private static double clamp(double x, double lo, double hi) { return Math.max(lo, Math.min(hi, x)); }
    private static double finiteNonnegative(double x) {
        if (!Double.isFinite(x) || x < 0.0) throw new IllegalStateException("Invalid saved native ride measurement");
        return x;
    }
    private static String message(RuntimeException error) { return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage(); }

    public record Snapshot(UUID cartId, String phase, double canonicalDistance, double travelledDistance,
                           double totalLength, double speed, double elapsedSeconds, int completedLaps,
                           String area, int seatedPlayers) {}

    private static final class State {
        private final UUID cartId;
        private UUID runId = UUID.randomUUID();
        private MineNativeArc arc;
        private String phase;
        private String failure = "";
        private String area = "station";
        private Vec3 lastBearing;
        private final Vector3d lastVelocity = new Vector3d();
        private final MineNativeHoldReadiness nativeHoldReadiness = new MineNativeHoldReadiness();
        private double lastCanonical;
        private double unwrapped;
        private double measuredDistance;
        private double elapsedSeconds;
        private double maxNativeSpeed;
        private double maxMeasuredSpeed;
        private double maxAcceleration;
        private double maxCurvature;
        private double maxGuideError;
        private double holdSeconds;
        private double waitSeconds;
        private double waitRequired = 3.0;
        private int completedLaps;
        private int targetLaps = 1;
        private boolean manual;
        private boolean returningToStation;
        private boolean autoResumePermitted;
        private boolean manualResumePermitted;
        private String resumePhase = "RUNNING";
        private double resumeWaitSeconds;
        private long lastLogTick = Long.MIN_VALUE;
        private State(UUID cartId, MineNativeArc arc, String phase, Vec3 lastBearing, double canonical) {
            this.cartId = cartId; this.arc = arc; this.phase = phase; this.lastBearing = lastBearing; this.lastCanonical = canonical;
        }
        private boolean running() { return "RUNNING".equals(phase) || "BRAKING".equals(phase) || "HOLDING".equals(phase); }
    }
}
