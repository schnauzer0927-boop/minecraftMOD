package dev.thundermine.tools.audio;

import com.mojang.logging.LogUtils;
import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartSeatedEntityCollision;
import dev.thundermine.tools.MineRideController;
import dev.thundermine.tools.NativeMineCourse;
import dev.thundermine.tools.ThunderMineTools;
import java.util.Map;
import java.util.UUID;
import java.util.WeakHashMap;
import java.util.function.Consumer;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;
import org.slf4j.Logger;

/** Common audio networking and registrations. No Minecraft client class is referenced here. */
public final class RideAudio {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final UUID NO_CART = new UUID(0L, 0L);
    private static final Map<ServerLevel, Long> LAST_SENT = new WeakHashMap<>();
    private static Consumer<RideAudioPayload> clientReceiver = payload -> {};
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, ThunderMineTools.MOD_ID);
    public static final DeferredHolder<SoundEvent, SoundEvent> EXPLORATION = sound("ride_exploration");
    public static final DeferredHolder<SoundEvent, SoundEvent> SUSPENSE = sound("ride_suspense");
    public static final DeferredHolder<SoundEvent, SoundEvent> CHASE = sound("ride_chase");

    private RideAudio() {}
    private static DeferredHolder<SoundEvent, SoundEvent> sound(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(
                ResourceLocation.fromNamespaceAndPath(ThunderMineTools.MOD_ID, name)));
    }

    /** Root entrypoint calls once during normal MOD construction. */
    public static void register(IEventBus modBus, ModContainer container) {
        SOUNDS.register(modBus);
        modBus.addListener(RideAudio::registerPayloads);
        container.registerConfig(ModConfig.Type.CLIENT, RideAudioConfig.SPEC,
                "thunder-mine-tools-client.toml");
        NeoForge.EVENT_BUS.addListener(RideAudio::onLevelUnload);
    }

    private static void registerPayloads(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToClient(RideAudioPayload.TYPE, RideAudioPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() -> clientReceiver.accept(payload)));
    }

    /** Installed by the Dist.CLIENT-only tick subscriber; absent on a dedicated server. */
    public static void setClientReceiver(Consumer<RideAudioPayload> receiver) {
        clientReceiver = java.util.Objects.requireNonNull(receiver);
    }

    /**
     * Root calls from its server tick using the real controller snapshot. Once per 20 ticks;
     * only a genuine Create seat hosted by the commissioned cart may receive active music.
     * Non-riders receive an explicit fade-out, and the client also independently checks them.
     */
    public static void send(ServerLevel level, MineRideController.Snapshot snapshot) {
        long tick = level.getGameTime();
        if (tick % 20L != 0L || LAST_SENT.getOrDefault(level, -1L) == tick) return;
        LAST_SENT.put(level, tick);
        String fingerprint = NativeMineCourse.route().fingerprint();
        for (var player : level.players()) {
            try {
                var host = player.getVehicle() instanceof SeatEntity
                        ? CoasterCartSeatedEntityCollision.hostCartFromVehicleChain(player) : null;
                boolean active = snapshot != null && host != null
                        && host.getUniqueId().equals(snapshot.cartId())
                        && RideAudioProgram.audiblePhase(snapshot.phase())
                        && NativeMineCourse.nativeEngaged(NativeMineCourse.cart(level));
                String area = snapshot != null && RideAudioProgram.knownArea(snapshot.area())
                        ? snapshot.area() : "base";
                double speed = snapshot != null && Double.isFinite(snapshot.speed())
                        ? Math.max(0.0, Math.min(150.0, snapshot.speed())) : 0.0;
                var payload = new RideAudioPayload(player.getUUID(),
                        snapshot == null ? NO_CART : snapshot.cartId(), level.dimension().location(),
                        fingerprint, area, active, speed);
                PacketDistributor.sendToPlayer(player, payload);
            } catch (RuntimeException error) {
                // Sound failure never feeds back into native motion or station state.
                LOGGER.warn("MINE_AUDIO_SEND_FAILED player={} reason={}", player.getUUID(), error.toString());
            }
        }
    }

    private static void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel serverLevel) LAST_SENT.remove(serverLevel);
    }
}
