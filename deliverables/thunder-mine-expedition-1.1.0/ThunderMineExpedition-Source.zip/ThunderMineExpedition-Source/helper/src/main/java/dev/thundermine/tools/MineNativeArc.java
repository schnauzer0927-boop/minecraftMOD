package dev.thundermine.tools;

import dev.silvergold.simulatedcoasters.track.graph.CoasterPathEdge;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathGraphManager;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathTrackFrame;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/** Arc-length lookup measured from the supplied MOD's actual, authored-order native graph. */
public final class MineNativeArc {
    private static final int SAMPLES = 128;
    private final ServerLevel level;
    private final List<Segment> segments = new ArrayList<>();
    private final Map<CoasterPathEdge, Segment> byIdentity = new IdentityHashMap<>();
    private final double totalLength;
    private final double stationRaw;
    private final int graphRevision;

    public MineNativeArc(ServerLevel level) {
        this.level = level;
        NativeMineCourse.requireClosedNativeTopology(level);
        var nodes = NativeMineCourse.nodes();
        var edges = NativeMineCourse.actualEdges(level);
        double offset = 0.0;
        for (int i = 0; i < nodes.size(); i++) {
            var a = nodes.get(i).block();
            var b = nodes.get((i + 1) % nodes.size()).block();
            CoasterPathEdge edge = null;
            for (var candidate : edges) {
                if ((candidate.from().equals(a) && candidate.to().equals(b))
                        || (candidate.from().equals(b) && candidate.to().equals(a))) {
                    if (edge != null) throw new IllegalStateException("Duplicate native edge at authored segment " + i);
                    edge = candidate;
                }
            }
            if (edge == null) throw new IllegalStateException("Missing native edge at authored segment " + i);
            boolean reverse = !edge.from().equals(a);
            double[] cumulative = new double[SAMPLES + 1];
            Vec3 previous = sample(edge, reverse, 0.0);
            for (int j = 1; j <= SAMPLES; j++) {
                Vec3 current = sample(edge, reverse, (double) j / SAMPLES);
                cumulative[j] = cumulative[j - 1] + current.distanceTo(previous);
                previous = current;
            }
            double length = cumulative[SAMPLES];
            if (!Double.isFinite(length) || length < 0.1) throw new IllegalStateException("Invalid native segment length " + i);
            Segment segment = new Segment(i, edge, reverse, offset, length, cumulative);
            segments.add(segment);
            byIdentity.put(edge, segment);
            offset += length;
        }
        totalLength = offset;
        CoasterPathTrackFrame.GraphHit station = NativeMineCourse.stationHit(level);
        stationRaw = rawAt(station);
        graphRevision = CoasterPathGraphManager.get(level).revision();
    }

    public double totalLength() { return totalLength; }
    public int graphRevision() { return graphRevision; }

    /** Canonical station-relative distance of an authored native anchor boundary. */
    public double nodeBoundaryDistance(int nodeIndex) {
        if (nodeIndex < 0 || nodeIndex >= segments.size()) {
            throw new IllegalArgumentException("Authored node index is outside the native course: " + nodeIndex);
        }
        return wrap(segments.get(nodeIndex).offset - stationRaw);
    }

    public Point atHit(CoasterPathTrackFrame.GraphHit hit) {
        Segment segment = segment(hit.edge());
        double authoredT = segment.reverse ? 1.0 - hit.t() : hit.t();
        double raw = rawAt(hit);
        double canonical = wrap(raw - stationRaw);
        double beforeT = Math.max(0.0, authoredT - 0.001);
        double afterT = Math.min(1.0, authoredT + 0.001);
        Vec3 tangent = sample(segment.edge, segment.reverse, afterT)
                .subtract(sample(segment.edge, segment.reverse, beforeT)).normalize();
        if (tangent.lengthSqr() < 0.9) throw new IllegalStateException("Degenerate native tangent");
        Vec3 before = positionAt(canonical - 0.35);
        Vec3 center = positionAt(canonical);
        Vec3 after = positionAt(canonical + 0.35);
        double chord = before.distanceTo(after);
        double a = before.distanceTo(center), b = center.distanceTo(after);
        double curvature = a > 1.0e-7 && b > 1.0e-7 && chord > 1.0e-7
                ? before.subtract(center).cross(after.subtract(center)).length() * 2.0 / (a * b * chord) : 0.0;
        return new Point(canonical, segment.index, authoredT, hit.point(), tangent, curvature);
    }

    public Vec3 positionAt(double canonical) {
        double raw = wrap(canonical + stationRaw);
        Segment selected = segments.get(segments.size() - 1);
        for (Segment segment : segments) {
            if (raw <= segment.offset + segment.length) { selected = segment; break; }
        }
        double local = Math.max(0.0, Math.min(selected.length, raw - selected.offset));
        int hi = 1;
        while (hi < SAMPLES && selected.cumulative[hi] < local) hi++;
        double loValue = selected.cumulative[hi - 1], hiValue = selected.cumulative[hi];
        double alpha = hiValue > loValue ? (local - loValue) / (hiValue - loValue) : 0.0;
        double t = ((hi - 1) + alpha) / SAMPLES;
        return sample(selected.edge, selected.reverse, t);
    }

    public double signedDelta(double previous, double current) {
        double delta = current - previous;
        if (delta > totalLength / 2.0) delta -= totalLength;
        if (delta < -totalLength / 2.0) delta += totalLength;
        return delta;
    }

    public double distanceFromStation(double canonical) {
        return Math.min(wrap(canonical), totalLength - wrap(canonical));
    }

    private double rawAt(CoasterPathTrackFrame.GraphHit hit) {
        Segment segment = segment(hit.edge());
        double t = Math.max(0.0, Math.min(1.0, segment.reverse ? 1.0 - hit.t() : hit.t()));
        double scaled = t * SAMPLES;
        int lo = Math.min(SAMPLES - 1, (int)Math.floor(scaled));
        double alpha = scaled - lo;
        return segment.offset + segment.cumulative[lo] * (1.0 - alpha) + segment.cumulative[lo + 1] * alpha;
    }

    private Segment segment(CoasterPathEdge edge) {
        Segment segment = byIdentity.get(edge);
        if (segment != null) return segment;
        for (Segment candidate : segments) {
            if (candidate.edge.from().equals(edge.from()) && candidate.edge.to().equals(edge.to())) return candidate;
        }
        throw new IllegalStateException("The native hit is outside the commissioned authored course");
    }

    private Vec3 sample(CoasterPathEdge edge, boolean reverse, double authoredT) {
        Vec3 sample = CoasterPathGraphManager.sampleEdgePosition(level, edge, reverse ? 1.0 - authoredT : authoredT);
        if (!Double.isFinite(sample.x) || !Double.isFinite(sample.y) || !Double.isFinite(sample.z)) {
            throw new IllegalStateException("Non-finite actual native rail sample");
        }
        return sample;
    }

    private double wrap(double distance) {
        double wrapped = distance % totalLength;
        return wrapped < 0 ? wrapped + totalLength : wrapped;
    }

    private record Segment(int index, CoasterPathEdge edge, boolean reverse, double offset,
                           double length, double[] cumulative) {}

    public record Point(double distance, int segmentIndex, double segmentT, Vec3 point,
                        Vec3 forward, double curvature) {}
}
