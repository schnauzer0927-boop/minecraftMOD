package dev.thundermine.tools;

/** Measures a genuine cart travelling around the small, horizontal commissioning circuit. */
public final class NativeCircuitProgress {
    private final double centerX;
    private final double centerZ;
    private final double direction;
    private double previousX;
    private double previousZ;
    private double previousAngle;
    private double radians;
    private double measuredDistance;

    public NativeCircuitProgress(double centerX, double centerZ, double startX, double startZ,
                                 double forwardX, double forwardZ) {
        double cross = (startX - centerX) * forwardZ - (startZ - centerZ) * forwardX;
        if (!finite(centerX, centerZ, startX, startZ, forwardX, forwardZ)
                || Math.abs(cross) < 1.0e-6) {
            throw new IllegalArgumentException("A finite station position and circuit tangent are required");
        }
        this.centerX = centerX;
        this.centerZ = centerZ;
        this.direction = Math.signum(cross);
        this.previousX = startX;
        this.previousZ = startZ;
        this.previousAngle = Math.atan2(startZ - centerZ, startX - centerX);
    }

    public double observe(double x, double z) {
        if (!finite(x, z)) {
            throw new IllegalArgumentException("Non-finite native position");
        }
        double step = Math.hypot(x - previousX, z - previousZ);
        double angle = Math.atan2(z - centerZ, x - centerX);
        double delta = Math.atan2(Math.sin(angle - previousAngle), Math.cos(angle - previousAngle));
        radians += delta * direction;
        measuredDistance += step;
        previousX = x;
        previousZ = z;
        previousAngle = angle;
        return step;
    }

    /** Reject a discontinuity before it can contribute distance or completed circuits. */
    public double observeChecked(double x, double z, double seconds, double maximumSpeed,
                                 double positionSlack) {
        if (!finite(x, z, seconds, maximumSpeed, positionSlack)
                || seconds <= 0.0 || maximumSpeed < 0.0 || positionSlack < 0.0) {
            throw new IllegalArgumentException("Invalid measurement limits");
        }
        double step = Math.hypot(x - previousX, z - previousZ);
        if (step > maximumSpeed * seconds + positionSlack) {
            throw new IllegalArgumentException("Discontinuous measured circuit position");
        }
        return observe(x, z);
    }

    /** Restores previously recorded measurement totals; does not alter any Minecraft position. */
    public void restoreMeasurement(double savedRadians, double savedDistance) {
        if (!finite(savedRadians, savedDistance) || savedDistance < 0.0) {
            throw new IllegalArgumentException("Invalid saved circuit measurements");
        }
        radians = savedRadians;
        measuredDistance = savedDistance;
    }

    public double progressRadians() { return radians; }
    public double measuredDistance() { return measuredDistance; }
    public double radiusAt(double x, double z) { return Math.hypot(x - centerX, z - centerZ); }
    public double forwardXAt(double x, double z) { return -(z - centerZ) * direction; }
    public double forwardZAt(double x, double z) { return (x - centerX) * direction; }
    public double remainingDistance(int targetLaps, double radius) {
        return Math.max(0.0, (targetLaps * Math.PI * 2.0 - radians) * radius);
    }

    private static boolean finite(double... values) {
        for (double value : values) {
            if (!Double.isFinite(value)) return false;
        }
        return true;
    }
}
