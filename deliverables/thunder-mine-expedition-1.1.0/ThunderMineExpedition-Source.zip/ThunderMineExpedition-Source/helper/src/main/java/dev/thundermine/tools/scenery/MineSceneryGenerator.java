package dev.thundermine.tools.scenery;

import com.mojang.logging.LogUtils;
import dev.thundermine.tools.MineCourseSavedData;
import dev.thundermine.tools.MineRoute;
import dev.thundermine.tools.NativeMineCourse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.LightBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraft.world.level.block.entity.SignText;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.AttachFace;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;

/** Original deterministic scenery, added only after the genuine native course is validated. */
public final class MineSceneryGenerator {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final int MAX_PLACEMENTS_PER_TICK = 6000;
    private static final int MAX_EXAMINED_PER_TICK = 45000;
    private static final Map<ServerLevel, Job> RUNNING = new IdentityHashMap<>();
    private static final Map<ServerLevel, TopsoilRepair> TOPSOIL_REPAIRS = new IdentityHashMap<>();
    private static final BlockState AIR = Blocks.AIR.defaultBlockState();
    private static final BlockState WOOD = Blocks.DARK_OAK_PLANKS.defaultBlockState();
    private static final BlockState TIMBER = Blocks.STRIPPED_DARK_OAK_LOG.defaultBlockState();
    private static final BlockState IRON = Blocks.IRON_BLOCK.defaultBlockState();
    private static final BlockState FENCE = Blocks.DARK_OAK_FENCE.defaultBlockState();
    private static final BlockState LAMP = Blocks.LANTERN.defaultBlockState();
    private static final BlockState HIDDEN_LIGHT = Blocks.LIGHT.defaultBlockState().setValue(LightBlock.LEVEL, 15);

    private MineSceneryGenerator() {}

    public static String start(ServerLevel level) {
        if (RUNNING.containsKey(level)) return status(level);
        if (!MineCourseSavedData.get(level).built()) throw new IllegalStateException("Construct and validate the native mine course before scenery");
        NativeMineCourse.requireClosedNativeTopology(level);
        var receipt = ScenerySavedData.get(level);
        String fingerprint = MineRoute.loadBundled().fingerprint();
        if (receipt.complete) return status(level);
        if (receipt.begun && !receipt.routeFingerprint.equals(fingerprint))
            throw new IllegalStateException("Scenery receipt belongs to another route; no world blocks were changed");
        NativeClearance clearance = new NativeClearance(level);
        var tasks = buildProgram(clearance);
        if (receipt.stage > tasks.size() || (receipt.stage < tasks.size() && receipt.cursor > tasks.get(receipt.stage).size()))
            throw new IllegalStateException("Invalid scenery resume cursor");
        receipt.begun = true;
        receipt.routeFingerprint = fingerprint;
        receipt.message = "Constructing original mine scenery; native rails and cart are protected";
        receipt.setDirty();
        RUNNING.put(level, new Job(clearance, tasks));
        LOGGER.info("MINE_SCENERY_START tasks={} examinedCandidateBudget={} protectedVoxels={} resumeStage={} resumeCursor={}",
                tasks.size(), tasks.stream().mapToLong(BuildTask::size).sum(), clearance.protectedVoxelCount(), receipt.stage, receipt.cursor);
        return status(level);
    }

    /** Invoke on the server thread once per tick; no background threads mutate world blocks. */
    public static void tick(ServerLevel level) {
        tickTopsoilRepair(level);
        Job job = RUNNING.get(level);
        if (job == null) return;
        ScenerySavedData receipt = ScenerySavedData.get(level);
        int placedThisTick = 0, examined = 0;
        long deadline = System.nanoTime() + 20_000_000L;
        while (receipt.stage < job.tasks.size() && placedThisTick < MAX_PLACEMENTS_PER_TICK
                && examined < MAX_EXAMINED_PER_TICK && System.nanoTime() < deadline) {
            BuildTask task = job.tasks.get(receipt.stage);
            if (receipt.cursor >= task.size()) {
                LOGGER.info("MINE_SCENERY_STAGE_DONE stage={}/{} name={} placed={} protected={}",
                        receipt.stage + 1, job.tasks.size(), task.name(), receipt.placed, receipt.skippedProtected);
                receipt.stage++;
                receipt.cursor = 0;
                receipt.setDirty();
                continue;
            }
            Placement placement = task.at(receipt.cursor++);
            examined++;
            if (placement == null) continue;
            BlockPos position = placement.position();
            if (job.clearance.blocksScenery(position)) { receipt.skippedProtected++; continue; }
            BlockState existing = level.getBlockState(position);
            String namespace = BuiltInRegistries.BLOCK.getKey(existing.getBlock()).getNamespace();
            // Native fake tracks, anchors, Create apparatus and Sable sublevel blocks are never replaced.
            if (!namespace.equals("minecraft") || (level.getBlockEntity(position) != null && !existing.is(Blocks.OAK_WALL_SIGN))) {
                receipt.skippedForeign++;
                continue;
            }
            if (existing.equals(placement.state())) continue;
            if (level.setBlock(position, placement.state(), 2)) {
                receipt.placed++;
                placedThisTick++;
            }
        }
        if (level.getGameTime() % 100 == 0) receipt.setDirty();
        if (receipt.stage >= job.tasks.size()) {
            decorateSigns(level);
            receipt.complete = true;
            receipt.message = "Original mine scenery complete; validate actual ride, boarding and screenshots separately";
            receipt.setDirty();
            RUNNING.remove(level);
            LOGGER.info("MINE_SCENERY_COMPLETE placed={} protectedSkips={} foreignSkips={} protectedVoxels={}",
                    receipt.placed, receipt.skippedProtected, receipt.skippedForeign, job.clearance.protectedVoxelCount());
        }
    }

    public static void detach(ServerLevel level) { RUNNING.remove(level); TOPSOIL_REPAIRS.remove(level); }
    public static boolean isRunning(ServerLevel level) { return RUNNING.containsKey(level) || TOPSOIL_REPAIRS.containsKey(level); }
    public static boolean isComplete(ServerLevel level) { return ScenerySavedData.get(level).complete; }
    public static String status(ServerLevel level) {
        var receipt = ScenerySavedData.get(level);
        Job job = RUNNING.get(level);
        String progress = job == null ? "" : " stage=" + receipt.stage + "/" + job.tasks.size()
                + " task=" + (receipt.stage < job.tasks.size() ? job.tasks.get(receipt.stage).name() : "finalize");
        return "Mine scenery: complete=" + receipt.complete + " running=" + isRunning(level)
                + " placed=" + receipt.placed + " protectedSkips=" + receipt.skippedProtected
                + " foreignSkips=" + receipt.skippedForeign + progress
                + (TOPSOIL_REPAIRS.containsKey(level) ? " topsoilRepair=" + TOPSOIL_REPAIRS.get(level).cursor : "");
    }

    /** Stabilize only original generated topsoil cells; never rebuild scenery or edit native tracks. */
    public static String stabilizeTopsoil(ServerLevel level) {
        if (!isComplete(level)) throw new IllegalStateException("Finish scenery before topsoil stabilization");
        if (!ScenerySavedData.get(level).routeFingerprint.equals(MineRoute.loadBundled().fingerprint()))
            throw new IllegalStateException("The terrain repair does not match this native route");
        if (RUNNING.containsKey(level)) throw new IllegalStateException("Do not overlap scenery generation and repair");
        if (TOPSOIL_REPAIRS.containsKey(level)) return status(level);
        TOPSOIL_REPAIRS.put(level, new TopsoilRepair());
        return "Original terrain topsoil stabilization started; only existing red sand at its original generated surface is replaced";
    }

    private static void tickTopsoilRepair(ServerLevel level) {
        TopsoilRepair repair = TOPSOIL_REPAIRS.get(level);
        if (repair == null) return;
        int examined = 0;
        long deadline = System.nanoTime() + 10_000_000L;
        while (repair.cursor < TerrainTask.NX * TerrainTask.NZ && examined++ < 3000 && System.nanoTime() < deadline) {
            int column = repair.cursor++;
            int x = TerrainTask.X0 + column % TerrainTask.NX;
            int z = TerrainTask.Z0 + column / TerrainTask.NX;
            if (hash(x, 0, z, 3) % 6 != 0) continue;
            BlockPos originalSurface = new BlockPos(x, terrainHeight(x, z), z);
            if (level.getBlockState(originalSurface).is(Blocks.RED_SAND)
                    && level.setBlock(originalSurface, Blocks.RED_SANDSTONE.defaultBlockState(), 2)) repair.changed++;
        }
        if (repair.cursor == TerrainTask.NX * TerrainTask.NZ) {
            TOPSOIL_REPAIRS.remove(level);
            LOGGER.info("MINE_SCENERY_TOPSOIL_STABILIZED examinedColumns={} changed={} fallingBlocksInsideClearanceRequireSeparateRemoval=true",
                    repair.cursor, repair.changed);
        }
    }

    /** Deliberately explicit inspection command; call after generation, not on every frame. */
    public static String clearanceReport(ServerLevel level) {
        NativeClearance clearance = new NativeClearance(level);
        long violations = 0;
        List<String> examples = new ArrayList<>();
        for (long packed : clearance.protectedVoxels()) {
            BlockPos p = BlockPos.of(packed);
            if (!clearance.blocksScenery(p)) continue;
            BlockState state = level.getBlockState(p);
            if (state.isAir()) continue;
            String namespace = BuiltInRegistries.BLOCK.getKey(state.getBlock()).getNamespace();
            if (!namespace.equals("minecraft")) continue;
            if (state.getCollisionShape(level, p).isEmpty()) continue;
            violations++;
            if (examples.size() < 8) examples.add(p.toShortString() + " " + BuiltInRegistries.BLOCK.getKey(state.getBlock()));
        }
        return "Native scenery clearance: protectedVoxels=" + clearance.protectedVoxelCount()
                + " solidViolations=" + violations + " examples=" + examples
                + "; station side-platform exceptions require actual boarding/ride verification";
    }

    private static List<BuildTask> buildProgram(NativeClearance clearance) {
        List<BuildTask> tasks = new ArrayList<>();
        // A continuous, irregular red-rock surface: eight solid layers seal the terrain.
        tasks.add(new TerrainTask());
        // This is a large mine chamber, not a repeated tube: irregular rock ceiling and side walls.
        tasks.add(box("giant underground excavation shell", -201, 14, -116, -46, 163, 116, p -> {
            double nx = (p.getX() + 125.0) / 76.0;
            double nz = p.getZ() / 112.0;
            double ny = (p.getY() - 86.0) / 73.0;
            double radius = nx * nx + ny * ny + nz * nz;
            double distortion = .035 * noise(p.getX(), p.getY(), p.getZ(), 41);
            if (radius < .90 + distortion || radius > 1.045 + distortion) return null;
            return caveStone(p);
        }));
        tasks.add(box("deep excavation irregular floor", -183, 18, -89, -70, 31, 90, p -> {
            double ellipse = sq((p.getX() + 125.0) / 60.0) + sq(p.getZ() / 92.0);
            int floor = 24 + (int)Math.round(2.5 * noise(p.getX(), 0, p.getZ(), 29));
            return ellipse < 1 && p.getY() <= floor && p.getY() > floor - 5 ? caveStone(p) : null;
        }));
        tasks.add(box("sealed underground settling lake", -149, 22, -43, -101, 28, 40, p -> {
            double ellipse = sq((p.getX() + 125.0) / 24.0) + sq((p.getZ() + 2.0) / 42.0);
            if (ellipse > 1.0) return null;
            if (p.getY() == 22 || ellipse > .86) return Blocks.DEEPSLATE_BRICKS.defaultBlockState();
            if (p.getY() <= 27) return Blocks.WATER.defaultBlockState();
            return AIR;
        }));
        // Carved-looking tunnel shells follow actual native track frames, with varied rough material.
        addTunnelShells(tasks, clearance);
        addStation(tasks);
        addBadlands(tasks);
        addExcavationFeatures(tasks);
        addCanyonFeatures(tasks);
        addRailSideDressing(tasks, clearance);
        return List.copyOf(tasks);
    }

    private static void addStation(List<BuildTask> tasks) {
        addFill(tasks, "safe station underfloor", 166, 78, -23, 197, 79, 23, Blocks.STONE_BRICKS.defaultBlockState());
        addFill(tasks, "boarding platform floor", 178, 82, -18, 197, 83, 20, WOOD);
        addFill(tasks, "arrival boardwalk", 178, 82, -30, 211, 83, -19, WOOD);
        addFill(tasks, "entrance boardwalk", 198, 81, -19, 220, 83, 5, WOOD);
        // Wide stairs remain outside the stopped wooden body; native tracks are still individually protected.
        addFill(tasks, "emergency dismount first step", 176, 79, -8, 177, 80, 8, WOOD);
        addFill(tasks, "emergency dismount second step", 177, 80, -8, 177, 82, 8, WOOD);
        for (int z : new int[]{-18, 20}) {
            addFill(tasks, "station roof west timber", 166, 80, z, 167, 96, z + 1, TIMBER);
            addFill(tasks, "station roof east timber", 195, 84, z, 196, 96, z + 1, TIMBER);
            addFill(tasks, "station steel crossbeam", 166, 94, z, 196, 95, z, IRON);
        }
        tasks.add(box("pitched original mine station roof", 164, 96, -20, 199, 105, 23, p -> {
            int roof = 98 + Math.max(0, 7 - (int)Math.abs((p.getX() - 181.5) / 2.3));
            return p.getY() == roof || p.getY() == roof - 1 ? WOOD : null;
        }));
        for (int z = -15; z <= 18; z += 6) {
            addFill(tasks, "station warm lamps", 192, 92, z, 192, 92, z, LAMP);
            addFill(tasks, "platform hidden light", 183, 85, z, 183, 85, z, HIDDEN_LIGHT);
        }
        addFill(tasks, "station back fence", 197, 84, -18, 197, 85, 20, FENCE);
        addFill(tasks, "queue divider north", 184, 84, -29, 205, 84, -29, FENCE);
        addFill(tasks, "queue divider south", 184, 84, -21, 205, 84, -21, FENCE);
        addFill(tasks, "queue return lane", 188, 84, -25, 205, 84, -25, FENCE);
        addFill(tasks, "dispatch console posts", 179, 84, -3, 179, 85, 3, TIMBER);
        addFill(tasks, "native seat boarding button", 178, 84, -2, 178, 84, -2,
                Blocks.OAK_BUTTON.defaultBlockState().setValue(ButtonBlock.FACING, Direction.WEST)
                        .setValue(ButtonBlock.FACE, AttachFace.WALL));
        addFill(tasks, "one-lap dispatch button", 178, 84, 0, 178, 84, 0,
                Blocks.STONE_BUTTON.defaultBlockState().setValue(ButtonBlock.FACING, Direction.WEST)
                        .setValue(ButtonBlock.FACE, AttachFace.WALL));
        addFill(tasks, "emergency stop button", 178, 84, 2, 178, 84, 2,
                Blocks.POLISHED_BLACKSTONE_BUTTON.defaultBlockState().setValue(ButtonBlock.FACING, Direction.WEST)
                        .setValue(ButtonBlock.FACE, AttachFace.WALL));
        addSign(tasks, 180, 85, -3, Direction.EAST);
        addSign(tasks, 180, 85, 0, Direction.EAST);
        addSign(tasks, 180, 85, 3, Direction.EAST);
        // Old company entrance gate: original name and simple crossed-pick visual.
        for (int z : new int[]{-21, 9}) addFill(tasks, "entrance gate uprights", 216, 84, z, 217, 95, z + 1, TIMBER);
        addFill(tasks, "entrance header", 216, 93, -21, 217, 95, 10, WOOD);
        addSign(tasks, 218, 93, -7, Direction.EAST);
        addHouse(tasks, "ore sorting depot", 200, 83, 22, 222, 11, 44, true);
        addHouse(tasks, "miner's office", 141, 80, 17, 160, 10, 36, false);
        addHouse(tasks, "abandoned tool shed", 113, 79, 53, 130, 8, 70, false);
        addHeadframe(tasks, 205, 84, 13, 33);
        // Crates, ore bins and railway material piles break up the platform surroundings.
        for (int i = 0; i < 14; i++) {
            int x = 196 + i % 5 * 4, z = 48 + i / 5 * 5;
            addFill(tasks, "ore bin", x, 80, z, x + 2, 82 + i % 2, z + 2,
                    i % 3 == 0 ? Blocks.RAW_COPPER_BLOCK.defaultBlockState() : Blocks.BARREL.defaultBlockState());
        }
    }

    private static void addBadlands(List<BuildTask> tasks) {
        for (int i = 0; i < 9; i++) {
            int x = 102 - i * 19, z = 144 + (i % 3) * 7;
            addRockSpire(tasks, x, z, 10 + (i % 4) * 4, 20 + (i % 5) * 8, 70 + i * 3);
        }
        // A timber headframe and stepped lookout beside the long ascent.
        addHeadframe(tasks, 100, 105, 131, 29);
        addFill(tasks, "lift lookout deck", 55, 121, 128, 84, 122, 141, WOOD);
        addFill(tasks, "lift lookout edge rail", 55, 123, 141, 84, 123, 141, FENCE);
        for (int x = 57; x <= 84; x += 9) {
            addFill(tasks, "lookout footings", x, 88, 132, x + 1, 121, 133, TIMBER);
            addFill(tasks, "lookout lanterns", x, 124, 140, x, 124, 140, LAMP);
        }
        addHouse(tasks, "abandoned compressor house", 18, 128, 136, 35, 9, 151, false);
        // Blasting props are inert red wool, black bands and signs; no TNT or destructive entities.
        for (int i = 0; i < 5; i++) {
            int x = 44 + i * 6;
            addFill(tasks, "inert dynamite stockpile", x, 123, 136, x + 2, 125, 138, Blocks.RED_WOOL.defaultBlockState());
            addFill(tasks, "dynamite crate band", x + 1, 123, 136, x + 1, 125, 138, Blocks.BLACK_WOOL.defaultBlockState());
        }
    }

    private static void addExcavationFeatures(List<BuildTask> tasks) {
        int[][] towers = {{-176,-57,83},{-76,-52,103},{-177,26,74},{-79,48,110},{-173,76,61}};
        for (int[] tower : towers) {
            int x = tower[0], z = tower[1], top = tower[2];
            for (int dx : new int[]{0, 8}) for (int dz : new int[]{0, 8})
                addFill(tasks, "excavation scaffold uprights", x + dx, 26, z + dz, x + dx, top, z + dz, TIMBER);
            for (int y = 38; y <= top; y += 16) {
                addFill(tasks, "excavation scaffold platform", x - 1, y, z - 1, x + 9, y, z + 9, WOOD);
                addFill(tasks, "excavation platform railing", x - 1, y + 1, z - 1, x + 9, y + 1, z - 1, FENCE);
                addFill(tasks, "excavation floor lamps", x + 4, y + 2, z + 4, x + 4, y + 2, z + 4, LAMP);
                addFill(tasks, "excavation lamp bounce", x + 4, y + 3, z + 4, x + 4, y + 3, z + 4, HIDDEN_LIGHT);
            }
        }
        // Long mine-footbridge overhead: substantial depth and a separate human walkway.
        addFill(tasks, "cavern suspended footbridge", -174, 67, 27, -78, 68, 31, WOOD);
        for (int z : new int[]{26, 32}) addFill(tasks, "footbridge railing", -174, 69, z, -78, 69, z, FENCE);
        for (int x = -170; x <= -80; x += 9) {
            int cableTop = 88 - (int)(14 * Math.sin(Math.PI * (x + 170) / 90.0));
            for (int z : new int[]{26, 32}) addFill(tasks, "footbridge suspension rods", x, 70, z, x, cableTop, z, Blocks.CHAIN.defaultBlockState());
        }
        addHeadframe(tasks, -160, 27, -12, 74);
        // Huge ragged ore faces, with ordinary vanilla lights behind translucent mineral chips.
        for (int z = -80; z <= 80; z += 16) {
            for (int side : new int[]{-1, 1}) {
                int x = side < 0 ? -181 : -71;
                int y = 53 + (z + 80) % 39;
                addFill(tasks, "large ore seam", x - 1, y, z, x + 1, y + 6, z + 5, Blocks.DEEPSLATE_COPPER_ORE.defaultBlockState());
                addFill(tasks, "lit ore seam", x, y + 2, z + 2, x, y + 4, z + 3, Blocks.SEA_LANTERN.defaultBlockState());
                addFill(tasks, "colored ore glazing", x - side * 2, y + 2, z + 2, x - side * 2, y + 4, z + 3,
                        side < 0 ? Blocks.CYAN_STAINED_GLASS.defaultBlockState() : Blocks.ORANGE_STAINED_GLASS.defaultBlockState());
            }
        }
        for (int i = 0; i < 13; i++) {
            int x = -168 + (i * 23 % 83), z = -81 + (i * 37 % 157);
            int top = 119 + (i % 4) * 7, length = 10 + i % 11;
            tasks.add(box("irregular cavern stalactite", x - 4, top - length, z - 4, x + 4, top, z + 4, p -> {
                double radius = .6 + 3.2 * (p.getY() - (top - length)) / length;
                return sq(p.getX() - x) + sq(p.getZ() - z) <= radius * radius ? Blocks.DRIPSTONE_BLOCK.defaultBlockState() : null;
            }));
        }
    }

    private static void addCanyonFeatures(List<BuildTask> tasks) {
        // Two curving canyon rims and freestanding eroded buttes frame the high-speed descent.
        for (int i = 0; i < 8; i++) {
            addRockSpire(tasks, -71 + i * 34, -163 - (i % 2) * 8, 15 + (i % 3) * 5, 40 + (i % 4) * 8, 38);
        }
        addRockSpire(tasks, -34, -72, 16, 43, 32);
        addRockSpire(tasks, 26, -66, 19, 46, 33);
        // Original weathered stone arch north of the track, visibly framing the escape horizon.
        tasks.add(box("canyon's eroded stone arch", -20, 43, -156, 69, 129, -146, p -> {
            double dx = (p.getX() - 24.0) / 43.0, dy = (p.getY() - 58.0) / 65.0;
            double ring = dx * dx + dy * dy;
            if (p.getY() < 58) return Math.abs(dx) > .83 ? sandstone(p) : null;
            return ring > .74 + .035 * noise(p.getX(), p.getY(), p.getZ(), 53) && ring < 1.05 ? sandstone(p) : null;
        }));
        addHouse(tasks, "abandoned canyon signal box", 61, 64, -139, 78, 12, -126, false);
        addHeadframe(tasks, 44, 38, -145, 44);
        for (int x = -57; x < 72; x += 16) {
            int y = 39 + Math.max(0, x + 60) / 10;
            addFill(tasks, "canyon construction trestle", x, 2, -105, x + 2, y, -103, TIMBER);
            addFill(tasks, "trestle stone footing", x - 1, 1, -107, x + 3, 5, -101, Blocks.STONE_BRICKS.defaultBlockState());
        }
    }

    private static void addRailSideDressing(List<BuildTask> tasks, NativeClearance clearance) {
        List<Placement> details = new ArrayList<>();
        for (int nodeIndex : new int[]{25, 38, 43}) {
            Vec3 approximate = Vec3.atCenterOf(MineRoute.loadBundled().nodes().get(nodeIndex).block());
            NativeMineCourse.GeometrySample nearest = null;
            double best = Double.POSITIVE_INFINITY;
            for (var sample : clearance.samples()) {
                double distance = sample.spine().distanceToSqr(approximate);
                if (distance < best) { best = distance; nearest = sample; }
            }
            if (nearest != null) {
                BlockPos warning = BlockPos.containing(nearest.spine().add(nearest.right().scale(6.7)).add(0, 2, 0));
                details.add(new Placement(warning.below(), IRON));
                details.add(new Placement(warning, Blocks.REDSTONE_LAMP.defaultBlockState()));
                details.add(new Placement(warning.below(2), Blocks.YELLOW_TERRACOTTA.defaultBlockState()));
                details.add(new Placement(warning.above(), HIDDEN_LIGHT));
            }
        }
        double lightDistance = 0, beamDistance = 0, braceDistance = 0;
        Vec3 previous = null;
        for (var frame : clearance.samples()) {
            Vec3 spine = frame.spine();
            if (previous != null) {
                double distance = spine.distanceTo(previous);
                lightDistance += distance; beamDistance += distance; braceDistance += distance;
            }
            previous = spine;
            if (lightDistance >= 5.0) {
                lightDistance = 0;
                for (int side : new int[]{-1, 1}) {
                    Vec3 lamp = spine.add(frame.right().scale(side * 7.4)).add(0, 2, 0);
                    details.add(new Placement(BlockPos.containing(lamp), HIDDEN_LIGHT));
                    if (isTunnel(spine) || spine.x < -107) {
                        details.add(new Placement(BlockPos.containing(lamp.add(0, -1, 0)), LAMP));
                        details.add(new Placement(BlockPos.containing(lamp.add(0, -2, 0)), TIMBER));
                    }
                }
            }
            if (beamDistance >= 13.0) {
                beamDistance = 0;
                for (int side : new int[]{-1, 1}) {
                    Vec3 foot = spine.add(frame.right().scale(side * 7.4));
                    BlockPos top = BlockPos.containing(foot.add(0, -1, 0));
                    int floor = spine.x < -108 ? 24 : Math.min(terrainHeight(top.getX(), top.getZ()), (int)spine.y - 9);
                    for (int y = Math.max(1, floor); y < top.getY(); y++) {
                        details.add(new Placement(new BlockPos(top.getX(), y, top.getZ()), TIMBER));
                        if (y % 14 == 0) details.add(new Placement(new BlockPos(top.getX() + side, y, top.getZ()), IRON));
                    }
                }
                Vec3 a = spine.add(frame.right().scale(-7.8)).add(0, -6.8, 0);
                Vec3 b = spine.add(frame.right().scale(7.8)).add(0, -6.8, 0);
                int pieces = (int)Math.ceil(a.distanceTo(b) * 2);
                for (int i = 0; i <= pieces; i++) details.add(new Placement(BlockPos.containing(a.lerp(b, (double)i / pieces)),
                        Blocks.STRIPPED_DARK_OAK_LOG.defaultBlockState().setValue(RotatedPillarBlock.AXIS, Direction.Axis.X)));
            }
            if (isTunnel(spine) && braceDistance >= 9.0) {
                braceDistance = 0;
                for (double angle = .12; angle < Math.PI * 1.97; angle += .1) {
                    Vec3 edge = spine.add(frame.right().scale(Math.cos(angle) * 8.2))
                            .add(frame.up().scale(Math.sin(angle) * 10.3));
                    details.add(new Placement(BlockPos.containing(edge), angle < .55 || angle > 5.7 ? IRON : TIMBER));
                }
            }
        }
        tasks.add(new PlacementTask("continuous safe lighting and timber/steel trestles", details));
    }

    private static void addTunnelShells(List<BuildTask> tasks, NativeClearance clearance) {
        Vec3 previous = null;
        for (var frame : clearance.samples()) {
            Vec3 center = frame.spine();
            if (!isTunnel(center)) continue;
            if (previous != null && previous.distanceTo(center) < 2.2) continue;
            previous = center;
            int cx = (int)Math.floor(center.x), cy = (int)Math.floor(center.y), cz = (int)Math.floor(center.z);
            tasks.add(box("rough mined tunnel lining", cx - 12, cy - 13, cz - 12, cx + 12, cy + 13, cz + 12, p -> {
                Vec3 delta = Vec3.atCenterOf(p).subtract(center);
                if (Math.abs(delta.dot(frame.forward())) > 1.8) return null;
                double radius = sq(delta.dot(frame.right()) / 8.2) + sq(delta.dot(frame.up()) / 10.3);
                double rough = .045 * noise(p.getX(), p.getY(), p.getZ(), 37);
                return radius >= .82 + rough && radius <= 1.10 + rough ? caveStone(p) : null;
            }));
        }
    }

    private static boolean isTunnel(Vec3 p) {
        return (p.x < 30 && p.x > -119 && p.z > 91)
                || (p.x > 127 && p.x < 168 && p.z < -39);
    }

    private static void addHeadframe(List<BuildTask> tasks, int x, int y, int z, int height) {
        for (int dx : new int[]{0, 7}) for (int dz : new int[]{0, 7}) {
            addFill(tasks, "mining headframe leg", x + dx, y, z + dz, x + dx, y + height, z + dz, TIMBER);
            for (int step = 0; step <= height; step++) {
                int diagonal = (step % 14) / 2;
                addFill(tasks, "headframe diagonal steel", x + diagonal, y + step, z + dz,
                        x + diagonal, y + step, z + dz, IRON);
            }
        }
        for (int rise = 12; rise <= height; rise += 12)
            tasks.add(box("headframe open steel tie", x, y + rise, z, x + 7, y + rise, z + 7,
                    p -> p.getX() == x || p.getX() == x + 7 || p.getZ() == z || p.getZ() == z + 7 ? IRON : null));
        addFill(tasks, "headframe top machinery deck", x - 1, y + height, z - 1, x + 8, y + height + 1, z + 8, WOOD);
        addFill(tasks, "headframe winding wheel", x + 2, y + height + 2, z + 3, x + 5, y + height + 5, z + 4,
                Blocks.POLISHED_BLACKSTONE_BRICKS.defaultBlockState());
        addFill(tasks, "hoist cable", x + 4, y + 3, z + 4, x + 4, y + height + 3, z + 4, Blocks.CHAIN.defaultBlockState());
        addFill(tasks, "hoist cage base", x + 2, y + 4, z + 2, x + 5, y + 4, z + 5, IRON);
        addFill(tasks, "hoist warm light", x + 4, y + height + 3, z + 8, x + 4, y + height + 3, z + 8, LAMP);
    }

    private static void addHouse(List<BuildTask> tasks, String name, int x0, int y0, int z0,
                                 int x1, int height, int z1, boolean ironRoof) {
        addFill(tasks, name + " stone foundations", x0 - 1, y0 - 3, z0 - 1, x1 + 1, y0, z1 + 1, Blocks.STONE_BRICKS.defaultBlockState());
        tasks.add(box(name + " weathered timber walls", x0, y0 + 1, z0, x1, y0 + height, z1, p -> {
            boolean perimeter = p.getX() == x0 || p.getX() == x1 || p.getZ() == z0 || p.getZ() == z1;
            if (!perimeter) return null;
            if (p.getX() >= x0 + 3 && p.getX() <= x0 + 5 && p.getZ() == z0 && p.getY() <= y0 + 4) return null;
            if (p.getY() >= y0 + 4 && p.getY() <= y0 + 6 && (p.getX() - x0) % 7 >= 3 && (p.getX() - x0) % 7 <= 5)
                return Blocks.GRAY_STAINED_GLASS.defaultBlockState();
            return (p.getX() - x0) % 6 == 0 || (p.getZ() - z0) % 6 == 0 ? TIMBER : Blocks.SPRUCE_PLANKS.defaultBlockState();
        }));
        tasks.add(box(name + " uneven roof", x0 - 1, y0 + height, z0 - 2, x1 + 1, y0 + height + 7, z1 + 2, p -> {
            int ridge = y0 + height + 6 - (int)Math.abs((p.getX() - (x0 + x1) / 2.0) * .55);
            if (p.getY() != ridge && p.getY() != ridge - 1) return null;
            return ironRoof ? Blocks.WAXED_OXIDIZED_CUT_COPPER.defaultBlockState() : WOOD;
        }));
        addFill(tasks, name + " internal lamp", x0 + 3, y0 + 7, z0 + 3, x0 + 3, y0 + 7, z0 + 3, LAMP);
    }

    private static void addRockSpire(List<BuildTask> tasks, int x, int z, int width, int height, int base) {
        tasks.add(box("naturally eroded red-rock butte", x - width, base, z - width, x + width, base + height, z + width, p -> {
            double rise = (p.getY() - base) / (double)height;
            double taper = 1.0 - .62 * rise;
            double radius = sq((p.getX() - x) / (width * taper)) + sq((p.getZ() - z) / (width * taper * .78));
            double rough = .11 * noise(p.getX(), p.getY(), p.getZ(), 17);
            // Solid exterior with a closed top and bottom; large interiors stay hollow to limit generation cost.
            if (radius > 1 + rough) return null;
            if (radius < .70 + rough && p.getY() > base + 2 && p.getY() < base + height - 3) return null;
            return sandstone(p);
        }));
    }

    private static void addFill(List<BuildTask> tasks, String name, int x0, int y0, int z0, int x1, int y1, int z1, BlockState state) {
        if (state.is(Blocks.DARK_OAK_FENCE)) {
            tasks.add(box(name, x0, y0, z0, x1, y1, z1, p -> state
                    .setValue(FenceBlock.WEST, p.getX() > x0)
                    .setValue(FenceBlock.EAST, p.getX() < x1)
                    .setValue(FenceBlock.NORTH, p.getZ() > z0)
                    .setValue(FenceBlock.SOUTH, p.getZ() < z1)));
            return;
        }
        tasks.add(box(name, x0, y0, z0, x1, y1, z1, p -> state));
    }
    private static void addSign(List<BuildTask> tasks, int x, int y, int z, Direction facing) {
        addFill(tasks, "visitor guide sign", x, y, z, x, y, z,
                Blocks.OAK_WALL_SIGN.defaultBlockState().setValue(WallSignBlock.FACING, facing));
    }
    private static BuildTask box(String name, int x0, int y0, int z0, int x1, int y1, int z1, Material material) {
        return new BoxTask(name, x0, y0, z0, x1, y1, z1, material);
    }

    private static int terrainHeight(int x, int z) {
        double edge = Math.min(Math.min(x + 219, 239 - x), Math.min(z + 189, 189 - z));
        double fade = Math.max(0, Math.min(1, edge / 31.0));
        fade = fade * fade * (3 - 2 * fade);
        double base = 38 + 7 * noise(x, 0, z, 31);
        double hill = 149 * Math.exp(-sq((x + 125.0) / 94.0) - sq(z / 141.0))
                + 93 * Math.exp(-sq((x - 64.0) / 132.0) - sq((z - 115.0) / 55.0));
        if (z < -70 && x > -105) hill *= .12;
        double height = base + hill + 4 * Math.sin(x * .17 + Math.sin(z * .09));
        if (x > 154 && z > -35 && z < 47) height = 79.0 + 1.0 * noise(x, 0, z, 11);
        return Math.max(2, (int)Math.round(2 + (height - 2) * fade));
    }
    private static BlockState sandstone(BlockPos p) {
        int band = Math.floorMod(p.getY() / 5 + (int)(noise(p.getX(), 0, p.getZ(), 91) * 2), 7);
        if (band == 0) return Blocks.BROWN_TERRACOTTA.defaultBlockState();
        if (band == 1) return Blocks.RED_TERRACOTTA.defaultBlockState();
        if (band == 5) return Blocks.YELLOW_TERRACOTTA.defaultBlockState();
        if (band == 6) return Blocks.TERRACOTTA.defaultBlockState();
        return hash(p.getX(), p.getY(), p.getZ(), 7) % 13 == 0 ? Blocks.RED_SANDSTONE.defaultBlockState() : Blocks.ORANGE_TERRACOTTA.defaultBlockState();
    }
    private static BlockState caveStone(BlockPos p) {
        long value = hash(p.getX(), p.getY(), p.getZ(), 13);
        if (value % 113 == 0) return Blocks.GLOWSTONE.defaultBlockState();
        if (value % 29 == 0) return Blocks.DEEPSLATE_IRON_ORE.defaultBlockState();
        if (value % 31 == 0) return Blocks.DEEPSLATE_COPPER_ORE.defaultBlockState();
        if (value % 13 == 0) return Blocks.TUFF.defaultBlockState();
        if (value % 7 == 0) return Blocks.ANDESITE.defaultBlockState();
        return p.getY() < 63 ? Blocks.DEEPSLATE.defaultBlockState() : Blocks.STONE.defaultBlockState();
    }
    private static double noise(int x, int y, int z, int seed) {
        return .53 * Math.sin(x * .074 + seed * .31) * Math.cos(z * .067 - seed * .21)
                + .30 * Math.sin(x * .181 + z * .133 + y * .089 + seed)
                + .17 * Math.cos(z * .319 - x * .227 + y * .193 + seed * .41);
    }
    private static long hash(int x, int y, int z, int seed) {
        long v = x * 0x632be59bd9b4e019L ^ y * 0x9e3779b97f4a7c15L ^ z * 0xc6bc279692b5cc83L ^ seed;
        v ^= v >>> 27; v *= 0x3c79ac492ba7b653L; v ^= v >>> 33;
        return v & Long.MAX_VALUE;
    }
    private static double sq(double value) { return value * value; }

    private static void decorateSigns(ServerLevel level) {
        setSign(level, new BlockPos(180, 85, -3), "右クリックで乗車", "BOARD", "鉱山車両へ", "Use board button");
        setSign(level, new BlockPos(180, 85, 0), "発車", "DISPATCH", "1周して駅へ帰還", "One adventure lap");
        setSign(level, new BlockPos(180, 85, 3), "緊急停止", "EMERGENCY STOP", "再発車は駅から", "Station control");
        setSign(level, new BlockPos(218, 93, -7), "THUNDER MINE", "EXPEDITION", "Original mine adventure", "駅は木の通路の先");
    }
    private static void setSign(ServerLevel level, BlockPos position, String a, String b, String c, String d) {
        if (!(level.getBlockEntity(position) instanceof SignBlockEntity sign)) return;
        Component[] lines = {Component.literal(a), Component.literal(b), Component.literal(c), Component.literal(d)};
        sign.setText(new SignText(lines, lines, DyeColor.BLACK, false), true);
        sign.setChanged();
        level.sendBlockUpdated(position, level.getBlockState(position), level.getBlockState(position), 3);
    }

    private record Job(NativeClearance clearance, List<BuildTask> tasks) {}
    private static final class TopsoilRepair { int cursor; long changed; }
    private record Placement(BlockPos position, BlockState state) {}
    private interface BuildTask { String name(); long size(); Placement at(long cursor); }
    @FunctionalInterface private interface Material { BlockState at(BlockPos position); }
    private record PlacementTask(String name, List<Placement> placements) implements BuildTask {
        @Override public long size() { return placements.size(); }
        @Override public Placement at(long cursor) { return placements.get((int)cursor); }
    }
    private record BoxTask(String name, int x0, int y0, int z0, int x1, int y1, int z1, Material material) implements BuildTask {
        @Override public long size() { return (long)(x1 - x0 + 1) * (y1 - y0 + 1) * (z1 - z0 + 1); }
        @Override public Placement at(long cursor) {
            int nx = x1 - x0 + 1, nz = z1 - z0 + 1;
            int x = x0 + (int)(cursor % nx);
            int z = z0 + (int)(cursor / nx % nz);
            int y = y0 + (int)(cursor / ((long)nx * nz));
            BlockPos pos = new BlockPos(x, y, z);
            BlockState state = material.at(pos);
            return state == null ? null : new Placement(pos, state);
        }
    }
    private static final class TerrainTask implements BuildTask {
        private static final int X0 = -219, X1 = 239, Z0 = -189, Z1 = 189;
        private static final int NX = X1 - X0 + 1, NZ = Z1 - Z0 + 1, DEPTH = 10;
        private final int[] heights = new int[NX * NZ];
        private final long[] offsets = new long[NX * NZ + 1];
        private TerrainTask() {
            for (int z = Z0; z <= Z1; z++) for (int x = X0; x <= X1; x++) heights[(z - Z0) * NX + x - X0] = terrainHeight(x, z);
            int maximumStep = 0;
            for (int column = 0; column < heights.length; column++) {
                int x = column % NX, z = column / NX, top = heights[column];
                int lowestNeighbor = top;
                if (x > 0) lowestNeighbor = Math.min(lowestNeighbor, heights[column - 1]);
                if (x < NX - 1) lowestNeighbor = Math.min(lowestNeighbor, heights[column + 1]);
                if (z > 0) lowestNeighbor = Math.min(lowestNeighbor, heights[column - NX]);
                if (z < NZ - 1) lowestNeighbor = Math.min(lowestNeighbor, heights[column + NX]);
                maximumStep = Math.max(maximumStep, top - lowestNeighbor);
                // Fill every steep cliff down to the neighboring surface: no exposed hollow seam.
                int depth = Math.min(top, Math.max(DEPTH, top - lowestNeighbor + 2));
                offsets[column + 1] = offsets[column] + depth;
            }
            LOGGER.info("MINE_SCENERY_TERRAIN_CONTINUITY columns={} maxAdjacentHeightStep={} sealedCandidateBlocks={}",
                    heights.length, maximumStep, offsets[heights.length]);
        }
        @Override public String name() { return "continuous badlands rock terrain"; }
        @Override public long size() { return offsets[heights.length]; }
        @Override public Placement at(long cursor) {
            int search = Arrays.binarySearch(offsets, cursor);
            int column = search >= 0 ? search : -search - 2;
            int depth = (int)(cursor - offsets[column]);
            int x = X0 + column % NX, z = Z0 + column / NX, top = heights[column];
            int y = top - depth;
            if (y < 1) return null;
            BlockPos p = new BlockPos(x, y, z);
            BlockState state = sandstone(p);
            // Gravity blocks can fall through intentionally omitted native clearance cells.
            // Keep the same red-rock palette while using an immovable surface instead.
            if (depth == 0 && hash(x, 0, z, 3) % 6 == 0) state = Blocks.RED_SANDSTONE.defaultBlockState();
            return new Placement(p, state);
        }
    }
}
