package dev.thundermine.tools;

/** Checks actual held pose over time; a native solver residual alone is not physical movement. */
final class MineNativeHoldReadiness {
    static final double MAX_RESIDUAL_SPEED = 0.10;
    static final double REQUIRED_STABLE_SECONDS = 0.50;
    static final double MAX_POSITION_DRIFT = 0.005;
    private static final double MAX_ROTATION_DRIFT_RADIANS = Math.toRadians(0.25);
    private double x, y, z, qx, qy, qz, qw;
    private double stableSeconds;
    private boolean sampled;

    void reset() { sampled = false; stableSeconds = 0.0; }

    void observe(boolean validNativeHold, double nativeSpeed, double dt,
                 double px, double py, double pz, double rx, double ry, double rz, double rw) {
        double norm = Math.sqrt(rx * rx + ry * ry + rz * rz + rw * rw);
        if (!validNativeHold || !Double.isFinite(nativeSpeed) || nativeSpeed < 0.0
                || nativeSpeed > MAX_RESIDUAL_SPEED || !Double.isFinite(dt) || dt <= 0.0 || dt > 0.10
                || !Double.isFinite(px) || !Double.isFinite(py) || !Double.isFinite(pz)
                || !Double.isFinite(norm) || norm < 0.9 || norm > 1.1) {
            reset(); return;
        }
        rx /= norm; ry /= norm; rz /= norm; rw /= norm;
        double distance = sampled ? Math.sqrt(square(px - x) + square(py - y) + square(pz - z)) : 0.0;
        double dot = sampled ? Math.min(1.0, Math.abs(rx * qx + ry * qy + rz * qz + rw * qw)) : 1.0;
        if (!sampled || distance > MAX_POSITION_DRIFT || 2.0 * Math.acos(dot) > MAX_ROTATION_DRIFT_RADIANS) {
            x = px; y = py; z = pz; qx = rx; qy = ry; qz = rz; qw = rw;
            sampled = true; stableSeconds = 0.0;
            return;
        }
        stableSeconds += dt;
    }

    boolean ready() { return sampled && stableSeconds + 1.0e-9 >= REQUIRED_STABLE_SECONDS; }
    double stableSeconds() { return stableSeconds; }
    private static double square(double value) { return value * value; }
}
