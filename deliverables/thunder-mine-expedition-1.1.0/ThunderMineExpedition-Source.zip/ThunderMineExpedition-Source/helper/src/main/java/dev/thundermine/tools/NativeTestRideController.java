package dev.thundermine.tools;

import com.mojang.logging.LogUtils;
import dev.ryanhcode.sable.api.physics.PhysicsPipeline;
import dev.ryanhcode.sable.neoforge.event.ForgeSablePostPhysicsTickEvent;
import dev.ryanhcode.sable.neoforge.event.ForgeSablePrePhysicsTickEvent;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartLinkPlacement;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartTrackSnap;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathGraphManager;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathTrackFrame;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.level.LevelEvent;
import org.joml.Quaterniond;
import org.joml.Vector3d;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;

/**
 * Explicit, small-course commissioning controller. Existing Simulated Coasters rail guides
 * and Sable/Rapier advance and rotate the body. This class changes native velocity only:
 * it never assigns a pose, teleports the cart, or fabricates a completed lap.
 */
public final class NativeTestRideController {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final String SAVE_KEY = "thunder_mine_native_test";
    private static final Map<ServerLevel, Session> SESSIONS = new IdentityHashMap<>();
    private static final Map<ServerLevel, String> RESTORE_FAILURES = new IdentityHashMap<>();
    private static final double TARGET_SPEED = 4.0;
    private static final double ACCELERATION = 2.0;
    private static final double BRAKING = 3.0;
    private static final double TWO_LAPS = Math.PI * 4.0;
    private static final double STATION_MARGIN_RADIANS = 0.025;
    private static final double STATION_DISTANCE_LIMIT = 0.65;
    private static final double HOLD_SECONDS = 3.0;
    private static final double TIMEOUT_SECONDS = 180.0;

    private NativeTestRideController() {}

    public static void register(IEventBus gameBus) {
        // Run after the unchanged MOD's normal-priority rail-guide/chain-lift callbacks.
        gameBus.addListener(EventPriority.LOWEST, NativeTestRideController::onPrePhysicsTick);
        gameBus.addListener(EventPriority.LOWEST, NativeTestRideController::onPostPhysicsTick);
        gameBus.addListener(NativeTestRideController::onLevelUnload);
    }

    /** Called after normal native cart construction; establishes a stationary commissioning seat. */
    public static void armStationHold(ServerLevel level, ServerSubLevel cart) {
        Session state = createSession(level, cart, "PARKED");
        SESSIONS.put(level, state);
        cartPhysics(level).resetVelocity(cart);
        writeNativeEvidence(level, cart, state);
        LOGGER.info("MINE_NATIVE_PARKED cart={} world={} gameTick={} station={}",
                cart.getUniqueId(), level.dimension().location(), level.getGameTime(), state.station);
    }

    /** Explicit start command. Runs two physical circuits, then verifies three stationary seconds. */
    public static String start(ServerLevel level) {
        if (!commissioned(level)) throw new IllegalStateException("Start refused: no successfully built dedicated native test course.");
        ServerSubLevel cart = CoasterTestService.cart(level);
        if (cart == null) throw new IllegalStateException("Start refused: the saved test cart is not loaded; build/load the test course first.");
        Session previous = SESSIONS.get(level);
        if (previous != null && previous.isRunning()) throw new IllegalStateException("The native two-lap test is already running.");
        CoasterTestService.requireClosedNativeTopology(level);
        Vec3 bearing = bearing(cart);
        Vec3 expectedStation = CoasterTestService.stationSpine(level).add(0.0, 0.3125, 0.0);
        if (bearing == null || bearing.distanceTo(expectedStation) > STATION_DISTANCE_LIMIT) {
            throw new IllegalStateException("Start refused: cart is not at the commissioned station; no automatic teleport was performed.");
        }
        if (!CoasterTestService.nativeEngaged(cart)) {
            throw new IllegalStateException("Start refused: the existing MOD reports the cart disengaged from its rails.");
        }
        Session state = createSession(level, cart, "RUNNING");
        RESTORE_FAILURES.remove(level);
        SESSIONS.put(level, state);
        cartPhysics(level).resetVelocity(cart);
        writeNativeEvidence(level, cart, state);
        LOGGER.info("MINE_NATIVE_TEST_STARTED run={} cart={} world={} gameTick={} targetSpeedBlocksPerSecond={} targetLaps=2",
                state.runId, state.cartId, level.dimension().location(), level.getGameTime(), TARGET_SPEED);
        return "Native two-lap test started at 4 blocks/second (14.4 km/h equivalent).";
    }

    public static String stop(ServerLevel level) {
        ServerSubLevel cart = CoasterTestService.cart(level);
        if (cart == null) return "Stop: no loaded test cart.";
        if (!commissioned(level)) {
            cartPhysics(level).resetVelocity(cart);
            return "Incomplete test cart velocity stopped; construction remains unverified.";
        }
        Session state = SESSIONS.get(level);
        if (state == null) {
            state = createSession(level, cart, "STOPPED");
            SESSIONS.put(level, state);
        }
        state.phase = "STOPPED";
        state.failure = "Stopped explicitly; this run is not a commissioning pass";
        cartPhysics(level).resetVelocity(cart);
        writeNativeEvidence(level, cart, state);
        return "Native velocity stopped; the cart was not moved back to the station.";
    }

    public static String status(ServerLevel level) {
        if (!commissioned(level)) return "Native ride test unavailable: construction has not committed successfully.";
        ServerSubLevel cart = CoasterTestService.cart(level);
        if (cart == null) return "No loaded native test cart. Saved identity: " + CoasterTestService.cartId(level);
        if (!ensureSession(level, cart)) return "Native controller restore refused: " + RESTORE_FAILURES.get(level);
        Session state = SESSIONS.get(level);
        Vector3d velocity = cartPhysics(level).getLinearVelocity(cart, new Vector3d());
        Vec3 point = bearing(cart);
        return String.format(Locale.ROOT,
                "Native cart=%s state=%s measured=%.2f blocks speed=%.3f blocks/s (%.2f km/h) completedLaps=%d engaged=%s bearing=%s failure=%s",
                cart.getUniqueId(), state.phase, state.progress.measuredDistance(), velocity.length(),
                velocity.length() * 3.6, state.completedLaps, CoasterTestService.nativeEngaged(cart),
                point, state.failure.isEmpty() ? "none" : state.failure);
    }

    /** Read-only boarding interlock: a committed, genuinely engaged body held at its station. */
    public static boolean heldAtStation(ServerLevel level) {
        if (!commissioned(level)) return false;
        ServerSubLevel cart = CoasterTestService.cart(level);
        if (cart == null || cart.isRemoved() || !ensureSession(level, cart)) return false;
        Session state = SESSIONS.get(level);
        if (!"PARKED".equals(state.phase) && !"PASSED".equals(state.phase)) return false;
        Vec3 point = bearing(cart);
        return CoasterTestService.nativeEngaged(cart) && point != null && finitePose(cart, point)
                && point.distanceTo(state.station) <= STATION_DISTANCE_LIMIT
                && cartPhysics(level).getLinearVelocity(cart, new Vector3d()).length() <= 0.05;
    }

    /** No replay on reload. Restore a saved parked/failed controller and report real read-back. */
    private static void observeReload(ServerLevel level, ServerSubLevel cart) {
        if (SESSIONS.containsKey(level)) return;
        CompoundTag user = cart.getUserDataTag();
        CompoundTag saved = user == null ? new CompoundTag() : user.getCompound(SAVE_KEY);
        String savedPhase = saved.getString("phase");
        Vec3 actual = bearing(cart);
        Vector3d velocity = cartPhysics(level).getLinearVelocity(cart, new Vector3d());
        boolean matchingIdentity = saved.hasUUID("cart_id") && cart.getUniqueId().equals(saved.getUUID("cart_id"));
        boolean observedStation = actual != null && actual.distanceTo(
                CoasterTestService.stationSpine(level).add(0.0, 0.3125, 0.0)) <= STATION_DISTANCE_LIMIT;
        boolean restorable = matchingIdentity && observedStation && velocity.length() <= 0.05
                && CoasterTestService.nativeEngaged(cart);
        Session state = createSession(level, cart, restorable &&
                ("PASSED".equals(savedPhase) || "PARKED".equals(savedPhase)) ? savedPhase : "INTERRUPTED");
        state.completedLaps = saved.getInt("completed_laps");
        state.failure = "INTERRUPTED".equals(state.phase) ? "Reload never resumes an unfinished commissioning run automatically" : "";
        if (saved.hasUUID("run_id")) state.runId = saved.getUUID("run_id");
        state.elapsedSeconds = saved.getDouble("elapsed_seconds");
        state.measuredDistance3d = saved.getDouble("measured_distance_3d");
        state.maxSpeed = saved.getDouble("max_native_speed");
        state.maxMeasuredSpeed = saved.getDouble("max_measured_speed");
        state.maxAcceleration = saved.getDouble("max_acceleration");
        state.holdSeconds = saved.getDouble("hold_seconds");
        state.progress.restoreMeasurement(saved.getDouble("progress_radians"), saved.getDouble("measured_distance_horizontal"));
        if ("PASSED".equals(state.phase) && (state.completedLaps != 2 || state.holdSeconds < HOLD_SECONDS
                || state.measuredDistance3d < state.radius * TWO_LAPS - 2.0
                || state.progress.progressRadians() < TWO_LAPS - STATION_MARGIN_RADIANS)) {
            state.phase = "INTERRUPTED";
            state.failure = "Saved pass measurements did not satisfy the two-lap station-hold criteria";
        }
        SESSIONS.put(level, state);
        double savedDelta = saved.contains("bearing_x") && actual != null ? actual.distanceTo(new Vec3(
                saved.getDouble("bearing_x"), saved.getDouble("bearing_y"), saved.getDouble("bearing_z"))) : Double.NaN;
        LOGGER.info("MINE_NATIVE_RELOAD cart={} world={} gameTick={} savedPhase={} restoredPhase={} savedCompletedLaps={} actualBearing={} savedBearingDelta={} actualVelocity={} savedGameTick={} nativeUuidMatches={}",
                cart.getUniqueId(), level.dimension().location(), level.getGameTime(), savedPhase, state.phase,
                state.completedLaps, actual, savedDelta, velocity, saved.getLong("game_tick"),
                matchingIdentity);
        writeNativeEvidence(level, cart, state);
    }

    public static void onPrePhysicsTick(ForgeSablePrePhysicsTickEvent event) {
        ServerLevel level = event.getPhysicsSystem().getLevel();
        if (!commissioned(level)) return;
        ServerSubLevel cart = CoasterTestService.cart(level);
        if (cart == null || cart.isRemoved()) return;
        if (!ensureSession(level, cart)) return;
        Session state = SESSIONS.get(level);
        if (!cart.getUniqueId().equals(state.cartId)) {
            fail(level, cart, state, "Native cart UUID changed during commissioning");
            return;
        }
        PhysicsPipeline pipeline = event.getPhysicsSystem().getPipeline();
        if (!state.isRunning()) {
            pipeline.resetVelocity(cart);
            return;
        }
        Vec3 bearing = bearing(cart);
        if (bearing == null || !finitePose(cart, bearing)) {
            fail(level, cart, state, "Invalid native bearing/pose");
            return;
        }
        if (!CoasterTestService.nativeEngaged(cart)) {
            fail(level, cart, state, "Existing rail guide disengaged");
            return;
        }
        CoasterPathTrackFrame.GraphHit hit = CoasterPathTrackFrame.nearestGraphHit(
                level, CoasterPathGraphManager.get(level), bearing, 1.0);
        if (hit == null) {
            fail(level, cart, state, "Native bearing is more than one block from the existing track graph");
            return;
        }
        CoasterPathTrackFrame.TrackBasis basis = CoasterPathTrackFrame.trackBasisAtHit(level, hit);
        Vec3 forward = basis.forward().normalize();
        Vec3 desired = new Vec3(state.progress.forwardXAt(bearing.x, bearing.z), 0.0,
                state.progress.forwardZAt(bearing.x, bearing.z)).normalize();
        if (forward.dot(desired) < 0.0) forward = forward.scale(-1.0);
        Vector3d nativeVelocity = pipeline.getLinearVelocity(cart, new Vector3d());
        double current = nativeVelocity.x * forward.x + nativeVelocity.y * forward.y + nativeVelocity.z * forward.z;
        double remaining = state.progress.remainingDistance(2, state.radius);
        double target = TARGET_SPEED;
        if ("HOLDING".equals(state.phase)) target = 0.0;
        else if (remaining <= TARGET_SPEED * TARGET_SPEED / (2.0 * BRAKING) + 1.0) {
            state.phase = "BRAKING";
            target = Math.min(TARGET_SPEED, Math.sqrt(2.0 * BRAKING * Math.max(0.0, remaining - 0.12)));
        }
        double maxDelta = (target < current ? BRAKING : ACCELERATION) * event.getTimeStep();
        double change = Math.max(-maxDelta, Math.min(maxDelta, target - current));
        pipeline.addLinearAndAngularVelocity(cart, new Vector3d(forward.x, forward.y, forward.z).mul(change), new Vector3d());
    }

    public static void onPostPhysicsTick(ForgeSablePostPhysicsTickEvent event) {
        ServerLevel level = event.getPhysicsSystem().getLevel();
        if (!commissioned(level)) return;
        ServerSubLevel cart = CoasterTestService.cart(level);
        if (cart == null || cart.isRemoved()) return;
        if (!ensureSession(level, cart)) return;
        Session state = SESSIONS.get(level);
        Vec3 point = bearing(cart);
        if (point == null || !finitePose(cart, point)) {
            fail(level, cart, state, "Invalid native pose after simulation");
            return;
        }
        Vector3d velocity = event.getPhysicsSystem().getPipeline().getLinearVelocity(cart, new Vector3d());
        if (state.isRunning()) {
            if (!CoasterTestService.nativeEngaged(cart)) {
                fail(level, cart, state, "Existing rail guide disengaged during the actual physics step");
                return;
            }
            double dt = event.getTimeStep();
            double measuredStep = state.lastPoint.distanceTo(point);
            // Reject discontinuous jumps instead of counting them as native travel or a lap.
            if (measuredStep > 8.0 * dt + 0.10) {
                fail(level, cart, state, "Native pose jumped " + measuredStep + " blocks in " + dt + " seconds");
                return;
            }
            state.elapsedSeconds += dt;
            state.progress.observeChecked(point.x, point.z, dt, 8.0, 0.10);
            state.measuredDistance3d += measuredStep;
            state.maxSpeed = Math.max(state.maxSpeed, velocity.length());
            state.maxMeasuredSpeed = Math.max(state.maxMeasuredSpeed, measuredStep / dt);
            state.maxAcceleration = Math.max(state.maxAcceleration, velocity.distance(state.lastVelocity) / dt);
            state.lastVelocity.set(velocity);
            state.lastPoint = point;
            double stationDistance = point.distanceTo(state.station);
            boolean atSecondStation = state.progress.progressRadians() >= TWO_LAPS - STATION_MARGIN_RADIANS
                    && stationDistance <= STATION_DISTANCE_LIMIT;
            state.completedLaps = Math.max(state.completedLaps,
                    Math.min(1, (int)Math.floor(Math.max(0.0, state.progress.progressRadians()) / (2.0 * Math.PI))));
            if (atSecondStation && velocity.length() <= 0.05) {
                state.phase = "HOLDING";
                state.completedLaps = 2;
                state.holdSeconds += dt;
            } else if ("HOLDING".equals(state.phase)) {
                fail(level, cart, state, "Cart moved out of the station's measured stop envelope during hold");
                return;
            }
            if (state.holdSeconds >= HOLD_SECONDS) {
                state.phase = "PASSED";
                LOGGER.info("MINE_NATIVE_TEST_PASSED run={} cart={} world={} gameTick={} laps={} measuredDistance3d={} elapsedSeconds={} maxNativeSpeed={} maxMeasuredSpeed={} maxAcceleration={} stationDistance={} stationarySeconds={} nativePoseAssignments=0",
                        state.runId, state.cartId, level.dimension().location(), level.getGameTime(), state.completedLaps,
                        state.measuredDistance3d, state.elapsedSeconds, state.maxSpeed, state.maxMeasuredSpeed,
                        state.maxAcceleration, stationDistance, state.holdSeconds);
                writeNativeEvidence(level, cart, state);
            } else if (state.elapsedSeconds > TIMEOUT_SECONDS) {
                fail(level, cart, state, "Two-lap commissioning exceeded 180 simulated seconds");
                return;
            }
        }
        if (state.lastLoggedTick != level.getGameTime() && level.getGameTime() % 20L == 0L) {
            state.lastLoggedTick = level.getGameTime();
            LOGGER.info("MINE_NATIVE_SAMPLE run={} cart={} world={} gameTick={} phase={} position={} bearing={} quaternion={} linearVelocity={} speedBlocksPerSecond={} measuredDistance3d={} progressRadians={} completedLaps={} engaged={}",
                    state.runId, state.cartId, level.dimension().location(), level.getGameTime(), state.phase,
                    cart.logicalPose().position(), point, cart.logicalPose().orientation(), velocity, velocity.length(),
                    state.measuredDistance3d, state.progress.progressRadians(), state.completedLaps,
                    CoasterTestService.nativeEngaged(cart));
            writeNativeEvidence(level, cart, state);
        }
    }

    public static void detach(ServerLevel level) {
        SESSIONS.remove(level);
        RESTORE_FAILURES.remove(level);
    }

    private static void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel level) detach(level);
    }

    private static boolean commissioned(ServerLevel level) {
        return level.dimension().equals(Level.OVERWORLD)
                && CoasterTestService.REQUIRED_WORLD_NAME.equals(level.getServer().getWorldData().getLevelName())
                && CoasterTestSavedData.get(level).built();
    }

    private static boolean ensureSession(ServerLevel level, ServerSubLevel cart) {
        if (SESSIONS.containsKey(level)) return true;
        if (RESTORE_FAILURES.containsKey(level)) {
            cartPhysics(level).resetVelocity(cart);
            return false;
        }
        try {
            CoasterTestService.requireClosedNativeTopology(level);
            observeReload(level, cart);
            return true;
        } catch (RuntimeException exception) {
            String reason = exception.getMessage() == null ? exception.getClass().getSimpleName() : exception.getMessage();
            RESTORE_FAILURES.put(level, reason);
            cartPhysics(level).resetVelocity(cart);
            LOGGER.error("MINE_NATIVE_RESTORE_REFUSED cart={} world={} gameTick={} reason={}",
                    cart.getUniqueId(), level.dimension().location(), level.getGameTime(), reason);
            return false;
        }
    }

    private static void fail(ServerLevel level, ServerSubLevel cart, Session state, String reason) {
        if ("FAILED".equals(state.phase)) return;
        state.phase = "FAILED";
        state.failure = reason;
        cartPhysics(level).resetVelocity(cart);
        writeNativeEvidence(level, cart, state);
        LOGGER.error("MINE_NATIVE_TEST_FAILED run={} cart={} world={} gameTick={} reason={}",
                state.runId, state.cartId, level.dimension().location(), level.getGameTime(), reason);
    }

    private static Session createSession(ServerLevel level, ServerSubLevel cart, String phase) {
        Vec3 station = CoasterTestService.stationSpine(level).add(0.0, 0.3125, 0.0);
        Vec3 forward = CoasterTestService.stationForward(level);
        List<BlockPos> anchors = CoasterTestService.anchors();
        if (anchors.size() != 4) throw new IllegalStateException("Commissioning requires the guarded four-anchor circuit");
        double centerX = anchors.stream().mapToDouble(p -> p.getX() + 0.5).average().orElseThrow();
        double centerZ = anchors.stream().mapToDouble(p -> p.getZ() + 0.5).average().orElseThrow();
        Vec3 actual = bearing(cart);
        if (actual == null) throw new IllegalStateException("Native coaster bearing was not found");
        NativeCircuitProgress progress = new NativeCircuitProgress(centerX, centerZ,
                actual.x, actual.z, forward.x, forward.z);
        return new Session(cart.getUniqueId(), phase, station, actual, progress,
                progress.radiusAt(station.x, station.z));
    }

    private static PhysicsPipeline cartPhysics(ServerLevel level) {
        return dev.ryanhcode.sable.sublevel.system.SubLevelPhysicsSystem.require(level).getPipeline();
    }

    private static Vec3 bearing(ServerSubLevel cart) {
        return CoasterCartLinkPlacement.bearingCenterWorld(cart, cart.logicalPose());
    }

    private static boolean finitePose(ServerSubLevel cart, Vec3 point) {
        Quaterniond orientation = cart.logicalPose().orientation();
        return Double.isFinite(point.x) && Double.isFinite(point.y) && Double.isFinite(point.z)
                && Double.isFinite(orientation.x) && Double.isFinite(orientation.y)
                && Double.isFinite(orientation.z) && Double.isFinite(orientation.w);
    }

    /** Preserve all existing MOD user-data siblings, including original train-link data. */
    private static void writeNativeEvidence(ServerLevel level, ServerSubLevel cart, Session state) {
        CompoundTag user = cart.getUserDataTag();
        user = user == null ? new CompoundTag() : user.copy();
        CompoundTag tag = new CompoundTag();
        tag.putInt("schema", 1);
        tag.putUUID("cart_id", cart.getUniqueId());
        tag.putUUID("run_id", state.runId);
        tag.putString("dimension", level.dimension().location().toString());
        tag.putLong("game_tick", level.getGameTime());
        tag.putString("phase", state.phase);
        tag.putString("failure", state.failure);
        tag.putInt("completed_laps", state.completedLaps);
        tag.putDouble("measured_distance_3d", state.measuredDistance3d);
        tag.putDouble("elapsed_seconds", state.elapsedSeconds);
        tag.putDouble("max_native_speed", state.maxSpeed);
        tag.putDouble("max_measured_speed", state.maxMeasuredSpeed);
        tag.putDouble("max_acceleration", state.maxAcceleration);
        tag.putDouble("progress_radians", state.progress.progressRadians());
        tag.putDouble("measured_distance_horizontal", state.progress.measuredDistance());
        tag.putDouble("hold_seconds", state.holdSeconds);
        tag.putBoolean("engaged", CoasterTestService.nativeEngaged(cart));
        tag.putInt("native_pose_assignments", 0);
        Vec3 point = bearing(cart);
        if (point != null) {
            tag.putDouble("bearing_x", point.x);
            tag.putDouble("bearing_y", point.y);
            tag.putDouble("bearing_z", point.z);
        }
        user.put(SAVE_KEY, tag);
        cart.setUserDataTag(user);
        // Sable's unchanged normal ServerLevel.save serializes this native user-data.
    }

    private static final class Session {
        private final UUID cartId;
        private UUID runId = UUID.randomUUID();
        private String phase;
        private String failure = "";
        private final Vec3 station;
        private Vec3 lastPoint;
        private final NativeCircuitProgress progress;
        private final double radius;
        private final Vector3d lastVelocity = new Vector3d();
        private double elapsedSeconds;
        private double measuredDistance3d;
        private double maxSpeed;
        private double maxMeasuredSpeed;
        private double maxAcceleration;
        private double holdSeconds;
        private int completedLaps;
        private long lastLoggedTick = Long.MIN_VALUE;

        private Session(UUID cartId, String phase, Vec3 station, Vec3 lastPoint,
                        NativeCircuitProgress progress, double radius) {
            this.cartId = cartId;
            this.phase = phase;
            this.station = station;
            this.lastPoint = lastPoint;
            this.progress = progress;
            this.radius = radius;
        }

        private boolean isRunning() {
            return "RUNNING".equals(phase) || "BRAKING".equals(phase) || "HOLDING".equals(phase);
        }
    }
}
