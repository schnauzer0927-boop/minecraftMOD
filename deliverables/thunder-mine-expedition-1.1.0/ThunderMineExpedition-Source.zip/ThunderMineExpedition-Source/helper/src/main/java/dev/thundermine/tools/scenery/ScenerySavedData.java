package dev.thundermine.tools.scenery;

import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Resumable scenery receipt; native rails and Sable cart persistence remain independent. */
public final class ScenerySavedData extends SavedData {
    private static final Factory<ScenerySavedData> FACTORY = new Factory<>(ScenerySavedData::new, ScenerySavedData::load, null);
    int stage;
    long cursor;
    long placed;
    long skippedProtected;
    long skippedForeign;
    boolean begun;
    boolean complete;
    String routeFingerprint = "";
    String message = "Scenery has not been constructed";

    public static ScenerySavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(FACTORY, "thunder_mine_scenery_v1");
    }
    private static ScenerySavedData load(CompoundTag tag, HolderLookup.Provider lookup) {
        var result = new ScenerySavedData();
        result.stage = Math.max(0, tag.getInt("Stage"));
        result.cursor = Math.max(0, tag.getLong("Cursor"));
        result.placed = Math.max(0, tag.getLong("Placed"));
        result.skippedProtected = Math.max(0, tag.getLong("SkippedProtected"));
        result.skippedForeign = Math.max(0, tag.getLong("SkippedForeign"));
        result.begun = tag.getBoolean("Begun");
        result.complete = tag.getBoolean("Complete");
        result.routeFingerprint = tag.getString("RouteFingerprint");
        result.message = tag.getString("Message");
        if (tag.getInt("Schema") != 1) throw new IllegalStateException("Unknown mine scenery receipt schema");
        return result;
    }
    @Override public CompoundTag save(CompoundTag tag, HolderLookup.Provider lookup) {
        tag.putInt("Schema", 1);
        tag.putInt("Stage", stage);
        tag.putLong("Cursor", cursor);
        tag.putLong("Placed", placed);
        tag.putLong("SkippedProtected", skippedProtected);
        tag.putLong("SkippedForeign", skippedForeign);
        tag.putBoolean("Begun", begun);
        tag.putBoolean("Complete", complete);
        tag.putString("RouteFingerprint", routeFingerprint);
        tag.putString("Message", message);
        return tag;
    }
}
