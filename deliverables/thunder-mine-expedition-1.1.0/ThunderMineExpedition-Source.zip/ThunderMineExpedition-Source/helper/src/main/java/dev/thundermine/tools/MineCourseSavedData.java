package dev.thundermine.tools;

import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.saveddata.SavedData;

/** Original construction receipt. All rails, cart blocks and physics use native save paths. */
public final class MineCourseSavedData extends SavedData {
    private static final String FILE_ID = "thunder_mine_native_course";
    private static final Factory<MineCourseSavedData> FACTORY =
            new Factory<>(MineCourseSavedData::new, MineCourseSavedData::load, null);
    private boolean reserved;
    private boolean built;
    private boolean pending;
    private boolean invalid;
    private boolean alignmentApplied;
    private long pendingSince;
    private UUID cartId;
    private String fingerprint = "";
    private String message = "Native mine course has not been constructed";
    private final Set<Long> forcedChunks = new LinkedHashSet<>();

    public MineCourseSavedData() {}

    public static MineCourseSavedData get(ServerLevel level) {
        return level.getDataStorage().computeIfAbsent(FACTORY, FILE_ID);
    }

    private static MineCourseSavedData load(CompoundTag tag, HolderLookup.Provider lookup) {
        var receipt = new MineCourseSavedData();
        receipt.reserved = tag.getBoolean("Reserved");
        receipt.built = tag.getBoolean("Built");
        receipt.pending = tag.getBoolean("Pending");
        receipt.alignmentApplied = tag.getBoolean("InitialPlacementAlignmentApplied");
        receipt.pendingSince = tag.getLong("PendingSince");
        receipt.cartId = tag.hasUUID("Cart") ? tag.getUUID("Cart") : null;
        receipt.fingerprint = tag.getString("RouteFingerprint");
        receipt.message = tag.getString("Message");
        for (long chunk : tag.getLongArray("OwnedForcedChunks")) receipt.forcedChunks.add(chunk);
        receipt.invalid = tag.getBoolean("Invalid") || tag.getInt("Schema") != 1
                || (receipt.reserved && !receipt.fingerprint.matches("[0-9a-f]{64}"))
                || (receipt.built && (!receipt.reserved || receipt.cartId == null))
                || (receipt.pending && (!receipt.reserved || receipt.cartId == null || receipt.built))
                || receipt.forcedChunks.size() > 1024;
        return receipt;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider lookup) {
        tag.putInt("Schema", 1);
        tag.putBoolean("Reserved", reserved);
        tag.putBoolean("Built", built);
        tag.putBoolean("Pending", pending);
        tag.putBoolean("Invalid", invalid);
        tag.putBoolean("InitialPlacementAlignmentApplied", alignmentApplied);
        tag.putLong("PendingSince", pendingSince);
        if (cartId != null) tag.putUUID("Cart", cartId);
        tag.putString("RouteFingerprint", fingerprint);
        tag.putString("Message", message);
        tag.putLongArray("OwnedForcedChunks", forcedChunks.stream().mapToLong(Long::longValue).toArray());
        return tag;
    }

    public boolean reserved() { return reserved; }
    public boolean built() { return built; }
    public boolean pending() { return pending; }
    public boolean invalid() { return invalid; }
    public boolean alignmentApplied() { return alignmentApplied; }
    public long pendingSince() { return pendingSince; }
    public UUID cartId() { return cartId; }
    public String fingerprint() { return fingerprint; }
    public String message() { return message; }
    public Set<Long> ownedForcedChunks() { return Set.copyOf(forcedChunks); }

    void reserve(String routeFingerprint) {
        reserved = true;
        built = false;
        pending = false;
        alignmentApplied = false;
        fingerprint = routeFingerprint;
        message = "Native mine construction reserved; not ready for riding";
        setDirty();
    }

    void ownForcedChunk(long packed) {
        forcedChunks.add(packed);
        setDirty();
    }

    void awaitInitialization(UUID actualCartId, long tick) {
        cartId = actualCartId;
        pending = true;
        pendingSince = tick;
        message = "Native rails, wooden body and Create seats placed; awaiting actual engagement";
        setDirty();
    }

    void recordCart(UUID actualCartId) { cartId = actualCartId; setDirty(); }

    void recordAlignment() { alignmentApplied = true; setDirty(); }

    void complete() {
        built = true;
        pending = false;
        message = "Native mine course constructed; full physical tour validation is separate";
        setDirty();
    }

    void fail(String failure) {
        built = false;
        pending = false;
        message = failure;
        setDirty();
    }
}
