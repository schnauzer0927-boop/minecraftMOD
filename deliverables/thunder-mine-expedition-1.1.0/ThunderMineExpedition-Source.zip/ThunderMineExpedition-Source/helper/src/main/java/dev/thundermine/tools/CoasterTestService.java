package dev.thundermine.tools;

import com.simibubi.create.AllBlocks;
import com.mojang.logging.LogUtils;
import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import com.simibubi.create.content.trains.track.BezierConnection;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.ryanhcode.sable.neoforge.event.ForgeSablePostPhysicsTickEvent;
import dev.silvergold.simulatedcoasters.CoasterTrackMaterials;
import dev.silvergold.simulatedcoasters.SimulatedCoastersBlocks;
import dev.silvergold.simulatedcoasters.track.CoasterAnchorBezierOptimizer;
import dev.silvergold.simulatedcoasters.track.CoasterPeerCurveHandleLengths;
import dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlock;
import dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlockEntity;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartBlock;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartMidTrackPlacement;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartLinkPlacement;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartResolve;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartSeatedEntityCollision;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartSpawner;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartTrackSnap;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathEdge;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathGraphManager;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathTrackFrame;
import dev.silvergold.simulatedcoasters.track.graph.CoasterTrackPropagator;
import java.util.ArrayList;
import java.util.List;
import java.util.IdentityHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.level.LevelEvent;
import org.joml.Vector3d;
import org.slf4j.Logger;

/** Original, bounded commissioning builder calling the unmodified MOD APIs. */
public final class CoasterTestService {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<ServerLevel, PendingObservation> PENDING = new IdentityHashMap<>();
    private static final int INITIALIZATION_TIMEOUT_TICKS = 80;
    private static final int REQUIRED_STATIONARY_TICKS = 5;
    public static final String REQUIRED_WORLD_NAME = "Thunder Mine Native Test";
    public static final double HANDLE_LENGTH = 4.0 / 3.0 * Math.tan(Math.PI / 8.0) * 24.0;
    public static final double STATION_T = 0.02;
    public static final BlockPos SEAT_LOCAL = new BlockPos(0, 1, 0);
    private static final Vec3 UP = new Vec3(0, 1, 0);
    private static final List<BlockPos> ANCHORS = List.of(
            new BlockPos(24, 76, 0), new BlockPos(0, 76, 24),
            new BlockPos(-24, 76, 0), new BlockPos(0, 76, -24));
    private static final List<Vec3> FORWARDS = List.of(
            new Vec3(0, 0, 1), new Vec3(-1, 0, 0),
            new Vec3(0, 0, -1), new Vec3(1, 0, 0));

    private CoasterTestService() {}

    public static List<BlockPos> anchors() { return ANCHORS; }

    public static UUID cartId(ServerLevel level) {
        return CoasterTestSavedData.get(level).cartId();
    }

    public static ServerSubLevel cart(ServerLevel level) {
        UUID id = cartId(level);
        return id == null ? null : CoasterCartResolve.findCartById(level, id);
    }

    public static CoasterPathEdge stationEdge(ServerLevel level) {
        for (var edge : CoasterPathGraphManager.get(level).edges()) {
            if (edge.from().equals(ANCHORS.get(0)) && edge.to().equals(ANCHORS.get(1)))
                return edge;
            if (edge.from().equals(ANCHORS.get(1)) && edge.to().equals(ANCHORS.get(0)))
                return edge;
        }
        throw new IllegalStateException("Native station edge is missing");
    }

    public static CoasterPathTrackFrame.GraphHit stationHit(ServerLevel level) {
        var edge = stationEdge(level);
        double t = edge.from().equals(ANCHORS.get(0)) ? STATION_T : 1.0 - STATION_T;
        return new CoasterPathTrackFrame.GraphHit(
                CoasterPathGraphManager.sampleEdgePosition(level, edge, t), edge, t);
    }

    public static Vec3 stationSpine(ServerLevel level) {
        return stationHit(level).point();
    }

    public static Vec3 stationForward(ServerLevel level) {
        var hit = stationHit(level);
        var edge = hit.edge();
        double aheadT = hit.t() + (edge.from().equals(ANCHORS.get(0)) ? 0.001 : -0.001);
        return CoasterPathGraphManager.sampleEdgePosition(level, edge, aheadT)
                .subtract(hit.point()).normalize();
    }

    public static boolean nativeEngaged(ServerSubLevel cart) {
        if (cart == null || cart.isRemoved() || CoasterCartTrackSnap.isBearingDisengaged(cart))
            return false;
        var state = cart.getPlot().getEmbeddedLevelAccessor().getBlockState(BlockPos.ZERO);
        return state.is(SimulatedCoastersBlocks.COASTER_CART_BLOCK.get())
                && state.getValue(CoasterCartBlock.SNAP_ENGAGED);
    }

    public static boolean occupied(ServerLevel level, ServerSubLevel cart) {
        for (var player : level.players()) {
            if (CoasterCartSeatedEntityCollision.hostCartFromVehicleChain(player) == cart)
                return true;
        }
        BlockPos seatGlobal = cart.getPlot().getCenterBlock().offset(SEAT_LOCAL);
        for (var seat : level.getEntitiesOfClass(SeatEntity.class, new AABB(seatGlobal).inflate(1))) {
            if (seat.isVehicle()) return true;
        }
        return false;
    }

    public static String build(ServerLevel level) {
        requireDedicatedWorld(level);
        var receipt = CoasterTestSavedData.get(level);
        if (receipt.invalid()) throw new IllegalStateException("Invalid helper receipt; no changes made");
        if (receipt.reserved()) throw new IllegalStateException("Test already reserved. Inspect status first");
        if (!CoasterPathGraphManager.get(level).edges().isEmpty())
            throw new IllegalStateException("Fresh test world required: an existing coaster graph was found");
        var container = SubLevelContainer.getContainer(level);
        if (container == null) throw new IllegalStateException("Sable server container is not ready");
        for (var existing : container.getAllSubLevels()) {
            if (!existing.isRemoved())
                throw new IllegalStateException("Fresh test world required: an existing sublevel was found");
        }
        requireClearSite(level);
        receipt.reserve();
        try {
            CoasterTrackPropagator.runBatchUpdate(level, () -> {
                for (BlockPos position : ANCHORS) {
                    if (!level.setBlock(position, SimulatedCoastersBlocks.COASTER_ANCHORPOINT.get()
                            .defaultBlockState().setValue(CoasterAnchorpointBlock.FACING, Direction.UP), 3))
                        throw new IllegalStateException("Anchor placement failed at " + position);
                    anchor(level, position).setLiftBlocks(0f);
                    anchor(level, position).setJointBankRadians(0f);
                }
                for (int i = 0; i < ANCHORS.size(); ++i) {
                    int next = (i + 1) % ANCHORS.size();
                    BlockPos a = ANCHORS.get(i), b = ANCHORS.get(next);
                    var curve = new BezierConnection(Couple.create(a, b),
                            Couple.create(CoasterAnchorpointBlockEntity.worldCenter(level, a),
                                    CoasterAnchorpointBlockEntity.worldCenter(level, b)),
                            Couple.create(FORWARDS.get(i), FORWARDS.get(next).scale(-1)),
                            Couple.create(UP, UP), true, false, CoasterTrackMaterials.COASTER);
                    CoasterPeerCurveHandleLengths.putCanonical(curve, HANDLE_LENGTH, HANDLE_LENGTH);
                    if (!CoasterAnchorBezierOptimizer.isBuiltPlacementCurveValid(curve)
                            || !CoasterAnchorBezierOptimizer.meetsMinCurveRadiusWithHandleLengths(
                                    curve, HANDLE_LENGTH, HANDLE_LENGTH))
                        throw new IllegalStateException("Native geometry validation rejected edge " + i);
                    anchor(level, a).putAnchorPeerCurve(level, b, curve);
                }
            });
            requireClosedNativeTopology(level);
            placePlatform(level);
            var hit = stationHit(level);
            var basis = CoasterPathTrackFrame.trackBasisAtHit(level, hit);
            // Native graph alignment may choose the opposite travel direction.
            if (basis.forward().dot(stationForward(level)) < 0)
                basis = new CoasterPathTrackFrame.TrackBasis(
                        basis.forward().scale(-1), basis.right().scale(-1), basis.up());
            var orientation = CoasterPathTrackFrame.quaternionFromTrackBasis(basis);
            var origin = CoasterCartMidTrackPlacement.plotOriginForGraphHit(level, hit, orientation, null);
            // Defer the single explicit placement snap until native bearing discovery
            // is available, rather than asking the factory to snap in its allocation tick.
            var spawned = CoasterCartSpawner.spawnMinimalContraption(level, origin, orientation, hit, false);
            if (spawned == null) throw new IllegalStateException("Native Sable cart factory returned null");
            receipt.recordCart(spawned.getUniqueId());
            if (!spawned.getPlot().getEmbeddedLevelAccessor().setBlock(SEAT_LOCAL,
                    AllBlocks.SEATS.get(DyeColor.BROWN).getDefaultState(), 3))
                throw new IllegalStateException("Native Create seat placement failed");
            container.physicsSystem().getPipeline().onStatsChanged(spawned);
            // Native sublevel/bearing discovery is not synchronous with allocation.
            // Confirm through later genuine physics callbacks, never by overriding
            // the existing MOD's snap flag or private caches.
            receipt.awaitNativeInitialization(level.getGameTime());
            PENDING.put(level, new PendingObservation());
            LOGGER.info("MINE_NATIVE_BUILD_PENDING cart={} gameTick={} nativeEngagedImmediately={} {}",
                    spawned.getUniqueId(), level.getGameTime(), nativeEngaged(spawned), nativeDiagnostics(level, spawned));
            return "Placed native 4-edge loop and seated cart " + spawned.getUniqueId()
                    + ". Waiting for actual native engagement/stationary checks; use mine_test status."
                    + " Ride and save/reload are not yet verified. Boarding pad: 28 77 1.";
        } catch (RuntimeException failure) {
            // Keep the receipt and original native state for explicit inspection/removal.
            // An incomplete build never becomes a claimed successful ride or ready world.
            receipt.fail("Construction failed: " + failure.getMessage());
            throw failure;
        }
    }

    public static String status(ServerLevel level) {
        var receipt = CoasterTestSavedData.get(level);
        var nativeCart = cart(level);
        int ownedEdges = ownedEdges(level).size();
        String position = nativeCart == null ? "unavailable" : String.format(Locale.ROOT,
                "%.3f,%.3f,%.3f", nativeCart.logicalPose().position().x(),
                nativeCart.logicalPose().position().y(), nativeCart.logicalPose().position().z());
        return "Test reserved=" + receipt.reserved() + ", built=" + receipt.built()
                + ", pendingNativeInitialization=" + receipt.pending()
                + ", receiptValid=" + !receipt.invalid() + ", nativeEdges=" + ownedEdges
                + ", cart=" + receipt.cartId() + ", loaded=" + (nativeCart != null)
                + ", engaged=" + nativeEngaged(nativeCart) + ", position=" + position
                + ". " + receipt.lastMessage()
                + (nativeCart == null ? "" : " " + nativeDiagnostics(level, nativeCart));
    }

    /** Finish construction only after real native callbacks demonstrate engagement. */
    public static void onNativePostPhysicsTick(ForgeSablePostPhysicsTickEvent event) {
        ServerLevel level = event.getPhysicsSystem().getLevel();
        var receipt = CoasterTestSavedData.get(level);
        if (!receipt.pending()) return;
        long gameTick = level.getGameTime();
        // Allocation's same-tick discovery caches must expire through their normal path.
        if (gameTick <= receipt.pendingSinceTick()) return;
        var observation = PENDING.computeIfAbsent(level, ignored -> new PendingObservation());
        if (observation.lastTick == gameTick) return;
        observation.lastTick = gameTick;
        var nativeCart = cart(level);
        if (gameTick - receipt.pendingSinceTick() > INITIALIZATION_TIMEOUT_TICKS) {
            receipt.fail("Native initialization timed out; construction remains unverified");
            PENDING.remove(level);
            LOGGER.error("MINE_NATIVE_BUILD_FAILED timeout gameTick={} cart={} {}", gameTick, receipt.cartId(),
                    nativeCart == null ? "cart unavailable" : nativeDiagnostics(level, nativeCart));
            return;
        }
        if (nativeCart == null) return;
        try {
            requireClosedNativeTopology(level);
            if (!observation.initialSnapApplied && !receipt.delayedInitialSnapApplied()) {
                if (CoasterCartTrackSnap.representativeBearingPlotPos(nativeCart) == null) return;
                CoasterCartTrackSnap.applyInitialSnapAfterSpawn(nativeCart, level, stationHit(level));
                observation.initialSnapApplied = true;
                receipt.recordDelayedInitialSnap();
                LOGGER.info("MINE_NATIVE_INITIAL_PLACEMENT_ALIGNED cart={} gameTick={} explicitPlacementAlignmentCount=1",
                        nativeCart.getUniqueId(), gameTick);
                // Collect later independent observations; this placement callback
                // itself contributes no stationary confirmation tick.
                return;
            }
            observation.initialSnapApplied = receipt.delayedInitialSnapApplied();
            Vec3 bearing = CoasterCartLinkPlacement.bearingCenterWorld(nativeCart, nativeCart.logicalPose());
            Vec3 expected = CoasterPathTrackFrame.pathAnchorForSnappedBlock(level, stationHit(level));
            Vector3d velocity = event.getPhysicsSystem().getPipeline().getLinearVelocity(nativeCart, new Vector3d());
            boolean realSeat = nativeCart.getPlot().getEmbeddedLevelAccessor().getBlockState(SEAT_LOCAL)
                    .is(AllBlocks.SEATS.get(DyeColor.BROWN).get());
            boolean stable = nativeEngaged(nativeCart) && realSeat && bearing != null
                    && Double.isFinite(bearing.x) && Double.isFinite(bearing.y) && Double.isFinite(bearing.z)
                    && bearing.distanceTo(expected) <= 0.65 && velocity.isFinite() && velocity.length() <= 0.05;
            observation.stableTicks = stable ? observation.stableTicks + 1 : 0;
            // This is a commissioning hold on the real body, not a pose assignment.
            event.getPhysicsSystem().getPipeline().resetVelocity(nativeCart);
            LOGGER.info("MINE_NATIVE_BUILD_OBSERVED cart={} gameTick={} engaged={} realSeat={} stableTicks={} {}",
                    nativeCart.getUniqueId(), gameTick, nativeEngaged(nativeCart), realSeat,
                    observation.stableTicks, nativeDiagnostics(level, nativeCart));
            if (observation.stableTicks >= REQUIRED_STATIONARY_TICKS) {
                NativeTestRideController.armStationHold(level, nativeCart);
                receipt.complete();
                PENDING.remove(level);
                LOGGER.info("MINE_NATIVE_BUILD_READY cart={} gameTick={} edges={} stableTicks={} explicitPlacementAlignmentCount=1 directRidePoseAssignments=0",
                        nativeCart.getUniqueId(), gameTick, ownedEdges(level).size(), observation.stableTicks);
            }
        } catch (RuntimeException failure) {
            receipt.fail("Native initialization failed: " + failure.getMessage());
            PENDING.remove(level);
            LOGGER.error("MINE_NATIVE_BUILD_FAILED gameTick={} cart={}", gameTick, receipt.cartId(), failure);
        }
    }

    public static void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel level) PENDING.remove(level);
    }

    private static String nativeDiagnostics(ServerLevel level, ServerSubLevel nativeCart) {
        var plot = nativeCart.getPlot();
        var bearing = CoasterCartLinkPlacement.bearingCenterWorld(nativeCart, nativeCart.logicalPose());
        var representative = CoasterCartTrackSnap.representativeBearingPlotPos(nativeCart);
        var bearingBlock = plot.getEmbeddedLevelAccessor().getBlockState(BlockPos.ZERO);
        var seat = plot.getEmbeddedLevelAccessor().getBlockState(SEAT_LOCAL);
        return "representative=" + representative + ", actualBearing=" + bearing
                + ", bearingBlock=" + bearingBlock + ", seatBlock=" + seat
                + ", disconnected=" + CoasterCartTrackSnap.isBearingDisengaged(nativeCart)
                + ", pipeline=" + SubLevelContainer.getContainer(level).physicsSystem().getPipeline().getClass().getName();
    }

    public static String remove(ServerLevel level) {
        requireDedicatedWorld(level);
        var receipt = CoasterTestSavedData.get(level);
        if (receipt.invalid() || !receipt.reserved())
            throw new IllegalStateException("No valid helper-owned construction receipt");
        var nativeCart = cart(level);
        if (receipt.cartId() != null && nativeCart == null)
            throw new IllegalStateException("Owned cart is unloaded; removal refused to preserve native storage");
        if (nativeCart != null && occupied(level, nativeCart))
            throw new IllegalStateException("Disembark all passengers before removing the test");
        // Refuse a changed block rather than deleting unrelated player construction.
        for (var position : ANCHORS) {
            var state = level.getBlockState(position);
            if (!state.isAir() && !state.is(SimulatedCoastersBlocks.COASTER_ANCHORPOINT.get()))
                throw new IllegalStateException("Anchor location changed: " + position);
        }
        for (var position : platformPositions()) {
            var state = level.getBlockState(position);
            if (!state.isAir() && !state.is(Blocks.OAK_PLANKS))
                throw new IllegalStateException("Platform location changed: " + position);
        }
        CoasterTrackPropagator.runBatchUpdate(level, () -> {
            for (var position : ANCHORS) {
                if (level.getBlockEntity(position) instanceof CoasterAnchorpointBlockEntity anchor)
                    anchor.detachAllConnections(level);
            }
        });
        // The propagator collects real anchor block entities when a batch flushes.
        // Flush disconnected curves while those anchors still exist, then remove them.
        if (!ownedEdges(level).isEmpty())
            throw new IllegalStateException("Native graph still has test edges; removal stopped before deleting anchors/cart");
        for (var position : ANCHORS) level.setBlock(position, Blocks.AIR.defaultBlockState(), 3);
        for (var position : platformPositions()) level.setBlock(position, Blocks.AIR.defaultBlockState(), 3);
        if (nativeCart != null) nativeCart.markRemoved();
        receipt.clear();
        PENDING.remove(level);
        return "Removed helper-owned test anchors, platform and native cart. Use normal save-all flush.";
    }

    public static List<CoasterPathEdge> ownedEdges(ServerLevel level) {
        return CoasterPathGraphManager.get(level).edges().stream()
                .filter(edge -> ANCHORS.contains(edge.from()) && ANCHORS.contains(edge.to())).toList();
    }

    public static void requireClosedNativeTopology(ServerLevel level) {
        var edges = ownedEdges(level);
        if (edges.size() != 4) throw new IllegalStateException("Expected 4 real native graph edges");
        for (var position : ANCHORS) {
            long degree = edges.stream()
                    .filter(edge -> edge.from().equals(position) || edge.to().equals(position)).count();
            if (degree != 2 || anchor(level, position).legCount() != 2)
                throw new IllegalStateException("Native loop is open or branched at " + position);
        }
    }

    private static CoasterAnchorpointBlockEntity anchor(ServerLevel level, BlockPos position) {
        if (level.getBlockEntity(position) instanceof CoasterAnchorpointBlockEntity anchor) return anchor;
        throw new IllegalStateException("Native anchor block entity is missing at " + position);
    }

    private static void requireDedicatedWorld(ServerLevel level) {
        if (!level.dimension().equals(Level.OVERWORLD)
                || !REQUIRED_WORLD_NAME.equals(level.getServer().getWorldData().getLevelName()))
            throw new IllegalStateException("Only the dedicated fresh world '"
                    + REQUIRED_WORLD_NAME + "' in the Overworld can be modified");
    }

    private static void requireClearSite(ServerLevel level) {
        for (var position : BlockPos.betweenClosed(-28, 75, -28, 31, 82, 28)) {
            if (!level.hasChunkAt(position))
                throw new IllegalStateException("Test site contains an unloaded chunk: " + position);
            if (!level.getBlockState(position).isAir())
                throw new IllegalStateException("Test site is not empty: " + position);
        }
    }

    private static List<BlockPos> platformPositions() {
        var positions = new ArrayList<BlockPos>();
        for (var position : BlockPos.betweenClosed(26, 76, -3, 30, 76, 6))
            positions.add(position.immutable());
        return List.copyOf(positions);
    }

    private static void placePlatform(ServerLevel level) {
        for (var position : platformPositions()) {
            if (!level.setBlock(position, Blocks.OAK_PLANKS.defaultBlockState(), 3))
                throw new IllegalStateException("Boarding platform placement failed at " + position);
        }
    }

    private static final class PendingObservation {
        long lastTick = Long.MIN_VALUE;
        int stableTicks;
        boolean initialSnapApplied;
    }
}
