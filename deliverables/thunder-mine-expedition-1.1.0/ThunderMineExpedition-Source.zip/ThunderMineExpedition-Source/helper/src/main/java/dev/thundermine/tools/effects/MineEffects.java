package dev.thundermine.tools.effects;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.logging.LogUtils;
import dev.thundermine.tools.MineNativeArc;
import dev.thundermine.tools.MineRideController;
import dev.thundermine.tools.MineRoute;
import dev.thundermine.tools.NativeMineCourse;
import dev.thundermine.tools.scenery.MineSceneryGenerator;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RedstoneLampBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.level.LevelEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.joml.Vector3f;
import org.slf4j.Logger;

/**
 * Original mine show cues driven by measured native rail distance. This module never
 * moves a cart, creates a damaging entity, breaks a block, or calls Level.explode.
 * Missing/failed show effects cannot affect the independent native ride controller.
 */
public final class MineEffects {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final Map<ServerLevel, Session> SESSIONS = new IdentityHashMap<>();
    private static final int MAX_EVENTS = 64;
    private static final int MAX_PENDING = 256;
    private static final int[] WARNING_FIXTURE_NODES = {25, 38, 43};
    private static final DustParticleOptions AMBER = new DustParticleOptions(new Vector3f(1.0f, .33f, .04f), 1.1f);
    private static final BlockParticleOption ROCK_DUST = new BlockParticleOption(ParticleTypes.BLOCK, Blocks.RED_SANDSTONE.defaultBlockState());
    private static List<Cue> cues;

    private MineEffects() {}

    public static void register(IEventBus gameBus) {
        gameBus.addListener(MineEffects::onServerTick);
        gameBus.addListener(MineEffects::onLevelUnload);
    }

    /** Summary of actual trigger/execute counts; it does not claim a client heard audio. */
    public static String status(ServerLevel level) {
        Session session = SESSIONS.get(level);
        if (session == null) return "Mine show: no observed native run; effects require completed scenery";
        return String.format(Locale.ROOT, "Mine show: active=%s triggers=%d executions=%d failures=%d pending=%d blinking=%d nativeDistance=%.3f",
                session.active, session.triggers, session.executions, session.failures,
                session.pending.size(), session.blinks.size(), session.distance);
    }

    private static void onServerTick(ServerTickEvent.Post event) {
        for (ServerLevel level : event.getServer().getAllLevels()) {
            try { tick(level); }
            catch (RuntimeException failure) {
                Session session = SESSIONS.remove(level);
                if (session != null) restoreLamps(level, session);
                LOGGER.warn("MINE_EFFECT_MODULE_FAILED dimension={} gameTick={} reason={}; native ride was not changed",
                        level.dimension().location(), level.getGameTime(), message(failure));
            }
        }
    }

    private static void tick(ServerLevel level) {
        // In particular, the bare native commissioning course has no show side effects.
        if (!MineSceneryGenerator.isComplete(level)) return;
        MineRideController.Snapshot snapshot = MineRideController.snapshot(level);
        Session session = SESSIONS.get(level);
        boolean running = snapshot != null && ("RUNNING".equals(snapshot.phase())
                || "BRAKING".equals(snapshot.phase()) || "HOLDING".equals(snapshot.phase()));
        if (!running) {
            if (session != null && session.active) {
                session.active = false;
                session.pending.clear();
                restoreLamps(level, session);
                LOGGER.info("MINE_EFFECT_RUN_END cart={} gameTick={} triggers={} executions={} failures={} nativeDistance={}",
                        session.cartId, level.getGameTime(), session.triggers, session.executions, session.failures, session.distance);
            }
            return;
        }
        boolean fresh = session == null || !session.active || !session.cartId.equals(snapshot.cartId())
                || snapshot.elapsedSeconds() + .1 < session.previousElapsed;
        if (fresh) {
            if (session != null) restoreLamps(level, session);
            session = new Session(level, snapshot);
            SESSIONS.put(level, session);
            LOGGER.info("MINE_EFFECT_RUN_START cart={} gameTick={} cues={} nativeArcLength={}",
                    session.cartId, level.getGameTime(), session.triggersByArc.size(), session.arc.totalLength());
            // A newly observed RUNNING session can also be a legitimate midride
            // reload. Only the actual station envelope receives a departure bell.
            if (session.arc.distanceFromStation(snapshot.canonicalDistance()) < 5.0) {
                for (Trigger trigger : session.triggersByArc) {
                    if (trigger.departure) queueCue(level, session, trigger, 0, snapshot);
                }
            }
        } else {
            double previous = session.distance;
            double delta = session.arc.signedDelta(session.previousCanonical, snapshot.canonicalDistance());
            // The controller already guards physical continuity. A broken show sample is
            // discarded rather than fabricating historical triggers or influencing motion.
            if (delta >= -.10 && delta <= 3.0) {
                session.distance += delta;
                for (Trigger trigger : session.triggersByArc) {
                    long firstLap = Math.max(0L, (long)Math.floor((previous - trigger.distance) / session.arc.totalLength()) + 1L);
                    double crossing = trigger.distance + firstLap * session.arc.totalLength();
                    if (crossing > previous && crossing <= session.distance
                            && (trigger.cue.repeatable || firstLap == 0L)) {
                        queueCue(level, session, trigger, firstLap, snapshot);
                    }
                }
            } else {
                LOGGER.warn("MINE_EFFECT_SAMPLE_REJECTED cart={} delta={} gameTick={}; native ride was not changed",
                        session.cartId, delta, level.getGameTime());
            }
        }
        session.previousCanonical = snapshot.canonicalDistance();
        session.previousElapsed = snapshot.elapsedSeconds();
        executeDue(level, session);
        updateLamps(level, session);
    }

    private static void queueCue(ServerLevel level, Session session, Trigger trigger, long lap,
                                 MineRideController.Snapshot snapshot) {
        String executionKey = trigger.cue.id + ":" + lap;
        if (!session.fired.add(executionKey)) return;
        session.triggers++;
        LOGGER.info("MINE_EFFECT_TRIGGER id={} lap={} node={} canonical={} triggerArc={} runDistance={} measuredDistance={} gameTick={} delayTicks={}",
                trigger.cue.id, lap + 1L, trigger.cue.node, snapshot.canonicalDistance(), trigger.distance,
                session.distance, snapshot.travelledDistance(), level.getGameTime(), trigger.cue.delayTicks);
        schedule(session, level.getGameTime() + trigger.cue.delayTicks, trigger.cue.id,
                () -> beginEffect(level, session, trigger));
    }

    private static void beginEffect(ServerLevel level, Session session, Trigger trigger) {
        Cue cue = trigger.cue;
        Vec3 position = trigger.effectPosition;
        switch (cue.type) {
            case STATION_BELL -> sound(level, position, SoundEvents.BELL_BLOCK, SoundSource.BLOCKS, cue.volume, 1.0f);
            case MINE_RUMBLE -> {
                sound(level, position, SoundEvents.ANVIL_LAND, SoundSource.AMBIENT, cue.volume * .7f, .65f);
                particles(level, ROCK_DUST, position.add(0, 3, 0), 16, 1.6, .5, 1.6, .06);
                schedule(session, level.getGameTime() + 12, cue.id,
                        () -> sound(level, position, SoundEvents.ANVIL_FALL, SoundSource.AMBIENT, cue.volume * .4f, .75f));
            }
            case WARNING -> {
                sound(level, position, SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.BLOCKS, cue.volume, 1.15f);
                particles(level, AMBER, position, 12, .5, .4, .5, 0);
                blink(level, session, cue.node, cue.durationTicks);
                schedule(session, level.getGameTime() + 16, cue.id,
                        () -> sound(level, position, SoundEvents.NOTE_BLOCK_PLING.value(), SoundSource.BLOCKS, cue.volume, 1.4f));
            }
            case STEAM -> {
                sound(level, position, SoundEvents.FIRE_EXTINGUISH, SoundSource.AMBIENT, cue.volume * .65f, .8f);
                particles(level, ParticleTypes.CLOUD, position, 28, 1.3, 1.4, 1.3, .035);
                schedule(session, level.getGameTime() + 15, cue.id,
                        () -> particles(level, ParticleTypes.CLOUD, position.add(0, 1.4, 0), 18, 1.4, .5, 1.4, .025));
            }
            case DUST_ROCKFALL -> {
                blink(level, session, cue.node, cue.durationTicks);
                sound(level, position, SoundEvents.ANVIL_LAND, SoundSource.AMBIENT, cue.volume, .65f);
                dustFall(level, position);
                schedule(session, level.getGameTime() + 14, cue.id, () -> dustFall(level, position.add(0, -.5, 0)));
                schedule(session, level.getGameTime() + 28, cue.id,
                        () -> sound(level, position, SoundEvents.ANVIL_FALL, SoundSource.AMBIENT, cue.volume * .6f, .75f));
            }
            case EXPLOSION_VISUAL -> {
                blink(level, session, cue.node, cue.durationTicks);
                sound(level, position, SoundEvents.GENERIC_EXPLODE.value(), SoundSource.BLOCKS, cue.volume, 1.15f);
                particles(level, ParticleTypes.EXPLOSION, position, 1, 0, 0, 0, 0);
                particles(level, ParticleTypes.FLAME, position, 16, .6, .6, .6, .03);
                particles(level, ParticleTypes.CAMPFIRE_COSY_SMOKE, position, 12, 1.0, .7, 1.0, .025);
            }
        }
    }

    private static void dustFall(ServerLevel level, Vec3 position) {
        // Block particles borrow a vanilla texture only; no FallingBlockEntity exists.
        particles(level, ROCK_DUST, position.add(0, 3.3, 0), 36, 1.8, .8, 1.8, .08);
        particles(level, ParticleTypes.CLOUD, position.add(0, .2, 0), 14, 1.4, .3, 1.4, .025);
    }

    private static void sound(ServerLevel level, Vec3 position, SoundEvent sound,
                              SoundSource category, float volume, float pitch) {
        level.playSound(null, position.x, position.y, position.z, sound, category,
                Math.max(0.0f, Math.min(1.0f, volume)), pitch);
    }

    private static void particles(ServerLevel level, ParticleOptions particle, Vec3 position, int count,
                                  double spreadX, double spreadY, double spreadZ, double speed) {
        level.sendParticles(particle, position.x, position.y, position.z, count, spreadX, spreadY, spreadZ, speed);
    }

    private static void schedule(Session session, long tick, String id, Runnable operation) {
        if (session.pending.size() >= MAX_PENDING) throw new IllegalStateException("Mine show queue exceeded its bounded capacity");
        session.pending.add(new Pending(tick, session.nextSequence++, id, operation));
    }

    private static void executeDue(ServerLevel level, Session session) {
        while (!session.pending.isEmpty() && session.pending.peek().tick <= level.getGameTime()) {
            Pending pending = session.pending.remove();
            try {
                pending.operation.run();
                session.executions++;
                LOGGER.info("MINE_EFFECT_EXECUTE id={} gameTick={} executions={}", pending.id, level.getGameTime(), session.executions);
            } catch (RuntimeException failure) {
                session.failures++;
                LOGGER.warn("MINE_EFFECT_FAILED id={} gameTick={} reason={}; native ride was not changed",
                        pending.id, level.getGameTime(), message(failure));
            }
        }
    }

    private static void blink(ServerLevel level, Session session, int node, int durationTicks) {
        BlockPos fixture = session.warningFixtures.get(node);
        if (fixture == null || !level.hasChunkAt(fixture) || level.getBlockEntity(fixture) != null) return;
        BlockState original = level.getBlockState(fixture);
        if (!original.is(Blocks.REDSTONE_LAMP)) return;
        session.blinks.putIfAbsent(fixture, new Blink(original, level.getGameTime(), level.getGameTime() + durationTicks));
    }

    private static void updateLamps(ServerLevel level, Session session) {
        var iterator = session.blinks.entrySet().iterator();
        while (iterator.hasNext()) {
            var entry = iterator.next();
            BlockPos position = entry.getKey();
            Blink blink = entry.getValue();
            try {
                if (!level.hasChunkAt(position) || level.getBlockEntity(position) != null) { iterator.remove(); continue; }
                BlockState current = level.getBlockState(position);
                if (!current.is(Blocks.REDSTONE_LAMP)) { iterator.remove(); continue; }
                if (level.getGameTime() >= blink.until) {
                    level.setBlock(position, blink.original, 2);
                    iterator.remove();
                } else {
                    boolean lit = ((level.getGameTime() - blink.start) / 6L) % 2L == 0L;
                    if (current.getValue(RedstoneLampBlock.LIT) != lit)
                        level.setBlock(position, current.setValue(RedstoneLampBlock.LIT, lit), 2);
                }
            } catch (RuntimeException failure) {
                session.failures++;
                iterator.remove();
                LOGGER.warn("MINE_EFFECT_LAMP_FAILED position={} reason={}; native ride was not changed", position, message(failure));
            }
        }
    }

    private static void restoreLamps(ServerLevel level, Session session) {
        for (var entry : session.blinks.entrySet()) {
            try {
                BlockPos position = entry.getKey();
                if (level.hasChunkAt(position) && level.getBlockEntity(position) == null
                        && level.getBlockState(position).is(Blocks.REDSTONE_LAMP)) {
                    level.setBlock(position, entry.getValue().original, 2);
                }
            } catch (RuntimeException failure) {
                LOGGER.warn("MINE_EFFECT_LAMP_RESTORE_FAILED position={} reason={}", entry.getKey(), message(failure));
            }
        }
        session.blinks.clear();
    }

    private static void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel level) {
            Session session = SESSIONS.remove(level);
            if (session != null) restoreLamps(level, session);
        }
    }

    private static List<Cue> configuredCues() {
        if (cues != null) return cues;
        List<Cue> parsed = new ArrayList<>();
        Set<String> ids = new HashSet<>();
        try (InputStream input = MineEffects.class.getResourceAsStream(MineRoute.BUNDLED_RESOURCE)) {
            if (input == null) throw new IllegalArgumentException("Bundled mine route is missing");
            JsonObject root = JsonParser.parseReader(new InputStreamReader(input, StandardCharsets.UTF_8)).getAsJsonObject();
            JsonArray array = root.getAsJsonArray("events");
            if (array != null) {
                if (array.size() > MAX_EVENTS) throw new IllegalArgumentException("At most " + MAX_EVENTS + " mine events are supported");
                for (JsonElement element : array) {
                    try {
                        JsonObject event = element.getAsJsonObject();
                        String id = event.get("id").getAsString();
                        if (!id.matches("[a-z][a-z0-9_]{0,63}") || !ids.add(id)) throw new IllegalArgumentException("Invalid or duplicate mine event ID: " + id);
                        int node = integer(event, "node", -1, 0, NativeMineCourse.nodes().size() - 1);
                        Kind type = Kind.valueOf(event.get("type").getAsString().toUpperCase(Locale.ROOT));
                        int delay = integer(event, "delayTicks", 0, 0, 200);
                        int duration = integer(event, "durationTicks", 80, 6, 200);
                        boolean repeatable = !event.has("repeatable") || event.get("repeatable").getAsBoolean();
                        float volume = event.has("volume") ? event.get("volume").getAsFloat() : .75f;
                        if (!Float.isFinite(volume) || volume < 0 || volume > 1.0f) throw new IllegalArgumentException("Event volume must be within [0,1]");
                        if (!event.has("enabled") || event.get("enabled").getAsBoolean())
                            parsed.add(new Cue(id, node, type, delay, duration, repeatable, volume));
                    } catch (RuntimeException failure) {
                        LOGGER.warn("MINE_EFFECT_CONFIG_ENTRY_REJECTED reason={}; other show cues and native ride remain independent", message(failure));
                    }
                }
            }
        } catch (Exception failure) {
            parsed.clear();
            LOGGER.warn("MINE_EFFECT_CONFIG_DISABLED reason={}; native ride remains independent", failure.getMessage());
        }
        cues = List.copyOf(parsed);
        return cues;
    }

    private static int integer(JsonObject source, String key, int fallback, int minimum, int maximum) {
        if (!source.has(key)) {
            if (fallback < minimum || fallback > maximum) throw new IllegalArgumentException("Missing required event field " + key);
            return fallback;
        }
        double value = source.get(key).getAsDouble();
        if (!Double.isFinite(value) || value != Math.rint(value) || value < minimum || value > maximum)
            throw new IllegalArgumentException("Event " + key + " must be an integer within [" + minimum + "," + maximum + "]");
        return (int)value;
    }

    private static String message(RuntimeException failure) {
        return failure.getMessage() == null ? failure.getClass().getSimpleName() : failure.getMessage();
    }

    private static final class Session {
        private final UUID cartId;
        private final MineNativeArc arc;
        private final List<Trigger> triggersByArc = new ArrayList<>();
        private final Map<Integer, BlockPos> warningFixtures = new java.util.HashMap<>();
        private final Map<BlockPos, Blink> blinks = new java.util.HashMap<>();
        private final Set<String> fired = new HashSet<>();
        private final PriorityQueue<Pending> pending = new PriorityQueue<>(Comparator.comparingLong(Pending::tick).thenComparingLong(Pending::sequence));
        private boolean active = true;
        private double distance;
        private double previousCanonical;
        private double previousElapsed;
        private long nextSequence;
        private long triggers;
        private long executions;
        private long failures;

        private Session(ServerLevel level, MineRideController.Snapshot snapshot) {
            cartId = snapshot.cartId();
            arc = new MineNativeArc(level);
            previousCanonical = snapshot.canonicalDistance();
            previousElapsed = snapshot.elapsedSeconds();
            distance = arc.signedDelta(0.0, previousCanonical);
            var frames = NativeMineCourse.geometrySamples(level);
            for (Cue cue : configuredCues()) {
                MineRoute.Node node = NativeMineCourse.nodes().get(cue.node);
                Vec3 anchor = Vec3.atLowerCornerOf(node.block()).add(.5, .25, .5);
                NativeMineCourse.GeometrySample nearest = frames.stream()
                        .min(Comparator.comparingDouble(frame -> frame.spine().distanceToSqr(anchor))).orElseThrow();
                Vec3 effectPosition = nearest.spine().add(nearest.right().scale(6.7)).add(0, 2, 0);
                // Node zero is just before canonical station S0; this particular cue
                // is the dispatch bell, so it follows departure, not the final approach.
                boolean departure = cue.node == 0 && cue.type == Kind.STATION_BELL;
                double triggerDistance = departure ? 0.0 : arc.nodeBoundaryDistance(cue.node);
                triggersByArc.add(new Trigger(cue, triggerDistance, effectPosition, departure));
            }
            for (int nodeIndex : WARNING_FIXTURE_NODES) {
                if (nodeIndex >= NativeMineCourse.nodes().size()) continue;
                // Match MineSceneryGenerator's fixture query exactly, including its
                // block-center Y coordinate on steep/banked native segments.
                Vec3 anchor = Vec3.atCenterOf(NativeMineCourse.nodes().get(nodeIndex).block());
                var nearest = frames.stream().min(Comparator.comparingDouble(frame -> frame.spine().distanceToSqr(anchor))).orElseThrow();
                // Exact independently generated, outside-clearance scenery fixtures only.
                // Never discover arbitrary nearby blocks or write a foreign block entity.
                BlockPos fixture = BlockPos.containing(nearest.spine().add(nearest.right().scale(6.7)).add(0, 2, 0));
                if (level.hasChunkAt(fixture) && level.getBlockEntity(fixture) == null
                        && level.getBlockState(fixture).is(Blocks.REDSTONE_LAMP)) {
                    warningFixtures.put(nodeIndex, fixture);
                }
            }
        }
    }

    private enum Kind { STATION_BELL, MINE_RUMBLE, WARNING, STEAM, DUST_ROCKFALL, EXPLOSION_VISUAL }
    private record Cue(String id, int node, Kind type, int delayTicks, int durationTicks, boolean repeatable, float volume) {}
    private record Trigger(Cue cue, double distance, Vec3 effectPosition, boolean departure) {}
    private record Pending(long tick, long sequence, String id, Runnable operation) {}
    private record Blink(BlockState original, long start, long until) {}
}
