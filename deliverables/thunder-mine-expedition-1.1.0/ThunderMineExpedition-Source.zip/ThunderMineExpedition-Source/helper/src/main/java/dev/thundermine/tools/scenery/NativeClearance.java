package dev.thundermine.tools.scenery;

import dev.thundermine.tools.NativeMineCourse;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.phys.Vec3;

/** Construction-only corridor measured from the installed MOD's actual track frames. */
public final class NativeClearance {
    private static final double HORIZONTAL = 4.6;
    private static final double DOWN = 5.0;
    private static final double UP = 7.0;
    private final LongOpenHashSet protectedVoxels = new LongOpenHashSet();
    private final List<NativeMineCourse.GeometrySample> samples;

    public NativeClearance(ServerLevel level) {
        samples = List.copyOf(NativeMineCourse.geometrySamples(level));
        if (samples.size() < 64) throw new IllegalStateException("Native rail samples are not ready");
        for (var frame : samples) {
            Vec3 center = frame.spine();
            // Include full block extents and the <= .6 block sampling gap.
            int x0 = (int)Math.floor(center.x - HORIZONTAL - .7);
            int x1 = (int)Math.ceil(center.x + HORIZONTAL + .7);
            int z0 = (int)Math.floor(center.z - HORIZONTAL - .7);
            int z1 = (int)Math.ceil(center.z + HORIZONTAL + .7);
            int y0 = (int)Math.floor(center.y - DOWN - .6);
            int y1 = (int)Math.ceil(center.y + UP + .6);
            for (int x = x0; x <= x1; x++) for (int z = z0; z <= z1; z++) {
                double dx = Math.max(0, Math.abs(x + .5 - center.x) - .5);
                double dz = Math.max(0, Math.abs(z + .5 - center.z) - .5);
                if (dx * dx + dz * dz > (HORIZONTAL + .35) * (HORIZONTAL + .35)) continue;
                for (int y = y0; y <= y1; y++) protectedVoxels.add(BlockPos.asLong(x, y, z));
            }
        }
    }

    public List<NativeMineCourse.GeometrySample> samples() { return samples; }
    public int protectedVoxelCount() { return protectedVoxels.size(); }
    public boolean contains(BlockPos block) { return protectedVoxels.contains(block.asLong()); }
    public boolean blocksScenery(BlockPos block) { return contains(block) && !stationException(block); }
    public LongOpenHashSet protectedVoxels() { return new LongOpenHashSet(protectedVoxels); }

    /** Only the verified, level, unbanked station has a platform close enough for boarding. */
    public static boolean stationException(BlockPos p) {
        if (p.getX() < 170 || p.getX() > 198 || p.getZ() < -12 || p.getZ() > 12) return false;
        if (p.getY() <= 79) return true; // beneath the station track, never through the vehicle
        if (p.getX() >= 178 && p.getY() >= 83) return true; // 3.5+ blocks outside the rail center
        return p.getX() == 177 && p.getY() >= 80 && p.getY() <= 82;
    }
}
