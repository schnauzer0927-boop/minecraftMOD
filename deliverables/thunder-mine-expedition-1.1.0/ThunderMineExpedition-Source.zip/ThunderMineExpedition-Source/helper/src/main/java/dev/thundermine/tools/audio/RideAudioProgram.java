package dev.thundermine.tools.audio;

import java.util.Set;

/** Theme selection uses the real ride area and measured physical velocity. */
public final class RideAudioProgram {
    private static final Set<String> AREAS = Set.of("base", "badlands", "mine_tunnel",
            "deep_excavation", "canyon", "return");
    private RideAudioProgram() {}
    public static boolean knownArea(String area) { return area != null && AREAS.contains(area); }
    public static boolean audiblePhase(String phase) {
        return "PARKED".equals(phase) || "PASSED".equals(phase) || "RUNNING".equals(phase)
                || "BRAKING".equals(phase) || "HOLDING".equals(phase);
    }
    public static String track(String area, double actualSpeed) {
        return switch (area) {
            case "mine_tunnel", "deep_excavation" -> "ride_suspense";
            case "canyon" -> "ride_chase";
            case "badlands" -> actualSpeed >= 7.0 ? "ride_chase" : "ride_exploration";
            default -> "ride_exploration";
        };
    }
}
