package dev.thundermine.tools;

/** Retained physical completion evidence permits a slow recovery, never an invented successful lap. */
final class MineReturnEligibility {
    private MineReturnEligibility() {}

    static boolean completedJourneyWasInterrupted(String phase, int completedLaps, int targetLaps,
                                                  double nativeLength, double measuredDistance,
                                                  double elapsedSeconds, double heldSeconds) {
        return "INTERRUPTED".equals(phase) && targetLaps >= 1 && targetLaps <= 3
                && completedLaps == targetLaps && Double.isFinite(nativeLength) && nativeLength > 0.1
                && Double.isFinite(measuredDistance)
                && measuredDistance >= 0.95 * nativeLength * targetLaps
                && measuredDistance <= 1.10 * nativeLength * targetLaps + 0.65
                && Double.isFinite(elapsedSeconds) && elapsedSeconds >= 3.0 && elapsedSeconds <= 480.0 * targetLaps
                && Double.isFinite(heldSeconds) && heldSeconds >= 3.0;
    }
}
