package dev.thundermine.tools;

import com.mojang.logging.LogUtils;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import dev.thundermine.tools.scenery.MineSceneryGenerator;
import dev.thundermine.tools.effects.MineEffects;
import dev.thundermine.tools.audio.RideAudio;
import org.slf4j.Logger;

/** Independent original test tooling; supplied MOD binaries stay unchanged. */
@Mod(ThunderMineTools.MOD_ID)
public final class ThunderMineTools {
    public static final String MOD_ID = "thunder_mine_tools";
    private static final Logger LOGGER = LogUtils.getLogger();

    public ThunderMineTools(IEventBus modEventBus, ModContainer modContainer) {
        modContainer.registerConfig(ModConfig.Type.COMMON, MineRideSettings.SPEC);
        RideAudio.register(modEventBus, modContainer);
        NeoForge.EVENT_BUS.addListener(this::registerCommands);
        // NativeTestRideController registers its genuine physics/tick listeners
        // separately. Nothing is constructed merely by loading this helper.
        NativeTestRideController.register(NeoForge.EVENT_BUS);
        NativeMineCourse.register(NeoForge.EVENT_BUS);
        MineRideController.register(NeoForge.EVENT_BUS);
        MineEffects.register(NeoForge.EVENT_BUS);
        NeoForge.EVENT_BUS.addListener(this::onServerTick);
        NeoForge.EVENT_BUS.addListener(EventPriority.LOWEST, CoasterTestService::onNativePostPhysicsTick);
        NeoForge.EVENT_BUS.addListener(CoasterTestService::onLevelUnload);
    }

    private void registerCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("mine_world")
                .then(Commands.literal("build").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_BUILD", () -> NativeMineCourse.build(context.getSource().getLevel()))))
                .then(Commands.literal("status").executes(context -> run(context.getSource(),
                        "WORLD_STATUS", () -> "Thunder Mine Tools 1.1.0 world=\"" + context.getSource().getLevel().getServer().getWorldData().getLevelName() + "\" " + NativeMineCourse.status(context.getSource().getLevel())
                                + " " + MineRideController.status(context.getSource().getLevel()))))
                .then(Commands.literal("validate").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_VALIDATE", () -> MineRideController.validate(context.getSource().getLevel(), 1))))
                .then(Commands.literal("start").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_START", () -> MineRideController.start(context.getSource().getLevel()))))
                .then(Commands.literal("stop").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_STOP", () -> MineRideController.stop(context.getSource().getLevel()))))
                .then(Commands.literal("resume").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_RESUME", () -> MineRideController.resume(context.getSource().getLevel()))))
                .then(Commands.literal("return_to_station").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_RETURN", () -> MineRideController.returnToStation(context.getSource().getLevel()))))
                .then(Commands.literal("stabilize_topsoil").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_TOPSOIL", () -> MineSceneryGenerator.stabilizeTopsoil(context.getSource().getLevel()))))
                .then(Commands.literal("board").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_BOARD", () -> MineRideController.board(context.getSource()))))
                .then(Commands.literal("scenery").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_SCENERY", () -> {
                            var level = context.getSource().getLevel();
                            var snapshot = MineRideController.snapshot(level);
                            if (snapshot == null || !"PASSED".equals(snapshot.phase()) || snapshot.completedLaps() < 1)
                                throw new IllegalStateException("A genuine completed native lap and station stop are required before scenery");
                            return MineSceneryGenerator.start(level);
                        })))
                .then(Commands.literal("scenery_status").executes(context -> run(context.getSource(),
                        "WORLD_SCENERY_STATUS", () -> MineSceneryGenerator.status(context.getSource().getLevel()))))
                .then(Commands.literal("clearance").requires(source -> source.hasPermission(2)).executes(context -> run(context.getSource(),
                        "WORLD_CLEARANCE", () -> MineSceneryGenerator.clearanceReport(context.getSource().getLevel()))))
                .then(Commands.literal("effects").executes(context -> run(context.getSource(),
                        "WORLD_EFFECTS", () -> MineEffects.status(context.getSource().getLevel())))));
        event.getDispatcher().register(Commands.literal("mine_test")
                .requires(source -> source.hasPermission(2))
                .then(Commands.literal("build").executes(context -> run(context.getSource(),
                        "BUILD", () -> CoasterTestService.build(context.getSource().getLevel()))))
                .then(Commands.literal("status").executes(context -> run(context.getSource(),
                        "STATUS", () -> CoasterTestService.status(context.getSource().getLevel())
                                + " " + NativeTestRideController.status(context.getSource().getLevel()))))
                .then(Commands.literal("board").executes(context -> run(context.getSource(),
                        "BOARD", () -> NativeBoarding.board(context.getSource()))))
                .then(Commands.literal("ride_status").executes(context -> run(context.getSource(),
                        "RIDE_STATUS", () -> NativeBoarding.status(context.getSource()))))
                .then(Commands.literal("start").executes(context -> run(context.getSource(),
                        "START", () -> {
                            var level = context.getSource().getLevel();
                            if (!CoasterTestSavedData.get(level).built())
                                throw new IllegalStateException("Build and inspect the native test first");
                            CoasterTestService.requireClosedNativeTopology(level);
                            var cart = CoasterTestService.cart(level);
                            if (cart == null) throw new IllegalStateException("The native cart is not loaded");
                            return NativeTestRideController.start(level);
                        })))
                .then(Commands.literal("stop").executes(context -> run(context.getSource(),
                        "STOP", () -> NativeTestRideController.stop(context.getSource().getLevel()))))
                .then(Commands.literal("remove").executes(context -> run(context.getSource(),
                        "REMOVE", () -> {
                            var level = context.getSource().getLevel();
                            // Stop real velocity before removal. The service also
                            // refuses passengers and any altered world blocks.
                            NativeTestRideController.stop(level);
                            String message = CoasterTestService.remove(level);
                            NativeTestRideController.detach(level);
                            return message;
                        }))));
    }

    private void onServerTick(ServerTickEvent.Post event) {
        for (var level : event.getServer().getAllLevels()) {
            MineSceneryGenerator.tick(level);
            if (level.getGameTime() % 20L == 0L) {
                try { RideAudio.send(level, MineRideController.snapshot(level)); }
                catch (RuntimeException audioFailure) { LOGGER.warn("MINE_AUDIO_TICK_FAILED {}", audioFailure.toString()); }
            }
        }
    }

    private static int run(CommandSourceStack source, String action, Operation operation) {
        try {
            String message = operation.run();
            source.sendSuccess(() -> Component.literal(message), false);
            LOGGER.info("MINE_TEST_{} {}", action, message);
            return 1;
        } catch (RuntimeException failure) {
            String message = failure.getMessage() == null ? failure.getClass().getSimpleName()
                    : failure.getMessage();
            source.sendFailure(Component.literal(message));
            LOGGER.warn("MINE_TEST_{}_FAILED {}", action, message, failure);
            return 0;
        }
    }

    @FunctionalInterface
    private interface Operation {
        String run();
    }
}
