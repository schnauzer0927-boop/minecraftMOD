package dev.thundermine.tools;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.HexFormat;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

/**
 * Immutable, validated authoring data for an original native Simulated Coasters circuit.
 * Speeds use blocks/second and acceleration/braking use blocks/second squared, matching
 * Sable's physical velocity API. Nodes are ordered in the direction of travel; the last
 * node connects to the first without repeating the first block in the JSON.
 *
 * <p>This parser validates data, not physical ride success. Native Bezier placement and
 * minimum-radius checks must still run before construction is committed.</p>
 */
public final class MineRoute {
    public static final String BUNDLED_RESOURCE = "/data/thunder_mine_tools/course/mine-route.json";
    public static final int MIN_NODES = 4;
    public static final int MAX_NODES = 256;
    public static final double MAX_ADJACENT_CHORD = 45.0;
    public static final double MAX_HANDLE_CHORD_RATIO = 0.7;
    private static final int MAX_JSON_BYTES = 2 * 1024 * 1024;
    private static final double PERPENDICULAR_TOLERANCE = 1.0e-3;
    private static final double MIN_VECTOR_LENGTH = 1.0e-9;
    private static final int WORLD_COORDINATE_LIMIT = 29_999_984;

    private final String name;
    private final List<Node> nodes;
    private final String fingerprint;

    private MineRoute(String name, List<Node> nodes, String fingerprint) {
        this.name = name;
        this.nodes = List.copyOf(nodes);
        this.fingerprint = fingerprint;
    }

    /** Read the packaged route once, on demand; this does not access or edit any world. */
    public static MineRoute loadBundled() {
        return BundledHolder.ROUTE;
    }

    private static final class BundledHolder {
        private static final MineRoute ROUTE = readBundled();
    }

    private static MineRoute readBundled() {
        try (InputStream input = MineRoute.class.getResourceAsStream(BUNDLED_RESOURCE)) {
            if (input == null) {
                throw new IllegalStateException("Missing bundled mine route: " + BUNDLED_RESOURCE);
            }
            return load(input);
        } catch (IOException failure) {
            throw new IllegalStateException("Could not close bundled mine route", failure);
        }
    }

    /**
     * Parse a bounded UTF-8 stream without closing it. Unknown root/node fields are ignored
     * so that authoring annotations can coexist with the validated operational fields.
     * Invalid input throws IllegalArgumentException; unreadable input throws IllegalStateException.
     */
    public static MineRoute load(InputStream input) {
        Objects.requireNonNull(input, "input");
        final byte[] bytes;
        try {
            bytes = input.readNBytes(MAX_JSON_BYTES + 1);
        } catch (IOException failure) {
            throw new IllegalStateException("Could not read mine route JSON", failure);
        }
        if (bytes.length > MAX_JSON_BYTES) {
            throw new IllegalArgumentException("Mine route JSON exceeds " + MAX_JSON_BYTES + " bytes");
        }
        final String json;
        try {
            json = StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(bytes)).toString();
        } catch (CharacterCodingException failure) {
            throw new IllegalArgumentException("Mine route JSON is not valid UTF-8", failure);
        }
        final JsonElement parsed;
        try {
            parsed = JsonParser.parseString(json);
        } catch (JsonParseException failure) {
            throw new IllegalArgumentException("Mine route JSON is malformed", failure);
        }
        if (!parsed.isJsonObject()) {
            throw new IllegalArgumentException("Mine route root must be an object");
        }
        JsonObject root = parsed.getAsJsonObject();
        String name = text(root, "name", "route", 160);
        JsonElement rawNodes = required(root, "nodes", "route");
        if (!rawNodes.isJsonArray()) {
            throw new IllegalArgumentException("route.nodes must be an array");
        }
        JsonArray array = rawNodes.getAsJsonArray();
        if (array.size() < MIN_NODES || array.size() > MAX_NODES) {
            throw new IllegalArgumentException("route.nodes must contain " + MIN_NODES + "–" + MAX_NODES + " nodes");
        }
        List<Node> nodes = new ArrayList<>(array.size());
        Set<BlockPos> blocks = new HashSet<>();
        for (int index = 0; index < array.size(); ++index) {
            String context = "route.nodes[" + index + "]";
            JsonElement element = array.get(index);
            if (!element.isJsonObject()) {
                throw new IllegalArgumentException(context + " must be an object");
            }
            JsonObject source = element.getAsJsonObject();
            Node node;
            try {
                node = new Node(block(source, context), vector(source, "forward", context),
                        vector(source, "up", context), number(source, "bankDegrees", context),
                        number(source, "handleIn", context), number(source, "handleOut", context),
                        text(source, "area", context, 120), number(source, "targetSpeed", context),
                        number(source, "acceleration", context), number(source, "braking", context));
            } catch (IllegalArgumentException failure) {
                throw new IllegalArgumentException(context + ": " + failure.getMessage(), failure);
            }
            if (!blocks.add(node.block())) {
                throw new IllegalArgumentException(context + " repeats block " + node.block()
                        + "; a closed route wraps implicitly and must not duplicate its first node");
            }
            nodes.add(node);
        }
        validateAdjacentNodes(nodes);
        return new MineRoute(name, nodes, sha256(bytes));
    }

    public String name() { return name; }
    public List<Node> nodes() { return nodes; }

    /** SHA-256 of the original bytes, including whitespace and optional authoring fields. */
    public String fingerprint() { return fingerprint; }

    private static void validateAdjacentNodes(List<Node> nodes) {
        for (int index = 0; index < nodes.size(); ++index) {
            int nextIndex = (index + 1) % nodes.size();
            Node from = nodes.get(index);
            Node to = nodes.get(nextIndex);
            double chord = Math.sqrt(from.block().distSqr(to.block()));
            String edge = "route edge " + index + "→" + nextIndex;
            if (chord > MAX_ADJACENT_CHORD) {
                throw new IllegalArgumentException(edge + " chord is " + chord
                        + " blocks; native default connection limit is " + MAX_ADJACENT_CHORD);
            }
            double limit = chord * MAX_HANDLE_CHORD_RATIO;
            if (from.handleOut() > limit + 1.0e-9 || to.handleIn() > limit + 1.0e-9) {
                throw new IllegalArgumentException(edge + " handles exceed " + limit
                        + " blocks (" + MAX_HANDLE_CHORD_RATIO + " × chord); shorten handles or move nodes");
            }
        }
    }

    private static JsonElement required(JsonObject object, String field, String context) {
        JsonElement value = object.get(field);
        if (value == null || value.isJsonNull()) {
            throw new IllegalArgumentException(context + "." + field + " is required");
        }
        return value;
    }

    private static String text(JsonObject object, String field, String context, int maxLength) {
        JsonElement value = required(object, field, context);
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isString()) {
            throw new IllegalArgumentException(context + "." + field + " must be a string");
        }
        String text = value.getAsString().strip();
        if (text.isEmpty() || text.length() > maxLength || text.chars().anyMatch(Character::isISOControl)) {
            throw new IllegalArgumentException(context + "." + field
                    + " must be nonblank, at most " + maxLength + " characters, with no control characters");
        }
        return text;
    }

    private static double number(JsonObject object, String field, String context) {
        return number(required(object, field, context), context + "." + field);
    }

    private static double number(JsonElement value, String context) {
        if (!value.isJsonPrimitive() || !value.getAsJsonPrimitive().isNumber()) {
            throw new IllegalArgumentException(context + " must be a finite JSON number");
        }
        double result;
        try {
            result = value.getAsDouble();
        } catch (NumberFormatException failure) {
            throw new IllegalArgumentException(context + " must be a finite JSON number", failure);
        }
        if (!Double.isFinite(result)) {
            throw new IllegalArgumentException(context + " must be finite");
        }
        return result;
    }

    private static JsonArray triple(JsonObject object, String field, String context) {
        JsonElement value = required(object, field, context);
        if (!value.isJsonArray() || value.getAsJsonArray().size() != 3) {
            throw new IllegalArgumentException(context + "." + field + " must be a three-number array");
        }
        return value.getAsJsonArray();
    }

    private static Vec3 vector(JsonObject object, String field, String context) {
        JsonArray value = triple(object, field, context);
        return new Vec3(number(value.get(0), context + "." + field + "[0]"),
                number(value.get(1), context + "." + field + "[1]"),
                number(value.get(2), context + "." + field + "[2]"));
    }

    private static BlockPos block(JsonObject object, String context) {
        JsonArray value = triple(object, "block", context);
        return new BlockPos(integer(value.get(0), context + ".block[0]"),
                integer(value.get(1), context + ".block[1]"),
                integer(value.get(2), context + ".block[2]"));
    }

    private static int integer(JsonElement value, String context) {
        number(value, context);
        try {
            return new BigDecimal(value.getAsString()).intValueExact();
        } catch (NumberFormatException | ArithmeticException failure) {
            throw new IllegalArgumentException(context + " must be an exact 32-bit integer", failure);
        }
    }

    private static Vec3 unit(Vec3 vector, String name) {
        Objects.requireNonNull(vector, name);
        if (!Double.isFinite(vector.x) || !Double.isFinite(vector.y) || !Double.isFinite(vector.z)) {
            throw new IllegalArgumentException(name + " must have finite components");
        }
        double length = Math.hypot(Math.hypot(vector.x, vector.y), vector.z);
        if (!Double.isFinite(length) || length < MIN_VECTOR_LENGTH) {
            throw new IllegalArgumentException(name + " must be a finite nonzero vector");
        }
        return vector.scale(1.0 / length);
    }

    private static void range(double value, String name, double minimum, double maximum) {
        if (!Double.isFinite(value) || value < minimum || value > maximum) {
            throw new IllegalArgumentException(name + " must be finite and within [" + minimum + ", " + maximum + "]");
        }
    }

    private static String sha256(byte[] bytes) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("Java SHA-256 provider is unavailable", impossible);
        }
    }

    /** A shared anchor frame; up is the unbanked perpendicular reference, never prebanked. */
    public record Node(BlockPos block, Vec3 forward, Vec3 up, double bankDegrees,
                       double handleIn, double handleOut, String area, double targetSpeed,
                       double acceleration, double braking) {
        public Node {
            block = Objects.requireNonNull(block, "block").immutable();
            if (Math.abs((long) block.getX()) > WORLD_COORDINATE_LIMIT
                    || Math.abs((long) block.getZ()) > WORLD_COORDINATE_LIMIT
                    || block.getY() < -64 || block.getY() > 319) {
                throw new IllegalArgumentException("block must be within the Minecraft 1.21.1 overworld bounds");
            }
            forward = unit(forward, "forward");
            up = unit(up, "up");
            double dot = forward.dot(up);
            if (Math.abs(dot) > PERPENDICULAR_TOLERANCE) {
                throw new IllegalArgumentException("up must be perpendicular to forward before banking; normalized dot=" + dot);
            }
            // Correct accepted floating-point authoring residue, not an invalid frame.
            up = unit(up.subtract(forward.scale(dot)), "up");
            range(bankDegrees, "bankDegrees", -60.0, 60.0);
            range(handleIn, "handleIn", 1.0e-4, 32.0);
            range(handleOut, "handleOut", 1.0e-4, 32.0);
            range(targetSpeed, "targetSpeed (blocks/second)", 0.0, 30.0);
            range(acceleration, "acceleration (blocks/second squared)", 0.05, 8.0);
            range(braking, "braking (blocks/second squared)", 0.05, 12.0);
            area = Objects.requireNonNull(area, "area").strip();
            if (area.isEmpty() || area.length() > 120 || area.chars().anyMatch(Character::isISOControl)) {
                throw new IllegalArgumentException("area must be a nonblank string of at most 120 characters without control characters");
            }
        }

        /** Right-handed Rodrigues rotation of the unbanked up around authored forward. */
        public Vec3 bankedUp() {
            double radians = Math.toRadians(bankDegrees);
            double cosine = Math.cos(radians);
            double sine = Math.sin(radians);
            return up.scale(cosine).add(forward.cross(up).scale(sine))
                    .add(forward.scale(forward.dot(up) * (1.0 - cosine))).normalize();
        }
    }
}
