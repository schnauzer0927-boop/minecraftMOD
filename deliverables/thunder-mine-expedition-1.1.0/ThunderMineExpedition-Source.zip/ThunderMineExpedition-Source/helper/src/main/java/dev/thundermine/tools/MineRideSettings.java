package dev.thundermine.tools;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Operational tuning leaves the authored geometry and its saved fingerprint unchanged. */
public final class MineRideSettings {
    public static final ModConfigSpec SPEC;
    private static final ModConfigSpec.BooleanValue ENHANCED;
    private static final ModConfigSpec.DoubleValue THRILL_FACTOR;
    private static final ModConfigSpec.DoubleValue BADLANDS_FACTOR;
    private static final ModConfigSpec.DoubleValue EXPLORATION_SPEED;

    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        builder.push("ride");
        ENHANCED = builder.comment("False restores the original authored speed targets.")
                .define("enhancedSpeed", true);
        THRILL_FACTOR = builder.comment("Tunnel and canyon boost; actual curve, acceleration and station limits still apply.")
                .defineInRange("thrillFactor", 1.25, 1.0, 1.25);
        BADLANDS_FACTOR = builder.defineInRange("badlandsFactor", 1.10, 1.0, 1.15);
        EXPLORATION_SPEED = builder.defineInRange("explorationSpeed", 4.0, 3.2, 4.0);
        builder.pop();
        SPEC = builder.build();
    }

    private MineRideSettings() {}

    public static double target(String area, int nodeIndex, double authored) {
        if (!ENHANCED.get()) return authored;
        return switch (area) {
            case "base" -> nodeIndex >= 1 && nodeIndex <= 5 ? EXPLORATION_SPEED.get() : authored;
            case "badlands" -> authored * BADLANDS_FACTOR.get();
            case "mine_tunnel", "canyon" -> authored * THRILL_FACTOR.get();
            default -> authored; // Slow scenic cavern, return approach and station retain their targets.
        };
    }
}
