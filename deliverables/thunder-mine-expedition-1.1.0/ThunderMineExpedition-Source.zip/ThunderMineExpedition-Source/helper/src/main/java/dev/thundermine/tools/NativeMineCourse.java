package dev.thundermine.tools;

import com.mojang.logging.LogUtils;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import com.simibubi.create.content.trains.track.BezierConnection;
import dev.ryanhcode.sable.api.sublevel.SubLevelContainer;
import dev.ryanhcode.sable.neoforge.event.ForgeSablePostPhysicsTickEvent;
import dev.ryanhcode.sable.sublevel.ServerSubLevel;
import dev.silvergold.simulatedcoasters.CoasterTrackMaterials;
import dev.silvergold.simulatedcoasters.SimulatedCoastersBlocks;
import dev.silvergold.simulatedcoasters.track.CoasterAnchorBezierOptimizer;
import dev.silvergold.simulatedcoasters.track.CoasterPeerCurveHandleLengths;
import dev.silvergold.simulatedcoasters.track.anchor.AnchorPeerFakeTracks;
import dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlock;
import dev.silvergold.simulatedcoasters.track.anchor.CoasterAnchorpointBlockEntity;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartBlock;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartLinkPlacement;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartMidTrackPlacement;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartResolve;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartSeatedEntityCollision;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartSpawner;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartTrackSnap;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathEdge;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathGraphManager;
import dev.silvergold.simulatedcoasters.track.graph.CoasterPathTrackFrame;
import dev.silvergold.simulatedcoasters.track.graph.CoasterTrackPropagator;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.createmod.catnip.data.Couple;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.state.properties.Half;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.event.level.LevelEvent;
import org.joml.Vector3d;
import org.slf4j.Logger;

/** Native course registration and original wooden body; never drives a fabricated path. */
public final class NativeMineCourse {
    public static final String REQUIRED_WORLD_NAME = "Coaster World - Thunder Mine Expedition";
    public static final double STATION_T = 0.02;
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final List<BlockPos> SEATS = List.of(new BlockPos(0, 2, 0), new BlockPos(0, 2, 1));
    private static final Map<ServerLevel, Pending> PENDING = new IdentityHashMap<>();
    private static final int INITIALIZATION_TIMEOUT = 100;

    private NativeMineCourse() {}

    public static void register(IEventBus bus) {
        bus.addListener(EventPriority.LOWEST, NativeMineCourse::onPostPhysics);
        bus.addListener(NativeMineCourse::onLevelUnload);
    }

    public static MineRoute route() { return MineRoute.loadBundled(); }
    public static MineRoute route(ServerLevel level) { return route(); }
    public static List<MineRoute.Node> nodes() { return route().nodes(); }
    public static List<BlockPos> seatLocals() { return SEATS; }
    public static UUID cartId(ServerLevel level) { return MineCourseSavedData.get(level).cartId(); }

    public static ServerSubLevel cart(ServerLevel level) {
        UUID id = cartId(level);
        return id == null ? null : CoasterCartResolve.findCartById(level, id);
    }

    public static boolean nativeEngaged(ServerSubLevel cart) {
        if (cart == null || cart.isRemoved() || CoasterCartTrackSnap.isBearingDisengaged(cart)) return false;
        var state = cart.getPlot().getEmbeddedLevelAccessor().getBlockState(BlockPos.ZERO);
        return state.is(SimulatedCoastersBlocks.COASTER_CART_BLOCK.get())
                && state.getValue(CoasterCartBlock.SNAP_ENGAGED);
    }

    public static boolean occupied(ServerLevel level, ServerSubLevel cart) {
        for (var player : level.players())
            if (CoasterCartSeatedEntityCollision.hostCartFromVehicleChain(player) == cart) return true;
        for (var seat : SEATS) {
            BlockPos global = cart.getPlot().getCenterBlock().offset(seat);
            for (var entity : level.getEntitiesOfClass(SeatEntity.class, new AABB(global).inflate(0.4)))
                if (entity.isVehicle()) return true;
        }
        return false;
    }

    /** Actual native graph edges, returned in JSON travel order rather than HashMap order. */
    public static List<CoasterPathEdge> actualEdges(ServerLevel level) {
        Map<String, CoasterPathEdge> byEndpoints = new HashMap<>();
        var authored = nodes();
        Set<BlockPos> owned = new HashSet<>();
        for (var node : authored) owned.add(node.block());
        for (var edge : CoasterPathGraphManager.get(level).edges()) {
            if (!owned.contains(edge.from()) || !owned.contains(edge.to())) continue;
            String key = key(edge.from(), edge.to());
            if (byEndpoints.putIfAbsent(key, edge) != null)
                throw new IllegalStateException("Duplicate native mine edge: " + key);
        }
        var ordered = new ArrayList<CoasterPathEdge>();
        for (int index = 0; index < authored.size(); index++) {
            var edge = byEndpoints.get(key(authored.get(index).block(), authored.get((index + 1) % authored.size()).block()));
            if (edge == null) throw new IllegalStateException("Missing actual native mine edge " + index);
            ordered.add(edge);
        }
        return List.copyOf(ordered);
    }

    public static void requireClosedTopology(ServerLevel level) {
        requireClosedNativeTopology(level);
    }

    public static void requireClosedNativeTopology(ServerLevel level) {
        var receipt = MineCourseSavedData.get(level);
        if (receipt.invalid() || !route().fingerprint().equals(receipt.fingerprint()))
            throw new IllegalStateException("Mine route/receipt mismatch; native course was not converted");
        var edges = actualEdges(level);
        if (edges.size() != nodes().size()) throw new IllegalStateException("Wrong actual native mine edge count");
        for (var node : nodes()) {
            var anchor = anchor(level, node.block());
            long degree = edges.stream().filter(edge -> edge.from().equals(node.block())
                    || edge.to().equals(node.block())).count();
            if (degree != 2 || anchor.legCount() != 2)
                throw new IllegalStateException("Mine route is open/branched at " + node.block());
        }
    }

    public static CoasterPathTrackFrame.GraphHit stationHit(ServerLevel level) {
        var edge = actualEdges(level).getFirst();
        double t = edge.from().equals(nodes().getFirst().block()) ? STATION_T : 1.0 - STATION_T;
        return new CoasterPathTrackFrame.GraphHit(CoasterPathGraphManager.sampleEdgePosition(level, edge, t), edge, t);
    }

    public static Vec3 stationBearing(ServerLevel level) {
        return CoasterPathTrackFrame.pathAnchorForSnappedBlock(level, stationHit(level));
    }

    public static Vec3 stationForward(ServerLevel level) {
        var hit = stationHit(level);
        double step = hit.edge().from().equals(nodes().getFirst().block()) ? 0.001 : -0.001;
        return CoasterPathGraphManager.sampleEdgePosition(level, hit.edge(), hit.t() + step)
                .subtract(hit.point()).normalize();
    }

    /** Persist normal vanilla forced chunks for the actual route, plus two chunks at each node. */
    public static int forceRouteChunks(ServerLevel level) {
        requireDedicatedWorld(level);
        var receipt = MineCourseSavedData.get(level);
        if (receipt.invalid()) throw new IllegalStateException("Invalid native mine construction receipt");
        if (!receipt.reserved()) receipt.reserve(route().fingerprint());
        if (!route().fingerprint().equals(receipt.fingerprint()))
            throw new IllegalStateException("Bundled route changed; refusing to alter the saved mine course");
        Set<Long> chunks = new LinkedHashSet<>();
        for (var node : nodes()) {
            int cx = node.block().getX() >> 4, cz = node.block().getZ() >> 4;
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++)
                chunks.add(ChunkPos.asLong(cx + dx, cz + dz));
        }
        if (chunks.size() > 1024) throw new IllegalStateException("Native mine route exceeds the chunk budget");
        for (long packed : chunks) {
            var chunk = new ChunkPos(packed);
            if (!level.getForcedChunks().contains(packed)) {
                level.setChunkForced(chunk.x, chunk.z, true);
                receipt.ownForcedChunk(packed);
            }
            level.getChunk(chunk.x, chunk.z);
        }
        LOGGER.info("MINE_MAIN_CHUNKS_READY total={} helperOwned={} fingerprint={}",
                chunks.size(), receipt.ownedForcedChunks().size(), route().fingerprint());
        return chunks.size();
    }

    /** Registers native rails in a prepared empty sweep; terrain creation is a separate phase. */
    public static String build(ServerLevel level) {
        requireDedicatedWorld(level);
        var receipt = MineCourseSavedData.get(level);
        if (receipt.invalid() || receipt.built() || receipt.pending() || receipt.cartId() != null)
            throw new IllegalStateException("Existing native mine construction must be preserved; no overwrite performed");
        if (!CoasterPathGraphManager.get(level).edges().isEmpty())
            throw new IllegalStateException("A fresh main world without another native coaster graph is required");
        var container = SubLevelContainer.getContainer(level);
        if (container == null) throw new IllegalStateException("Sable server container is not ready");
        for (var existing : container.getAllSubLevels())
            if (!existing.isRemoved()) throw new IllegalStateException("Main native world already contains a sublevel");
        forceRouteChunks(level);
        var curves = authoredCurves();
        try {
            for (var node : nodes()) {
                if (!level.getBlockState(node.block()).isAir())
                    throw new IllegalStateException("Native anchor site is occupied: " + node.block());
            }
            requireClearance(level, temporarySamples(level, curves));
            CoasterTrackPropagator.runBatchUpdate(level, () -> {
                for (var node : nodes()) {
                    if (!level.setBlock(node.block(), SimulatedCoastersBlocks.COASTER_ANCHORPOINT.get()
                            .defaultBlockState().setValue(CoasterAnchorpointBlock.FACING, Direction.UP), 3))
                        throw new IllegalStateException("Native anchor placement failed: " + node.block());
                    anchor(level, node.block()).setLiftBlocks(0f);
                    anchor(level, node.block()).setJointBankRadians((float)Math.toRadians(node.bankDegrees()));
                }
                for (int index = 0; index < nodes().size(); index++)
                    anchor(level, nodes().get(index).block()).putAnchorPeerCurve(level,
                            nodes().get((index + 1) % nodes().size()).block(), curves.get(index));
            });
            requireClosedNativeTopology(level);
            requireClearance(level, geometrySamples(level));
            var hit = stationHit(level);
            var basis = CoasterPathTrackFrame.trackBasisAtHit(level, hit);
            if (basis.forward().dot(stationForward(level)) < 0)
                basis = new CoasterPathTrackFrame.TrackBasis(basis.forward().scale(-1), basis.right().scale(-1), basis.up());
            var orientation = CoasterPathTrackFrame.quaternionFromTrackBasis(basis);
            var origin = CoasterCartMidTrackPlacement.plotOriginForGraphHit(level, hit, orientation, null);
            var spawned = CoasterCartSpawner.spawnMinimalContraption(level, origin, orientation, hit, false);
            if (spawned == null) throw new IllegalStateException("Native mine cart allocation failed");
            receipt.recordCart(spawned.getUniqueId());
            buildWoodenBody(spawned);
            container.physicsSystem().getPipeline().onStatsChanged(spawned);
            receipt.awaitInitialization(spawned.getUniqueId(), level.getGameTime());
            PENDING.put(level, new Pending());
            LOGGER.info("MINE_MAIN_BUILD_PENDING cart={} nodes={} seats={} fingerprint={} gameTick={}",
                    spawned.getUniqueId(), nodes().size(), SEATS.size(), route().fingerprint(), level.getGameTime());
            return "Native mine rails and wooden two-seat cart placed; awaiting actual physics engagement. Tour unverified.";
        } catch (RuntimeException failure) {
            receipt.fail("Native main construction failed: " + failure.getMessage());
            throw failure;
        }
    }

    private static List<BezierConnection> authoredCurves() {
        var curves = new ArrayList<BezierConnection>();
        for (int index = 0; index < nodes().size(); index++) {
            var a = nodes().get(index);
            var b = nodes().get((index + 1) % nodes().size());
            var curve = new BezierConnection(Couple.create(a.block(), b.block()),
                    Couple.create(Vec3.atLowerCornerOf(a.block()).add(0.5, 0.25, 0.5),
                            Vec3.atLowerCornerOf(b.block()).add(0.5, 0.25, 0.5)),
                    Couple.create(a.forward(), b.forward().scale(-1)),
                    Couple.create(a.bankedUp(), b.bankedUp()), true, false, CoasterTrackMaterials.COASTER);
            boolean aIsLow = a.block().asLong() <= b.block().asLong();
            CoasterPeerCurveHandleLengths.putCanonical(curve,
                    aIsLow ? a.handleOut() : b.handleIn(), aIsLow ? b.handleIn() : a.handleOut());
            if (!CoasterAnchorBezierOptimizer.isBuiltPlacementCurveValid(curve)
                    || !CoasterAnchorBezierOptimizer.meetsMinCurveRadiusWithHandleLengths(curve, a.handleOut(), b.handleIn()))
                throw new IllegalStateException("Original native curve validation rejected mine edge " + index);
            curves.add(curve);
        }
        return List.copyOf(curves);
    }

    private static void buildWoodenBody(ServerSubLevel cart) {
        var embedded = cart.getPlot().getEmbeddedLevelAccessor();
        for (int x = -1; x <= 1; x++) for (int z = -1; z <= 2; z++)
            putBody(cart, new BlockPos(x, 1, z), Blocks.SPRUCE_PLANKS.defaultBlockState());
        for (int z = -1; z <= 2; z++) {
            putBody(cart, new BlockPos(-1, 2, z), trapdoor(Direction.WEST));
            putBody(cart, new BlockPos(1, 2, z), trapdoor(Direction.EAST));
        }
        putBody(cart, new BlockPos(0, 2, -1), trapdoor(Direction.NORTH));
        putBody(cart, new BlockPos(0, 2, 2), trapdoor(Direction.SOUTH));
        for (var seat : SEATS) putBody(cart, seat, AllBlocks.SEATS.get(DyeColor.BROWN).getDefaultState());
        if (!embedded.getBlockState(BlockPos.ZERO).is(SimulatedCoastersBlocks.COASTER_CART_BLOCK.get()))
            throw new IllegalStateException("Original native cart-bearing block was displaced");
    }

    private static net.minecraft.world.level.block.state.BlockState trapdoor(Direction direction) {
        return Blocks.SPRUCE_TRAPDOOR.defaultBlockState().setValue(TrapDoorBlock.FACING, direction)
                .setValue(TrapDoorBlock.HALF, Half.BOTTOM).setValue(TrapDoorBlock.OPEN, true);
    }

    private static void putBody(ServerSubLevel cart, BlockPos local, net.minecraft.world.level.block.state.BlockState state) {
        if (!cart.getPlot().getEmbeddedLevelAccessor().setBlock(local, state, 3))
            throw new IllegalStateException("Native wooden cart body placement failed at " + local);
    }

    public static List<GeometrySample> geometrySamples(ServerLevel level) {
        return sampledFrames(level, actualEdges(level));
    }

    private static List<GeometrySample> temporarySamples(ServerLevel level, List<BezierConnection> curves) {
        var edges = new ArrayList<CoasterPathEdge>();
        for (int index = 0; index < curves.size(); index++)
            edges.add(CoasterPathEdge.curve(nodes().get(index).block(),
                    nodes().get((index + 1) % nodes().size()).block(), curves.get(index)));
        return sampledFrames(level, edges);
    }

    private static List<GeometrySample> sampledFrames(ServerLevel level, List<CoasterPathEdge> edges) {
        var samples = new ArrayList<GeometrySample>();
        for (int index = 0; index < edges.size(); index++) {
            var edge = edges.get(index);
            boolean forward = edge.from().equals(nodes().get(index).block());
            double chord = Math.sqrt(nodes().get(index).block().distSqr(nodes().get((index + 1) % nodes().size()).block()));
            int steps = Math.max(32, (int)Math.ceil(chord * 8));
            for (int sample = 0; sample <= steps; sample++) {
                double t = (double)sample / steps;
                if (!forward) t = 1.0 - t;
                var point = CoasterPathGraphManager.sampleEdgePosition(level, edge, t);
                var hit = new CoasterPathTrackFrame.GraphHit(point, edge, t);
                var basis = CoasterPathTrackFrame.trackBasisAtHit(level, hit);
                double dt = forward ? 0.0001 : -0.0001;
                double nextT = Math.max(0, Math.min(1, t + dt));
                if (nextT == t) nextT = t - dt;
                Vec3 authoredForward = CoasterPathGraphManager.sampleEdgePosition(level, edge, nextT).subtract(point);
                if ((forward && nextT < t) || (!forward && nextT > t)) authoredForward = authoredForward.scale(-1);
                if (basis.forward().dot(authoredForward) < 0)
                    basis = new CoasterPathTrackFrame.TrackBasis(basis.forward().scale(-1), basis.right().scale(-1), basis.up());
                samples.add(new GeometrySample(point, basis.forward(), basis.right(), basis.up()));
            }
        }
        return List.copyOf(samples);
    }

    /** Conservative native cart/rider sampling; nonempty results abort rather than hide obstructions. */
    public static void requireClearance(ServerLevel level, List<GeometrySample> samples) {
        Set<BlockPos> touched = new HashSet<>();
        double[] xs = {-1.55, -0.75, 0, 0.75, 1.55};
        double[] ys = {0.1, 0.65, 1.3, 2.0, 2.7, 3.4};
        double[] zs = {-1.55, -0.65, 0.3, 1.25, 2.55};
        Set<BlockPos> ownAnchors = new HashSet<>();
        for (var node : nodes()) ownAnchors.add(node.block());
        for (var sample : samples) {
            var bearing = sample.spine().add(sample.up().scale(0.3125));
            for (double x : xs) for (double y : ys) for (double z : zs) {
                Vec3 point = bearing.add(sample.right().scale(x)).add(sample.up().scale(y))
                        .subtract(sample.forward().scale(z));
                BlockPos block = BlockPos.containing(point);
                if (!touched.add(block)) continue;
                if (!level.hasChunkAt(block)) throw new IllegalStateException("Native mine sweep reaches an unloaded chunk: " + block);
                var state = level.getBlockState(block);
                if (state.isAir()) continue;
                // Original anchors have an empty Sable collision shape, and managed
                // fake track cells are original interaction objects, not scenery.
                if (ownAnchors.contains(block) && state.is(SimulatedCoastersBlocks.COASTER_ANCHORPOINT.get())) continue;
                if (AnchorPeerFakeTracks.isManagedFakeTrack(level, block)) continue;
                if (!state.getFluidState().isEmpty() || !state.getCollisionShape(level, block).isEmpty())
                    throw new IllegalStateException("Native mine cart/rider sweep is blocked at " + block + " by " + state);
            }
        }
        LOGGER.info("MINE_MAIN_CLEARANCE_VALIDATED sampledFrames={} uniqueWorldCells={}", samples.size(), touched.size());
    }

    private static void onPostPhysics(ForgeSablePostPhysicsTickEvent event) {
        ServerLevel level = event.getPhysicsSystem().getLevel();
        var receipt = MineCourseSavedData.get(level);
        if (!receipt.pending() || level.getGameTime() <= receipt.pendingSince()) return;
        var waiting = PENDING.computeIfAbsent(level, ignored -> new Pending());
        if (waiting.lastTick == level.getGameTime()) return;
        waiting.lastTick = level.getGameTime();
        var cart = cart(level);
        if (level.getGameTime() - receipt.pendingSince() > INITIALIZATION_TIMEOUT) {
            receipt.fail("Native mine initialization timed out; full course remains unverified");
            PENDING.remove(level);
            LOGGER.error("MINE_MAIN_BUILD_FAILED timeout cart={}", receipt.cartId());
            return;
        }
        if (cart == null) return;
        try {
            requireClosedNativeTopology(level);
            if (!receipt.alignmentApplied()) {
                if (CoasterCartTrackSnap.representativeBearingPlotPos(cart) == null) return;
                CoasterCartTrackSnap.applyInitialSnapAfterSpawn(cart, level, stationHit(level));
                receipt.recordAlignment();
                LOGGER.info("MINE_MAIN_PLACEMENT_ALIGNED cart={} explicitPlacementAlignmentCount=1", cart.getUniqueId());
                return;
            }
            Vec3 bearing = CoasterCartLinkPlacement.bearingCenterWorld(cart, cart.logicalPose());
            Vector3d velocity = event.getPhysicsSystem().getPipeline().getLinearVelocity(cart, new Vector3d());
            boolean seats = SEATS.stream().allMatch(local -> cart.getPlot().getEmbeddedLevelAccessor()
                    .getBlockState(local).is(AllBlocks.SEATS.get(DyeColor.BROWN).get()));
            boolean stable = nativeEngaged(cart) && seats && bearing != null && velocity.isFinite()
                    && bearing.distanceTo(stationBearing(level)) <= 0.65 && velocity.length() <= 0.05;
            waiting.stableTicks = stable ? waiting.stableTicks + 1 : 0;
            event.getPhysicsSystem().getPipeline().resetVelocity(cart);
            LOGGER.info("MINE_MAIN_BUILD_OBSERVED cart={} stableTicks={} engaged={} seats={} bearing={} speed={}",
                    cart.getUniqueId(), waiting.stableTicks, nativeEngaged(cart), seats, bearing, velocity.length());
            if (waiting.stableTicks >= 5) {
                MineRideController.armStationHold(level, cart);
                receipt.complete();
                PENDING.remove(level);
                LOGGER.info("MINE_MAIN_BUILD_READY cart={} nodes={} seats={} explicitPlacementAlignmentCount=1 directRidePoseAssignments=0 fingerprint={}",
                        cart.getUniqueId(), nodes().size(), SEATS.size(), route().fingerprint());
            }
        } catch (RuntimeException failure) {
            receipt.fail("Native mine initialization failed: " + failure.getMessage());
            PENDING.remove(level);
            LOGGER.error("MINE_MAIN_BUILD_FAILED cart={}", receipt.cartId(), failure);
        }
    }

    public static String status(ServerLevel level) {
        var receipt = MineCourseSavedData.get(level);
        var cart = cart(level);
        return String.format(Locale.ROOT,
                "Mine built=%s pending=%s valid=%s cart=%s loaded=%s engaged=%s seats=%d ownedForcedChunks=%d fingerprint=%s. %s",
                receipt.built(), receipt.pending(), !receipt.invalid(), receipt.cartId(), cart != null,
                nativeEngaged(cart), SEATS.size(), receipt.ownedForcedChunks().size(), receipt.fingerprint(), receipt.message());
    }

    public static void requireDedicatedWorld(ServerLevel level) {
        if (!level.dimension().equals(Level.OVERWORLD)
                || !REQUIRED_WORLD_NAME.equals(level.getServer().getWorldData().getLevelName()))
            throw new IllegalStateException("Only the separate '" + REQUIRED_WORLD_NAME + "' Overworld may be constructed");
    }

    private static CoasterAnchorpointBlockEntity anchor(ServerLevel level, BlockPos position) {
        if (level.getBlockEntity(position) instanceof CoasterAnchorpointBlockEntity anchor) return anchor;
        throw new IllegalStateException("Missing native mine anchor at " + position);
    }

    private static String key(BlockPos a, BlockPos b) {
        long x = a.asLong(), y = b.asLong();
        return x <= y ? x + ":" + y : y + ":" + x;
    }

    private static void onLevelUnload(LevelEvent.Unload event) {
        if (event.getLevel() instanceof ServerLevel level) PENDING.remove(level);
    }

    public record GeometrySample(Vec3 spine, Vec3 forward, Vec3 right, Vec3 up) {}
    private static final class Pending {
        long lastTick = Long.MIN_VALUE;
        int stableTicks;
    }
}
