package dev.thundermine.tools;

/** Validates continuous resume measurements without resetting the journey or its station target. */
public final class MineResumeState {
    public static final double MAX_RESTORE_POSITION_DELTA = 1.5;
    private MineResumeState() {}

    public static Restored restore(double length, double savedLength, int targetLaps, int completedLaps,
                                   double savedCanonical, double actualCanonical, double savedUnwrapped,
                                   double measuredDistance, double elapsedSeconds, double actualBearingDelta) {
        for (double value : new double[]{length, savedLength, savedCanonical, actualCanonical,
                savedUnwrapped, measuredDistance, elapsedSeconds, actualBearingDelta}) {
            if (!Double.isFinite(value)) throw new IllegalArgumentException("Non-finite saved native resume measurement");
        }
        if (length <= 0.0 || Math.abs(length - savedLength) > 0.05
                || targetLaps < 1 || targetLaps > 3 || completedLaps < 0 || completedLaps > targetLaps
                || savedCanonical < 0 || savedCanonical >= length || actualCanonical < 0 || actualCanonical >= length
                || savedUnwrapped < -0.65 || savedUnwrapped > length * targetLaps + 0.65
                || measuredDistance < 0 || elapsedSeconds < 0 || elapsedSeconds > 480.0 * targetLaps
                || actualBearingDelta < 0 || actualBearingDelta > MAX_RESTORE_POSITION_DELTA) {
            throw new IllegalArgumentException("Saved native resume measurements do not match the live course");
        }
        double delta = actualCanonical - savedCanonical;
        if (delta > length / 2.0) delta -= length;
        if (delta < -length / 2.0) delta += length;
        if (Math.abs(delta) > MAX_RESTORE_POSITION_DELTA) {
            throw new IllegalArgumentException("Native restored arc position differs too far from its saved position");
        }
        return new Restored(savedUnwrapped + delta, measuredDistance + actualBearingDelta,
                elapsedSeconds, completedLaps, delta);
    }

    public record Restored(double unwrapped, double measuredDistance, double elapsedSeconds,
                           int completedLaps, double projectionDelta) {}
}
