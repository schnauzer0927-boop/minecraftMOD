package dev.thundermine.tools.audio;

import dev.thundermine.tools.ThunderMineTools;
import java.util.Objects;
import java.util.UUID;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Small server-authoritative music state; carries no drive or pose instructions. */
public record RideAudioPayload(UUID playerId, UUID cartId, ResourceLocation dimension,
                               String routeFingerprint, String area, boolean active,
                               double actualSpeed) implements CustomPacketPayload {
    public static final Type<RideAudioPayload> TYPE = new Type<>(
            ResourceLocation.fromNamespaceAndPath(ThunderMineTools.MOD_ID, "ride_audio"));
    public static final StreamCodec<RegistryFriendlyByteBuf, RideAudioPayload> STREAM_CODEC =
            StreamCodec.of((buffer, value) -> {
                buffer.writeUUID(value.playerId());
                buffer.writeUUID(value.cartId());
                buffer.writeResourceLocation(value.dimension());
                buffer.writeUtf(value.routeFingerprint(), 64);
                buffer.writeUtf(value.area(), 32);
                buffer.writeBoolean(value.active());
                buffer.writeDouble(value.actualSpeed());
            }, buffer -> new RideAudioPayload(buffer.readUUID(), buffer.readUUID(),
                    buffer.readResourceLocation(), buffer.readUtf(64), buffer.readUtf(32),
                    buffer.readBoolean(), buffer.readDouble()));

    public RideAudioPayload {
        Objects.requireNonNull(playerId, "playerId");
        Objects.requireNonNull(cartId, "cartId");
        Objects.requireNonNull(dimension, "dimension");
        Objects.requireNonNull(routeFingerprint, "routeFingerprint");
        Objects.requireNonNull(area, "area");
        if (!routeFingerprint.matches("[0-9a-f]{64}") || !RideAudioProgram.knownArea(area)
                || !Double.isFinite(actualSpeed) || actualSpeed < 0.0 || actualSpeed > 150.0) {
            throw new IllegalArgumentException("Invalid bounded attraction audio state");
        }
    }

    @Override public Type<RideAudioPayload> type() { return TYPE; }
}
