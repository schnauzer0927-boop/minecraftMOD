package dev.thundermine.tools.audio;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Client preferences; MUSIC and MASTER sliders remain authoritative. */
public final class RideAudioConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue ENABLED;
    public static final ModConfigSpec.DoubleValue VOLUME;
    public static final ModConfigSpec.DoubleValue FADE_SECONDS;

    static {
        var builder = new ModConfigSpec.Builder();
        builder.comment("Original onboard music for a genuine Thunder Mine passenger.",
                        "Minecraft Music and Master volume settings also apply.")
                .push("ride_audio");
        ENABLED = builder.comment("Enable attraction music while riding.")
                .define("enabled", true);
        VOLUME = builder.comment("Onboard music gain; does not override Minecraft volume sliders.")
                .defineInRange("volume", 0.65, 0.0, 1.0);
        FADE_SECONDS = builder.comment("Fade and area crossfade duration in seconds.")
                .defineInRange("fade_seconds", 1.2, 0.2, 4.0);
        builder.pop();
        SPEC = builder.build();
    }

    private RideAudioConfig() {}
    public static boolean enabled() { return !SPEC.isLoaded() || ENABLED.get(); }
    public static double volume() { return SPEC.isLoaded() ? VOLUME.get() : 0.65; }
    public static double fadeSeconds() { return SPEC.isLoaded() ? FADE_SECONDS.get() : 1.2; }
}
