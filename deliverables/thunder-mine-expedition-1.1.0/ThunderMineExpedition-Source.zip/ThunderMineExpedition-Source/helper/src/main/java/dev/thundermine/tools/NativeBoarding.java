package dev.thundermine.tools;

import com.mojang.logging.LogUtils;
import com.simibubi.create.AllBlocks;
import com.simibubi.create.content.contraptions.actors.seat.SeatBlock;
import com.simibubi.create.content.contraptions.actors.seat.SeatEntity;
import dev.ryanhcode.sable.sublevel.SubLevel;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartLinkPlacement;
import dev.silvergold.simulatedcoasters.track.cart.CoasterCartSeatedEntityCollision;
import java.util.Locale;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;

/** Station helper invoking the supplied Create seat interaction, with real proximity and hold guards. */
public final class NativeBoarding {
    private static final Logger LOGGER = LogUtils.getLogger();

    private NativeBoarding() {}

    public static String board(CommandSourceStack source) {
        if (!(source.getEntity() instanceof ServerPlayer player)) {
            throw new IllegalStateException("Boarding requires a real player at the native test station.");
        }
        var level = player.serverLevel();
        if (level != source.getLevel()) {
            throw new IllegalStateException("Player and command must be in the same world.");
        }
        if (player.getVehicle() != null) {
            throw new IllegalStateException("Disembark your current vehicle before boarding the test cart.");
        }
        var cart = CoasterTestService.cart(level);
        if (cart == null || !NativeTestRideController.heldAtStation(level)) {
            throw new IllegalStateException("Boarding refused: the committed native cart must be engaged and held at its station.");
        }
        Vec3 bearing = CoasterCartLinkPlacement.bearingCenterWorld(cart, cart.logicalPose());
        if (bearing == null || player.position().distanceToSqr(bearing) > 25.0) {
            throw new IllegalStateException("Boarding refused: stand within five world blocks of the native cart.");
        }
        BlockPos seatGlobal = cart.getPlot().getCenterBlock().offset(CoasterTestService.SEAT_LOCAL);
        var seatState = level.getBlockState(seatGlobal);
        if (!seatState.is(AllBlocks.SEATS.get(DyeColor.BROWN).get())
                || !(seatState.getBlock() instanceof SeatBlock)) {
            throw new IllegalStateException("The original brown Create seat is missing from the native cart plot.");
        }
        if (SeatBlock.isSeatOccupied(level, seatGlobal)) {
            throw new IllegalStateException("The native Create seat is occupied; try again after it is empty.");
        }

        // Existing Create creates its own SeatEntity and performs startRiding. Sable keeps
        // that seat in the native plot and handles the passenger's world-space position.
        SeatBlock.sitDown(level, seatGlobal, player);
        Entity vehicle = player.getVehicle();
        SubLevel host = CoasterCartSeatedEntityCollision.hostCartFromVehicleChain(player);
        boolean exactSeat = vehicle instanceof SeatEntity
                && "create:seat".equals(BuiltInRegistries.ENTITY_TYPE.getKey(vehicle.getType()).toString());
        if (!exactSeat || host == null || !cart.getUniqueId().equals(host.getUniqueId())) {
            player.stopRiding();
            if (vehicle instanceof SeatEntity seat && !seat.isVehicle()) seat.discard();
            throw new IllegalStateException("Create boarding did not produce the expected native seat/cart identity; it was cancelled.");
        }
        LOGGER.info("MINE_NATIVE_BOARDING player={} cart={} seatEntity={} vehicleType={} nativeHost={} gameTick={} playerWorldPosition={} bearingWorld={} seatGlobalPlotCell={}",
                player.getUUID(), cart.getUniqueId(), vehicle.getUUID(),
                BuiltInRegistries.ENTITY_TYPE.getKey(vehicle.getType()), host.getUniqueId(),
                level.getGameTime(), player.position(), bearing, seatGlobal);
        return "Boarded the real Create seat on native cart " + cart.getUniqueId()
                + ". Use mine_test start for the physical test; Shift disembarks.";
    }

    /** Real read-back for a later tick; entering a command does not mount or move the player. */
    public static String status(CommandSourceStack source) {
        if (!(source.getEntity() instanceof ServerPlayer player)) {
            throw new IllegalStateException("Ride status requires a player command context.");
        }
        Entity vehicle = player.getVehicle();
        SubLevel host = CoasterCartSeatedEntityCollision.hostCartFromVehicleChain(player);
        String type = vehicle == null ? "none" : BuiltInRegistries.ENTITY_TYPE.getKey(vehicle.getType()).toString();
        String hostId = host == null ? "none" : host.getUniqueId().toString();
        return String.format(Locale.ROOT, "vehicle=%s seatEntity=%s nativeHostCart=%s playerWorldPosition=%s gameTick=%d",
                type, vehicle == null ? "none" : vehicle.getUUID(), hostId,
                player.position(), player.serverLevel().getGameTime());
    }
}
