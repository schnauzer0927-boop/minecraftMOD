#!/usr/bin/env python3
"""Run the installed unmodified production client for a local test session."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import uuid
import zipfile

PROJECT = Path(__file__).resolve().parent.parent
BASE = PROJECT / "run-native-client-production"
VID = "neoforge-21.1.228"
JDK = Path("/workspace/.tools/thunder-mine-java21/extracted/usr/lib/jvm/java-21-openjdk-amd64")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--singleplayer", default="", help="Existing saves directory name to quick-play")
    parser.add_argument("--multiplayer", default="", help="Local test server address to quick-play")
    args = parser.parse_args()
    if args.singleplayer and args.multiplayer:
        raise SystemExit("Choose either singleplayer or multiplayer")
    if args.multiplayer and args.multiplayer not in ("127.0.0.1:25576", "localhost:25576",
                                                       "127.0.0.1:25577", "localhost:25577"):
        raise SystemExit("This development launcher connects only to the local test server")
    mc = json.loads((BASE / "versions/1.21.1/1.21.1.json").read_text())
    neo = json.loads((BASE / f"versions/{VID}/{VID}.json").read_text())
    library_root = BASE / "libraries"
    game = BASE / "game"
    natives = BASE / "natives"
    natives.mkdir(exist_ok=True)
    features = {"is_demo_user": False, "has_custom_resolution": True,
                "has_quick_plays_support": True, "is_quick_play_singleplayer": bool(args.singleplayer),
                "is_quick_play_multiplayer": bool(args.multiplayer), "is_quick_play_realms": False}

    def allowed(rules: list | None) -> bool:
        if not rules:
            return True
        result = False
        for rule in rules:
            matches = True
            for key, value in rule.get("os", {}).items():
                actual = {"name": "linux", "arch": "amd64", "version": os.uname().release}[key]
                if re.search(value, actual) is None:
                    matches = False
            if any(features.get(key, False) != value for key, value in rule.get("features", {}).items()):
                matches = False
            if matches:
                result = rule["action"] == "allow"
        return result

    def extract_native(path: Path) -> None:
        with zipfile.ZipFile(path) as archive:
            for member in archive.infolist():
                if member.is_dir() or member.filename.startswith("META-INF/"):
                    continue
                relative = Path(member.filename)
                if relative.is_absolute() or ".." in relative.parts:
                    raise RuntimeError("Unsafe native JAR entry")
                target = natives / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(archive.read(member))

    # Loader versions replace inherited artifacts by group/artifact/classifier.
    libraries = {}
    for library in mc["libraries"] + neo["libraries"]:
        if not allowed(library.get("rules")):
            continue
        pieces = library["name"].split(":")
        libraries[tuple(pieces[:2] + pieces[3:])] = library
    classpath = []
    verified = []
    for library in libraries.values():
        downloads = library.get("downloads", {})
        item = downloads.get("artifact")
        if item:
            path = library_root / item["path"]
            if not path.is_file() or hashlib.sha1(path.read_bytes()).hexdigest() != item["sha1"]:
                raise RuntimeError(f"Library SHA-1 mismatch or missing file: {path}")
            classpath.append(str(path))
            verified.append(item["path"])
            if "natives-linux" in path.name:
                extract_native(path)
        native = library.get("natives", {}).get("linux")
        if native:
            item = downloads["classifiers"][native.replace("${arch}", "64")]
            path = library_root / item["path"]
            if hashlib.sha1(path.read_bytes()).hexdigest() != item["sha1"]:
                raise RuntimeError(f"Native library SHA-1 mismatch: {path}")
            extract_native(path)
    selected_client = BASE / f"versions/{VID}/{VID}.jar"
    original_client = BASE / "versions/1.21.1/1.21.1.jar"
    if hashlib.sha1(original_client.read_bytes()).hexdigest() != mc["downloads"]["client"]["sha1"]:
        raise RuntimeError("Minecraft client JAR SHA-1 mismatch")
    if not selected_client.exists():
        selected_client.write_bytes(original_client.read_bytes())
    if hashlib.sha1(selected_client.read_bytes()).hexdigest() != mc["downloads"]["client"]["sha1"]:
        raise RuntimeError("Selected inherited Minecraft JAR changed")
    classpath.append(str(selected_client))
    asset_root = BASE / "assets"
    asset_index = mc["assetIndex"]
    if hashlib.sha1((asset_root / "indexes" / (asset_index["id"] + ".json")).read_bytes()).hexdigest() != asset_index["sha1"]:
        raise RuntimeError("Asset index SHA-1 mismatch")
    raw = bytearray(hashlib.md5(b"OfflinePlayer:Dev").digest())
    raw[6] = (raw[6] & 15) | 48
    raw[8] = (raw[8] & 63) | 128
    values = {"natives_directory": str(natives), "launcher_name": "thunder-mine-production-verification",
              "launcher_version": "1", "classpath": os.pathsep.join(classpath),
              "classpath_separator": os.pathsep, "library_directory": str(library_root),
              "version_name": VID, "auth_player_name": "Dev", "game_directory": str(game),
              "assets_root": str(asset_root), "assets_index_name": asset_index["id"],
              "auth_uuid": uuid.UUID(bytes=bytes(raw)).hex, "auth_access_token": "0", "clientid": "",
              "auth_xuid": "", "user_type": "legacy", "version_type": "release",
              "resolution_width": "1280", "resolution_height": "720",
              "quickPlayPath": str(game / "quickplay.json"), "quickPlaySingleplayer": args.singleplayer,
              "quickPlayMultiplayer": args.multiplayer}

    def expand(arg: str) -> str:
        return re.sub(r"\$\{([^}]+)\}", lambda match: values[match[1]], arg)

    def arguments(kind: str) -> list[str]:
        result = []
        for node in mc["arguments"][kind] + neo["arguments"][kind]:
            if isinstance(node, str):
                result.append(expand(node))
            elif allowed(node["rules"]):
                value = node["value"]
                result.extend(expand(arg) for arg in ([value] if isinstance(value, str) else value))
        return result

    java = str(JDK / "bin/java")
    command = [java, "-Xms1G", "-Xmx5G"] + arguments("jvm") + [neo["mainClass"]] + arguments("game")
    (BASE / "launch-command.txt").write_text(shlex.join(command) + "\n")
    mod_hashes = [{"filename": path.name, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
                  for path in sorted((game / "mods").glob("*.jar"))]
    (BASE / "launch-evidence.json").write_text(json.dumps({"minecraft": "1.21.1", "loader": "NeoForge",
                                                            "loader_version": "21.1.228", "mainClass": neo["mainClass"],
                                                            "verified_libraries": verified, "classpath_artifacts": len(classpath),
                                                            "mods": mod_hashes, "local_development_player": "Dev",
                                                            "online_authentication_tested": False,
                                                            "private_friend_gate_override": False,
                                                            "singleplayer": args.singleplayer,
                                                            "multiplayer": args.multiplayer}, indent=2) + "\n")
    # Headless CI has no speakers. Keep the normal audio engine operational with
    # its standard null backend; audible listening remains explicitly untested.
    os.environ.setdefault("ALSOFT_DRIVERS", "null")
    os.chdir(BASE)
    os.execv(java, command)


if __name__ == "__main__":
    main()
