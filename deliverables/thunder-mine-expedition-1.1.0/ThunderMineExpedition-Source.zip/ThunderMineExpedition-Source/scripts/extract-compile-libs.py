#!/usr/bin/env python3
"""Make bundled APIs visible to javac. Never modify or redistribute the uploads."""
import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
manifest = json.loads((root / "data/mod-manifest.json").read_text())
output = root / "build/compile-libs"
output.mkdir(parents=True, exist_ok=True)
results = []
for artifact in manifest["artifacts"]:
    path = root / "input-mods" / artifact["filename"]
    if hashlib.sha256(path.read_bytes()).hexdigest() != artifact["sha256"]:
        raise SystemExit(f"Upload changed: {path.name}")
    with zipfile.ZipFile(path) as jar:
        if jar.testzip() is not None:
            raise SystemExit(f"Invalid upload CRC: {path.name}")
        for name in jar.namelist():
            if name.startswith("META-INF/jarjar/") and name.endswith(".jar"):
                data = jar.read(name)
                target = output / (path.stem + "__" + Path(name).name)
                target.write_bytes(data)
                with zipfile.ZipFile(target) as nested:
                    if nested.testzip() is not None:
                        raise SystemExit(f"Invalid bundled CRC: {name}")
                results.append({"source": path.name, "entry": name,
                                "output": target.name, "sha256": hashlib.sha256(data).hexdigest()})
(output / "manifest.json").write_text(json.dumps(results, indent=2) + "\n")
print(f"Prepared {len(results)} unchanged bundled compile-only libraries")
