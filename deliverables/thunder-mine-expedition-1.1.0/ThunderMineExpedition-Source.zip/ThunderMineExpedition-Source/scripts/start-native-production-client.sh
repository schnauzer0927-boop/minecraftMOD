#!/usr/bin/env bash
set -euo pipefail
task_project_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
source /workspace/minecraftMOD/scripts/display-environment.sh
export ALSOFT_DRIVERS=null
exec python3 "$task_project_dir/scripts/launch-native-production-client.py" "$@"
