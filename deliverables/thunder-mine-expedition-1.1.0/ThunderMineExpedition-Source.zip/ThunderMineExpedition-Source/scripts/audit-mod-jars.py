#!/usr/bin/env python3
"""Read the unmodified supplied MOD JARs and emit metadata/dependency evidence.

The script does not load Java classes, alter archives, or install/execute MODs.
Python 3.11+ supplies tomllib; only the standard library is used.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import struct
import tomllib
import zipfile


def inspect_archive(data: bytes, filename: str, nested: bool = False) -> dict:
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = archive.namelist()
        metadata_names = [n for n in names if n.endswith("neoforge.mods.toml") or n.endswith("/mods.toml")]
        metadata = [tomllib.loads(archive.read(n).decode("utf-8")) for n in metadata_names]
        class_majors = sorted({struct.unpack(">H", archive.read(n)[6:8])[0]
                               for n in names if n.endswith(".class")})
        license_entries = [n for n in names if not n.endswith("/") and
                           (n.upper().startswith("LICENSE") or
                            n.startswith("META-INF/") and "LICENSE" in n.upper())]
        jars = json.loads(archive.read("META-INF/jarjar/metadata.json"))["jars"] \
            if "META-INF/jarjar/metadata.json" in names else []
        result = {
            "filename": filename,
            "size_bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
            "zip_crc_valid": archive.testzip() is None,
            "class_major_versions": class_majors,
            "java_minimum_from_class_major": max(class_majors, default=44) - 44,
            "metadata_entries": metadata_names,
            "metadata": metadata,
            "license_entries": license_entries,
            "jarjar": jars,
            "bundled_jars": [],
        }
        if not nested:
            for jar in jars:
                child = inspect_archive(archive.read(jar["path"]), jar["path"], True)
                child["jarjar_identifier"] = jar["identifier"]
                child["jarjar_version"] = jar["version"]
                result["bundled_jars"].append(child)
        gates = [n for n in names if "PrivateFriendBuildGate" in n]
        if gates:
            references = [n for n in names if not n.endswith("/") and
                          b"PrivateFriendBuildGate" in archive.read(n)]
            external_references = [n for n in references if "PrivateFriendBuildGate" not in n]
            result["unused_private_gate_evidence"] = {
                "classes": gates,
                "scope": "Unused helper class in the official public release; no external archive references or client tick invocation found.",
                "screen_title": "Simulated Coasters — private build",
                "screen_message": "Only whitelisted accounts may play with this JAR.",
                "all_reference_entries": references,
                "external_reference_entries": external_references,
                "active_gate_proven_by_static_audit": False,
                "bypassed": False,
            }
        return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("jars", type=Path, nargs="+")
    parser.add_argument("--output", type=Path, default=Path("data/mod-manifest.json"))
    args = parser.parse_args()
    result = {
        "schema": 1,
        "audit_mode": "Read-only archive metadata and bytecode header inspection",
        "required_environment": {
            "minecraft": "1.21.1",
            "loader": "NeoForge",
            "loader_minimum": "21.1.228",
            "loader_recommended_test_pin": "21.1.228",
            "java_minimum": 21,
            "old_forge_1_20_1_compatible": False,
            "additional_top_level_mod_jars_required_by_declared_dependencies": [],
            "loader_installation_libraries_download_separately": True,
        },
        "artifacts": [inspect_archive(p.read_bytes(), p.name) for p in args.jars],
        "publication_policy": {
            "supplied_mod_jars_modified": False,
            "supplied_mod_jars_to_be_bundled_with_world": False,
            "reason": "World and independent tools can be published without redistributing third-party MOD binaries; Create asset license is All Rights Reserved. All supplied files match official public Modrinth releases.",
        },
        "public_references": [
            {"url": "https://github.com/ryanhcode/sable", "verified_http": 200},
            {"url": "https://raw.githubusercontent.com/ryanhcode/sable/main/LICENSE.md", "verified_http": 200},
            {"url": "https://raw.githubusercontent.com/ryanhcode/sable/main/README.md", "verified_http": 200},
            {"url": "https://raw.githubusercontent.com/Creators-of-Create/Create/ac0c444d9828da3453ae8cc65338e8de063286fb/LICENSE.md", "verified_http": 200},
            {"url": "https://www.curseforge.com/minecraft/mc-mods/create", "source": "Create JAR displayURL"},
            {"url": "https://modrinth.com/mod/sable", "source": "Verified Sable public README"},
            {"url": "https://www.curseforge.com/minecraft/mc-mods/sable", "source": "Verified Sable public README"},
            {"url": "https://api.modrinth.com/v2/project/create-coasters-simulated", "verified_http": 200},
            {"url": "https://api.modrinth.com/v2/project/create-coasters-simulated/version", "verified_http": 200},
            {"url": "https://cdn.modrinth.com/data/W1ZUfWdr/versions/PGhQoSBq/simulatedcoasters-0.1.5.jar", "verified_http": 200, "identical_to_supplied_jar": True},
        ],
    }
    evidence = Path(__file__).resolve().parent.parent / "evidence" / "mod-audit"
    for artifact in result["artifacts"]:
        reference = evidence / (Path(artifact["filename"]).stem + ".official-version.json")
        if not reference.is_file():
            continue
        official = json.loads(reference.read_text(encoding="utf-8"))
        original = next(p for p in args.jars if p.name == artifact["filename"])
        binary = original.read_bytes()
        matching = [f for f in official.get("files", []) if f.get("filename") == artifact["filename"]]
        if len(matching) != 1:
            continue
        public_file = matching[0]
        checks = {algorithm: hashlib.new(algorithm, binary).hexdigest() == digest
                  for algorithm, digest in public_file["hashes"].items()}
        artifact["official_public_distribution"] = {
            "project_id": official["project_id"],
            "version_id": official["id"],
            "version_number": official["version_number"],
            "published_at": official["date_published"],
            "url": public_file["url"],
            "hash_checks": checks,
            "all_official_hashes_match": all(checks.values()),
            "metadata_evidence": str(reference.relative_to(evidence.parent.parent)),
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), "artifacts": len(result["artifacts"]),
                      "all_crc_valid": all(a["zip_crc_valid"] for a in result["artifacts"])}, indent=2))


if __name__ == "__main__":
    main()
