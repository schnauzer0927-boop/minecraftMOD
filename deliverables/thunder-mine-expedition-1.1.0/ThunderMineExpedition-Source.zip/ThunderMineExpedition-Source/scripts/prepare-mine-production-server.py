#!/usr/bin/env python3
"""Prepare the separate full mine-world server, reusing verified NeoForge libraries.

No server is started and no native-test world or original MOD is modified.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shlex
import shutil


JAVA21 = Path("/workspace/.tools/thunder-mine-java21/extracted/usr/lib/jvm/java-21-openjdk-amd64")
VERSION = "21.1.228"
MODS = {
    "sable-neoforge-1.21.1-2.0.6.jar": "9c199157843bf953a47dff625fc5bb41c01a90538d35ad18e6996bbcb8a617c2",
    "simulatedcoasters-0.1.5.jar": "f80b4c3cdf9fa6188804967147761b0373e150a6eadbdc53626e5ac9700b2049",
    "create-1.21.1-6.0.10.jar": "ef87fe5709f1ba1f5b8bb20a2925b5afb4669e178fd6d8bf10c167759eefe37a",
}


def digest(path: Path) -> str:
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=Path("run-native-test-production"))
    parser.add_argument("--server", type=Path, default=Path("run-mine-production"))
    parser.add_argument("--attachments", type=Path, default=Path("/workspace/attachments"))
    args = parser.parse_args()
    source = args.source.resolve()
    server = args.server.resolve()
    if source == server or server.exists() and any(server.iterdir()):
        raise SystemExit("Refusing to overwrite source, existing server, or world.")
    libraries = source / "libraries"
    unix_args = libraries / "net/neoforged/neoforge" / VERSION / "unix_args.txt"
    if not libraries.is_dir() or not unix_args.is_file() or not (source / "run.sh").is_file():
        raise SystemExit("Expected the successfully installed official NeoForge 21.1.228 native-test server.")
    project = Path(__file__).resolve().parent.parent
    installation_record = project / "toolchain/neoforge-production/server-install-provenance.json"
    installed = json.loads(installation_record.read_text())
    if installed["loader_version"] != VERSION or installed["installer_exit_code"] != 0 or not installed["checksum_matches"]:
        raise SystemExit("Official NeoForge installer provenance is incomplete or mismatched.")
    if not (JAVA21 / "bin/java").is_file() or not (JAVA21 / "bin/javac").is_file():
        raise SystemExit("The separately verified Java21 JDK is required.")

    # Reference immutable installed dependency files; copy no source-world data.
    library_manifest = [
        {"path": str(p.relative_to(libraries)), "size_bytes": p.stat().st_size, "sha256": digest(p)}
        for p in sorted(libraries.rglob("*")) if p.is_file()
    ]
    server.mkdir(parents=True, exist_ok=True)
    (server / "libraries").symlink_to(libraries, target_is_directory=True)
    launcher_copies = []
    for name in ("run.sh", "run.bat"):
        original = source / name
        if original.is_file():
            target = server / name
            shutil.copy2(original, target)
            if digest(original) != digest(target):
                raise RuntimeError("Official launcher copy mismatch")
            launcher_copies.append({"filename": name, "sha256": digest(target)})

    mods_dir = server / "mods"
    mods_dir.mkdir()
    mod_manifest = []
    for filename, sha in MODS.items():
        candidates = list(args.attachments.rglob(filename))
        if len(candidates) != 1 or digest(candidates[0]) != sha:
            raise RuntimeError("Original uploaded MOD missing or altered: " + filename)
        target = mods_dir / filename
        shutil.copy2(candidates[0], target)
        if digest(target) != sha:
            raise RuntimeError("Original MOD copy mismatch: " + filename)
        mod_manifest.append({"filename": filename, "size_bytes": target.stat().st_size,
                             "sha256": sha, "copy_verified": True, "jar_modified": False})

    (server / "server.properties").write_text("""# Dedicated original Thunder Mine Expedition build/test server
server-ip=127.0.0.1
server-port=25577
online-mode=false
enable-rcon=false
enable-query=false
level-name=Coaster World - Thunder Mine Expedition
level-seed=20261012
level-type=minecraft:flat
generator-settings={"biome":"minecraft:plains","layers":[{"block":"minecraft:bedrock","height":1},{"block":"minecraft:stone","height":60},{"block":"minecraft:dirt","height":3},{"block":"minecraft:grass_block","height":1}],"structure_overrides":[]}
generate-structures=false
gamemode=adventure
force-gamemode=false
difficulty=peaceful
spawn-protection=0
view-distance=6
simulation-distance=4
max-tick-time=60000
max-players=1
allow-flight=true
enable-command-block=true
motd=Thunder Mine Expedition - localhost development only
""", encoding="utf-8")
    (server / "user_jvm_args.txt").write_text("-Xms1G\n-Xmx6G\n")
    (server / "eula.txt").write_text("# Minecraft EULA accepted for the authorized local development workflow.\neula=true\n")
    wrapper = server / "start-local.sh"
    wrapper.write_text(
        "#!/usr/bin/env bash\nset -euo pipefail\n"
        + "export JAVA_HOME=" + shlex.quote(str(JAVA21)) + "\n"
        + "export PATH=\"$JAVA_HOME/bin:$PATH\"\n"
        + "cd -- \"$(dirname -- \"${BASH_SOURCE[0]}\")\"\n"
        + "exec ./run.sh nogui \"$@\"\n"
    )
    wrapper.chmod(0o755)
    provenance = {
        "minecraft": "1.21.1", "loader": "NeoForge", "loader_version": VERSION,
        "java_home": str(JAVA21), "server_directory": str(server),
        "world_name": "Coaster World - Thunder Mine Expedition", "world_seed": 20261012,
        "flat_ground_y": 0, "flat_ground_explanation": "65 flat layers begin at Minecraft dimension minY=-64; top grass is -64+65-1=0.",
        "purpose": "Prove the native full course in clear air before procedural mine scenery.",
        "libraries_link": {"kind": "directory symbolic link", "target": str(libraries),
                           "source_installation_record": str(installation_record),
                           "source_installer_sha256": installed["installer_sha256"],
                           "source_original_world_data_copied": False,
                           "manifest_file": "mine-production-library-manifest.json",
                           "files_count": len(library_manifest)},
        "official_launcher_copies": launcher_copies, "original_mods": mod_manifest,
        "helper_mod_copied": False, "server_started_by_preparation": False,
        "bind_address": "127.0.0.1", "port": 25577,
        "client_private_gate_changed": False, "previous_native_test_world_modified": False,
    }
    out = project / "toolchain/neoforge-production"
    (out / "mine-production-library-manifest.json").write_text(json.dumps(library_manifest, indent=2) + "\n")
    (out / "mine-production-environment.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(json.dumps(provenance, indent=2))


if __name__ == "__main__":
    main()
