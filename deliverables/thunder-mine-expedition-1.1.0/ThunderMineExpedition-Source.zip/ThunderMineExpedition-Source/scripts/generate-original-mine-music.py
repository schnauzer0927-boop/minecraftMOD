#!/usr/bin/env python3
"""Render three original mine-adventure scores; no external samples or songs.

SPDX-License-Identifier: MIT
Requires Python 3, NumPy, ffmpeg (libvorbis), and ffprobe.
The notes below are an original score written for Thunder Mine Expedition.
Every note and reverberation tail wraps into the same loop buffer, rather than
being cut off at the end. All pseudorandom percussion is reproducibly seeded.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import tempfile
import wave

import numpy as np

SAMPLE_RATE = 44_100
MOD_ID = "thunder_mine_tools"
ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "helper/src/main/resources/assets" / MOD_ID / "sounds/music"
EVIDENCE = ROOT / "evidence/music-original-synthesis.json"
TAU = 2.0 * math.pi

# Pitch numbers are MIDI pitches, solely used as a frequency notation. No MIDI
# files, soundfonts, sampled recordings, or third-party compositions are used.
SCORES = {
    "exploration": {
        "title": "Lanterns at Red Mesa", "bpm": 108, "bars": 16, "seed": 17021,
        "chords": [
            [50, 53, 57], [46, 50, 53], [48, 53, 57], [48, 52, 55],
            [50, 53, 57], [43, 46, 50], [46, 50, 53], [45, 49, 52],
            [50, 53, 57], [46, 50, 53], [48, 53, 57], [48, 52, 55],
            [43, 46, 50], [46, 50, 53], [45, 49, 52], [50, 53, 57],
        ],
        # Each tuple: beat within bar, pitch, duration in beats. The original
        # sixteen-bar melody has two related phrases and a returning cadence.
        "melody": [
            [(0, 74, .7), (1, 77, .5), (1.75, 81, .8), (3, 77, .45), (3.5, 74, .4)],
            [(0, 77, 1.1), (1.5, 74, .5), (2.25, 70, .6), (3, 72, .6)],
            [(0, 72, .6), (.75, 77, .6), (1.5, 81, 1), (3, 79, .7)],
            [(0, 76, .7), (1, 72, .7), (2, 67, .7), (3, 69, .5), (3.5, 72, .4)],
            [(0, 74, 1.1), (1.5, 77, .5), (2.25, 81, .7), (3.25, 84, .5)],
            [(0, 82, .8), (1, 79, .8), (2, 77, .5), (2.75, 74, .8)],
            [(0, 77, .8), (1, 74, .5), (1.75, 72, .8), (3, 70, .7)],
            [(0, 73, .8), (1, 76, .6), (2, 81, 1.4)],
            [(0, 86, .7), (1, 81, .5), (1.75, 77, .8), (3, 74, .7)],
            [(0, 77, .8), (1, 82, .6), (2, 81, .5), (2.75, 77, .8)],
            [(0, 81, .7), (1, 84, .5), (1.75, 81, .7), (3, 77, .6)],
            [(0, 79, .8), (1, 76, .5), (1.75, 72, .7), (3, 67, .5), (3.5, 69, .4)],
            [(0, 70, .7), (1, 74, .6), (2, 79, .9), (3.25, 77, .5)],
            [(0, 77, .8), (1, 74, .6), (2, 70, .6), (3, 72, .6)],
            [(0, 73, .6), (.75, 76, .6), (1.5, 81, .7), (2.5, 76, .6), (3.5, 73, .4)],
            [(0, 74, 1.4), (2, 69, .5), (2.75, 72, .6), (3.5, 74, .4)],
        ],
    },
    "mine_suspense": {
        "title": "Picks Behind the Wall", "bpm": 96, "bars": 12, "seed": 17022,
        "chords": [
            [38, 45, 53], [38, 46, 53], [43, 50, 58], [45, 52, 61],
            [38, 45, 53], [46, 53, 62], [43, 50, 58], [45, 52, 61],
            [38, 45, 53], [41, 48, 57], [46, 53, 62], [45, 52, 61],
        ],
        "melody": [
            [(0, 81, 1.7), (2.5, 77, 1)], [(1, 82, 1.2), (3, 81, .7)],
            [(0, 79, 1.5), (2, 74, 1.4)], [(0, 73, .8), (1.5, 76, 1.4), (3.5, 73, .35)],
            [(0, 77, 1.6), (2.75, 81, .9)], [(1, 82, 1.4), (3, 86, .8)],
            [(0, 86, 1.4), (2, 82, .7), (3, 79, .7)], [(0, 81, 1), (1.5, 76, 1.1), (3, 73, .7)],
            [(0, 74, 2.5)], [(0, 77, 1.2), (2, 81, 1.4)],
            [(0, 82, 1), (1.5, 77, 1.4), (3.25, 74, .6)], [(0, 73, 1.4), (2, 76, .8), (3.25, 81, .6)],
        ],
    },
    "canyon_chase": {
        "title": "Run Across Iron Canyon", "bpm": 132, "bars": 16, "seed": 17023,
        "chords": [
            [50, 53, 57], [46, 50, 53], [53, 57, 60], [48, 52, 55],
            [50, 53, 57], [43, 46, 50], [46, 50, 53], [45, 49, 52],
            [50, 53, 57], [53, 57, 60], [46, 50, 53], [48, 52, 55],
            [43, 46, 50], [46, 50, 53], [45, 49, 52], [50, 53, 57],
        ],
        "melody": [
            [(0, 74, .4), (.5, 77, .4), (1, 81, .4), (1.5, 86, .4), (2, 81, .4), (2.5, 77, .4), (3, 74, .7)],
            [(0, 77, .4), (.5, 74, .4), (1, 70, .4), (1.5, 74, .4), (2, 77, .7), (3, 82, .7)],
            [(0, 81, .4), (.5, 84, .4), (1, 89, .7), (2, 84, .4), (2.5, 81, .4), (3, 77, .7)],
            [(0, 79, .4), (.5, 76, .4), (1, 72, .7), (2, 76, .4), (2.5, 79, .4), (3, 84, .7)],
            [(0, 86, .7), (1, 81, .4), (1.5, 77, .4), (2, 74, .4), (2.5, 77, .4), (3, 81, .7)],
            [(0, 82, .4), (.5, 79, .4), (1, 74, .4), (1.5, 79, .4), (2, 82, .7), (3, 86, .7)],
            [(0, 82, .4), (.5, 77, .4), (1, 74, .7), (2, 70, .4), (2.5, 74, .4), (3, 77, .7)],
            [(0, 81, .7), (1, 76, .4), (1.5, 73, .4), (2, 69, .4), (2.5, 73, .4), (3, 76, .7)],
            [(0, 74, .4), (.5, 77, .4), (1, 81, .4), (1.5, 86, .4), (2, 89, .4), (2.5, 86, .4), (3, 81, .7)],
            [(0, 89, .7), (1, 84, .4), (1.5, 81, .4), (2, 77, .4), (2.5, 81, .4), (3, 84, .7)],
            [(0, 86, .4), (.5, 82, .4), (1, 77, .7), (2, 74, .4), (2.5, 77, .4), (3, 82, .7)],
            [(0, 84, .4), (.5, 79, .4), (1, 76, .4), (1.5, 72, .4), (2, 67, .7), (3, 72, .7)],
            [(0, 74, .4), (.5, 79, .4), (1, 82, .7), (2, 86, .4), (2.5, 82, .4), (3, 79, .7)],
            [(0, 77, .4), (.5, 74, .4), (1, 70, .7), (2, 74, .4), (2.5, 77, .4), (3, 82, .7)],
            [(0, 81, .4), (.5, 80, .4), (1, 76, .4), (1.5, 73, .4), (2, 69, .4), (2.5, 73, .4), (3, 76, .7)],
            [(0, 74, .7), (1, 81, .4), (1.5, 77, .4), (2, 74, .4), (2.5, 72, .4), (3, 69, .4), (3.5, 72, .4)],
        ],
    },
}


def frequency(note: int) -> float:
    return 440.0 * 2.0 ** ((note - 69) / 12.0)


def timebase(seconds: float) -> np.ndarray:
    return np.arange(max(1, round(seconds * SAMPLE_RATE)), dtype=np.float64) / SAMPLE_RATE


def attack(t: np.ndarray, seconds: float = .004) -> np.ndarray:
    return np.minimum(1.0, t / seconds) ** 2


def release_tail(t: np.ndarray, duration: float) -> np.ndarray:
    return np.minimum(1.0, np.maximum(0.0, (t[-1] - t) / min(.018, duration / 5)))


def pluck(note: int, seconds: float, kind: str, rng: np.random.Generator) -> np.ndarray:
    t = timebase(seconds + .8)
    f = frequency(note)
    y = np.zeros(len(t))
    for h in range(1, 13):
        # Banjo has a sharper metallic upper spectrum; guitar is rounder. Each
        # upper partial decays faster than the fundamental (plucked-string feel).
        brightness = .90 if kind == "banjo" else 1.7
        detune = 1 + (.00007 if kind == "banjo" else .000025) * h * h
        partial = np.sin(TAU * f * h * detune * t + .07 * (h % 3))
        decay = (.48 if kind == "banjo" else .95) / (1 + .19 * h)
        y += partial * np.exp(-t / decay) / h ** brightness
    noise = rng.normal(0, 1, len(t))
    y += .06 * noise * np.exp(-t / .011)
    y *= attack(t, .003) * release_tail(t, seconds)
    return .55 * y


def bass(note: int, seconds: float) -> np.ndarray:
    t = timebase(seconds + .20)
    f = frequency(note)
    y = np.sin(TAU * f * t) + .22 * np.sin(TAU * 2 * f * t) + .06 * np.sin(TAU * 3 * f * t)
    return y * attack(t, .009) * np.exp(-t / max(.25, seconds * .7)) * release_tail(t, seconds)


def fiddle(note: int, seconds: float) -> np.ndarray:
    t = timebase(seconds + .085)
    f = frequency(note)
    phase = TAU * f * t + .23 * np.sin(TAU * 5.5 * t) * (1 - np.exp(-t / .12))
    y = sum(np.sin(h * phase) / h ** 1.45 for h in range(1, 9))
    env = attack(t, .025) * np.minimum(1.0, np.maximum(0, (seconds + .07 - t) / .07))
    return .55 * y * env


def bell(note: int, seconds: float) -> np.ndarray:
    t = timebase(seconds + 1.6)
    f = frequency(note)
    y = np.zeros(len(t))
    for ratio, gain, decay in [(1, .6, 1.6), (2.01, .3, .8), (2.76, .12, .5), (4.02, .05, .28)]:
        y += gain * np.sin(TAU * f * ratio * t) * np.exp(-t / decay)
    return y * attack(t, .006) * release_tail(t, seconds)


def pad(notes: list[int], seconds: float) -> np.ndarray:
    t = timebase(seconds + .65)
    y = np.zeros(len(t))
    for note in notes:
        f = frequency(note)
        for cents in [-4, 4]:
            y += np.sin(TAU * f * 2 ** (cents / 1200) * t) + .15 * np.sin(TAU * 2 * f * t)
    env = np.minimum(1.0, t / .28) * np.minimum(1.0, np.maximum(0, (seconds + .65 - t) / .65))
    return y / (2 * len(notes)) * env


def percussion(kind: str, rng: np.random.Generator) -> np.ndarray:
    duration = {"kick": .23, "snare": .16, "hat": .08, "wood": .10, "shaker": .10, "metal": .36}[kind]
    t = timebase(duration)
    noise = rng.normal(0, 1, len(t))
    high_noise = noise - np.roll(noise, 1)
    if kind == "kick":
        phase = TAU * (48 * t + 60 * .02 * (1 - np.exp(-t / .02)))
        y = np.sin(phase) * np.exp(-t / .060) + .12 * noise * np.exp(-t / .004)
    elif kind == "snare":
        y = (.48 * high_noise + .22 * np.sin(TAU * 175 * t)) * np.exp(-t / .026)
    elif kind in {"hat", "shaker"}:
        y = .25 * high_noise * np.exp(-t / (.011 if kind == "hat" else .025))
    elif kind == "wood":
        y = (np.sin(TAU * 850 * t) + .35 * np.sin(TAU * 1421 * t)) * np.exp(-t / .017)
    else:
        y = sum(np.sin(TAU * f * t) / (i + 2) for i, f in enumerate([720, 1177, 1649, 2381])) * np.exp(-t / .09)
    return y * attack(t, .0008) * release_tail(t, duration)


class Loop:
    def __init__(self, score: dict):
        self.score = score
        self.beat = 60 / score["bpm"]
        self.samples = round(score["bars"] * 4 * self.beat * SAMPLE_RATE)
        self.audio = np.zeros((self.samples, 2), dtype=np.float64)
        self.rng = np.random.default_rng(score["seed"])
        self.notes = 0
        self.drums = 0

    def add(self, beat: float, signal: np.ndarray, gain: float, pan: float = 0) -> None:
        start = round(beat * self.beat * SAMPLE_RATE) % self.samples
        p = (pan + 1) * math.pi / 4
        stereo = signal[:, None] * np.array([math.cos(p), math.sin(p)])[None, :] * gain
        # A note at the end of the score is not truncated: its tail is added to
        # the beginning, exactly as if this period had played forever.
        offset = 0
        while offset < len(stereo):
            count = min(len(stereo) - offset, self.samples - start)
            self.audio[start:start + count] += stereo[offset:offset + count]
            offset += count
            start = 0

    def note(self, beat: float, pitch: int, length: float, instrument: str, gain: float, pan: float = 0) -> None:
        seconds = length * self.beat
        if instrument in {"banjo", "guitar"}:
            signal = pluck(pitch, seconds, instrument, self.rng)
        else:
            signal = {"bass": bass, "bell": bell, "fiddle": fiddle}[instrument](pitch, seconds)
        self.add(beat, signal, gain, pan)
        self.notes += 1

    def drum(self, beat: float, kind: str, gain: float, pan: float = 0) -> None:
        self.add(beat, percussion(kind, self.rng), gain, pan)
        self.drums += 1

    def render(self, name: str) -> np.ndarray:
        for bar, chord in enumerate(self.score["chords"]):
            b = bar * 4
            if name == "exploration":
                # Alternating acoustic bass and off-beat strummed/plucked chords.
                for beat in [0, 2]:
                    self.note(b + beat, chord[0] - 12, .75, "bass", .22)
                for beat in [1, 3]:
                    for i, pitch in enumerate(chord):
                        self.note(b + beat + .026 * i, pitch + 12, .8, "guitar", .075, -.25)
                for beat in [0, 1, 2, 3]:
                    self.drum(b + beat + .5, "shaker", .12, .3)
                self.drum(b, "kick", .18)
                self.drum(b + 2, "wood", .12, -.2)
                if bar % 4 == 3:
                    self.drum(b + 3.5, "wood", .07, .2)
                self.add(b, pad([pitch + 12 for pitch in chord], 4 * self.beat), .045, .25)
                melody_instrument, melody_gain = "banjo", .22
            elif name == "mine_suspense":
                self.add(b, pad(chord, 4 * self.beat), .17, -.12)
                for beat, offset in [(0, 0), (.75, 7), (1.5, 12), (2.5, 7), (3.25, 12)]:
                    self.note(b + beat, chord[0] + offset, .6, "guitar", .11, -.35)
                self.note(b, chord[0] - 12, 2.2, "bass", .17)
                self.drum(b + 1, "wood", .14, -.5)
                self.drum(b + 2.5, "metal", .065, .55)
                self.drum(b + 3.25, "wood", .09, -.25)
                if bar % 3 == 2:
                    self.drum(b + 3.5, "metal", .08, .25)
                melody_instrument, melody_gain = "bell", .20
            else:
                for beat in [0, 1, 2, 3]:
                    self.note(b + beat, chord[0] - 12 + (7 if beat % 2 else 0), .5, "bass", .23)
                    self.drum(b + beat, "kick", .24 if beat % 2 == 0 else .12)
                    self.drum(b + beat + .5, "hat", .13, .4)
                for beat in [1, 3]:
                    self.drum(b + beat, "snare", .23, -.12)
                for beat in [.5, 1.5, 2.5, 3.5]:
                    for i, pitch in enumerate(chord):
                        self.note(b + beat + i * .015, pitch + 12, .38, "guitar", .075, -.5)
                # A banjo-like response fills the second half of alternate bars.
                if bar % 2:
                    for i, pitch in enumerate([chord[1] + 12, chord[2] + 12, chord[0] + 24]):
                        self.note(b + 2.25 + i * .5, pitch, .3, "banjo", .075, .5)
                if bar % 4 == 3:
                    self.drum(b + 3.25, "snare", .10, -.2)
                    self.drum(b + 3.75, "snare", .10, .2)
                self.add(b, pad([pitch + 12 for pitch in chord], 4 * self.beat), .025, .2)
                melody_instrument, melody_gain = "fiddle", .18
            for beat, pitch, length in self.score["melody"][bar]:
                self.note(b + beat, pitch, length, melody_instrument, melody_gain, .1)

        # Circular stereo early reflections: the room keeps ringing across the
        # loop boundary. A separate low-gain cross-channel tail widens the scene.
        dry = self.audio.copy()
        room = np.zeros_like(dry)
        for milliseconds, gain, cross in [(43, .15, False), (71, .10, True), (113, .075, False), (173, .055, True), (263, .035, True), (397, .022, False)]:
            shifted = np.roll(dry, round(milliseconds * SAMPLE_RATE / 1000), axis=0)
            room += gain * (shifted[:, ::-1] if cross else shifted)
        audio = dry + room
        audio -= audio.mean(axis=0)
        # A mild, static soft knee controls transient peaks without pumping or
        # changing the beat timeline. It is intentionally not a loudness maximizer.
        scale = .28 / max(float(np.sqrt(np.mean(audio ** 2))), 1e-8)
        audio = np.tanh(audio * scale * .95)
        # The chase score's dense treble has slightly higher Vorbis reconstruction
        # overshoot, so it gets a little more pre-encode headroom.
        audio *= (.83 if name == "canyon_chase" else .87) / np.max(np.abs(audio))
        return audio


def stats(audio: np.ndarray) -> dict:
    peak = float(np.max(np.abs(audio)))
    rms = float(np.sqrt(np.mean(audio ** 2)))
    seam = np.abs(audio[0] - audio[-1])
    steps = np.abs(np.diff(audio, axis=0))
    return {
        "sample_frames": len(audio), "duration_seconds": len(audio) / SAMPLE_RATE,
        "peak_linear": peak, "peak_dbfs": 20 * math.log10(max(peak, 1e-12)),
        "rms_linear": rms, "rms_dbfs": 20 * math.log10(max(rms, 1e-12)),
        "dc_offset_per_channel": [float(x) for x in audio.mean(axis=0)],
        "loop_boundary_delta_per_channel": [float(x) for x in seam],
        "adjacent_sample_delta_99_9_percentile": float(np.quantile(steps, .999)),
        "nonfinite_samples": int(np.count_nonzero(~np.isfinite(audio))),
        "clipped_samples": int(np.count_nonzero(np.abs(audio) >= 1)),
    }


def ogg_last_granule(path: Path) -> int:
    raw = path.read_bytes()
    cursor, granule = 0, 0
    while cursor < len(raw):
        if raw[cursor:cursor + 4] != b"OggS":
            raise ValueError("Invalid Ogg page boundary")
        value = int.from_bytes(raw[cursor + 6:cursor + 14], "little")
        if value != 2**64 - 1:
            granule = value
        segments = raw[cursor + 26]
        cursor += 27 + segments + sum(raw[cursor + 27:cursor + 27 + segments])
    return granule


def encode(name: str, audio: np.ndarray, temp: Path) -> tuple[Path, dict]:
    path = OUT / f"{name}.ogg"
    wav = temp / f"{name}.wav"
    with wave.open(str(wav), "wb") as stream:
        stream.setnchannels(2)
        stream.setsampwidth(2)
        stream.setframerate(SAMPLE_RATE)
        stream.writeframes((np.clip(audio, -1, 1) * 32767).astype("<i2").tobytes())
    subprocess.run([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(wav),
        "-map_metadata", "-1", "-c:a", "libvorbis", "-q:a", "5",
        "-fflags", "+bitexact", "-flags:a", "+bitexact",
        "-metadata", f"title={SCORES[name]['title']}",
        "-metadata", "artist=Thunder Mine Expedition original synthesis",
        "-metadata", "copyright=Original score and synthesized audio; MIT license",
        "-metadata", f"LOOPSTART=0", "-metadata", f"LOOPEND={len(audio)}",
        str(path),
    ], check=True)
    probe = json.loads(subprocess.check_output([
        "ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(path),
    ]))
    decoded = subprocess.check_output([
        "ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(path),
        "-f", "f32le", "-acodec", "pcm_f32le", "-",
    ])
    samples = np.frombuffer(decoded, dtype="<f4").reshape(-1, 2).astype(np.float64)
    metrics = stats(samples)
    assert metrics["nonfinite_samples"] == 0 and metrics["clipped_samples"] == 0
    assert metrics["peak_linear"] < .98, "Decoded peak must retain headroom"
    assert metrics["rms_dbfs"] > -22, "Score must not be nearly silent"
    assert max(metrics["loop_boundary_delta_per_channel"]) < .06, "Excessive loop discontinuity"
    assert ogg_last_granule(path) == len(audio), "Ogg timeline length changed"
    assert len(samples) == len(audio), "Decoded frame count changed"
    assert probe["streams"][0]["codec_name"] == "vorbis"
    assert int(probe["streams"][0]["sample_rate"]) == SAMPLE_RATE
    assert probe["streams"][0]["channels"] == 2
    return path, {
        "decoded": metrics, "ogg_granule_sample_frames": ogg_last_granule(path),
        "codec": "vorbis", "sample_rate": SAMPLE_RATE, "channels": 2,
        "vorbis_quality": 5, "file_bytes": path.stat().st_size,
        "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        "probe_duration_seconds": float(probe["format"]["duration"]),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--track", choices=list(SCORES), help="Regenerate just one score")
    args = parser.parse_args()
    for executable in ["ffmpeg", "ffprobe"]:
        if not shutil.which(executable):
            parser.error(f"{executable} is required")
    OUT.mkdir(parents=True, exist_ok=True)
    EVIDENCE.parent.mkdir(parents=True, exist_ok=True)
    evidence = {
        "generator": "scripts/generate-original-mine-music.py", "license": "MIT",
        "provenance": "Original note scores and algorithmically synthesized instruments; no imported audio, sample libraries, soundfonts, or third-party songs.",
        "loop_method": "Note tails and stereo early reflections are circularly accumulated into the exact musical period.",
        "human_listening": "NOT VERIFIED: this environment has no human audio audition.",
        "tools": {"numpy": np.__version__, "ffmpeg": subprocess.check_output(["ffmpeg", "-version"], text=True).splitlines()[0]},
        "tracks": {},
    }
    if args.track and EVIDENCE.exists():
        evidence["tracks"] = json.loads(EVIDENCE.read_text())["tracks"]
    with tempfile.TemporaryDirectory(prefix="mine-original-music-") as temporary:
        for name in [args.track] if args.track else SCORES:
            score = SCORES[name]
            assert len(score["chords"]) == score["bars"] == len(score["melody"])
            loop = Loop(score)
            audio = loop.render(name)
            path, encoded = encode(name, audio, Path(temporary))
            evidence["tracks"][name] = {
                "title": score["title"], "bpm": score["bpm"], "meter": "4/4", "bars": score["bars"],
                "seed": score["seed"], "pitched_note_events": loop.notes, "percussion_events": loop.drums,
                "source_pcm": stats(audio), "resource": f"{MOD_ID}:music/{name}",
                "output": str(path.relative_to(ROOT)), **encoded,
            }
            print(f"{name}: {len(audio) / SAMPLE_RATE:.6f}s, {encoded['file_bytes']} bytes, "
                  f"decoded peak {encoded['decoded']['peak_dbfs']:.2f} dBFS, RMS {encoded['decoded']['rms_dbfs']:.2f} dBFS")
    sounds = {
        "ride_exploration": {"sounds": [{"name": f"{MOD_ID}:music/exploration", "stream": True}]},
        "ride_suspense": {"sounds": [{"name": f"{MOD_ID}:music/mine_suspense", "stream": True}]},
        "ride_chase": {"sounds": [{"name": f"{MOD_ID}:music/canyon_chase", "stream": True}]},
    }
    (OUT.parent.parent / "sounds.json").write_text(json.dumps(sounds, indent=2) + "\n")
    evidence["generator_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    EVIDENCE.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
