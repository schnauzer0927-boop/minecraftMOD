#!/usr/bin/env python3
"""Install a separate official client and verify downloaded Mojang artifacts."""
from __future__ import annotations

import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import urllib.parse
import urllib.request
import zipfile


PROJECT = Path(__file__).resolve().parent.parent
BASE = PROJECT / "run-native-client-production"
JDK = Path("/workspace/.tools/thunder-mine-java21/extracted/usr/lib/jvm/java-21-openjdk-amd64")
NEO_VERSION = "21.1.228"
VID = "neoforge-" + NEO_VERSION
OLD_ASSETS = Path("/workspace/.gradle/caches/forge_gradle/assets")
SERVER_LIB = PROJECT / "run-native-test-production/libraries"
EXPECTED = {
    "sable-neoforge-1.21.1-2.0.6.jar": "9c199157843bf953a47dff625fc5bb41c01a90538d35ad18e6996bbcb8a617c2",
    "simulatedcoasters-0.1.5.jar": "f80b4c3cdf9fa6188804967147761b0373e150a6eadbdc53626e5ac9700b2049",
    "create-1.21.1-6.0.10.jar": "ef87fe5709f1ba1f5b8bb20a2925b5afb4669e178fd6d8bf10c167759eefe37a",
}


def fetch(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "ThunderMineExpedition-Setup/1.0"})
    with urllib.request.urlopen(request, timeout=120) as response:
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {url}")
        return response.read()


def artifact(target: Path, details: dict, candidates: tuple[Path, ...] = ()) -> str:
    digest = details["sha1"]
    for candidate in (target, *candidates):
        if candidate.is_file() and hashlib.sha1(candidate.read_bytes()).hexdigest() == digest:
            if candidate != target:
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(candidate, target)
            return "cached"
    data = fetch(details["url"])
    if hashlib.sha1(data).hexdigest() != digest or len(data) != details["size"]:
        raise RuntimeError(f"Authoritative SHA-1 or size mismatch: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".download")
    temporary.write_bytes(data)
    temporary.replace(target)
    return "downloaded"


def allowed(rules: list | None) -> bool:
    if not rules:
        return True
    result = False
    for rule in rules:
        matches = True
        for key, value in rule.get("os", {}).items():
            actual = {"name": "linux", "arch": "amd64", "version": os.uname().release}[key]
            if re.search(value, actual) is None:
                matches = False
        if rule.get("features"):
            matches = False
        if matches:
            result = rule["action"] == "allow"
    return result


def main() -> None:
    BASE.mkdir(parents=True, exist_ok=True)
    (BASE / "versions/1.21.1").mkdir(parents=True, exist_ok=True)
    (BASE / "libraries").mkdir(exist_ok=True)
    game = BASE / "game"
    (game / "mods").mkdir(parents=True, exist_ok=True)
    manifest = json.loads(fetch("https://piston-meta.mojang.com/mc/game/version_manifest_v2.json"))
    entry = next(v for v in manifest["versions"] if v["id"] == "1.21.1")
    metadata = fetch(entry["url"])
    if hashlib.sha1(metadata).hexdigest() != entry["sha1"]:
        raise RuntimeError("Official Minecraft version JSON SHA-1 mismatch")
    mc = json.loads(metadata)
    (BASE / "versions/1.21.1/1.21.1.json").write_bytes(metadata)
    artifact(BASE / "versions/1.21.1/1.21.1.jar", mc["downloads"]["client"])
    libraries = BASE / "libraries"
    tasks = []
    for library in mc["libraries"]:
        if not allowed(library.get("rules")):
            continue
        downloads = library.get("downloads", {})
        if "artifact" in downloads:
            item = downloads["artifact"]
            tasks.append((libraries / item["path"], item, (SERVER_LIB / item["path"],)))
        native = library.get("natives", {}).get("linux")
        if native:
            item = downloads["classifiers"][native.replace("${arch}", "64")]
            tasks.append((libraries / item["path"], item, (SERVER_LIB / item["path"],)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        results = list(pool.map(lambda task: artifact(*task), tasks))
    print(f"Verified {len(tasks)} Mojang libraries ({results.count('downloaded')} downloaded)", flush=True)

    # An installer expects the normal launcher profile file even for a dedicated
    # offline development directory. No account, token, or identity is provided.
    profile = BASE / "launcher_profiles.json"
    if not profile.exists():
        profile.write_text(json.dumps({"profiles": {}, "settings": {}}, indent=2))
    installer = PROJECT / "toolchain/neoforge-production" / f"neoforge-{NEO_VERSION}-installer.jar"
    expected_installer = installer.with_suffix(installer.suffix + ".sha256").read_text().strip()
    if hashlib.sha256(installer.read_bytes()).hexdigest() != expected_installer:
        raise RuntimeError("Official NeoForge installer SHA-256 mismatch")
    flags = []
    for scheme in ("http", "https"):
        proxy = os.environ.get(scheme.upper() + "_PROXY") or os.environ.get(scheme + "_proxy")
        if proxy:
            parsed = urllib.parse.urlparse(proxy)
            if parsed.username or parsed.password or not parsed.hostname:
                raise RuntimeError("Unsupported authenticated or malformed mandatory proxy")
            flags += [f"-D{scheme}.proxyHost={parsed.hostname}", f"-D{scheme}.proxyPort={parsed.port or 80}"]
    log = PROJECT / "evidence/neoforge-production-client-install.log"
    installed_json = BASE / f"versions/{VID}/{VID}.json"
    if not installed_json.is_file():
        with log.open("w") as output:
            process = subprocess.run([str(JDK / "bin/java"), *flags, "-jar", str(installer),
                                      "--installClient", str(BASE)], cwd=BASE, stdout=output,
                                     stderr=subprocess.STDOUT, check=False)
        if process.returncode != 0 or not installed_json.is_file():
            raise RuntimeError(f"Official client installer failed ({process.returncode}); see {log}")
    neo = json.loads(installed_json.read_text())
    for library in neo["libraries"]:
        if allowed(library.get("rules")) and "artifact" in library.get("downloads", {}):
            item = library["downloads"]["artifact"]
            artifact(libraries / item["path"], item, (SERVER_LIB / item["path"],))
    print("Official NeoForge production client installed", flush=True)

    assets = BASE / "assets"
    index = mc["assetIndex"]
    index_path = assets / "indexes" / (index["id"] + ".json")
    artifact(index_path, index, (OLD_ASSETS / "indexes" / index_path.name,))
    asset_index = json.loads(index_path.read_text())
    jobs = []
    for details in asset_index["objects"].values():
        digest = details["hash"]
        relative = Path("objects") / digest[:2] / digest
        jobs.append((assets / relative,
                     {"sha1": digest, "size": details["size"],
                      "url": "https://resources.download.minecraft.net/" + digest[:2] + "/" + digest},
                     (OLD_ASSETS / relative,)))
    # Asset names may share an object hash; avoid concurrent writes to the same file.
    jobs = list({str(job[0]): job for job in jobs}.values())
    with concurrent.futures.ThreadPoolExecutor(max_workers=12) as pool:
        results = list(pool.map(lambda task: artifact(*task), jobs))
    print(f"Verified {len(jobs)} Minecraft assets ({results.count('downloaded')} downloaded)", flush=True)
    mods = []
    for filename, digest in EXPECTED.items():
        original = PROJECT / "input-mods" / filename
        if hashlib.sha256(original.read_bytes()).hexdigest() != digest:
            raise RuntimeError(f"Original supplied JAR changed: {filename}")
        target = game / "mods" / filename
        shutil.copy2(original, target)
        if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            raise RuntimeError(f"JAR copy verification failed: {filename}")
        mods.append({"filename": filename, "sha256": digest, "modified": False})
    # Existing options are deliberately retained across successive launches.
    options = game / "options.txt"
    if not options.exists():
        options.write_text("renderDistance:6\nsimulationDistance:5\nmaxFps:30\nfullscreen:false\n")
    provenance = {"minecraft": "1.21.1", "loader": "NeoForge", "loader_version": NEO_VERSION,
                  "minecraft_version_sha1": entry["sha1"], "minecraft_client_sha1": mc["downloads"]["client"]["sha1"],
                  "assets_index": index["id"], "verified_asset_objects": len(jobs), "original_mods": mods,
                  "java_home": str(JDK), "client_directory": str(BASE), "tls_verification": True,
                  "private_friend_gate_override": False, "client_started": False}
    (BASE / "client-install-provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(json.dumps(provenance, indent=2), flush=True)


if __name__ == "__main__":
    main()
