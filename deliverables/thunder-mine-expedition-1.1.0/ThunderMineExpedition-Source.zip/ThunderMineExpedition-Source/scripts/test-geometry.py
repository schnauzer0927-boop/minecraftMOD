#!/usr/bin/env python3
"""Regression checks that reject unsafe authored native test geometry."""
import copy
import importlib.util
import json
import unittest
from pathlib import Path

root = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("geometry", root / "scripts/validate-test-geometry.py")
geometry = importlib.util.module_from_spec(spec)
spec.loader.exec_module(geometry)


class NativeTestGeometry(unittest.TestCase):
    def setUp(self):
        self.course = json.loads((root / "data/minimal-test-course.json").read_text())

    def test_authored_quarters_are_closed_and_not_too_sharp(self):
        result = geometry.validate(self.course)
        self.assertTrue(result["geometry_passed"], result["errors"])
        self.assertAlmostEqual(result["length_blocks"], 2 * 3.141592653589793 * 24, delta=0.1)
        self.assertGreater(result["minimum_radius_blocks"], 23.5)
        self.assertFalse(result["native_runtime_tested"])

    def test_open_route_is_not_commissionable(self):
        self.course["loop"] = False
        self.assertFalse(geometry.validate(self.course)["geometry_passed"])

    def test_duplicate_anchor_is_rejected(self):
        self.course["nodes"][1]["block"] = copy.deepcopy(self.course["nodes"][0]["block"])
        self.assertFalse(geometry.validate(self.course)["geometry_passed"])

    def test_too_long_native_span_is_rejected(self):
        self.course["nodes"][1]["block"][0] += 200
        self.assertFalse(geometry.validate(self.course)["geometry_passed"])

    def test_tangent_normal_conflict_is_rejected(self):
        self.course["nodes"][0]["up"] = [0, 0, 1]
        self.assertFalse(geometry.validate(self.course)["geometry_passed"])

    def test_narrow_hairpin_is_rejected(self):
        self.course["handle_length"] = 0.1
        self.assertFalse(geometry.validate(self.course)["geometry_passed"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
