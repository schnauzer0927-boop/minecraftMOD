#!/usr/bin/env python3
"""Parser unit tests use explicitly synthetic fixtures, never Minecraft runtime evidence."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location("native_evidence", Path(__file__).with_name("extract-native-ride-evidence.py"))
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

PASS = "MINE_MAIN_RIDE_PASSED run=fixture-run cart=fixture-cart gameTick=200 laps=1 nativeArcLength=1000 measuredDistance=999.8 elapsedSeconds=180 maxNativeSpeed=10 maxMeasuredSpeed=10.2 maxAcceleration=6 stationDistance=0.1 stationarySeconds=3.025 nativePoseAssignments=0\n"
SAMPLE = "MINE_MAIN_SAMPLE run=fixture-run cart=fixture-cart gameTick=20 phase=RUNNING s=100 nativeSpeed=6 elapsed=20 laps=0 area=mine engaged=true seated=1 bearing=(1.0, 2.0, 3.0) quaternion=( 0.0E+0 0.0E+0 0.0E+0 1.0E+0) loadedAhead=true\n"


class NativeEvidenceParserTests(unittest.TestCase):
    def extract(self, text, scope="main"):
        with tempfile.TemporaryDirectory(prefix="native-evidence-parser-fixture-") as directory:
            path = Path(directory) / "synthetic-parser-fixture.log"
            path.write_text(text)
            return module.extract([path], scope)

    def test_missing_pass_is_refused_even_with_running_and_seated_samples(self):
        result = self.extract(SAMPLE)
        self.assertFalse(result["evidence_accepted"])
        self.assertEqual(result["explicit_valid_pass_count"], 0)

    def test_explicit_physical_pass_and_actual_sample_fields_are_extracted(self):
        result = self.extract(SAMPLE + PASS)
        self.assertTrue(result["evidence_accepted"])
        self.assertEqual(result["runs"][0]["seated_sample_count"], 1)
        self.assertEqual(result["runs"][0]["first_sample"]["fields"]["bearing"], [1.0, 2.0, 3.0])
        self.assertEqual(result["runs"][0]["first_sample"]["fields"]["quaternion"], [0, 0, 0, 1])

    def test_invalid_station_or_missing_speed_metrics_do_not_count_as_a_pass(self):
        result = self.extract(PASS.replace("stationDistance=0.1", "stationDistance=5.0"))
        self.assertFalse(result["evidence_accepted"])
        self.assertEqual(result["explicit_valid_pass_count"], 0)
        result = self.extract(PASS.replace("maxMeasuredSpeed=10.2 ", ""))
        self.assertFalse(result["evidence_accepted"])

    def test_duplicate_console_and_file_records_count_only_once(self):
        result = self.extract(SAMPLE + SAMPLE + PASS + PASS)
        self.assertEqual(result["explicit_valid_pass_count"], 1)
        self.assertEqual(result["runs"][0]["sample_count"], 1)
        self.assertEqual(result["duplicate_records_ignored"], 2)

    def test_resume_and_show_cues_are_associated_without_inventing_a_new_run(self):
        text = SAMPLE + "MINE_EFFECT_TRIGGER id=fixture-rockfall lap=0 node=12 gameTick=22 delayTicks=0\n"
        text += "MINE_EFFECT_EXECUTE id=fixture-rockfall gameTick=22 executions=1\n"
        text += "MINE_MAIN_RIDE_RESUMED run=fixture-run cart=fixture-cart gameTick=100 phase=RUNNING canonicalS=420 elapsedSeconds=71 seated=1 nativePoseAssignments=0\n" + PASS
        result = self.extract(text)
        self.assertEqual(len(result["runs"]), 1)
        self.assertEqual(len(result["resume_records"]), 1)
        self.assertEqual(result["cue_execution_counts"], {"fixture-rockfall": 1})
        self.assertEqual(result["runs"][0]["cue_triggers"], {"fixture-rockfall": 1})

    def test_native_failure_is_reported_even_when_a_pass_marker_exists(self):
        result = self.extract(PASS + "MINE_MAIN_RIDE_FAILED run=fixture-run cart=fixture-cart gameTick=205 reason=fixture-failure\n")
        self.assertFalse(result["evidence_accepted"])
        self.assertEqual(len(result["native_failure_records"]), 1)
        self.assertEqual(result["explicit_valid_pass_count"], 1)

    def test_resume_command_refusal_is_preserved_even_after_a_later_pass(self):
        result = self.extract("MINE_TEST_WORLD_RESUME_FAILED Resume refused: native body was not ready.\n" + PASS)
        self.assertFalse(result["evidence_accepted"])
        self.assertEqual(result["native_failure_records"][0]["marker"], "MINE_TEST_WORLD_RESUME_FAILED")
        self.assertEqual(result["explicit_valid_pass_count"], 1)


if __name__ == "__main__":
    unittest.main()
