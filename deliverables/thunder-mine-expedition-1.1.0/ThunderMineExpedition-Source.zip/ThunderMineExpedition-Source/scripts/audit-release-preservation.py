#!/usr/bin/env python3
"""Read-only integrity audit of uploads, protected old artifacts, and source scope.

This does not build, start Minecraft, change worlds, or certify a finished ride.
An optional source ZIP is checked for accidentally bundled vendor/runtime files.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import zipfile


PROJECT = Path(__file__).resolve().parent.parent
UPLOADS = {
    "sable-neoforge-1.21.1-2.0.6.jar": (12986135, "9c199157843bf953a47dff625fc5bb41c01a90538d35ad18e6996bbcb8a617c2"),
    "simulatedcoasters-0.1.5.jar": (1892119, "f80b4c3cdf9fa6188804967147761b0373e150a6eadbdc53626e5ac9700b2049"),
    "create-1.21.1-6.0.10.jar": (19123767, "ef87fe5709f1ba1f5b8bb20a2925b5afb4669e178fd6d8bf10c167759eefe37a"),
}
COPY_ROOTS = [PROJECT / p for p in (
    "run-native-test-production/mods", "run-mine-production/mods", "run-native-client-production/game/mods")]


def digest(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()


def file_check(path, expected_hash, expected_size=None):
    exists = path.is_file()
    actual_hash = digest(path) if exists else None
    size = path.stat().st_size if exists else None
    return {"path": str(path), "size_bytes": size, "sha256": actual_hash,
            "unchanged": exists and actual_hash == expected_hash and
                         (expected_size is None or expected_size == size)}


def helper_jar_check(path):
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        forbidden = [n for n in names if n.endswith(".jar") or n.startswith((
            "dev/silvergold/", "dev/ryanhcode/", "com/simibubi/", "net/minecraft/",
            "assets/create/", "assets/sable/", "assets/simulatedcoasters/"))]
        own = [n for n in names if n.endswith(".class") and n.startswith("dev/thundermine/")]
        other = [n for n in names if n.endswith(".class") and n not in own]
        valid = archive.testzip() is None and not forbidden and not other and bool(own)
        return {"path": str(path), "sha256": digest(path), "size_bytes": path.stat().st_size,
                "crc_valid": archive.testzip() is None, "own_class_files": len(own),
                "vendor_entries": forbidden, "other_namespace_classes": other,
                "vendor_bundle_check_pass": valid}


def source_zip_check(path):
    with zipfile.ZipFile(path) as archive:
        failures = []
        names = archive.namelist()
        for name in names:
            relative = Path(*Path(name).parts[1:])
            parts = relative.parts
            if not parts:
                continue
            if parts[0] in {"analysis", "build", "input-mods", "toolchain", "dist", "vendor", "vendors"} or parts[0].startswith("run-"):
                failures.append(name)
            elif relative.suffix.lower() in {".class", ".so", ".dll", ".dylib", ".l4z"}:
                failures.append(name)
            elif relative.suffix.lower() == ".jar" and relative.as_posix() != "helper/gradle/wrapper/gradle-wrapper.jar":
                failures.append(name)
            elif name.endswith(".javap.txt") or "decompiled" in parts:
                failures.append(name)
        valid = archive.testzip() is None and not failures and bool(names)
        return {"path": str(path), "size_bytes": path.stat().st_size, "sha256": digest(path),
                "entries": len(names), "crc_valid": archive.testzip() is None,
                "forbidden_vendor_runtime_entries": failures, "pass": valid,
                "gradle_wrapper_is_permitted_build_tool": True}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--attachments", type=Path, default=Path("/workspace/attachments"))
    parser.add_argument("--legacy-release", type=Path, default=Path("/workspace/minecraftMOD/coasterengineering/dist/release-2.0.0"))
    parser.add_argument("--helper-jar", type=Path, default=PROJECT / "helper/build/libs/thunder-mine-tools-1.0.0.jar")
    parser.add_argument("--source-zip", type=Path)
    parser.add_argument("--output", type=Path, default=PROJECT / "evidence/audit/preservation-and-source-audit.json")
    args = parser.parse_args()
    uploads, copies = [], []
    for filename, (size, expected) in UPLOADS.items():
        matches = list(args.attachments.rglob(filename))
        if len(matches) != 1:
            raise SystemExit("Expected exactly one original upload: " + filename)
        uploads.append(file_check(matches[0], expected, size))
        for directory in COPY_ROOTS:
            candidate = directory / filename
            if directory.is_dir():
                copies.append(file_check(candidate, expected, size))
    protected = []
    for line in (args.legacy_release / "SHA256SUMS").read_text().splitlines():
        checksum, filename = line.split(maxsplit=1)
        protected.append(file_check(args.legacy_release / filename.strip(), checksum))
    java = sorted((PROJECT / "helper/src").rglob("*.java"))
    declarations = [re.search(r"^package\s+([^;]+);", p.read_text(), re.M).group(1) for p in java]
    source_scope = {
        "java_files": len(java), "package_namespaces": sorted(set(declarations)),
        "all_java_under_own_namespace": all(s.startswith("dev.thundermine.") or s == "dev.thundermine" for s in declarations),
        "packager_allowlisted_roots": ["docs", "data", "scripts", "helper/src", "specific helper build files", "explicit commissioning evidence"],
        "excluded_analysis_vendor_roots": ["analysis", "build", "input-mods", "toolchain", "run-*", "dist"],
        "evidence_caution": "Explicit commissioning evidence must not add decompiled sources or *.javap.txt.",
        "generator_sha256": digest(PROJECT / "scripts/generate-mine-course.py"),
        "course_data_sha256": digest(PROJECT / "data/mine-route.json"),
        "helper_embedded_route_matches": (PROJECT / "data/mine-route.json").read_bytes() ==
                                        (PROJECT / "helper/src/main/resources/data/thunder_mine_tools/course/mine-route.json").read_bytes(),
    }
    result = {
        "schema": 1, "scope": "Read-only integrity and packaging audit; not final runtime commissioning",
        "uploads": uploads, "runtime_mod_copies": copies,
        "protected_coaster_engineering_2_0_artifacts": protected,
        "all_uploads_and_copies_unchanged": all(r["unchanged"] for r in uploads + copies),
        "all_protected_2_0_artifacts_unchanged": all(r["unchanged"] for r in protected),
        "source_scope": source_scope, "helper_jar": helper_jar_check(args.helper_jar),
        "final_scenery_ride_is_not_certified_by_this_audit": True,
    }
    if args.source_zip:
        result["final_source_zip"] = source_zip_check(args.source_zip)
    result["integrity_audit_pass"] = (result["all_uploads_and_copies_unchanged"] and
        result["all_protected_2_0_artifacts_unchanged"] and source_scope["all_java_under_own_namespace"] and
        source_scope["helper_embedded_route_matches"] and result["helper_jar"]["vendor_bundle_check_pass"] and
        (not args.source_zip or result["final_source_zip"]["pass"]))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "pass": result["integrity_audit_pass"],
                      "uploads": len(uploads), "runtime_copies": len(copies), "old_2_0_files": len(protected)}, indent=2))
    if not result["integrity_audit_pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
