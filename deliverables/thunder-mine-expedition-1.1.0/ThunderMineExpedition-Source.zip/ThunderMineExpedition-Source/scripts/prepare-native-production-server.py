#!/usr/bin/env python3
"""Install the unmodified official NeoForge server; never start the game server."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import urllib.error
import urllib.request
import urllib.parse


VERSION = "21.1.228"
INSTALLER_URL = (
    "https://maven.neoforged.net/releases/net/neoforged/neoforge/"
    + VERSION + "/neoforge-" + VERSION + "-installer.jar"
)
JDK = Path("/workspace/.tools/thunder-mine-java21/extracted/usr/lib/jvm/java-21-openjdk-amd64")
EXPECTED = {
    "sable-neoforge-1.21.1-2.0.6.jar": "9c199157843bf953a47dff625fc5bb41c01a90538d35ad18e6996bbcb8a617c2",
    "simulatedcoasters-0.1.5.jar": "f80b4c3cdf9fa6188804967147761b0373e150a6eadbdc53626e5ac9700b2049",
    "create-1.21.1-6.0.10.jar": "ef87fe5709f1ba1f5b8bb20a2925b5afb4669e178fd6d8bf10c167759eefe37a",
}


def fetch(url: str) -> bytes:
    request = urllib.request.Request(url, headers={"User-Agent": "ThunderMineExpedition-Setup/1.0"})
    with urllib.request.urlopen(request, timeout=120) as response:
        if response.status != 200:
            raise RuntimeError(f"HTTP {response.status}: {url}")
        return response.read()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", type=Path, default=Path("run-native-test-production"))
    parser.add_argument("--attachments", type=Path, default=Path("/workspace/attachments"))
    args = parser.parse_args()
    server = args.server.resolve()
    if (server / "server.properties").exists() or (server / "Thunder Mine Native Test").exists():
        raise SystemExit("Existing configured server/world detected; refusing to overwrite it.")
    project = Path(__file__).resolve().parent.parent
    toolchain = project / "toolchain" / "neoforge-production"
    evidence = project / "evidence"
    toolchain.mkdir(parents=True, exist_ok=True)
    evidence.mkdir(parents=True, exist_ok=True)
    server.mkdir(parents=True, exist_ok=True)

    installer = toolchain / f"neoforge-{VERSION}-installer.jar"
    checksum = None
    checksum_url = None
    checksum_algorithm = None
    for algorithm in ("sha256", "sha1"):
        candidate = INSTALLER_URL + "." + algorithm
        try:
            checksum = fetch(candidate).decode("ascii").strip().split()[0].lower()
            if len(checksum) != hashlib.new(algorithm).digest_size * 2 or not all(c in "0123456789abcdef" for c in checksum):
                raise RuntimeError("Malformed authoritative Maven checksum")
            checksum_url = candidate
            checksum_algorithm = algorithm
            break
        except urllib.error.HTTPError as exc:
            if exc.code != 404:
                raise
    if checksum is None or checksum_algorithm is None:
        raise RuntimeError("No authoritative Maven SHA-256/SHA-1 checksum available")
    binary = fetch(INSTALLER_URL)
    actual = hashlib.new(checksum_algorithm, binary).hexdigest()
    if actual != checksum:
        raise RuntimeError("Official installer checksum mismatch")
    installer.write_bytes(binary)
    (toolchain / (installer.name + "." + checksum_algorithm)).write_text(checksum + "\n")

    log = evidence / "neoforge-production-install.log"
    # Java does not automatically consume the environment's mandatory HTTP
    # proxy. Use the same configured proxy as urllib/curl, never an alternative.
    proxy_flags = []
    for scheme in ("http", "https"):
        proxy = os.environ.get(scheme.upper() + "_PROXY") or os.environ.get(scheme + "_proxy")
        if proxy:
            parsed = urllib.parse.urlparse(proxy)
            if parsed.username or parsed.password:
                raise RuntimeError("Authenticated proxy requires environment Java proxy support; credentials are not placed on command lines")
            if not parsed.hostname:
                raise RuntimeError("Malformed environment proxy URL")
            proxy_flags.extend([f"-D{scheme}.proxyHost={parsed.hostname}",
                                f"-D{scheme}.proxyPort={parsed.port or 80}"])
    with log.open("w", encoding="utf-8") as output:
        result = subprocess.run(
            [str(JDK / "bin/java"), *proxy_flags, "-jar", str(installer), "--installServer"],
            cwd=server, stdout=output, stderr=subprocess.STDOUT, check=False,
        )
    if result.returncode != 0 or not (server / "run.sh").is_file():
        raise RuntimeError(f"Official installer failed ({result.returncode}); see {log}")

    original_mods = []
    mods_dir = server / "mods"
    mods_dir.mkdir(exist_ok=True)
    for filename, digest in EXPECTED.items():
        candidates = list(args.attachments.rglob(filename))
        if len(candidates) != 1:
            raise RuntimeError(f"Expected exactly one supplied file: {filename}")
        original = candidates[0]
        original_digest = hashlib.sha256(original.read_bytes()).hexdigest()
        if original_digest != digest:
            raise RuntimeError(f"Supplied JAR changed: {filename}")
        target = mods_dir / filename
        shutil.copy2(original, target)
        if hashlib.sha256(target.read_bytes()).hexdigest() != digest:
            raise RuntimeError(f"Copy verification failed: {filename}")
        original_mods.append({"filename": filename, "size_bytes": original.stat().st_size,
                              "sha256": digest, "copy_verified": True, "jar_modified": False})

    # Dedicated local console test server, no public listener and no client gate changes.
    properties = """# Isolated official NeoForge 21.1.228 test server
server-ip=127.0.0.1
server-port=25576
online-mode=false
enable-rcon=false
enable-query=false
level-name=Thunder Mine Native Test
level-seed=20261012
level-type=minecraft:flat
generator-settings={"biome":"minecraft:plains","layers":[{"block":"minecraft:bedrock","height":1},{"block":"minecraft:stone","height":60},{"block":"minecraft:dirt","height":3},{"block":"minecraft:grass_block","height":1}],"structure_overrides":[]}
generate-structures=false
gamemode=creative
force-gamemode=false
difficulty=peaceful
spawn-protection=0
view-distance=6
simulation-distance=4
max-tick-time=60000
max-players=1
allow-flight=true
enable-command-block=true
motd=Thunder Mine Native Test - localhost only
"""
    (server / "server.properties").write_text(properties, encoding="utf-8")
    (server / "eula.txt").write_text("# Minecraft EULA accepted for the authorized local development server.\neula=true\n")
    (server / "user_jvm_args.txt").write_text("-Xms1G\n-Xmx4G\n")
    java_wrapper = server / "start-local.sh"
    java_wrapper.write_text(
        "#!/usr/bin/env bash\nset -euo pipefail\n"
        + f"export JAVA_HOME={str(JDK)!r}\n"
        + "export PATH=\"$JAVA_HOME/bin:$PATH\"\n"
        + "cd -- \"$(dirname -- \"${BASH_SOURCE[0]}\")\"\n"
        + "exec ./run.sh nogui \"$@\"\n"
    )
    java_wrapper.chmod(0o755)
    provenance = {
        "minecraft": "1.21.1", "loader": "NeoForge", "loader_version": VERSION,
        "java_home": str(JDK), "server_directory": str(server), "installer_url": INSTALLER_URL,
        "installer_size_bytes": len(binary), "installer_sha256": hashlib.sha256(binary).hexdigest(),
        "authoritative_checksum_url": checksum_url, "checksum_algorithm": checksum_algorithm,
        "authoritative_checksum": checksum, "checksum_matches": True, "tls_verification": True,
        "installer_exit_code": result.returncode, "original_mods": original_mods,
        "server_started": False, "bind_address": "127.0.0.1", "port": 25576,
        "client_private_gate_modified": False,
    }
    (toolchain / "server-install-provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(json.dumps(provenance, indent=2))


if __name__ == "__main__":
    main()
