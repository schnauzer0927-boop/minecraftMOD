#!/usr/bin/env bash
# Source only for Thunder Mine work; retain the separate Java17 Forge workflow.
THUNDER_MINE_PROJECT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
THUNDER_MINE_JDK="${THUNDER_MINE_JAVA_HOME:-/workspace/.tools/thunder-mine-java21/extracted/usr/lib/jvm/java-21-openjdk-amd64}"
if [[ ! -x "$THUNDER_MINE_JDK/bin/javac" ]]; then
    printf 'Java21 JDK missing: run scripts/setup-java21-debian.sh first\n' >&2
    return 1
fi
export JAVA_HOME="$THUNDER_MINE_JDK"
export PATH="$JAVA_HOME/bin:$PATH"
export GRADLE_USER_HOME="${GRADLE_USER_HOME:-/workspace/.gradle}"
