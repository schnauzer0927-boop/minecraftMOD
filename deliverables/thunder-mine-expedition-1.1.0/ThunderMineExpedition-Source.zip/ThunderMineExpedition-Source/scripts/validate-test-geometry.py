#!/usr/bin/env python3
"""Validate authored Bezier geometry, never substitute for native ride tests."""
import argparse
import json
import math
from pathlib import Path


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def scale(a, n):
    return tuple(x * n for x in a)


def sub(a, b):
    return add(a, scale(b, -1))


def length(a):
    return math.sqrt(sum(x * x for x in a))


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    x, y, z = a
    u, v, w = b
    return (y * w - z * v, z * u - x * w, x * v - y * u)


def point(p, t):
    u = 1 - t
    weights = (u ** 3, 3 * u * u * t, 3 * u * t * t, t ** 3)
    return tuple(sum(weights[k] * p[k][axis] for k in range(4)) for axis in range(3))


def derivatives(p, t):
    u = 1 - t
    d = add(add(scale(sub(p[1], p[0]), 3 * u * u),
                scale(sub(p[2], p[1]), 6 * u * t)),
            scale(sub(p[3], p[2]), 3 * t * t))
    dd = add(scale(add(sub(p[2], scale(p[1], 2)), p[0]), 6 * u),
             scale(add(sub(p[3], scale(p[2], 2)), p[1]), 6 * t))
    return d, dd


def validate(data, samples=2048):
    errors = []
    nodes = data["nodes"]
    if not data.get("loop") or len(nodes) < 3:
        errors.append("Test commissioning requires a closed course with at least 3 anchors")
    if len({tuple(n["block"]) for n in nodes}) != len(nodes):
        errors.append("Duplicate anchor positions")
    offset = data["native_anchor_center_offset"]
    handle = data["handle_length"]
    spans = []
    for i, a in enumerate(nodes):
        b = nodes[(i + 1) % len(nodes)]
        if abs(length(a["forward"]) - 1) > 1e-9 or abs(dot(a["forward"], a["up"])) > 1e-9:
            errors.append(f"{a['id']}: invalid tangent/normal frame")
        first, last = add(a["block"], offset), add(b["block"], offset)
        chord = length(sub(last, first))
        if chord > data["maximum_anchor_chord"]:
            errors.append(f"{a['id']}->{b['id']}: exceeds native placement chord limit")
        p = (first, add(first, scale(a["forward"], handle)),
             sub(last, scale(b["forward"], handle)), last)
        previous = first
        arc = 0.0
        minimum_radius = math.inf
        for j in range(samples + 1):
            t = j / samples
            current = point(p, t)
            arc += length(sub(current, previous))
            previous = current
            d, dd = derivatives(p, t)
            speed = length(d)
            if speed < 1e-8:
                errors.append(f"{a['id']}->{b['id']}: degenerate tangent at {t}")
                continue
            curvature = length(cross(d, dd)) / speed ** 3
            if curvature > 1e-12:
                minimum_radius = min(minimum_radius, 1 / curvature)
        if minimum_radius < data["minimum_design_radius"]:
            errors.append(f"{a['id']}->{b['id']}: curvature below design radius")
        spans.append({"from": a["id"], "to": b["id"], "chord_blocks": chord,
                      "length_blocks": arc, "minimum_radius_blocks": minimum_radius})
    total = sum(s["length_blocks"] for s in spans)
    return {"schema": 1, "course_id": data["id"], "geometry_passed": not errors,
            "errors": errors, "spans": spans, "length_blocks": total,
            "minimum_radius_blocks": min(s["minimum_radius_blocks"] for s in spans),
            "reference_seconds_at_4_blocks_per_second": total / 4,
            "native_runtime_tested": False,
            "scope": "Authored cubic geometry only; no Rapier, guide, passenger, save or station assertion"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("course", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = validate(json.loads(args.course.read_text(encoding="utf-8")))
    formatted = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(formatted, encoding="utf-8")
    print(formatted, end="")
    raise SystemExit(0 if result["geometry_passed"] else 1)


if __name__ == "__main__":
    main()
