#!/usr/bin/env python3
"""Original authored native-Bezier route. Shape calculations are not physics tests."""
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COUNT = 64
TAU = 2 * math.pi
HEIGHTS = [(0, 82), (.35, 84), (.90, 115), (1.20, 126), (1.55, 72),
           (2.00, 58), (2.35, 73), (2.80, 48), (3.20, 44), (3.65, 99),
           (4.00, 112), (4.65, 55), (5.05, 88),
           (5.60, 75), (5.95, 82), (TAU, 82)]


def length(v): return math.sqrt(sum(x * x for x in v))
def scale(v, s): return [x * s for x in v]
def sub(a, b): return [x - y for x, y in zip(a, b)]
def add(a, b): return [x + y for x, y in zip(a, b)]
def dot(a, b): return sum(x * y for x, y in zip(a, b))
def cross(a, b): return [a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]]
def unit(v): return scale(v, 1 / length(v))


def height(t):
    for (a, y), (b, z) in zip(HEIGHTS, HEIGHTS[1:]):
        if a <= t <= b:
            f = (t - a) / (b - a)
            return y + (z - y) * f * f * (3 - 2 * f)
    raise ValueError(t)


def profile(t):
    if t < .55: return 'base', 3.2, 1.8, 7.0
    if t < 1.25: return 'badlands', 5.0, 2.8, 8.0
    if t < 2.0: return 'mine_tunnel', 12.2, 4.5, 8.0
    if t < 2.6: return 'mine_tunnel', 8.8, 3.2, 8.0
    if t < 3.1: return 'deep_excavation', 3.4, 2.2, 8.0
    if t < 3.7: return 'deep_excavation', 4.8, 3.2, 8.0
    if t < 4.25: return 'canyon', 7.8, 3.0, 8.0
    if t < 5.4: return 'canyon', 13.5, 4.5, 8.0
    if t < 5.8: return 'return', 7.0, 2.5, 8.0
    return 'return', 4.0, 2.0, 8.0


def point(p, t):
    u = 1 - t
    w = [u**3, 3*u*u*t, 3*u*t*t, t**3]
    return [sum(w[j]*p[j][k] for j in range(4)) for k in range(3)]


def radius(p, t):
    u = 1 - t
    d = add(add(scale(sub(p[1],p[0]),3*u*u),scale(sub(p[2],p[1]),6*u*t)),scale(sub(p[3],p[2]),3*t*t))
    dd = add(scale(add(sub(p[2],scale(p[1],2)),p[0]),6*u),scale(add(sub(p[3],scale(p[2],2)),p[1]),6*t))
    k = length(cross(d,dd))/max(length(d)**3,1e-15)
    return 1/k if k > 1e-10 else 1e10


def main():
    positions = []
    for i in range(COUNT):
        t = TAU * i / COUNT
        positions.append([round(150*math.cos(t)+24*math.cos(2*t)),
                          round(height(t)), round(128*math.sin(t)+26*math.sin(3*t))])
    nodes = []
    for i, pos in enumerate(positions):
        t = TAU * i / COUNT
        tangent = scale(sub(positions[(i+1)%COUNT], positions[(i-1)%COUNT]), .5)
        forward = unit(tangent)
        up = unit(sub([0,1,0], scale(forward, forward[1])))
        before = sub(pos,positions[(i-1)%COUNT]); after = sub(positions[(i+1)%COUNT],pos)
        turn = cross(unit(before),unit(after))[1]
        area, speed, acceleration, braking = profile(t)
        bank = 0 if area in ('base','return') else max(-22,min(22, -turn*110))
        nodes.append({'block':pos,'forward':forward,'up':up,'bankDegrees':bank,
                      'handleIn':length(tangent)/3,'handleOut':length(tangent)/3,
                      'area':area,'targetSpeed':speed,'acceleration':acceleration,'braking':braking})
    spans=[]; total=0; reference_time=0
    for i,a in enumerate(nodes):
        b=nodes[(i+1)%COUNT]
        p=[a['block'],add(a['block'],scale(a['forward'],a['handleOut'])),
           sub(b['block'],scale(b['forward'],b['handleIn'])),b['block']]
        previous=p[0]; distance=0; smallest=1e10
        for j in range(1,257):
            v=point(p,j/256); distance+=length(sub(v,previous)); previous=v
            smallest=min(smallest,radius(p,j/256))
        # A conservative authored lateral acceleration cap, not a Rapier simulation.
        capped_speed=min(a['targetSpeed'],math.sqrt(4.5*smallest))
        a['targetSpeed']=round(capped_speed,6)
        chord=length(sub(a['block'],b['block']))
        if chord>45 or smallest<3.5:
            raise ValueError(f'Unsafe authored span {i}: chord={chord}, radius={smallest}')
        spans.append({'index':i,'area':a['area'],'length':distance,'chord':chord,
                      'minimumRadius':smallest,'targetSpeed':a['targetSpeed']})
        total+=distance; reference_time+=distance/a['targetSpeed']
    data={'schema':1,'id':'thunder-mine-expedition-v1','name':'Thunder Mine Expedition',
          'worldName':'Coaster World - Thunder Mine Expedition','closed':True,'nodes':nodes,
          'stationWaitTicks':200,'dispatchDelayTicks':60,
          'events':[{'id':'departure','node':0,'type':'station_bell'},
                    {'id':'first_drop','node':13,'type':'mine_rumble'},
                    {'id':'blast_warning','node':25,'type':'warning'},
                    {'id':'cavern_reveal','node':29,'type':'steam'},
                    {'id':'collapse_escape','node':38,'type':'dust_rockfall'},
                    {'id':'canyon_escape','node':43,'type':'explosion_visual'},
                    {'id':'return','node':59,'type':'station_bell'}]}
    out=ROOT/'helper/src/main/resources/data/thunder_mine_tools/course/mine-route.json'
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(data,indent=2)+'\n')
    (ROOT/'data/mine-route.json').write_text(json.dumps(data,indent=2)+'\n')
    report={'authored_geometry_only':True,'native_runtime_tested':False,'nodes':COUNT,
            'length_blocks':total,'minimum_radius':min(s['minimumRadius'] for s in spans),
            'maximum_chord':max(s['chord'] for s in spans),
            'height_range_blocks':max(p[1] for p in positions)-min(p[1] for p in positions),
            'constant_section_reference_seconds':reference_time,'spans':spans}
    (ROOT/'evidence/main-authored-geometry.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='spans'},indent=2))


if __name__=='__main__': main()
