#!/usr/bin/env bash
set -euo pipefail

# Isolated APT state; repository signatures and package hashes remain mandatory.
# Nothing is installed into /usr and the previous Java 17 project is untouched.
TOOLCHAIN_BASE="${THUNDER_MINE_TOOLCHAIN_BASE:-/workspace/.tools/thunder-mine-java21}"
APT_STATE="$TOOLCHAIN_BASE/apt"
JDK_ROOT="$TOOLCHAIN_BASE/extracted"
mkdir -p "$APT_STATE/lists/partial" "$APT_STATE/archives/partial" "$APT_STATE/etc/apt.conf.d" "$APT_STATE/etc/sources.list.d" "$APT_STATE/downloads" "$JDK_ROOT"
cat > "$APT_STATE/etc/apt.conf" <<EOF
Dir::Etc::main "/dev/null";
Dir::Etc::parts "$APT_STATE/etc/apt.conf.d";
EOF
# APT_CONFIG is read before the system config directories, avoiding unrelated
# system maintenance hooks while preserving the installed archive keyring.
export APT_CONFIG="$APT_STATE/etc/apt.conf"
cat > "$APT_STATE/etc/sources.list" <<'EOF'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.pgp] https://deb.debian.org/debian trixie main
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.pgp] https://deb.debian.org/debian-security trixie-security main
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.pgp] https://deb.debian.org/debian trixie-updates main
EOF
APT_ARGS=(
    -o "Dir::Etc::main=/dev/null"
    -o "Dir::Etc::parts=$APT_STATE/etc/apt.conf.d"
    -o "Dir::Etc::sourcelist=$APT_STATE/etc/sources.list"
    -o "Dir::Etc::sourceparts=$APT_STATE/etc/sources.list.d"
    -o "Dir::State::lists=$APT_STATE/lists"
    -o "Dir::Cache::archives=$APT_STATE/archives"
    -o "Dir::Cache::pkgcache=$APT_STATE/pkgcache.bin"
    -o "Dir::Cache::srcpkgcache=$APT_STATE/srcpkgcache.bin"
    -o "APT::Get::AllowUnauthenticated=false"
    -o "Acquire::AllowInsecureRepositories=false"
    -o "Acquire::https::Verify-Peer=true"
    -o "Acquire::https::Verify-Host=true"
)
/usr/bin/apt-get "${APT_ARGS[@]}" update
(
    cd "$APT_STATE/downloads"
    /usr/bin/apt-get "${APT_ARGS[@]}" download openjdk-21-jdk-headless openjdk-21-jre-headless
    sha256sum ./*.deb > "$TOOLCHAIN_BASE/downloaded-packages.sha256"
    for package in ./*.deb; do
        dpkg-deb --extract "$package" "$JDK_ROOT"
    done
)
JDK_HOME="$JDK_ROOT/usr/lib/jvm/java-21-openjdk-amd64"
"$JDK_HOME/bin/java" -version
"$JDK_HOME/bin/javac" -version
printf 'THUNDER_MINE_JAVA_HOME=%s\n' "$JDK_HOME"
