#!/usr/bin/env python3
"""Commission a prepared release copy with a pinned helper, then stop normally.

Only documented read commands plus save-all/stop are issued. No NBT, vehicle pose,
completion state, block geometry, source world, or prior artifact is patched.
"""
import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import queue
import re
import shutil
import subprocess
import threading
import time
import tomllib
import zipfile


PROJECT = Path(__file__).resolve().parent.parent
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")
CART = "a7826a81-9ae0-4d9d-91b0-f6932c9f46db"


def sha(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--server", type=Path, default=PROJECT / "run-mine-release-1.0.1")
    parser.add_argument("--helper", type=Path, default=PROJECT / "helper/build/libs/thunder-mine-tools-1.0.1.jar")
    parser.add_argument("--expected-sha256", required=True)
    parser.add_argument("--preparation", type=Path, default=PROJECT / "evidence/release-1.0.1/preparation-provenance.json")
    parser.add_argument("--timeout", type=float, default=300.0)
    parser.add_argument("--log", type=Path, default=PROJECT / "evidence/release-1.0.1/normal-save-server.log")
    parser.add_argument("--proof", type=Path, default=PROJECT / "evidence/release-1.0.1/normal-save-server-proof.json")
    args = parser.parse_args()
    if sha(args.helper) != args.expected_sha256:
        raise SystemExit("Final helper checksum mismatch; refusing to launch")
    if args.log.exists() or args.proof.exists():
        raise SystemExit("Existing version-specific evidence must not be overwritten")
    with zipfile.ZipFile(args.helper) as helper_archive:
        metadata = tomllib.loads(helper_archive.read("META-INF/neoforge.mods.toml").decode())
        entries = [m for m in metadata.get("mods", []) if m.get("modId") == "thunder_mine_tools"]
        if len(entries) != 1 or helper_archive.testzip() is not None:
            raise SystemExit("Pinned independent helper metadata/CRC invalid")
        helper_version = entries[0]["version"]
    preparation = json.loads(args.preparation.read_text())
    server = args.server.resolve()
    source = Path(preparation["source_world"])
    world = server / "Coaster World - Thunder Mine Expedition"
    target = server / "mods" / args.helper.name
    other_helpers = [p for p in (server / "mods").glob("thunder-mine-tools-*.jar") if p.name != args.helper.name]
    if other_helpers:
        raise SystemExit("Another helper version is installed; refusing duplicate MOD IDs")
    shutil.copy2(args.helper, target)
    if sha(target) != args.expected_sha256:
        raise SystemExit("Final helper copy mismatch")
    args.log.parent.mkdir(parents=True, exist_ok=True)
    output = args.log.open("w", encoding="utf-8")
    process = subprocess.Popen([str(server / "start-local.sh")], cwd=server,
                               stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT, text=True, bufsize=1)
    events = queue.Queue()

    def reader():
        for raw in process.stdout:
            output.write(raw)
            output.flush()
            events.put(ANSI.sub("", raw).strip())
        events.put(None)

    reader_thread = threading.Thread(target=reader, daemon=True)
    reader_thread.start()

    def command(text):
        output.write("RELEASE_AUDIT_COMMAND " + text + "\n")
        output.flush()
        process.stdin.write(text + "\n")
        process.stdin.flush()

    began = time.monotonic()
    deadline = began + args.timeout
    done = False
    reloaded = None
    statuses = []
    poses = []
    clearance = None
    first_pose_at = None
    second_commands_sent = False
    saved = False
    stopped = False
    stop_at = None
    failure = None
    try:
        while time.monotonic() < deadline:
            try:
                line = events.get(timeout=0.2)
            except queue.Empty:
                line = ""
            if line is None:
                break
            if any(marker in line for marker in (
                "MINE_MAIN_RESTORE_REFUSED", "MINE_MAIN_NATIVE_HOLD_FAILED",
                "Encountered an unexpected exception", "A crash report has been saved")):
                failure = line
                break
            if "MINE_MAIN_RELOAD " in line:
                reloaded = line
            if 'Done (' in line and not done:
                done = True
                command("mine_world status")
                command("mine_world clearance")
                command("data get sub_level " + CART + " thunder_mine_expedition")
            if "MINE_TEST_WORLD_STATUS " in line:
                statuses.append(line)
            if "MINE_TEST_WORLD_CLEARANCE " in line:
                clearance = line
            if "bearing_x:" in line and "bearing_y:" in line and "bearing_z:" in line:
                pose = {axis: float(re.search(r"\b" + axis + r":\s*([-+0-9.eE]+)", line).group(1))
                        for axis in ("bearing_x", "bearing_y", "bearing_z")}
                if not all(math.isfinite(value) for value in pose.values()):
                    raise RuntimeError("Nonfinite native pose readback")
                poses.append({"read_elapsed_seconds": time.monotonic() - began, "bearing": pose, "raw": line})
                if first_pose_at is None:
                    first_pose_at = time.monotonic()
            if first_pose_at is not None and not second_commands_sent and time.monotonic() - first_pose_at >= 10.0:
                command("mine_world status")
                command("data get sub_level " + CART + " thunder_mine_expedition")
                second_commands_sent = True
            if second_commands_sent and len(poses) >= 2 and len(statuses) >= 2 and not stopped:
                if not reloaded or "uuidMatches=true" not in reloaded or "fingerprintMatches=true" not in reloaded:
                    raise RuntimeError("Native identity/fingerprint reload not proven")
                if "restoredPhase=PASSED" not in reloaded and "restoredPhase=PARKED" not in reloaded:
                    raise RuntimeError("Actual native course did not restore parked/passed")
                for status in (statuses[0], statuses[-1]):
                    if "phase=PASSED" not in status and "phase=PARKED" not in status:
                        raise RuntimeError("Native phase changed during held station check")
                    if "engaged=true" not in status or "seated=0" not in status:
                        raise RuntimeError("Stationary native guide/passenger state not proven")
                    speed = float(re.search(r"speed=([0-9.]+)", status).group(1))
                    if speed > 0.10:
                        raise RuntimeError("Native solver velocity exceeded held stability threshold")
                if clearance is None or "solidViolations=0" not in clearance:
                    raise RuntimeError("Actual scenery clearance was not proven")
                drift = math.dist(list(poses[0]["bearing"].values()), list(poses[-1]["bearing"].values()))
                if drift > 0.005:
                    raise RuntimeError("Native bearing drift exceeded held station tolerance")
                command("save-all flush")
                command("stop")
                stopped = True
                stop_at = time.monotonic()
            if "Saved the game" in line or "All chunks are saved" in line:
                saved = True
            if stopped and stop_at is not None and time.monotonic() - stop_at > 60.0:
                failure = "Normal stop exceeded 60 seconds"
                break
        if process.poll() is None:
            if not stopped:
                try:
                    command("save-all flush")
                    command("stop")
                except BrokenPipeError:
                    pass
            try:
                process.wait(timeout=60.0)
            except subprocess.TimeoutExpired:
                process.terminate()
                process.wait(timeout=10.0)
                failure = failure or "Server did not complete normal stop"
        if not stopped or not saved or process.returncode != 0:
            failure = failure or "Required held check/normal save/normal shutdown incomplete"
    except Exception as error:
        failure = str(error)
        if process.poll() is None:
            try:
                command("save-all flush")
                command("stop")
                process.wait(timeout=60.0)
            except (BrokenPipeError, subprocess.TimeoutExpired):
                process.terminate()
                process.wait(timeout=10.0)
    finally:
        reader_thread.join(timeout=5.0)
        output.close()
    unchanged = all((source / name).is_file() and sha(source / name) == item["sha256"]
                    for name, item in preparation["source_copy_snapshot_manifest"].items())
    spec = importlib.util.spec_from_file_location("mine_packaging_nbt", PROJECT / "scripts/package-mine-world.py")
    nbt = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(nbt)
    level = nbt.read_nbt(world / "level.dat")["Data"]
    proof = {
        "schema": 1, "world": str(world), "helper_jar_sha256": args.expected_sha256,
        "helper_version": helper_version, "minecraft": "1.21.1", "neoforge": "21.1.228",
        "normal_server_exit_code": process.returncode, "native_reload": reloaded,
        "stationary_statuses": statuses, "readonly_native_bearing_snapshots": poses,
        "bearing_drift_over_10_seconds": math.dist(list(poses[0]["bearing"].values()), list(poses[-1]["bearing"].values())) if len(poses) >= 2 else None,
        "clearance": clearance, "normal_save_observed": saved, "normal_stop_requested": stopped,
        "has_level_Player": "Player" in level, "game_type": level.get("GameType"),
        "allow_commands": level.get("allowCommands"), "source_world_unchanged": unchanged,
        "raw_world_nbt_edited": False, "completion_state_written_by_audit": False,
        "native_pose_assignment_by_audit": False, "failure": failure,
        "level_dat_sha256": sha(world / "level.dat"), "evidence_log": str(args.log),
    }
    proof["pass"] = failure is None and unchanged and "Player" not in level and level.get("GameType") == 2
    args.proof.parent.mkdir(parents=True, exist_ok=True)
    args.proof.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"pass": proof["pass"], "proof": str(args.proof), "world": str(world), "failure": failure}, indent=2))
    if not proof["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
