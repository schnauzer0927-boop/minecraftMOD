Apex Predator 1.5.1 — Blockbench編集用ファイル

このZIPはモデル編集用です。Minecraftのmodsフォルダへ入れるMODは
別ファイルの apexpredator-1.20.1-1.5.1.jar です。
公式配布・詳しい検証記録:
https://github.com/schnauzer0927-boop/minecraftMOD/releases/tag/v1.5.1

1. ZIPを展開します。
2. Blockbench 5.xで以下を開きます。
   Apex本体: models/blockbench/apex.bbmodel
   公式GeckoLib Models & Animations / GeckoLib Animation Utilsプラグインが必要です。
   GeckoLib Animated Model / Entity形式で、28ボーン・333キューブ・37クリップです。
   Apex Fang: models/blockbench/apex_fang.bbmodel
   標準Java Block/Item形式です。56キューブ・18グループ・8表示設定です。
   両方ともPNGを埋め込んでおり、別PCでも外部パスなしで開けます。
3. Edit / Paint / Displayで編集し、Embed Texturesを有効にして保存します。
   本体のボーン名・階層と37アニメーションの名前・攻撃時刻を維持してください。
   Fangのenergy_channel/core/accent_left/accent_rightは発光宣言なので保持します。
4. 以下を展開フォルダのルートで実行します。Python 3標準ライブラリだけで動作し、
   pip installは不要です。まず確認用の出力先へ書き出してください。

   python3 scripts/blockbench/apex_body.py export --output build/blockbench/apex.geo.json --textures-dir build/blockbench/textures
   python3 scripts/blockbench/apex_fang.py export --output build/blockbench/apex_fang.json --textures-dir build/blockbench/textures

初期状態の編集元と同梱ランタイムリソースの一致確認:
   python3 scripts/blockbench/apex_body.py check
   python3 scripts/blockbench/apex_fang.py check
意味のある編集を加えた後、古いランタイムとの差分をcheckが報告するのは正常です。
確認用出力への照合や、MODリソースへの反映方法は models/blockbench/README.md と
docs/BLOCKBENCH-FANG.md に記載しています。

アニメーションはモデル/PNGの書き出しでは変更されません。
Blockbench標準のアニメーションJSON書き出しは時刻をグリッドに丸めるため、
元のランタイムアニメーションへ直接書き出さないでください。
将来、head/neck等の値のみ最小補正が必要な場合は、時刻を丸めない専用CLIで
別ファイルへ出力し、全時刻と差分を確認します。
   python3 scripts/blockbench/apex_body.py export-animations --output build/blockbench/apex.animation.json
このCLIは同梱の既存ランタイムアニメーションへの直接上書きを拒否します。

同梱の20件のPythonテスト:
   python3 -m unittest discover -s scripts/blockbench -p 'test_apex_body.py' -v
   python3 -m unittest discover -s tests/blockbench -p 'test_apex_fang.py' -v
scripts/art/generate_apex_model.pyは旧生成処理の履歴・上書き防止確認用です。
通常の編集では使いません。明示的な旧再生成にはPillow/NumPyが別途必要です。

このZIPは完全なForgeソースプロジェクトではありません。
編集内容をMOD jarへビルドするには、mainではなくv1.5.1タグのソース一式を取得します。
Gitがある場合:
   git clone --branch v1.5.1 https://github.com/schnauzer0927-boop/minecraftMOD.git
Gitがない場合は、次のSource ZIPをダウンロード・展開します:
https://github.com/schnauzer0927-boop/minecraftMOD/archive/refs/tags/v1.5.1.zip
取得した完全なソースの同じ相対パスへ編集済み.bbmodelをコピーして、
手順どおり書き出した後、Java 17環境で ./gradlew build を実行してください。
リポジトリ向けMarkdownのVALIDATION.md等のリンク先はソース一式またはGitHubで参照します。
