Apex Predator 1.15.2 — Blockbench編集用ファイル

このZIPはモデル編集用です。Minecraftのmodsフォルダへ入れるMODは
別ファイルの apexpredator-1.20.1-1.15.2.jar です。
対応環境は Minecraft 1.20.1 / Forge 47.4.10 / Java 17 です。
1.15.2はMODのバージョンです。Minecraftのバージョンではありません。
公式配布・詳しい検証記録:
https://github.com/schnauzer0927-boop/minecraftMOD/releases/tag/v1.15.2

1. ZIPを展開します。
2. Blockbench 5.xで以下を開きます。
   Apex本体: models/blockbench/apex.bbmodel
   公式GeckoLib Models & Animations / GeckoLib Animation Utilsプラグインが必要です。
   GeckoLib Animated Model / Entity形式で、28ボーン・498キューブ・37クリップです。
   HUNTER設計図に沿って再構築した正式モデルです。
   1024×1024 PNGの通常装甲・通常発光・回復発光の3枚を埋め込んでいます。
   Apex Fang: models/blockbench/apex_fang.bbmodel
   標準Java Block/Item形式です。56キューブ・18グループ・8表示設定です。
   Fangは従来デザインを維持し、128×128の専用PNGを埋め込んでいます。
   両方とも別PCで外部テクスチャパスなしで開けます。
3. Edit / Paint / Displayで編集し、Embed Texturesを有効にして保存します。
   本体の既存28ボーン名・階層と37アニメーションの名前・攻撃時刻を維持してください。
   Fangのenergy_channel/core/accent_left/accent_rightは発光宣言なので保持します。
4. 以下を展開フォルダのルートで実行します。Python 3標準ライブラリだけで動作し、
   pip installは不要です。まず確認用の出力先へ書き出してください。

   python3 scripts/blockbench/apex_body.py export --output build/blockbench/apex.geo.json --textures-dir build/blockbench/textures
   python3 scripts/blockbench/apex_fang.py export --output build/blockbench/apex_fang.json --textures-dir build/blockbench/textures

本体のPNGは textures-dir/entity/ 以下へ、Fangは textures-dir/item/ 以下へ出力されます。
本体の3枚は apex.png / apex_glow.png / apex_healing_glow.png です。
最後のPNGは既存Phase 3自己回復の発光マスクで、通常の発光マスクとUVを共有します。
上の通常exportで形状と3枚すべてを反映でき、アニメーションは変更されません。

初期状態の編集元と同梱ランタイムリソースの一致確認:
   python3 scripts/blockbench/apex_body.py check
   python3 scripts/blockbench/apex_fang.py check
意味のある編集を加えた後、古いランタイムとの差分をcheckが報告するのは正常です。
確認用出力への照合や、MODリソースへの反映方法は models/blockbench/README.md と
docs/BLOCKBENCH-FANG.md に記載しています。
設計と比較の記録は docs/REFERENCE-DESIGN-1.15.2.md と docs/visuals/ にあります。
リグと可動域の検証記録は docs/VALIDATION-1.15.2-rig.md にあります。

Blockbench標準のアニメーションJSON書き出しは時刻をグリッドに丸めるため、
元のランタイムアニメーションへ直接書き出さないでください。
将来、必要なrotation/positionだけ最小補正するときは、時刻を丸めない専用CLIで
別ファイルへ出力し、全時刻と差分を確認します。
   python3 scripts/blockbench/apex_body.py export-animations --output build/blockbench/apex.animation.json
このCLIは既存ランタイムアニメーションへの直接上書きを拒否します。

同梱の28件のPythonテスト:
   python3 -m unittest discover -s scripts/blockbench -p 'test_apex_body.py' -v
   python3 -m unittest discover -s scripts/blockbench -p 'test_apex_reference.py' -v
   python3 -m unittest discover -s tests/blockbench -p 'test_apex_fang.py' -v
形状の回帰テストはレンダー比較やMinecraft内のアニメーション確認の代わりにはなりません。
scripts/art/generate_apex_model.pyは旧生成処理の履歴・上書き防止確認用です。
通常の編集では使いません。明示的な旧再生成に限りPillow/NumPyが別途必要です。
通常のモデル/PNG書き出しと上のテストには追加Pythonパッケージは不要です。

このZIPは完全なForgeソースプロジェクトではありません。
編集内容をMOD jarへビルドするには、v1.15.2タグのソース一式を取得します。
Gitがある場合:
   git clone --branch v1.15.2 https://github.com/schnauzer0927-boop/minecraftMOD.git
Gitがない場合は、次のSource ZIPをダウンロード・展開します:
https://github.com/schnauzer0927-boop/minecraftMOD/archive/refs/tags/v1.15.2.zip
取得した完全なソースの同じ相対パスへ編集済み.bbmodelをコピーして、
手順どおり書き出した後、Java 17環境で ./gradlew build を実行してください。
リポジトリ向けMarkdownのVALIDATION.md等のリンク先はソース一式またはGitHubで参照します。
